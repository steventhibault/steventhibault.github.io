from __future__ import annotations

import collections
import copy
import ctypes
import difflib
import glob
import json
import os
import queue
import re
import shutil
import subprocess
import tempfile
import textwrap
import threading
import time
import traceback
import winreg
import webbrowser
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
import tkinter as tk
import tkinter.font as tkfont
from tkinter import filedialog, messagebox, simpledialog, ttk

from PIL import (
    Image,
    ImageDraw,
    ImageFont,
    ImageOps,
    ImageSequence,
    ImageStat,
    ImageTk,
)
from pypdf import PdfReader, PdfWriter


APP_TITLE = "PacketFlow"
APP_DIR = Path(__file__).resolve().parent

# User-writable data directory – falls back to APP_DIR when %APPDATA% is unavailable
# (e.g. portable/USB installs).  Rules stay next to the executable so they travel
# with the installation; only mutable user state moves to APPDATA.
_APPDATA_ROOT = os.environ.get("APPDATA", "")
APP_DATA_DIR: Path = (
    Path(_APPDATA_ROOT) / "PacketFlow"
    if _APPDATA_ROOT
    else APP_DIR
)
try:
    APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    APP_DATA_DIR = APP_DIR

RULES_PATH = APP_DIR / "rules.json"
CORRECTION_MEMORY_PATH = APP_DATA_DIR / "correction_memory.json"
SETTINGS_PATH = APP_DATA_DIR / "settings.json"
ERROR_LOG_PATH = APP_DATA_DIR / "PacketFlow Error Log.txt"
APP_ICON_PATH = APP_DIR / "packetflow.ico"
APP_ICON_PNG_PATH = APP_DIR / "packetflow-icon.png"
APP_USER_MODEL_ID = "PacketFlow.DocumentProcessor"

# Visual theme
COLOR_BG = "#f4f6f9"
COLOR_SURFACE = "#ffffff"
COLOR_ACCENT = "#1d4ed8"
COLOR_ACCENT_HOVER = "#1e40af"
COLOR_TEXT = "#111827"
COLOR_MUTED = "#6b7280"
COLOR_PREVIEW_BG = "#e5e7eb"
COLOR_SORTED = "#166534"
COLOR_UNSORTED = "#b45309"
COLOR_BLANK = "#9ca3af"
COLOR_READING = "#2563eb"

OCR_WORKERS = min(8, max(2, os.cpu_count() or 4))
TESSERACT_BASE_ARGS = ["--oem", "1", "-c", "preserve_interword_spaces=1"]
IMAGE_INPUT_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".jfif",
    ".bmp",
    ".tif",
    ".tiff",
    ".gif",
    ".webp",
}
TEXT_INPUT_EXTENSIONS = {".txt", ".log", ".csv", ".md"}
WORD_INPUT_EXTENSIONS = {".doc", ".docx", ".rtf", ".odt", ".html", ".htm"}
SPREADSHEET_INPUT_EXTENSIONS = {".xls", ".xlsx", ".xlsm", ".ods"}
PRESENTATION_INPUT_EXTENSIONS = {".ppt", ".pptx", ".odp"}
SUPPORTED_INPUT_EXTENSIONS = (
    {".pdf"}
    | IMAGE_INPUT_EXTENSIONS
    | TEXT_INPUT_EXTENSIONS
    | WORD_INPUT_EXTENSIONS
    | SPREADSHEET_INPUT_EXTENSIONS
    | PRESENTATION_INPUT_EXTENSIONS
)


class OfficeConverterUnavailable(RuntimeError):
    pass


@dataclass
class Assignment:
    page_index: int
    document: str
    rotation: int = 0
    sequence: float | None = None

    @property
    def page_number(self) -> int:
        return self.page_index + 1


def find_program(name: str, common_paths: list[str]) -> str | None:
    located = shutil.which(name)
    if located:
        return located
    for raw_path in common_paths:
        expanded = os.path.expandvars(raw_path)
        matches = sorted(glob.glob(expanded), reverse=True)
        if matches:
            return matches[0]
    return None


def safe_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "_", name.strip())
    name = name.rstrip(". ")
    # Strip any existing .pdf suffix (case-insensitive) before re-adding it so
    # inputs like "My Doc.PDF" or "My Doc.pdf.pdf" are normalised cleanly.
    name = re.sub(r"\.pdf$", "", name, flags=re.IGNORECASE)
    name = name.rstrip(". ")
    return (name + ".pdf") if name else "Unsorted.pdf"


def safe_folder_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "_", name.strip())
    name = name.rstrip(". ")
    return name or "Sorted Packet"


def configure_windows_app_identity():
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            APP_USER_MODEL_ID
        )
    except Exception:
        pass


def acquire_single_instance() -> bool:
    global INSTANCE_MUTEX_HANDLE
    kernel32 = ctypes.windll.kernel32
    kernel32.CreateMutexW.restype = ctypes.c_void_p
    kernel32.CreateMutexW.argtypes = [
        ctypes.c_void_p,
        ctypes.c_int,
        ctypes.c_wchar_p,
    ]
    handle = kernel32.CreateMutexW(None, False, INSTANCE_MUTEX_NAME)
    if not handle:
        return True
    INSTANCE_MUTEX_HANDLE = handle
    return kernel32.GetLastError() != 183


def report_fatal_error(exc: BaseException):
    details = (
        f"{APP_TITLE} could not start.\n\n"
        f"{''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))}"
    )
    try:
        ERROR_LOG_PATH.write_text(details, encoding="utf-8")
    except Exception:
        pass
    try:
        messagebox.showerror(
            APP_TITLE,
            "PacketFlow could not start.\n\n"
            f"{exc}\n\n"
            f"Details were saved to:\n{ERROR_LOG_PATH}",
        )
    except Exception:
        pass


class PacketAnalyzer:
    def __init__(self, rules: dict):
        self.rules = rules
        self.pdftoppm = find_program(
            "pdftoppm",
            [
                r"C:\Program Files\poppler-*\Library\bin\pdftoppm.exe",
                r"C:\Program Files\poppler\Library\bin\pdftoppm.exe",
                r"C:\Program Files (x86)\poppler-*\Library\bin\pdftoppm.exe",
            ],
        )
        self.tesseract = find_program(
            "tesseract",
            [
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            ],
        )

    def check_dependencies(self) -> None:
        missing = []
        if not self.pdftoppm:
            missing.append("Poppler (pdftoppm)")
        if not self.tesseract:
            missing.append("Tesseract OCR")
        if missing:
            raise RuntimeError(
                "Missing required software: "
                + ", ".join(missing)
                + ". Close the app and run 'Start PacketFlow.cmd' "
                + "to receive installation help."
            )

    def analyze(
        self,
        pdf_path: Path,
        work_dir: Path,
        progress_callback,
    ) -> tuple[
        list[Path],
        list[str],
        list[Assignment],
        list[int],
        set[int],
        list[int],
    ]:
        self.check_dependencies()
        reader = PdfReader(str(pdf_path))
        page_count = len(reader.pages)
        image_prefix = work_dir / "page"

        progress_callback(2, "Rendering packet pages...")
        subprocess.run(
            [
                self.pdftoppm,
                "-jpeg",
                "-r",
                "110",
                "-jpegopt",
                "quality=78",
                str(pdf_path),
                str(image_prefix),
            ],
            check=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )

        images = sorted(work_dir.glob("page-*.jpg"))
        if len(images) != page_count:
            raise RuntimeError(
                f"Rendered {len(images)} page images, but the PDF has {page_count} pages."
            )

        ocr_texts: list[str] = [""] * page_count
        rotations: list[int] = [0] * page_count
        blank_pages: set[int] = set()
        fingerprints: list[int] = [0] * page_count
        worker_count = min(OCR_WORKERS, page_count)
        completed = 0
        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            future_pages = {
                executor.submit(
                    self.analyze_page,
                    index,
                    image_path,
                    work_dir,
                    pdf_path,
                ): index
                for index, image_path in enumerate(images)
            }
            for future in as_completed(future_pages):
                index, text, rotation, is_blank, fingerprint = future.result()
                ocr_texts[index] = text
                rotations[index] = rotation
                fingerprints[index] = fingerprint
                if is_blank:
                    blank_pages.add(index)
                completed += 1
                percent = 8 + int((completed / max(page_count, 1)) * 82)
                progress_callback(
                    percent,
                    f"Reading pages: {completed} of {page_count} complete...",
                    index,
                )

        progress_callback(94, "Building document groups...")
        assignments = self.classify_pages(ocr_texts, rotations, blank_pages)
        progress_callback(100, "Analysis complete")
        return (
            images,
            ocr_texts,
            assignments,
            rotations,
            blank_pages,
            fingerprints,
        )

    def analyze_page(
        self,
        index: int,
        image_path: Path,
        work_dir: Path,
        pdf_path: Path,
    ) -> tuple[int, str, int, bool, int]:
        with Image.open(image_path) as source_image:
            image = source_image.convert("RGB")
        grayscale = image.convert("L")
        statistics = ImageStat.Stat(grayscale)
        histogram = grayscale.histogram()
        ink_ratio = sum(histogram[:235]) / max(image.width * image.height, 1)
        fingerprint = self.page_fingerprint(grayscale)

        if statistics.stddev[0] < 3 and ink_ratio < 0.002:
            return index, "", 0, True, fingerprint

        with tempfile.NamedTemporaryFile(
            suffix=".jpg", dir=work_dir, delete=False
        ) as rotated_handle:
            rotated_path = Path(rotated_handle.name)
            image.rotate(180).save(rotated_path, quality=85)

        with ThreadPoolExecutor(max_workers=2) as orientation_pool:
            original_future = orientation_pool.submit(self.ocr_image, image_path)
            rotated_future = orientation_pool.submit(self.ocr_image, rotated_path)
            original_text = original_future.result()
            rotated_text = rotated_future.result()

        original_score = self.orientation_score(original_text)
        rotated_score = self.orientation_score(rotated_text)
        if rotated_score > original_score * 1.12 + 15:
            image.rotate(180).save(image_path, quality=85)
            selected_text = rotated_text
            rotation = 180
        else:
            selected_text = original_text
            rotation = 0
        rotated_path.unlink(missing_ok=True)

        if len(re.findall(r"[A-Za-z]{3,}", selected_text)) < 60:
            selected_text += "\n__SPARSE_SCAN__\n"
            detail_text = self.high_resolution_ocr(
                pdf_path, index, work_dir, rotation
            )
            if detail_text:
                selected_text += "\n" + detail_text

        return index, selected_text, rotation, False, fingerprint

    @staticmethod
    def page_fingerprint(grayscale: Image.Image) -> int:
        """Return a tiny difference hash using the image already in memory."""
        sample = grayscale.resize((17, 16), Image.Resampling.BILINEAR)
        pixels = list(sample.getdata())
        fingerprint = 0
        for row in range(16):
            offset = row * 17
            for column in range(16):
                fingerprint <<= 1
                if pixels[offset + column] > pixels[offset + column + 1]:
                    fingerprint |= 1
        return fingerprint

    def high_resolution_ocr(
        self,
        pdf_path: Path,
        page_index: int,
        work_dir: Path,
        rotation: int,
    ) -> str:
        prefix = work_dir / f"detail-{page_index + 1:03}"
        detail_path = prefix.with_suffix(".jpg")
        subprocess.run(
            [
                self.pdftoppm,
                "-f",
                str(page_index + 1),
                "-l",
                str(page_index + 1),
                "-singlefile",
                "-jpeg",
                "-r",
                "300",
                str(pdf_path),
                str(prefix),
            ],
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if not detail_path.exists():
            return ""
        try:
            if rotation:
                with Image.open(detail_path) as source_image:
                    source_image.rotate(rotation).save(detail_path, quality=88)
            result = subprocess.run(
                [
                    self.tesseract,
                    str(detail_path),
                    "stdout",
                    *TESSERACT_BASE_ARGS,
                    "--psm",
                    "6",
                    "-c",
                    "user_defined_dpi=300",
                ],
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
            )
            return result.stdout.decode("utf-8", errors="ignore")
        finally:
            detail_path.unlink(missing_ok=True)

    def ocr_image(self, image_path: Path) -> str:
        result = subprocess.run(
            [
                self.tesseract,
                str(image_path),
                "stdout",
                *TESSERACT_BASE_ARGS,
                "--psm",
                "11",
                "-c",
                "user_defined_dpi=110",
            ],
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
        return result.stdout.decode("utf-8", errors="ignore")

    @staticmethod
    def orientation_score(text: str) -> int:
        normalized = re.sub(r"\s+", " ", text.lower())
        words = re.findall(r"[a-z]{3,}", normalized)
        keywords = (
            "employee",
            "employer",
            "signature",
            "application",
            "authorization",
            "background",
            "withholding",
            "orientation",
            "employment",
            "instructions",
            "maine",
            "payroll",
            "coverage",
            "waiver",
            "deposit",
            "handbook",
        )
        return len(words) + (20 * sum(word in normalized for word in keywords))

    def classify_pages(
        self,
        texts: list[str],
        rotations: list[int] | None = None,
        blank_pages: set[int] | None = None,
    ) -> list[Assignment]:
        normalized = [re.sub(r"\s+", " ", text.lower()) for text in texts]
        rotations = rotations or [0] * len(texts)
        blank_pages = blank_pages or set()
        assignments: list[Assignment] = []
        last_i9_page: int | None = None

        def add(
            page_index: int,
            document: str,
            sequence: float | None = None,
        ):
            if sequence is None:
                sequence = self.document_sequence(document, normalized[page_index])
            candidate = Assignment(
                page_index,
                document,
                rotations[page_index],
                sequence,
            )
            if candidate not in assignments:
                assignments.append(candidate)

        for index, text in enumerate(normalized):
            if index in blank_pages:
                continue

            custom_document = self.match_custom_rule(text)
            if custom_document:
                add(index, custom_document)
                if custom_document == "Banking.pdf":
                    add(index, "Viventium Direct Deposit.pdf")
                continue

            if (
                "non-disclosure agreement" in text
                or "nondisclosure agreement" in text
            ):
                add(index, "Non-Disclosure Agreement.pdf")
                continue

            has_i9 = "form i-9" in text or (
                "employment eligibility verification" in text
                and (
                    "department of homeland security" in text
                    or "citizenship and immigration services" in text
                    or "anti-discrimination notice" in text
                )
            ) or (
                "lists of acceptable documents" in text
                and "documents that establish identity" in text
                and "employment authorization" in text
            )
            has_orientation = (
                "orientation agenda" in text
                or (
                    "congratulations" in text
                    and "welcome to our team" in text
                )
            )
            has_social_security_card = (
                (
                    ("security" in text or "ocial secur" in text)
                    and "established" in text
                    and "signature" in text
                )
                or "social security administration" in text
                or (
                    "security administration" in text
                    and ("social" in text or "soc security" in text)
                )
            )
            social_security_is_restricted = any(
                restriction in text
                for restriction in (
                    "not valid for employment",
                    "valid for work only with ins authorization",
                    "valid for work only with dhs authorization",
                )
            )
            has_social_security_card = (
                has_social_security_card and not social_security_is_restricted
            )
            license_detail_markers = sum(
                marker in text
                for marker in (
                    "dl. no",
                    "class",
                    "expires",
                    "issued",
                    "endorsements",
                    "restrictions",
                )
            )
            has_driver_license = (
                any(
                    marker in text
                    for marker in (
                        "driver's license",
                        "driver'slicense",
                        "driver'siicense",
                        "drivers license",
                    )
                )
                and license_detail_markers >= 1
            )
            passport_detail_markers = sum(
                marker in text
                for marker in (
                    "nationality",
                    "passport no",
                    "passport number",
                    "date of expiry",
                    "date of expiration",
                    "expiration date",
                    "issuing country",
                    "place of birth",
                )
            )
            has_passport = (
                (
                    "passport card" in text
                    and passport_detail_markers >= 1
                )
                or (
                    "passport" in text
                    and passport_detail_markers >= 2
                    and (
                        "united states of america" in text
                        or "issuing country" in text
                        or "nationality" in text
                    )
                )
            )
            has_permanent_resident_card = (
                "permanent resident card" in text
                or "alien registration receipt card" in text
                or (
                    re.search(r"\b(?:i|1)[ -]?551\b", text) is not None
                    and any(
                        marker in text
                        for marker in (
                            "resident since",
                            "card expires",
                            "alien registration",
                            "uscis#",
                            "uscis #",
                        )
                    )
                )
            )
            has_temporary_i551 = (
                "temporary i-551" in text
                or "temporary 1-551" in text
                or "upon endorsement serves as temporary i-551" in text
                or (
                    "machine readable immigrant visa" in text
                    and "passport" in text
                )
            )
            has_employment_authorization_card = (
                "employment authorization card" in text
                or (
                    "employment authorization document" in text
                    and re.search(r"\b(?:i|1)[ -]?766\b", text) is not None
                )
                or (
                    re.search(r"\b(?:i|1)[ -]?766\b", text) is not None
                    and "uscis" in text
                    and ("category" in text or "card expires" in text)
                )
            )
            has_i94 = (
                re.search(r"\b(?:i|1)[ -]?94a?\b", text) is not None
                or "arrival/departure record" in text
                or "arrival-departure record" in text
            ) and any(
                marker in text
                for marker in (
                    "class of admission",
                    "admit until",
                    "departure number",
                    "admission number",
                    "refugee",
                    "asylee",
                )
            )
            has_foreign_passport_work_authorization = (
                "passport" in text
                and (
                    has_temporary_i551
                    or (
                        has_i94
                        and any(
                            marker in text
                            for marker in (
                                "employment authorized",
                                "authorized to work",
                                "nonimmigrant status",
                                "h-1b",
                                "h1b",
                                "refugee",
                                "asylee",
                                "federated states of micronesia",
                                "marshall islands",
                                "compact of free association",
                            )
                        )
                    )
                )
            )
            identity_detail_markers = sum(
                marker in text
                for marker in (
                    "date of birth",
                    "dob",
                    "sex",
                    "height",
                    "eye color",
                    "eyes",
                    "address",
                    "photograph",
                    "photo",
                )
            )
            has_government_id = (
                any(
                    marker in text
                    for marker in (
                        "government identification card",
                        "government id card",
                        "personal identity verification",
                        "piv card",
                        "common access card",
                        "cac card",
                        "state identification card",
                        "state id card",
                    )
                )
                and identity_detail_markers >= 1
            )
            has_school_id = (
                any(
                    marker in text
                    for marker in (
                        "school identification card",
                        "school id card",
                        "student identification card",
                        "student id card",
                    )
                )
                and ("student" in text or "school" in text)
            )
            has_voter_registration = (
                "voter registration card" in text
                or "voter's registration card" in text
                or "voters registration card" in text
            )
            has_military_id = any(
                marker in text
                for marker in (
                    "uniformed services identification",
                    "united states uniformed services",
                    "military identification card",
                    "military id card",
                    "military dependent",
                    "dependent identification card",
                    "department of defense identification",
                    "dod identification card",
                    "common access card",
                    "draft record",
                )
            )
            has_merchant_mariner_card = (
                "merchant mariner card" in text
                or "merchant mariner credential" in text
                or (
                    "united states coast guard" in text
                    and "merchant mariner" in text
                )
            )
            has_tribal_document = any(
                marker in text
                for marker in (
                    "native american tribal document",
                    "tribal identification card",
                    "tribal enrollment card",
                    "certificate of degree of indian blood",
                )
            )
            has_canadian_driver_license = (
                ("canada" in text or "canadian" in text)
                and any(
                    marker in text
                    for marker in (
                        "driver's licence",
                        "driver licence",
                        "permis de conduire",
                    )
                )
                and license_detail_markers >= 1
            )
            has_us_citizen_id = (
                re.search(r"\b(?:i|1)[ -]?197\b", text) is not None
                and "citizen" in text
                and "identification" in text
            )
            has_resident_citizen_id = (
                re.search(r"\b(?:i|1)[ -]?179\b", text) is not None
                and "resident citizen" in text
                and "identification" in text
            )
            has_dhs_employment_document = any(
                marker in text
                for marker in (
                    "refugee travel document",
                    "reentry permit",
                    "re-entry permit",
                    "certificate of citizenship",
                    "certificate of naturalization",
                    "replacement certificate of citizenship",
                    "replacement certificate of naturalization",
                )
            ) or any(
                re.search(pattern, text) is not None
                for pattern in (
                    r"\b(?:i|1)[ -]?571\b",
                    r"\b(?:i|1)[ -]?327\b",
                    r"\bn[ -]?560\b",
                    r"\bn[ -]?561\b",
                    r"\bn[ -]?550\b",
                    r"\bn[ -]?570\b",
                )
            )
            has_birth_certificate = (
                "certificate of live birth" in text
                or "certified abstract of a certificate of live birth" in text
                or "consular report of birth abroad" in text
                or "certification of report of birth" in text
                or "certification of birth abroad" in text
                or any(
                    form_number in text
                    for form_number in ("ds-1350", "fs-545", "fs-240")
                )
                or (
                    "vital records" in text
                    and "birth place" in text
                    and "date of birth" in text
                )
            )
            has_marriage_certificate = (
                "certificate of marriage" in text
                or (
                    "vital records" in text
                    and "marriage" in text
                    and ("party a" in text or "party b" in text)
                )
            )
            has_interview_statement = (
                "interview statement" in text
                or (
                    "interviewed by" in text
                    and "what are your strengths" in text
                    and (
                        "what are your weaknesses" in text
                        or "why do you want this job" in text
                        or "why do youwantthisjob" in text
                    )
                )
            )
            is_i9_adjacent = (
                last_i9_page is not None
                and 0 < index - last_i9_page <= 3
            )
            has_minor_identity_record = (
                is_i9_adjacent
                and any(
                    marker in text
                    for marker in (
                        "school record",
                        "school report card",
                        "student report card",
                        "clinic record",
                        "doctor record",
                        "hospital record",
                        "day care record",
                        "day-care record",
                        "nursery school record",
                    )
                )
            )
            has_acceptable_replacement_receipt = (
                is_i9_adjacent
                and "receipt" in text
                and any(
                    marker in text
                    for marker in (
                        "replacement",
                        "lost",
                        "stolen",
                        "damaged",
                        "form i-797c",
                        "notice of action",
                        "adit stamp",
                        "refugee stamp",
                    )
                )
            )

            if has_i9 and has_orientation:
                # Mixed documents on one scan require rescanning. The app does
                # not divide a source page.
                continue
            if has_i9:
                add(index, "Form I-9 Employment Eligibility Verification.pdf")
                last_i9_page = index
                continue
            if has_orientation:
                add(index, "Orientation Agenda.pdf")
                continue
            if has_birth_certificate or has_marriage_certificate:
                add(index, "Birth and Marriage Certificates.pdf")
                continue
            if has_interview_statement:
                add(index, "Interview Statement.pdf")
                continue
            if any(
                (
                    has_social_security_card,
                    has_driver_license,
                    has_passport,
                    has_permanent_resident_card,
                    has_temporary_i551,
                    has_employment_authorization_card,
                    has_foreign_passport_work_authorization,
                    has_government_id,
                    has_school_id,
                    has_voter_registration,
                    has_military_id,
                    has_merchant_mariner_card,
                    has_tribal_document,
                    has_canadian_driver_license,
                    has_us_citizen_id,
                    has_resident_citizen_id,
                    has_dhs_employment_document,
                    has_minor_identity_record,
                    has_acceptable_replacement_receipt,
                )
            ):
                add(index, "Form I-9 Employment Eligibility Verification.pdf")
                continue
            if (
                is_i9_adjacent
                and "__sparse_scan__" in text
            ):
                # ID cards are often small, photographed, or faint enough that
                # OCR returns mostly noise. Immediately following I-9 pages are
                # treated as supporting identification unless a recognizable
                # certificate or other document matched above.
                add(index, "Form I-9 Employment Eligibility Verification.pdf")
                continue

            if "recording of time worked" in text:
                add(index, "Time Recording.pdf")
                continue

            job_application_markers = (
                "job application",
                "employee availability sheet",
                "non-exempt compensation agreement",
                "companion checklist",
                "comprehensive hiring form",
                "handbook acknowledgement form",
                "personal support specialist",
                "reasons for immediate termination",
                "requests that all employees follow the following rules",
                "nothing in this employee handbook shall form a contract",
                "employee handbook shall form a contract",
                "by signing this agreement",
                "acknowledges receipt of, and agreement to",
                "compensation agreement",
                "medical examination and drug test",
                "work reference",
                "personal references",
                "at-will employment",
                "must have a reliable enclosed vehicle",
                "the job description provides a framework for the job",
                "duties and responsibilities listed above for my position",
            )
            is_resume_page = (
                (
                    "experience" in text
                    and re.search(
                        r"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}",
                        text,
                    )
                    is not None
                )
                or ("page 2 of 2" in text and "education" in text)
            )
            if is_resume_page or any(
                marker in text for marker in job_application_markers
            ):
                add(index, "Job Application.pdf")
                continue

            if "cherkr" in text or (
                "consumer report" in text and "candidate disclosure" in text
            ):
                add(index, "CHERKR Authorization.pdf")
                continue

            if (
                "maine background check center" in text
                or "background check report correcting inaccurate information"
                in text
                or (
                    "authorization and release by the applicant" in text
                    and "background check center" in text
                )
            ):
                add(index, "MBC Authorization.pdf")
                continue

            if "application fee paid for maine criminal background check" in text:
                add(index, "MBC Payment.pdf")
                continue

            if "child abuse background check confirmation" in text:
                add(
                    index,
                    "Confirmation - Child Abuse Registry Background Check Request.pdf",
                )
                continue

            if (
                "child abuse and neglect records information" in text
                or "child protective services case" in text
                or (
                    "child and family services" in text
                    and "authorization release" in text
                )
            ):
                add(index, "Child Protective Services Authorization.pdf")
                continue

            if "w-4me" in text or (
                "maine" in text and "withholding allowance certificate" in text
            ):
                add(index, "Payroll.pdf")
                continue

            if "form 8850" in text or "work opportunity credit" in text:
                add(index, "Payroll.pdf")
                continue

            if (
                "form w-4" in text
                or "employee’s withholding certificate" in text
                or "employee's withholding certificate" in text
                or "multiple jobs worksheet" in text
            ) and (
                "internal revenue" in text
                or "treasury" in text
                or "multiple jobs worksheet" in text
                or "general instructions" in text
            ):
                add(index, "Federal W-4 Withholding.pdf")
                continue

            is_legacy_payroll = (
                "paypro payroll" in text
                or "skylight payoptions" in text
                or (
                    "card mailing address" in text
                    and "net pay" in text
                    and "employee signature" in text
                )
            )
            if is_legacy_payroll:
                continue

            is_direct_deposit_form = (
                "viventium payroll" in text
                or "employee direct deposit authorization" in text
                or "direct deposit authorization form" in text
                or "direct deposit enrollment form" in text
                or (
                    "direct deposit" in text
                    and (
                        "authorization agreement" in text
                        or "payroll compensation" in text
                        or "sign this direct deposit form" in text
                    )
                )
            )
            if is_direct_deposit_form:
                add(index, "Viventium Direct Deposit.pdf")
                continue

            if self.looks_like_banking_page(
                text, index, normalized, blank_pages
            ):
                add(index, "Banking.pdf")
                add(index, "Viventium Direct Deposit.pdf")
                continue

            if "auto enrol" in text and "opt out" in text:
                add(index, "Auto Enrollment Opt Out.pdf")
                continue

            if (
                "waiver form" in text
                or "decline all coverage" in text
                or ("employee" in text and "choice" in text and "waiver" in text)
            ):
                add(index, "Employee Choice Acknowledgement Waiver.pdf")
                continue

        return sorted(assignments, key=lambda item: (item.document.lower(), item.page_index))

    def match_custom_rule(self, text: str) -> str | None:
        text = re.sub(r"\s+", " ", text.lower())
        for rule in self.rules.get("custom_rules", []):
            document = str(rule.get("document", "")).strip()
            keywords = [
                re.sub(r"\s+", " ", str(keyword).strip().lower())
                for keyword in rule.get("keywords", [])
                if str(keyword).strip()
            ]
            if not document or not keywords:
                continue
            matches = [keyword in text for keyword in keywords]
            mode = str(rule.get("match_mode", "all")).lower()
            if (mode == "any" and any(matches)) or (
                mode != "any" and all(matches)
            ):
                return document
        return None

    @staticmethod
    def document_sequence(document: str, text: str) -> float | None:
        if document == "Form I-9 Employment Eligibility Verification.pdf":
            if "form i-9" in text or "department of homeland security" in text:
                return 1
            return 2

        if document == "Job Application.pdf":
            markers = (
                ("job application", 1),
                ("work reference", 2),
                ("medical examination and drug test", 3),
                ("page 1 of 2", 13),
                ("page 2 of 2", 14),
                ("employee availability sheet", 4),
                ("nothing in this employee handbook shall form a contract", 5),
                ("employee handbook shall form a contract", 5),
                ("by signing this agreement", 5),
                ("acknowledges receipt of, and agreement to", 5),
                ("comprehensive hiring form", 6),
                ("companion checklist", 7),
                ("non-exempt compensation agreement", 8),
                ("compensation agreement", 8),
                ("requests that all employees follow the following rules", 9),
                ("reasons for immediate termination", 9.5),
                ("must have a reliable enclosed vehicle", 11),
                ("at least 18 years of age", 11),
                ("personal support specialist", 10),
                ("handbook acknowledgement form", 12),
                ("the job description provides a framework for the job", 12.5),
                ("duties and responsibilities listed above for my position", 12.5),
            )
            for marker, sequence in markers:
                if marker in text:
                    return sequence
            if (
                "experience" in text
                and re.search(
                    r"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}",
                    text,
                )
                is not None
            ):
                return 13

        if document == "MBC Authorization.pdf":
            if "notification and authorization and release" in text:
                return 1
            if "authorization and release" in text and "applicant" in text:
                return 2
            if "signature of applicant" in text and "title 18" in text:
                return 2
            if "voluntary consent for disclosure" in text:
                return 3
            return 4

        if document == "Federal W-4 Withholding.pdf":
            heading = text[:500]
            if "multiple jobs worksheet" in heading:
                return 3
            if "general instructions" in heading or "page 2" in heading:
                return 2
            return 1

        if document == "Viventium Direct Deposit.pdf":
            if "direct deposit" in text or "viventium" in text:
                return 1
            return 2

        return None

    @staticmethod
    def looks_like_banking_page(
        text: str,
        index: int,
        all_texts: list[str],
        blank_pages: set[int] | None = None,
    ) -> bool:
        blank_pages = blank_pages or set()
        strong_banking_words = (
            "routing number",
            "voided check",
            "checking account",
            "savings account",
            "this check",
            "pay to the",
            "new balance",
        )
        if any(word in text for word in strong_banking_words):
            return True
        if (
            len(text.strip()) < 350 or "__sparse_scan__" in text
        ) and index > 0 and index not in blank_pages:
            previous = all_texts[index - 1]
            return (
                "direct deposit" in previous
                or "attach a voided check" in previous
                or "viventium" in previous
            )
        return False


try:
    import customtkinter as ctk
except ImportError as exc:
    raise SystemExit("Missing required package: customtkinter. Run Start PacketFlow.cmd so it can install dependencies.") from exc

try:
    import windnd
except ImportError:
    windnd = None

try:
    import pystray
except ImportError:
    pystray = None


DEFAULT_SETTINGS = {
    "watch_enabled": False,
    "watch_folder": "",
    "start_with_windows": False,
    "start_minimized_to_tray": False,
    "show_notifications": True,
    "open_window_when_scanner_file_detected": True,
    "automatically_export_scanner_packets": False,
    "apply_remembered_corrections": True,
    "apply_remembered_pdf_order": True,
    "remember_last_export_location": True,
    "last_export_location": "",
    "show_duplicate_warnings": True,
    "show_low_confidence_warnings": True,
    "organization_name": "",
    "header_title": "Onboarding Document Processor",
    "branding_logo": "packetflow-logo.png",
}

STARTUP_VALUE_NAME = "PacketFlow"
OLD_STARTUP_VALUE_NAMES = ()
STARTUP_REGISTRY_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"
INSTANCE_MUTEX_NAME = "Local\\PacketFlowDocumentProcessor"
INSTANCE_MUTEX_HANDLE = None

# Product palette
NAVY = "#071B3A"
HEADER_BG = "#C2F1F9"
CARD_NAVY = "#112C6B"
PRODUCT_BLUE = "#1E88E5"
BRIGHT_BLUE = "#4DA3FF"
SUCCESS_GREEN = "#63C393"
APP_BG = "#F3F5F7"
CARD_BG = "#FFFFFF"
BORDER = "#DDE5EE"
TEXT = "#0F172A"
MUTED = "#64748B"
WARNING = "#8A2020"
DANGER = "#DC2626"
BLANK = "#94A3B8"


class PacketSorterApp:
    def __init__(self, root: ctk.CTk):
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")
        self.root = root
        self.root.title(APP_TITLE)
        self.window_icon = None
        self.apply_window_icon()
        self.root.after(250, self.apply_window_icon)
        self.root.after(1000, self.apply_window_icon)
        self.root.geometry("1440x900")
        self.root.minsize(1180, 760)
        self.root.configure(fg_color=APP_BG)
        # Open maximized/full-screen-window style on Windows so the PDF preview
        # has as much room as possible without hiding the taskbar.
        try:
            self.root.state("zoomed")
        except Exception:
            try:
                self.root.attributes("-zoomed", True)
            except Exception:
                pass

        self.rules = self.load_rules()
        self.analyzer = PacketAnalyzer(self.rules)
        self.pdf_path: Path | None = None
        self.reader: PdfReader | None = None
        self.packet_source_paths: list[Path] = []
        self.packet_display_name: str | None = None
        self.packet_base_stem: str | None = None
        self.manual_packet_dir: Path | None = None
        self.retired_manual_dirs: list[Path] = []
        self.pending_append_state: dict | None = None
        self.work_dir: Path | None = None
        self.additional_work_dirs: list[Path] = []
        self.page_images: list[Path] = []
        self.ocr_texts: list[str] = []
        self.page_rotations: list[int] = []
        self.page_manual_rotations: list[int] = []
        self.blank_pages: set[int] = set()
        self.page_fingerprints: list[int] = []
        self.assignments: list[Assignment] = []
        self.document_order: list[str] = []
        self.duplicate_pairs: list[tuple[int, int]] = []
        self.low_confidence_pages: set[int] = set()
        self.memory_applied_pages: set[int] = set()
        self.preferred_document_order: list[str] = []
        self.correction_memory = self.load_correction_memory()
        self.settings = self.load_settings()
        self.export_packet_name: str | None = None
        saved_export_location = self.settings.get("last_export_location", "")
        self.export_parent_folder: Path | None = (
            Path(saved_export_location)
            if saved_export_location and Path(saved_export_location).is_dir()
            else None
        )
        self.packet_exported = True
        self.current_packet_from_watch = False
        self.exiting = False
        self.tray_icon = None
        self.undo_stack: collections.deque[dict] = collections.deque(maxlen=20)
        self.custom_document_types: set[str] = set()
        self.watch_folder: Path | None = None
        configured_watch_folder = self.settings.get("watch_folder")
        if configured_watch_folder:
            self.watch_folder = Path(configured_watch_folder)
        self.watch_enabled = bool(
            self.settings.get("watch_enabled")
            and self.watch_folder
            and self.watch_folder.is_dir()
        )
        self.watch_known_files: set[Path] = set()
        self.watch_candidates: dict[Path, tuple[int, float, int]] = {}
        self.watch_queue: list[Path] = []
        self.preview_photo = None
        self.preview_image_refs: list[ImageTk.PhotoImage] = []
        self.preview_page_offsets: list[int] = []
        # LRU cache for rendered page thumbnails.  48 entries covers a
        # 24-page packet viewed at two zoom levels before eviction begins.
        # Using an OrderedDict lets us do O(1) move-to-end on cache hit and
        # O(1) popitem(last=False) eviction, with no extra dependencies.
        self.preview_cache: collections.OrderedDict[
            tuple[int, int, int], ImageTk.PhotoImage
        ] = collections.OrderedDict()
        self._preview_cache_max = 48
        self.preview_cache_size = (0, 0)
        self.analyzing = False
        self.worker_queue: queue.Queue = queue.Queue()
        self.selected_pages: set[int] = set()
        self.selected_document: str | None = None
        self.preview_page_position = 0
        self.preview_nav_var = tk.StringVar(value="")
        self.page_status_widgets: dict[int, dict[str, object]] = {}
        self.output_row_widgets: dict[str, object] = {}
        self.dragging_document: str | None = None

        self.status_var = tk.StringVar(value="Open a PDF packet to begin.")
        self.summary_var = tk.StringVar(value="No packet loaded")
        self.packet_filename_var = tk.StringVar(value="Original PDF: No packet selected")
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_label_var = tk.StringVar(value="0%")
        self.packet_stats_var = tk.StringVar(value="Open a packet to begin")
        self.document_var = tk.StringVar()
        self.action_title_var = tk.StringVar(
            value=f"Assign Selected Pages · {self.active_profile_name}"
        )

        self.build_ui()
        self.bind_shortcuts()
        self.bind_file_drop()
        self.initialize_tray()
        self.initialize_watch_folder()
        self.update_startup_registration()
        self.root.after(80, self.poll_worker_queue)
        self.root.after(1500, self.poll_watch_folder)
        if self.setting_enabled("start_minimized_to_tray") and self.watch_enabled:
            self.root.after(250, self.minimize_to_tray)

    def apply_window_icon(self):
        if APP_ICON_PATH.exists():
            try:
                self.root.wm_iconbitmap(str(APP_ICON_PATH))
                self.root.wm_iconbitmap(default=str(APP_ICON_PATH))
            except Exception:
                pass
        if APP_ICON_PNG_PATH.exists():
            try:
                self.window_icon = tk.PhotoImage(file=str(APP_ICON_PNG_PATH))
                self.root.iconphoto(True, self.window_icon)
            except Exception:
                self.window_icon = None

    def load_rules(self) -> dict:
        with RULES_PATH.open("r", encoding="utf-8") as handle:
            stored = json.load(handle)
        if isinstance(stored.get("profiles"), dict) and stored["profiles"]:
            self.rule_profiles = {
                str(name): self.normalize_rule_profile(profile)
                for name, profile in stored["profiles"].items()
                if str(name).strip() and isinstance(profile, dict)
            }
            requested = str(stored.get("active_profile", "")).strip()
            self.active_profile_name = (
                requested
                if requested in self.rule_profiles
                else next(iter(self.rule_profiles))
            )
        else:
            self.active_profile_name = "Onboarding"
            self.rule_profiles = {
                self.active_profile_name: self.normalize_rule_profile(stored)
            }
        return self.rule_profiles[self.active_profile_name]

    @staticmethod
    def normalize_rule_profile(profile: dict) -> dict:
        return {
            "document_types": list(profile.get("document_types", [])),
            "expected_document_types": list(
                profile.get("expected_document_types", [])
            ),
            "custom_rules": list(profile.get("custom_rules", [])),
        }

    def save_rules(self) -> bool:
        try:
            self.rule_profiles[self.active_profile_name] = self.rules
            RULES_PATH.write_text(
                json.dumps(
                    {
                        "schema_version": 2,
                        "active_profile": self.active_profile_name,
                        "profiles": self.rule_profiles,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
            self.analyzer.rules = self.rules
            self.refresh_document_choices()
            return True
        except Exception as exc:
            messagebox.showerror(
                APP_TITLE,
                "The document rules could not be saved.\n\n" + str(exc),
            )
            return False

    def switch_rule_profile(self, profile_name: str) -> bool:
        if profile_name not in self.rule_profiles:
            return False
        if hasattr(self, "correction_memory_profiles"):
            self.correction_memory_profiles[self.active_profile_name] = {
                "corrections": self.correction_memory,
                "output_order": self.preferred_document_order,
            }
        self.rule_profiles[self.active_profile_name] = self.rules
        self.active_profile_name = profile_name
        self.rules = self.rule_profiles[profile_name]
        self.analyzer.rules = self.rules
        if hasattr(self, "correction_memory_profiles"):
            memory = self.correction_memory_profiles.get(profile_name, {})
            self.correction_memory = list(memory.get("corrections", []))
            self.preferred_document_order = [
                safe_filename(str(document))
                for document in memory.get("output_order", [])
                if str(document).strip()
            ]
        self.custom_document_types.clear()
        if hasattr(self, "action_title_var"):
            self.action_title_var.set(
                f"Assign Selected Pages · {self.active_profile_name}"
            )
        self.refresh_document_choices()
        if self.pdf_path:
            self.status_var.set(
                f"Profile changed to {profile_name}. Reanalyzing the loaded packet..."
            )
            self.root.after(100, self.start_analysis)
        else:
            self.status_var.set(f"Active profile: {profile_name}")
        rules_saved = self.save_rules()
        memory_saved = (
            self.save_correction_memory()
            if hasattr(self, "correction_memory_profiles")
            else True
        )
        return rules_saved and memory_saved

    def load_settings(self) -> dict:
        settings = dict(DEFAULT_SETTINGS)
        if not SETTINGS_PATH.exists():
            return settings
        try:
            data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                settings.update(data)
            return settings
        except Exception:
            return settings

    def setting_enabled(self, name: str) -> bool:
        return bool(self.settings.get(name, DEFAULT_SETTINGS.get(name, False)))

    def save_settings(self) -> bool:
        try:
            self.settings["watch_enabled"] = self.watch_enabled
            self.settings["watch_folder"] = (
                str(self.watch_folder) if self.watch_folder else ""
            )
            if (
                self.setting_enabled("remember_last_export_location")
                and self.export_parent_folder
            ):
                self.settings["last_export_location"] = str(
                    self.export_parent_folder
                )
            SETTINGS_PATH.write_text(
                json.dumps(self.settings, indent=2),
                encoding="utf-8",
            )
            return True
        except Exception as exc:
            messagebox.showerror(
                APP_TITLE,
                "The program settings could not be saved.\n\n" + str(exc),
            )
            return False

    def startup_command(self) -> str:
        launcher = APP_DIR / "launcher.ps1"
        return (
            'powershell.exe -NoProfile -WindowStyle Hidden '
            f'-ExecutionPolicy Bypass -File "{launcher}"'
        )

    def update_startup_registration(self) -> bool:
        try:
            with winreg.CreateKey(
                winreg.HKEY_CURRENT_USER,
                STARTUP_REGISTRY_PATH,
            ) as key:
                for old_name in OLD_STARTUP_VALUE_NAMES:
                    try:
                        winreg.DeleteValue(key, old_name)
                    except FileNotFoundError:
                        pass
                if self.setting_enabled("start_with_windows"):
                    winreg.SetValueEx(
                        key,
                        STARTUP_VALUE_NAME,
                        0,
                        winreg.REG_SZ,
                        self.startup_command(),
                    )
                else:
                    try:
                        winreg.DeleteValue(key, STARTUP_VALUE_NAME)
                    except FileNotFoundError:
                        pass
            return True
        except Exception as exc:
            messagebox.showerror(
                APP_TITLE,
                "The Windows startup setting could not be changed.\n\n"
                + str(exc),
            )
            return False

    def initialize_tray(self):
        if pystray is None or not APP_ICON_PNG_PATH.exists():
            return
        try:
            image = Image.open(APP_ICON_PNG_PATH).convert("RGBA")
            menu = pystray.Menu(
                pystray.MenuItem(
                    "Open Processor",
                    lambda _icon, _item: self.root.after(0, self.show_window),
                    default=True,
                ),
                pystray.MenuItem(
                    "Scanner Folder",
                    lambda _icon, _item: self.root.after(
                        0, self.choose_scanner_folder
                    ),
                ),
                pystray.MenuItem(
                    "Open Scanner Folder",
                    lambda _icon, _item: self.root.after(
                        0, self.open_watch_folder
                    ),
                ),
                pystray.MenuItem(
                    "Preferences",
                    lambda _icon, _item: self.root.after(
                        0, self.show_preferences
                    ),
                ),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem(
                    "Exit",
                    lambda _icon, _item: self.root.after(
                        0, self.exit_application
                    ),
                ),
            )
            self.tray_icon = pystray.Icon(
                "packetflow",
                image,
                APP_TITLE,
                menu,
            )
            self.tray_icon.run_detached()
        except Exception:
            self.tray_icon = None

    def show_window(self):
        self.root.deiconify()
        try:
            self.root.state("zoomed")
        except Exception:
            pass
        self.root.lift()
        self.root.focus_force()

    def minimize_to_tray(self):
        if self.tray_icon is None:
            self.root.iconify()
            return
        self.root.withdraw()

    def notify_user(self, title: str, message: str):
        if not self.setting_enabled("show_notifications"):
            return
        if self.tray_icon is not None:
            try:
                self.tray_icon.notify(message, title)
                return
            except Exception:
                pass
        try:
            self.root.bell()
        except Exception:
            pass

    def open_watch_folder(self):
        if not self.watch_folder or not self.watch_folder.is_dir():
            messagebox.showinfo(
                APP_TITLE,
                "No scanner folder is currently configured.",
            )
            return
        try:
            os.startfile(self.watch_folder)
        except Exception as exc:
            messagebox.showerror(
                APP_TITLE,
                "The scanner folder could not be opened.\n\n" + str(exc),
            )

    def exit_application(self):
        self.exiting = True
        self.save_settings()
        self.cleanup_work_files()
        if self.tray_icon is not None:
            try:
                self.tray_icon.stop()
            except Exception:
                pass
        self.root.destroy()

    def show_preferences(self):
        window = ctk.CTkToplevel(self.root)
        window.title("Preferences")
        window.geometry("590x650")
        window.minsize(560, 600)
        window.transient(self.root)
        window.grab_set()

        ctk.CTkLabel(
            window,
            text="Preferences",
            text_color=CARD_NAVY,
            font=("Segoe UI", 20, "bold"),
        ).pack(anchor="w", padx=22, pady=(18, 3))
        ctk.CTkLabel(
            window,
            text="Operational features can be changed at any time. "
            "Safety and privacy protections remain enabled.",
            text_color=MUTED,
            font=("Segoe UI", 11),
            wraplength=530,
            justify="left",
        ).pack(anchor="w", padx=22, pady=(0, 12))

        content = ctk.CTkScrollableFrame(
            window,
            fg_color="#FFFFFF",
            border_width=1,
            border_color=BORDER,
        )
        content.pack(fill="both", expand=True, padx=20, pady=(0, 12))

        scanner_row = ctk.CTkFrame(content, fg_color="#F8FAFC", corner_radius=6)
        scanner_row.pack(fill="x", padx=10, pady=(8, 5))
        scanner_row.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            scanner_row,
            text="Scanner Folder",
            text_color=TEXT,
            font=("Segoe UI", 12, "bold"),
        ).grid(row=0, column=0, sticky="w", padx=10, pady=(8, 1))
        scanner_path_var = tk.StringVar(
            value=str(self.watch_folder) if self.watch_folder else "No folder selected"
        )
        ctk.CTkLabel(
            scanner_row,
            textvariable=scanner_path_var,
            text_color=MUTED,
            font=("Segoe UI", 10),
            wraplength=380,
            anchor="w",
            justify="left",
        ).grid(row=1, column=0, sticky="w", padx=10, pady=(0, 8))

        def browse_scanner_folder():
            selected = filedialog.askdirectory(
                title="Choose the scanner's PDF destination folder",
                initialdir=str(
                    self.watch_folder
                    or (self.pdf_path.parent if self.pdf_path else Path.home())
                ),
                mustexist=True,
                parent=window,
            )
            if not selected:
                return
            self.watch_folder = Path(selected)
            scanner_path_var.set(str(self.watch_folder))
            pause_watch_var.set(False)

        ctk.CTkButton(
            scanner_row,
            text="Browse",
            command=browse_scanner_folder,
            width=82,
            height=28,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
        ).grid(row=0, column=1, rowspan=2, padx=10, pady=8)

        pause_watch_var = tk.BooleanVar(value=not self.watch_enabled)
        pause_row = ctk.CTkFrame(content, fg_color="transparent")
        pause_row.pack(fill="x", padx=10, pady=5)
        ctk.CTkSwitch(
            pause_row,
            text="Pause scanner folder watching",
            variable=pause_watch_var,
            text_color=TEXT,
            font=("Segoe UI", 12, "bold"),
            progress_color="#C78B22",
            button_color=PRODUCT_BLUE,
        ).pack(anchor="w")
        ctk.CTkLabel(
            pause_row,
            text="Turn this on to stop automatic intake without changing the selected folder.",
            text_color=MUTED,
            font=("Segoe UI", 10),
            wraplength=430,
            justify="left",
            anchor="w",
        ).pack(anchor="w", padx=(28, 0), pady=(1, 0))

        option_specs = [
            (
                "start_with_windows",
                "Start with Windows",
                "Launch the processor when this Windows user signs in.",
            ),
            (
                "start_minimized_to_tray",
                "Start minimized to tray",
                "Begin in the system tray when scanner watching is enabled.",
            ),
            (
                "show_notifications",
                "Show packet-ready notifications",
                "Display a Windows tray notification after analysis finishes.",
            ),
            (
                "open_window_when_scanner_file_detected",
                "Open and maximize for new scans",
                "Bring the processor forward as soon as a new scanner PDF is loaded.",
            ),
            (
                "automatically_export_scanner_packets",
                "Automatically start export for new scans",
                "After analysis, go directly to the save-location dialog.",
            ),
            (
                "apply_remembered_corrections",
                "Apply remembered page corrections",
                "Reuse approved assignments for matching forms.",
            ),
            (
                "apply_remembered_pdf_order",
                "Apply remembered PDF order",
                "Use the saved output order on future packets.",
            ),
            (
                "remember_last_export_location",
                "Remember last export location",
                "Start the folder browser at the most recently used location.",
            ),
            (
                "show_duplicate_warnings",
                "Show duplicate-page warnings",
                "Include suspected duplicate scans in the review summary.",
            ),
            (
                "show_low_confidence_warnings",
                "Show low-confidence warnings",
                "Include faint or weakly recognized pages in the review summary.",
            ),
        ]
        variables: dict[str, tk.BooleanVar] = {}
        for name, label, description in option_specs:
            row = ctk.CTkFrame(content, fg_color="transparent")
            row.pack(fill="x", padx=10, pady=5)
            row.grid_columnconfigure(0, weight=1)
            variable = tk.BooleanVar(value=self.setting_enabled(name))
            variables[name] = variable
            ctk.CTkSwitch(
                row,
                text=label,
                variable=variable,
                text_color=TEXT,
                font=("Segoe UI", 12, "bold"),
                progress_color=SUCCESS_GREEN,
                button_color=PRODUCT_BLUE,
            ).grid(row=0, column=0, sticky="w")
            ctk.CTkLabel(
                row,
                text=description,
                text_color=MUTED,
                font=("Segoe UI", 10),
                wraplength=430,
                justify="left",
                anchor="w",
            ).grid(row=1, column=0, sticky="w", padx=(28, 0), pady=(1, 0))

        ctk.CTkButton(
            content,
            text="Manage Remembered Settings",
            command=self.show_memory_manager,
            fg_color="#FFFFFF",
            hover_color="#FFF8E8",
            border_color="#C78B22",
            border_width=1,
            text_color="#7A5418",
            corner_radius=5,
            height=32,
            font=("Segoe UI", 11, "bold"),
        ).pack(fill="x", padx=10, pady=(8, 10))

        customization_row = ctk.CTkFrame(content, fg_color="transparent")
        customization_row.pack(fill="x", padx=10, pady=(0, 10))
        customization_row.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkButton(
            customization_row,
            text="Customize Branding",
            command=self.show_branding_manager,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_color=PRODUCT_BLUE,
            border_width=1,
            text_color=PRODUCT_BLUE,
            height=32,
        ).grid(row=0, column=0, sticky="ew", padx=(0, 5))
        ctk.CTkButton(
            customization_row,
            text="Manage Document Rules",
            command=self.show_rule_manager,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_color=PRODUCT_BLUE,
            border_width=1,
            text_color=PRODUCT_BLUE,
            height=32,
        ).grid(row=0, column=1, sticky="ew", padx=(5, 0))

        ctk.CTkLabel(
            window,
            text=(
                "Always enabled: blank-page removal, privacy cleanup, audit log, "
                "existing-file protection, orientation checks, and waiting for "
                "scanner files to finish. Manual exports include final review."
            ),
            text_color="#7A5418",
            fg_color="#FFF8E8",
            corner_radius=6,
            font=("Segoe UI", 10),
            wraplength=530,
            justify="left",
        ).pack(fill="x", padx=20, pady=(0, 10), ipady=7)

        def save_preferences():
            requested_watch = not pause_watch_var.get()
            if requested_watch and not self.watch_folder:
                selected = filedialog.askdirectory(
                    title="Choose the scanner's PDF destination folder",
                    initialdir=str(
                        self.pdf_path.parent if self.pdf_path else Path.home()
                    ),
                    mustexist=True,
                    parent=window,
                )
                if not selected:
                    return
                self.watch_folder = Path(selected)
                scanner_path_var.set(str(self.watch_folder))
            for name, variable in variables.items():
                self.settings[name] = bool(variable.get())
            self.settings["watch_enabled"] = requested_watch
            self.watch_enabled = bool(
                requested_watch
                and self.watch_folder
                and self.watch_folder.is_dir()
            )
            if not self.watch_enabled:
                self.watch_candidates.clear()
                self.watch_queue.clear()
            if not self.setting_enabled("remember_last_export_location"):
                self.settings["last_export_location"] = ""
                self.export_parent_folder = None
            self.initialize_watch_folder()
            if not self.update_startup_registration():
                return
            if self.save_settings():
                self.update_watch_button()
                window.destroy()
                self.status_var.set("Preferences saved.")

        button_row = ctk.CTkFrame(window, fg_color="transparent")
        button_row.pack(fill="x", padx=20, pady=(0, 16))
        ctk.CTkButton(
            button_row,
            text="Cancel",
            command=window.destroy,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
            width=120,
        ).pack(side="right")
        ctk.CTkButton(
            button_row,
            text="Save Preferences",
            command=save_preferences,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
            width=160,
        ).pack(side="right", padx=(0, 8))

    def show_branding_manager(self):
        window = ctk.CTkToplevel(self.root)
        window.title("Customize Branding")
        window.geometry("590x390")
        window.transient(self.root)
        window.grab_set()

        ctk.CTkLabel(
            window,
            text="Customize Branding",
            text_color=CARD_NAVY,
            font=("Segoe UI", 20, "bold"),
        ).pack(anchor="w", padx=22, pady=(18, 4))
        ctk.CTkLabel(
            window,
            text="These settings affect this computer only.",
            text_color=MUTED,
            font=("Segoe UI", 11),
        ).pack(anchor="w", padx=22, pady=(0, 14))

        organization_var = tk.StringVar(
            value=self.settings.get("organization_name", "")
        )
        title_var = tk.StringVar(
            value=self.settings.get(
                "header_title",
                "Onboarding Document Processor",
            )
        )
        selected_logo = {
            "path": None,
            "reset": False,
        }
        logo_name_var = tk.StringVar(
            value=self.settings.get("branding_logo", "packetflow-logo.png")
        )

        form = ctk.CTkFrame(window, fg_color="#FFFFFF")
        form.pack(fill="both", expand=True, padx=20, pady=(0, 12))
        ctk.CTkLabel(
            form,
            text="Organization name",
            text_color=TEXT,
            font=("Segoe UI", 11, "bold"),
        ).pack(anchor="w", padx=12, pady=(12, 4))
        ctk.CTkEntry(form, textvariable=organization_var).pack(
            fill="x",
            padx=12,
        )
        ctk.CTkLabel(
            form,
            text="Header title",
            text_color=TEXT,
            font=("Segoe UI", 11, "bold"),
        ).pack(anchor="w", padx=12, pady=(12, 4))
        ctk.CTkEntry(form, textvariable=title_var).pack(fill="x", padx=12)
        ctk.CTkLabel(
            form,
            text="Header logo",
            text_color=TEXT,
            font=("Segoe UI", 11, "bold"),
        ).pack(anchor="w", padx=12, pady=(12, 4))
        logo_row = ctk.CTkFrame(form, fg_color="transparent")
        logo_row.pack(fill="x", padx=12, pady=(0, 12))
        ctk.CTkLabel(
            logo_row,
            textvariable=logo_name_var,
            text_color=MUTED,
            anchor="w",
        ).pack(side="left", fill="x", expand=True)

        def choose_logo():
            chosen = filedialog.askopenfilename(
                title="Choose a header logo",
                filetypes=[
                    ("Image files", "*.png;*.jpg;*.jpeg;*.webp"),
                    ("All files", "*.*"),
                ],
                parent=window,
            )
            if not chosen:
                return
            selected_logo["path"] = Path(chosen)
            selected_logo["reset"] = False
            logo_name_var.set(Path(chosen).name)

        def reset_logo():
            selected_logo["path"] = None
            selected_logo["reset"] = True
            logo_name_var.set("packetflow-logo.png")

        ctk.CTkButton(
            logo_row,
            text="Choose Logo",
            command=choose_logo,
            width=100,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
        ).pack(side="left", padx=(8, 5))
        ctk.CTkButton(
            logo_row,
            text="Use Default",
            command=reset_logo,
            width=96,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
        ).pack(side="left")

        def save_branding():
            logo_name = self.settings.get(
                "branding_logo",
                "packetflow-logo.png",
            )
            if selected_logo["reset"]:
                logo_name = "packetflow-logo.png"
            elif selected_logo["path"]:
                source = selected_logo["path"]
                suffix = source.suffix.lower()
                if suffix not in (".png", ".jpg", ".jpeg", ".webp"):
                    messagebox.showwarning(
                        APP_TITLE,
                        "Choose a PNG, JPG, JPEG, or WebP logo.",
                        parent=window,
                    )
                    return
                logo_name = "customer-logo" + suffix
                try:
                    shutil.copy2(source, APP_DIR / logo_name)
                except Exception as exc:
                    messagebox.showerror(
                        APP_TITLE,
                        "The logo could not be saved.\n\n" + str(exc),
                        parent=window,
                    )
                    return
            self.settings["organization_name"] = organization_var.get().strip()
            self.settings["header_title"] = (
                title_var.get().strip() or "Onboarding Document Processor"
            )
            self.settings["branding_logo"] = logo_name
            if self.save_settings():
                self.apply_branding()
                window.destroy()
                self.status_var.set("Branding updated.")

        buttons = ctk.CTkFrame(window, fg_color="transparent")
        buttons.pack(fill="x", padx=20, pady=(0, 16))
        ctk.CTkButton(
            buttons,
            text="Cancel",
            command=window.destroy,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
            width=110,
        ).pack(side="right")
        ctk.CTkButton(
            buttons,
            text="Save Branding",
            command=save_branding,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
            width=140,
        ).pack(side="right", padx=(0, 8))

    def apply_branding(self):
        if hasattr(self, "header_title_label"):
            self.header_title_label.configure(
                text=self.settings.get(
                    "header_title",
                    "Onboarding Document Processor",
                )
            )
        organization = self.settings.get("organization_name", "").strip()
        if hasattr(self, "header_subtitle_label"):
            self.header_subtitle_label.configure(
                text=organization
                or "OCR + document classification + review before export"
            )
        if hasattr(self, "logo_label"):
            logo_path = APP_DIR / self.settings.get(
                "branding_logo",
                "packetflow-logo.png",
            )
            try:
                image = Image.open(logo_path)
                target_w = min(260, image.width)
                target_h = max(1, int(target_w * image.height / image.width))
                if target_h > 68:
                    target_h = 68
                    target_w = max(
                        1,
                        int(target_h * image.width / image.height),
                    )
                self.logo_img = ctk.CTkImage(
                    light_image=image,
                    dark_image=image,
                    size=(target_w, target_h),
                )
                self.logo_label.configure(text="", image=self.logo_img)
            except Exception:
                self.logo_label.configure(
                    text="PacketFlow",
                    image=None,
                )

    @staticmethod
    def suggested_rule_keywords(text: str) -> list[str]:
        title_terms = {
            "acknowledgment",
            "agreement",
            "application",
            "authorization",
            "certificate",
            "consent",
            "disclosure",
            "eligibility",
            "enrollment",
            "notice",
            "payroll",
            "policy",
            "statement",
            "verification",
            "waiver",
        }
        generic_phrases = {
            "employee signature",
            "employer signature",
            "please print",
            "print name",
            "signature date",
            "today date",
        }
        candidates = []
        seen = set()
        for position, raw_line in enumerate(text.splitlines()[:80]):
            line = re.sub(r"\s+", " ", raw_line.strip().lower())
            if not 8 <= len(line) <= 100:
                continue
            if len(re.findall(r"[a-z]{3,}", line)) < 2:
                continue
            if any(phrase in line for phrase in generic_phrases):
                continue
            if re.search(r"\b\d{3}[-.\s]\d{2}[-.\s]\d{4}\b", line):
                continue
            if re.search(r"\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b", line):
                continue
            if re.search(r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\b", line):
                continue
            if sum(character.isdigit() for character in line) > 3:
                continue
            if "_" in line or line.count(".") > 4:
                continue
            if line in seen:
                continue
            seen.add(line)
            words = set(re.findall(r"[a-z]{3,}", line))
            score = max(0, 30 - position)
            score += 25 * len(words & title_terms)
            score += 10 if len(line) <= 60 else 0
            score += 15 if raw_line.strip().isupper() else 0
            candidates.append((score, position, line))
        candidates.sort(key=lambda item: (-item[0], item[1]))
        return [line for _score, _position, line in candidates[:5]]

    def learn_document_rules(
        self,
        document: str,
        pages: list[int],
    ) -> tuple[int, list[str]]:
        learned = 0
        learned_phrases: list[str] = []
        rules = self.rules.setdefault("custom_rules", [])
        for page in pages:
            if page >= len(self.ocr_texts):
                continue
            suggestions = self.suggested_rule_keywords(self.ocr_texts[page])
            if not suggestions:
                continue
            keywords = suggestions[:2]
            normalized_keywords = {
                re.sub(r"\s+", " ", keyword.strip().lower())
                for keyword in keywords
            }
            duplicate = any(
                str(rule.get("document", "")).casefold()
                == document.casefold()
                and {
                    re.sub(r"\s+", " ", str(keyword).strip().lower())
                    for keyword in rule.get("keywords", [])
                }
                == normalized_keywords
                for rule in rules
            )
            if duplicate:
                continue
            rules.append(
                {
                    "document": document,
                    "expected": False,
                    "match_mode": "all",
                    "keywords": keywords,
                    "sample_filename": "Learned from reviewed packet",
                    "source": "learned",
                }
            )
            learned += 1
            learned_phrases.extend(keywords)
        return learned, list(dict.fromkeys(learned_phrases))

    def show_rule_manager(self):
        window = ctk.CTkToplevel(self.root)
        window.title("Document Rules")
        window.geometry("820x590")
        window.minsize(700, 500)
        window.transient(self.root)
        window.grab_set()

        ctk.CTkLabel(
            window,
            text="Document Rules",
            text_color=CARD_NAVY,
            font=("Segoe UI", 20, "bold"),
        ).pack(anchor="w", padx=22, pady=(18, 3))
        ctk.CTkLabel(
            window,
            text=(
                "Custom rules run before the built-in starter rules. Use distinctive "
                "phrases that are printed consistently on the form."
            ),
            text_color=MUTED,
            font=("Segoe UI", 11),
            wraplength=760,
            justify="left",
        ).pack(anchor="w", padx=22, pady=(0, 12))

        profile_row = ctk.CTkFrame(
            window,
            fg_color="#F8FAFC",
            corner_radius=6,
        )
        profile_row.pack(fill="x", padx=20, pady=(0, 10))
        ctk.CTkLabel(
            profile_row,
            text="Active profile",
            text_color=TEXT,
            font=("Segoe UI", 11, "bold"),
        ).pack(side="left", padx=(10, 8), pady=9)
        profile_var = tk.StringVar(value=self.active_profile_name)
        profile_combo = ctk.CTkComboBox(
            profile_row,
            variable=profile_var,
            values=list(self.rule_profiles),
            state="readonly",
            width=180,
        )
        profile_combo.pack(side="left", pady=8)

        rule_list = tk.Listbox(
            window,
            font=("Segoe UI", 11),
            activestyle="none",
            selectmode="browse",
        )
        rule_list.pack(fill="both", expand=True, padx=20, pady=(0, 10))

        def refresh_rules(select_index: int | None = None):
            rule_list.delete(0, tk.END)
            for rule in self.rules.get("custom_rules", []):
                expected = "Expected" if rule.get("expected") else "Optional"
                source = (
                    "Learned"
                    if rule.get("source") == "learned"
                    else "Custom"
                )
                mode = str(rule.get("match_mode", "all")).upper()
                keywords = "; ".join(rule.get("keywords", []))
                rule_list.insert(
                    tk.END,
                    f"{rule.get('document', '')}  |  {source}  |  {expected}  |  "
                    f"Match {mode}: {keywords}",
                )
            if select_index is not None and rule_list.size():
                selected = min(select_index, rule_list.size() - 1)
                rule_list.selection_set(selected)
                rule_list.see(selected)

        def selected_rule_index() -> int | None:
            selection = rule_list.curselection()
            return int(selection[0]) if selection else None

        def refresh_profiles():
            profile_combo.configure(values=list(self.rule_profiles))
            profile_var.set(self.active_profile_name)

        def profile_change_allowed() -> bool:
            if self.analyzing:
                messagebox.showwarning(
                    APP_TITLE,
                    "Wait for the current analysis to finish before changing profiles.",
                    parent=window,
                )
                return False
            if self.pdf_path:
                messagebox.showwarning(
                    APP_TITLE,
                    "Export the loaded packet before changing profiles. This keeps "
                    "one packet from being reviewed under two different workflows.",
                    parent=window,
                )
                return False
            return True

        def activate_profile(profile_name: str):
            if profile_name == self.active_profile_name:
                return
            if not profile_change_allowed():
                profile_var.set(self.active_profile_name)
                return
            if self.switch_rule_profile(profile_name):
                refresh_profiles()
                refresh_rules()

        profile_combo.configure(command=activate_profile)

        def unique_profile_name(name: str, excluding: str | None = None) -> bool:
            normalized = name.casefold()
            return not any(
                existing.casefold() == normalized and existing != excluding
                for existing in self.rule_profiles
            )

        def create_profile():
            if not profile_change_allowed():
                return
            name = simpledialog.askstring(
                APP_TITLE,
                "New profile name:",
                parent=window,
            )
            if not name:
                return
            name = re.sub(r"\s+", " ", name.strip())
            if not unique_profile_name(name):
                messagebox.showwarning(
                    APP_TITLE,
                    "A profile with that name already exists.",
                    parent=window,
                )
                return
            copy_current = messagebox.askyesno(
                APP_TITLE,
                f"Copy the current {self.active_profile_name} profile?\n\n"
                "Choose No to start with a blank profile.",
                parent=window,
            )
            self.rule_profiles[self.active_profile_name] = self.rules
            self.rule_profiles[name] = (
                copy.deepcopy(self.rules)
                if copy_current
                else {
                    "document_types": [],
                    "expected_document_types": [],
                    "custom_rules": [],
                }
            )
            self.switch_rule_profile(name)
            refresh_profiles()
            refresh_rules()

        def duplicate_profile():
            if not profile_change_allowed():
                return
            name = simpledialog.askstring(
                APP_TITLE,
                "Name for the copied profile:",
                initialvalue=f"{self.active_profile_name} Copy",
                parent=window,
            )
            if not name:
                return
            name = re.sub(r"\s+", " ", name.strip())
            if not unique_profile_name(name):
                messagebox.showwarning(
                    APP_TITLE,
                    "A profile with that name already exists.",
                    parent=window,
                )
                return
            self.rule_profiles[self.active_profile_name] = self.rules
            self.rule_profiles[name] = copy.deepcopy(self.rules)
            self.switch_rule_profile(name)
            refresh_profiles()
            refresh_rules()

        def rename_profile():
            old_name = self.active_profile_name
            name = simpledialog.askstring(
                APP_TITLE,
                "Rename profile:",
                initialvalue=old_name,
                parent=window,
            )
            if not name:
                return
            name = re.sub(r"\s+", " ", name.strip())
            if name == old_name:
                return
            if not unique_profile_name(name, excluding=old_name):
                messagebox.showwarning(
                    APP_TITLE,
                    "A profile with that name already exists.",
                    parent=window,
                )
                return
            renamed = {}
            for profile_name, profile in self.rule_profiles.items():
                renamed[name if profile_name == old_name else profile_name] = profile
            self.rule_profiles = renamed
            self.active_profile_name = name
            self.rules = self.rule_profiles[name]
            self.analyzer.rules = self.rules
            self.action_title_var.set(f"Assign Selected Pages · {name}")
            if old_name in self.correction_memory_profiles:
                self.correction_memory_profiles[name] = (
                    self.correction_memory_profiles.pop(old_name)
                )
            self.save_rules()
            self.save_correction_memory()
            refresh_profiles()
            refresh_rules()

        def delete_profile():
            if not profile_change_allowed():
                return
            if len(self.rule_profiles) <= 1:
                messagebox.showwarning(
                    APP_TITLE,
                    "PacketFlow must keep at least one profile.",
                    parent=window,
                )
                return
            deleting = self.active_profile_name
            if not messagebox.askyesno(
                APP_TITLE,
                f"Delete the {deleting} profile?\n\n"
                "Its document rules cannot be recovered unless previously exported.",
                parent=window,
            ):
                return
            del self.rule_profiles[deleting]
            self.correction_memory_profiles.pop(deleting, None)
            next_profile = next(iter(self.rule_profiles))
            self.active_profile_name = next_profile
            self.rules = self.rule_profiles[next_profile]
            self.analyzer.rules = self.rules
            self.action_title_var.set(
                f"Assign Selected Pages · {next_profile}"
            )
            memory = self.correction_memory_profiles.get(next_profile, {})
            self.correction_memory = list(memory.get("corrections", []))
            self.preferred_document_order = [
                safe_filename(str(document))
                for document in memory.get("output_order", [])
                if str(document).strip()
            ]
            self.custom_document_types.clear()
            self.save_rules()
            self.save_correction_memory()
            refresh_profiles()
            refresh_rules()

        ctk.CTkButton(
            profile_row,
            text="New",
            command=create_profile,
            width=58,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color=PRODUCT_BLUE,
            text_color=PRODUCT_BLUE,
        ).pack(side="left", padx=(8, 4), pady=8)
        ctk.CTkButton(
            profile_row,
            text="Duplicate",
            command=duplicate_profile,
            width=82,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
        ).pack(side="left", padx=4, pady=8)
        ctk.CTkButton(
            profile_row,
            text="Rename",
            command=rename_profile,
            width=72,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
        ).pack(side="left", padx=4, pady=8)
        ctk.CTkButton(
            profile_row,
            text="Delete",
            command=delete_profile,
            width=66,
            fg_color="#FFFFFF",
            hover_color="#FBEAEA",
            border_width=1,
            border_color=WARNING,
            text_color=WARNING,
        ).pack(side="left", padx=(4, 10), pady=8)

        def open_rule_editor(
            rule: dict | None = None,
            sample_path: Path | None = None,
        ):
            editor = ctk.CTkToplevel(window)
            editor.title("Document Recognition Rule")
            editor.geometry("620x520")
            editor.transient(window)
            editor.grab_set()

            existing = dict(rule or {})
            default_document = (
                safe_filename(sample_path.stem)
                if sample_path
                else ""
            )
            if default_document and not default_document.lower().endswith(".pdf"):
                default_document += ".pdf"
            document_var = tk.StringVar(
                value=existing.get("document", default_document)
            )
            mode_var = tk.StringVar(
                value=existing.get("match_mode", "all").title()
            )
            expected_var = tk.BooleanVar(
                value=bool(existing.get("expected", False))
            )

            ctk.CTkLabel(
                editor,
                text="Output PDF name",
                font=("Segoe UI", 11, "bold"),
                text_color=TEXT,
            ).pack(anchor="w", padx=20, pady=(18, 4))
            ctk.CTkEntry(
                editor,
                textvariable=document_var,
            ).pack(fill="x", padx=20)

            ctk.CTkLabel(
                editor,
                text="Identifying phrases (one per line)",
                font=("Segoe UI", 11, "bold"),
                text_color=TEXT,
            ).pack(anchor="w", padx=20, pady=(14, 4))
            keyword_box = ctk.CTkTextbox(editor, height=210)
            keyword_box.pack(fill="both", expand=True, padx=20)
            keywords = list(existing.get("keywords", []))
            if sample_path:
                try:
                    reader = PdfReader(str(sample_path))
                    sample_text = "\n".join(
                        page.extract_text() or ""
                        for page in reader.pages[:5]
                    )
                    if sample_text.strip():
                        keywords = self.suggested_rule_keywords(sample_text)
                    else:
                        messagebox.showinfo(
                            APP_TITLE,
                            "The sample appears to be image-only. Enter two or more "
                            "distinctive phrases printed on the form. PacketFlow will "
                            "use OCR when processing real packets.",
                            parent=editor,
                        )
                except Exception as exc:
                    messagebox.showwarning(
                        APP_TITLE,
                        "The sample could not be read automatically.\n\n"
                        + str(exc),
                        parent=editor,
                    )
            keyword_box.insert("1.0", "\n".join(keywords))

            options = ctk.CTkFrame(editor, fg_color="transparent")
            options.pack(fill="x", padx=20, pady=12)
            ctk.CTkLabel(
                options,
                text="Match mode",
                text_color=TEXT,
                font=("Segoe UI", 11, "bold"),
            ).pack(side="left")
            ctk.CTkComboBox(
                options,
                variable=mode_var,
                values=["All", "Any"],
                width=100,
                state="readonly",
            ).pack(side="left", padx=(8, 20))
            ctk.CTkSwitch(
                options,
                text="Expected in every packet",
                variable=expected_var,
                progress_color=SUCCESS_GREEN,
                button_color=PRODUCT_BLUE,
            ).pack(side="left")

            def save_rule():
                raw_document = document_var.get().strip()
                entered_keywords = [
                    re.sub(r"\s+", " ", line.strip().lower())
                    for line in keyword_box.get("1.0", "end").splitlines()
                    if line.strip()
                ]
                entered_keywords = list(dict.fromkeys(entered_keywords))
                if not raw_document or len(entered_keywords) < 1:
                    messagebox.showwarning(
                        APP_TITLE,
                        "Enter an output PDF name and at least one identifying phrase.",
                        parent=editor,
                    )
                    return
                document = safe_filename(raw_document)
                saved_rule = {
                    "document": document,
                    "expected": bool(expected_var.get()),
                    "match_mode": mode_var.get().lower(),
                    "keywords": entered_keywords,
                    "sample_filename": sample_path.name if sample_path else existing.get(
                        "sample_filename",
                        "",
                    ),
                }
                rules = self.rules.setdefault("custom_rules", [])
                if rule is None:
                    rules.append(saved_rule)
                    selected = len(rules) - 1
                else:
                    selected = rules.index(rule)
                    old_document = str(rule.get("document", ""))
                    rules[selected] = saved_rule
                    if (
                        old_document != document
                        and old_document in self.rules["expected_document_types"]
                    ):
                        self.rules["expected_document_types"].remove(
                            old_document
                        )
                if document not in self.rules["document_types"]:
                    self.rules["document_types"].append(document)
                expected_documents = self.rules["expected_document_types"]
                if saved_rule["expected"] and document not in expected_documents:
                    expected_documents.append(document)
                if not saved_rule["expected"] and document in expected_documents:
                    expected_documents.remove(document)
                if self.save_rules():
                    refresh_rules(selected)
                    editor.destroy()

            editor_buttons = ctk.CTkFrame(editor, fg_color="transparent")
            editor_buttons.pack(fill="x", padx=20, pady=(0, 16))
            ctk.CTkButton(
                editor_buttons,
                text="Cancel",
                command=editor.destroy,
                fg_color="#FFFFFF",
                hover_color="#F8FAFC",
                border_width=1,
                border_color="#CBD5E1",
                text_color=TEXT,
                width=100,
            ).pack(side="right")
            ctk.CTkButton(
                editor_buttons,
                text="Save Rule",
                command=save_rule,
                fg_color=PRODUCT_BLUE,
                hover_color=SUCCESS_GREEN,
                width=120,
            ).pack(side="right", padx=(0, 8))

        def add_from_pdf():
            selected = filedialog.askopenfilename(
                title="Choose a sample form PDF",
                filetypes=[("PDF files", "*.pdf")],
                parent=window,
            )
            if selected:
                open_rule_editor(sample_path=Path(selected))

        def edit_selected():
            index = selected_rule_index()
            if index is None:
                messagebox.showwarning(
                    APP_TITLE,
                    "Select a custom rule to edit.",
                    parent=window,
                )
                return
            open_rule_editor(self.rules["custom_rules"][index])

        def delete_selected():
            index = selected_rule_index()
            if index is None:
                return
            rule = self.rules["custom_rules"][index]
            if not messagebox.askyesno(
                APP_TITLE,
                f"Delete the custom rule for {rule.get('document', '')}?",
                parent=window,
            ):
                return
            document = rule.get("document", "")
            del self.rules["custom_rules"][index]
            if not any(
                item.get("document") == document
                for item in self.rules["custom_rules"]
            ):
                if document in self.rules["expected_document_types"]:
                    self.rules["expected_document_types"].remove(document)
            if self.save_rules():
                refresh_rules(index)

        def export_profile():
            destination = filedialog.asksaveasfilename(
                title=f"Export {self.active_profile_name} profile",
                defaultextension=".json",
                filetypes=[("JSON profile", "*.json")],
                parent=window,
            )
            if destination:
                try:
                    exported_by = os.environ.get("USERNAME") or os.environ.get("USER") or ""
                except Exception:
                    exported_by = ""
                Path(destination).write_text(
                    json.dumps(
                        {
                            "schema_version": 2,
                            "profile_name": self.active_profile_name,
                            # Provenance fields — help teams track which version of
                            # a profile is installed on which workstation.
                            "exported_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                            "exported_by": exported_by,
                            "profile": self.rules,
                        },
                        indent=2,
                    ),
                    encoding="utf-8",
                )

        def import_profile():
            source = filedialog.askopenfilename(
                title="Import PacketFlow rule profile",
                filetypes=[("JSON profile", "*.json")],
                parent=window,
            )
            if not source:
                return
            try:
                imported = json.loads(Path(source).read_text(encoding="utf-8"))
                if not isinstance(imported, dict):
                    raise ValueError("The profile must contain a JSON object.")
                if isinstance(imported.get("profile"), dict):
                    suggested_name = str(
                        imported.get("profile_name", Path(source).stem)
                    ).strip()
                    imported_profile = imported["profile"]
                else:
                    suggested_name = Path(source).stem
                    imported_profile = imported
                for key in (
                    "document_types",
                    "expected_document_types",
                    "custom_rules",
                ):
                    if not isinstance(imported_profile.get(key), list):
                        raise ValueError(f"The profile is missing {key}.")
            except Exception as exc:
                messagebox.showerror(
                    APP_TITLE,
                    "The rule profile is not valid.\n\n" + str(exc),
                    parent=window,
                )
                return
            profile_name = simpledialog.askstring(
                APP_TITLE,
                "Save imported profile as:",
                initialvalue=suggested_name,
                parent=window,
            )
            if not profile_name:
                return
            profile_name = re.sub(r"\s+", " ", profile_name.strip())
            if not profile_change_allowed():
                return
            existing = next(
                (
                    name
                    for name in self.rule_profiles
                    if name.casefold() == profile_name.casefold()
                ),
                None,
            )
            if existing and not messagebox.askyesno(
                APP_TITLE,
                f"Replace the existing {existing} profile?",
                parent=window,
            ):
                return
            if existing:
                profile_name = existing
            self.rule_profiles[self.active_profile_name] = self.rules
            self.rule_profiles[profile_name] = self.normalize_rule_profile(
                imported_profile
            )
            if profile_name == self.active_profile_name:
                self.rules = self.rule_profiles[profile_name]
                self.analyzer.rules = self.rules
                self.custom_document_types.clear()
                saved = self.save_rules()
            else:
                saved = self.switch_rule_profile(profile_name)
            if saved:
                refresh_profiles()
                refresh_rules()

        controls = ctk.CTkFrame(window, fg_color="transparent")
        controls.pack(fill="x", padx=20, pady=(0, 16))
        ctk.CTkButton(
            controls,
            text="Add Sample PDF",
            command=add_from_pdf,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
        ).pack(side="left")
        ctk.CTkButton(
            controls,
            text="Add Manually",
            command=open_rule_editor,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color=PRODUCT_BLUE,
            text_color=PRODUCT_BLUE,
        ).pack(side="left", padx=6)
        ctk.CTkButton(
            controls,
            text="Edit",
            command=edit_selected,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
            width=70,
        ).pack(side="left")
        ctk.CTkButton(
            controls,
            text="Delete",
            command=delete_selected,
            fg_color="#FFFFFF",
            hover_color="#FBEAEA",
            border_width=1,
            border_color=WARNING,
            text_color=WARNING,
            width=75,
        ).pack(side="left", padx=6)
        ctk.CTkButton(
            controls,
            text="Close",
            command=window.destroy,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
            width=80,
        ).pack(side="right")
        ctk.CTkButton(
            controls,
            text="Export Profile",
            command=export_profile,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color=PRODUCT_BLUE,
            text_color=PRODUCT_BLUE,
        ).pack(side="right", padx=6)
        ctk.CTkButton(
            controls,
            text="Import Profile",
            command=import_profile,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color=PRODUCT_BLUE,
            text_color=PRODUCT_BLUE,
        ).pack(side="right")

        rule_list.bind("<Double-Button-1>", lambda _event: edit_selected())
        refresh_rules()

    # Maximum correction-memory entries kept per profile.  Older entries are
    # trimmed on load so the file stays small after months of use.
    _CORRECTION_MEMORY_MAX = 500

    @staticmethod
    def _deduplicate_corrections(entries: list[dict]) -> list[dict]:
        """Remove exact-duplicate correction entries, keeping the last occurrence."""
        seen: dict[str, int] = {}
        for position, entry in enumerate(entries):
            key = json.dumps(entry, sort_keys=True)
            seen[key] = position
        kept = {position for position in seen.values()}
        return [entry for position, entry in enumerate(entries) if position in kept]

    def load_correction_memory(self) -> list[dict]:
        self.correction_memory_profiles: dict[str, dict] = {}
        if not CORRECTION_MEMORY_PATH.exists():
            return []
        try:
            data = json.loads(CORRECTION_MEMORY_PATH.read_text(encoding="utf-8"))
            if isinstance(data, list):
                cleaned = self._deduplicate_corrections(data)[-self._CORRECTION_MEMORY_MAX:]
                self.correction_memory_profiles[self.active_profile_name] = {
                    "corrections": cleaned,
                    "output_order": [],
                }
                return cleaned
            if isinstance(data, dict):
                if isinstance(data.get("profiles"), dict):
                    self.correction_memory_profiles = {
                        str(name): {
                            "corrections": self._deduplicate_corrections(
                                list(profile.get("corrections", []))
                            )[-self._CORRECTION_MEMORY_MAX:],
                            "output_order": list(
                                profile.get("output_order", [])
                            ),
                        }
                        for name, profile in data["profiles"].items()
                        if isinstance(profile, dict)
                    }
                    active_memory = self.correction_memory_profiles.get(
                        self.active_profile_name,
                        {},
                    )
                    self.preferred_document_order = [
                        safe_filename(str(document))
                        for document in active_memory.get("output_order", [])
                        if str(document).strip()
                    ]
                    return list(active_memory.get("corrections", []))
                saved_order = data.get("output_order", [])
                if isinstance(saved_order, list):
                    self.preferred_document_order = [
                        safe_filename(str(document))
                        for document in saved_order
                        if str(document).strip()
                    ]
                corrections = data.get("corrections", [])
                corrections = corrections if isinstance(corrections, list) else []
                corrections = self._deduplicate_corrections(corrections)[-self._CORRECTION_MEMORY_MAX:]
                self.correction_memory_profiles[self.active_profile_name] = {
                    "corrections": corrections,
                    "output_order": self.preferred_document_order,
                }
                return corrections
            return []
        except Exception:
            return []

    def save_correction_memory(self) -> bool:
        try:
            self.correction_memory_profiles[self.active_profile_name] = {
                "corrections": self.correction_memory,
                "output_order": self.preferred_document_order,
            }
            CORRECTION_MEMORY_PATH.write_text(
                json.dumps(
                    {
                        "schema_version": 2,
                        "profiles": self.correction_memory_profiles,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
            return True
        except Exception as exc:
            messagebox.showerror(
                APP_TITLE,
                "The correction could not be saved for future packets.\n\n"
                + str(exc),
            )
            return False

    @staticmethod
    def correction_signature(text: str) -> list[str]:
        cleaned = text.lower().replace("__sparse_scan__", " ")
        tokens = re.findall(r"[a-z]{4,}", cleaned)
        shingles = {
            f"{tokens[index]} {tokens[index + 1]}"
            for index in range(len(tokens) - 1)
        }
        return sorted(shingles)

    def apply_correction_memory(
        self,
        texts: list[str],
        assignments: list[Assignment],
        rotations: list[int],
        blank_pages: set[int],
    ) -> tuple[list[Assignment], set[int]]:
        if not self.correction_memory:
            return assignments, set()

        updated = list(assignments)
        applied: set[int] = set()
        for index, text in enumerate(texts):
            if index in blank_pages:
                continue
            current = set(self.correction_signature(text))
            if len(current) < 12:
                continue
            best_entry = None
            best_score = 0.0
            for entry in self.correction_memory:
                remembered = set(entry.get("signature", []))
                overlap = len(current & remembered)
                if overlap < 12:
                    continue
                score = overlap / max(len(current | remembered), 1)
                if score > best_score:
                    best_score = score
                    best_entry = entry
            if best_entry is None or best_score < 0.82:
                continue
            document = safe_filename(str(best_entry.get("document", "")))
            updated = [item for item in updated if item.page_index != index]
            updated.append(Assignment(index, document, rotations[index], None))
            if document == "Banking.pdf":
                updated.append(
                    Assignment(
                        index,
                        "Viventium Direct Deposit.pdf",
                        rotations[index],
                        None,
                    )
                )
            applied.add(index)
        return updated, applied

    @staticmethod
    def find_duplicate_pairs(
        texts: list[str],
        fingerprints: list[int],
        blank_pages: set[int],
    ) -> list[tuple[int, int]]:
        normalized = [
            re.sub(r"\s+", " ", text.replace("__SPARSE_SCAN__", "").strip().lower())
            for text in texts
        ]
        duplicates: list[tuple[int, int]] = []
        for left in range(len(texts)):
            if left in blank_pages or len(normalized[left]) < 40:
                continue
            for right in range(left + 1, len(texts)):
                if right in blank_pages:
                    continue
                distance = (fingerprints[left] ^ fingerprints[right]).bit_count()
                if distance > 40:
                    continue
                if normalized[left] == normalized[right]:
                    duplicates.append((left, right))
                    continue
                similarity = difflib.SequenceMatcher(
                    None,
                    normalized[left],
                    normalized[right],
                    autojunk=False,
                ).ratio()
                if similarity >= 0.92:
                    duplicates.append((left, right))
        return duplicates

    def calculate_low_confidence_pages(
        self,
        texts: list[str],
        assignments: list[Assignment],
    ) -> set[int]:
        assigned = {item.page_index for item in assignments}
        return {
            index
            for index, text in enumerate(texts)
            if index in assigned
            and (
                "__SPARSE_SCAN__" in text
                or self.analyzer.orientation_score(text) < 45
            )
        }

    def bind_file_drop(self):
        if windnd is None:
            return
        try:
            windnd.hook_dropfiles(
                self.root,
                func=lambda paths: self.root.after(
                    0,
                    lambda: self.handle_dropped_files(paths),
                ),
            )
        except Exception:
            pass

    def handle_dropped_files(self, paths):
        selected_paths = []
        for raw_path in paths:
            if isinstance(raw_path, bytes):
                path = Path(raw_path.decode("utf-8", errors="replace"))
            else:
                path = Path(str(raw_path))
            if (
                path.is_file()
                and path.suffix.lower() in SUPPORTED_INPUT_EXTENSIONS
            ):
                selected_paths.append(path)
        if not selected_paths:
            messagebox.showwarning(
                APP_TITLE,
                "Drop a supported PDF, image, text, or Office file onto "
                "the application window.",
            )
            return
        if (
            not self.reader
            and len(selected_paths) == 1
            and selected_paths[0].suffix.lower() == ".pdf"
        ):
            self.load_packet(selected_paths[0])
        else:
            self.add_file_paths(selected_paths)

    def initialize_watch_folder(self):
        if not self.watch_enabled or not self.watch_folder:
            self.update_watch_button()
            return
        try:
            self.watch_known_files = {
                path.resolve()
                for path in self.watch_folder.glob("*.pdf")
                if path.is_file()
            }
        except Exception:
            self.watch_enabled = False
        self.update_watch_button()

    def update_watch_button(self):
        if not hasattr(self, "watch_button"):
            return
        if self.watch_enabled and self.watch_folder:
            self.watch_button.configure(
                text="Scanner Folder",
                border_color=SUCCESS_GREEN,
                text_color="#287A55",
            )
            self.watch_folder_label.configure(
                text=f"Watching: {self.watch_folder}",
                text_color="#287A55",
            )
        else:
            self.watch_button.configure(
                text="Scanner Folder",
                border_color="#CBD5E1",
                text_color=TEXT,
            )
            self.watch_folder_label.configure(
                text="Scanner folder is paused or not selected",
                text_color=MUTED,
            )

    def choose_scanner_folder(self):
        proceed = messagebox.askyesno(
            APP_TITLE,
            "Choose the scanner folder for new PDFs?\n\n"
            "The processor must remain open. Existing PDFs will be ignored. "
            "A new PDF will be analyzed only after the scanner finishes writing "
            "it, and it will wait if another packet still needs review.\n\n"
            "Pause or resume watching from Preferences.\n\n"
            "Continue?",
        )
        if not proceed:
            return
        selected = filedialog.askdirectory(
            title="Choose the scanner's PDF destination folder",
            initialdir=str(
                self.watch_folder
                or (self.pdf_path.parent if self.pdf_path else Path.home())
            ),
            mustexist=True,
        )
        if not selected:
            return
        self.watch_folder = Path(selected)
        self.watch_enabled = True
        self.watch_candidates.clear()
        self.watch_queue.clear()
        self.watch_known_files = {
            path.resolve()
            for path in self.watch_folder.glob("*.pdf")
            if path.is_file()
        }
        self.save_settings()
        self.update_watch_button()
        self.status_var.set(f"Watching scanner folder: {self.watch_folder}")

    def poll_watch_folder(self):
        try:
            if self.watch_enabled and self.watch_folder and self.watch_folder.is_dir():
                now = time.time()
                try:
                    pdf_candidates = list(self.watch_folder.glob("*.pdf"))
                except OSError as exc:
                    # The scanner folder became unavailable (e.g. mapped network
                    # drive went offline).  Show a one-time status message and
                    # reschedule — do NOT disable watching so recovery is automatic
                    # when the drive reconnects.
                    self.status_var.set(
                        f"Scanner folder temporarily unavailable: {exc}"
                    )
                    return
                for path in pdf_candidates:
                    if not path.is_file():
                        continue
                    resolved = path.resolve()
                    if resolved in self.watch_known_files or resolved in self.watch_queue:
                        continue
                    try:
                        stat = path.stat()
                    except OSError:
                        continue
                    previous = self.watch_candidates.get(resolved)
                    if previous and previous[:2] == (stat.st_size, stat.st_mtime):
                        stable_checks = previous[2] + 1
                    else:
                        stable_checks = 0
                    self.watch_candidates[resolved] = (
                        stat.st_size,
                        stat.st_mtime,
                        stable_checks,
                    )
                    if (
                        stat.st_size > 0
                        and stable_checks >= 2
                        and now - stat.st_mtime >= 2
                    ):
                        try:
                            with path.open("rb") as handle:
                                PdfReader(handle)
                        except Exception:
                            continue
                        self.watch_known_files.add(resolved)
                        self.watch_candidates.pop(resolved, None)
                        self.watch_queue.append(resolved)
                self.process_watch_queue()
        finally:
            self.root.after(1500, self.poll_watch_folder)

    def process_watch_queue(self):
        if not self.watch_queue or self.analyzing:
            return
        next_packet = self.watch_queue.pop(0)
        if self.setting_enabled("open_window_when_scanner_file_detected"):
            self.show_window()
        self.load_packet(next_packet, from_watch=True)

    def bind_shortcuts(self):
        self.root.bind("<Control-o>", lambda _event: self.open_packet())
        self.root.bind("<Control-Shift-O>", lambda _event: self.add_files())
        self.root.bind("<Control-e>", lambda _event: self.export_pdfs())
        self.root.bind("<Control-Return>", lambda _event: self.assign_to_document())
        self.root.bind("<Control-z>", lambda _event: self.undo_last_change())

    def build_ui(self):
        """Windows-style utility layout.

        Left: compact page list. Center: large preview. Right: controls/output/status.
        This keeps the PDF preview as the main working area instead of pushing it
        down with assignment/output panels.
        """
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(1, weight=1)

        # Light product header, closer to a professional Windows installer/wizard
        self.header = ctk.CTkFrame(self.root, fg_color=HEADER_BG, corner_radius=0, height=96)
        self.header.grid(row=0, column=0, sticky="ew")
        self.header.grid_propagate(False)
        self.header.grid_columnconfigure(1, weight=1)
        self.header.grid_columnconfigure(2, weight=0)
        self.header.grid_columnconfigure(3, weight=0)

        self.logo_frame = ctk.CTkFrame(self.header, fg_color="transparent", corner_radius=0, width=280, height=84)
        self.logo_frame.grid(row=0, column=0, padx=(18, 16), pady=6, sticky="w")
        self.logo_frame.grid_propagate(False)
        self.logo_label = ctk.CTkLabel(
            self.logo_frame,
            text="PacketFlow",
            text_color=CARD_NAVY,
            font=("Segoe UI", 15, "bold"),
        )
        logo_path = APP_DIR / self.settings.get(
            "branding_logo",
            "packetflow-logo.png",
        )
        if logo_path.exists():
            try:
                img = Image.open(logo_path)
                target_w = min(260, img.width)
                target_h = max(1, int(target_w * img.height / img.width))
                if target_h > 68:
                    target_h = 68
                    target_w = max(1, int(target_h * img.width / img.height))
                self.logo_img = ctk.CTkImage(light_image=img, dark_image=img, size=(target_w, target_h))
                self.logo_label.configure(text="", image=self.logo_img)
            except Exception:
                pass
        self.logo_label.pack(expand=True, fill="both")

        title_block = ctk.CTkFrame(self.header, fg_color="transparent")
        title_block.grid(row=0, column=1, sticky="w")
        self.header_title_label = ctk.CTkLabel(
            title_block,
            text=self.settings.get(
                "header_title",
                "Onboarding Document Processor",
            ),
            text_color=CARD_NAVY,
            font=("Segoe UI", 21, "bold"),
        )
        self.header_title_label.pack(anchor="w")
        self.header_subtitle_label = ctk.CTkLabel(
            title_block,
            text=self.settings.get("organization_name", "").strip()
            or "OCR + document classification + review before export",
            text_color="#1D4E89",
            font=("Segoe UI", 13),
        )
        self.header_subtitle_label.pack(anchor="w")

        # Status/progress lives in the header to free the right pane for Output PDFs.
        header_status = ctk.CTkFrame(self.header, fg_color="transparent")
        header_status.grid(row=0, column=2, padx=(12, 14), pady=10, sticky="e")
        header_status.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            header_status,
            textvariable=self.status_var,
            text_color="#1D4E89",
            font=("Segoe UI", 11),
            wraplength=360,
            anchor="e",
            justify="right",
        ).grid(row=0, column=0, columnspan=2, sticky="e", pady=(0, 4))
        self.progress = ctk.CTkProgressBar(
            header_status,
            width=300,
            height=8,
            fg_color="#DDEBF5",
            progress_color=PRODUCT_BLUE,
            corner_radius=4,
        )
        self.progress.grid(row=1, column=0, sticky="ew")
        self.progress.set(0)
        ctk.CTkLabel(
            header_status,
            textvariable=self.progress_label_var,
            text_color=CARD_NAVY,
            font=("Segoe UI", 11, "bold"),
            width=42,
        ).grid(row=1, column=1, padx=(8, 0), sticky="e")
        ctk.CTkLabel(
            header_status,
            textvariable=self.packet_stats_var,
            text_color="#1D4E89",
            font=("Segoe UI", 9),
            wraplength=360,
            anchor="e",
            justify="right",
        ).grid(row=2, column=0, columnspan=2, sticky="e", pady=(3, 0))

        toolbar = ctk.CTkFrame(self.header, fg_color="transparent")
        toolbar.grid(row=0, column=3, padx=(0, 22), pady=18, sticky="e")
        self.open_button = ctk.CTkButton(
            toolbar,
            text="Open Packet",
            command=self.open_packet,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
            text_color="white",
            corner_radius=5,
            height=36,
            width=118,
            font=("Segoe UI", 12, "bold"),
        )
        self.open_button.pack(side="left", padx=(0, 8))
        self.add_files_button = ctk.CTkButton(
            toolbar,
            text="Add Files",
            command=self.add_files,
            fg_color="#F8FAFC",
            hover_color=SUCCESS_GREEN,
            text_color=TEXT,
            border_width=1,
            border_color="#B8C7D8",
            corner_radius=5,
            height=36,
            width=96,
            font=("Segoe UI", 12, "bold"),
        )
        self.add_files_button.pack(side="left", padx=(0, 8))
        self.export_button = ctk.CTkButton(
            toolbar,
            text="Export PDFs",
            command=self.export_pdfs,
            state="disabled",
            fg_color="#F8FAFC",
            hover_color=SUCCESS_GREEN,
            text_color=MUTED,
            border_width=1,
            border_color="#B8C7D8",
            corner_radius=5,
            height=36,
            width=112,
            font=("Segoe UI", 12, "bold"),
        )
        self.export_button.pack(side="left")
        self.review_button = ctk.CTkButton(
            toolbar,
            text="Review Packet",
            command=self.show_packet_review,
            state="disabled",
            fg_color="#F8FAFC",
            hover_color=SUCCESS_GREEN,
            text_color=MUTED,
            border_width=1,
            border_color="#B8C7D8",
            corner_radius=5,
            height=36,
            width=112,
            font=("Segoe UI", 12, "bold"),
        )
        self.review_button.pack(side="left", padx=(8, 0))

        # Main three-column layout. The center preview gets the extra space.
        main = ctk.CTkFrame(self.root, fg_color=APP_BG, corner_radius=0)
        main.grid(row=1, column=0, sticky="nsew", padx=14, pady=12)
        main.grid_columnconfigure(0, weight=0, minsize=252)
        main.grid_columnconfigure(1, weight=1)
        main.grid_columnconfigure(2, weight=0, minsize=340)
        main.grid_rowconfigure(0, weight=1)

        # Compact page list panel
        self.left_card = self.card(main)
        self.left_card.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.left_card.configure(width=252)
        self.left_card.grid_propagate(False)
        self.left_card.grid_rowconfigure(1, weight=1)
        self.left_card.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            self.left_card,
            text="Packet Pages",
            text_color=TEXT,
            font=("Segoe UI", 15, "bold"),
        ).grid(row=0, column=0, sticky="w", padx=10, pady=(9, 5))
        self.pages_scroll = ctk.CTkScrollableFrame(
            self.left_card,
            fg_color=CARD_BG,
            scrollbar_button_color="#CBD5E1",
            scrollbar_button_hover_color="#94A3B8",
        )
        self.pages_scroll.grid(row=1, column=0, sticky="nsew", padx=6, pady=(0, 6))

        # Large center preview. No assignment/output panels below it.
        self.preview_card = self.card(main)
        self.preview_card.grid(row=0, column=1, sticky="nsew", padx=(0, 10))
        self.preview_card.grid_columnconfigure(0, weight=1)
        self.preview_card.grid_columnconfigure(1, weight=0)
        self.preview_card.grid_rowconfigure(1, weight=1)
        top_preview = ctk.CTkFrame(self.preview_card, fg_color="transparent")
        top_preview.grid(row=0, column=0, sticky="ew", padx=12, pady=(9, 7))
        top_preview.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            top_preview,
            text="Page Preview",
            text_color=TEXT,
            font=("Segoe UI", 15, "bold"),
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(
            top_preview,
            textvariable=self.summary_var,
            text_color=MUTED,
            font=("Segoe UI", 11),
        ).grid(row=0, column=1, sticky="e", padx=(0, 10))
        preview_nav = ctk.CTkFrame(top_preview, fg_color="transparent")
        preview_nav.grid(row=0, column=2, sticky="e")
        self.preview_prev_button = ctk.CTkButton(
            preview_nav,
            text="‹",
            width=32,
            height=24,
            command=self.preview_previous_page,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color="#CBD5E1",
            text_color=CARD_NAVY,
            corner_radius=4,
            font=("Segoe UI", 14, "bold"),
        )
        self.preview_prev_button.pack(side="left", padx=(0, 4))
        ctk.CTkLabel(
            preview_nav,
            textvariable=self.preview_nav_var,
            text_color=MUTED,
            font=("Segoe UI", 10),
            width=92,
        ).pack(side="left")
        self.preview_next_button = ctk.CTkButton(
            preview_nav,
            text="›",
            width=32,
            height=24,
            command=self.preview_next_page,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color="#CBD5E1",
            text_color=CARD_NAVY,
            corner_radius=4,
            font=("Segoe UI", 14, "bold"),
        )
        self.preview_next_button.pack(side="left", padx=(4, 0))
        preview_rotation = ctk.CTkFrame(
            top_preview,
            fg_color="transparent",
        )
        preview_rotation.grid(
            row=1,
            column=0,
            columnspan=3,
            pady=(5, 1),
        )
        ctk.CTkButton(
            preview_rotation,
            text="↶",
            command=lambda: self.rotate_selected_pages(-90),
            width=34,
            height=27,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_color="#CBD5E1",
            border_width=1,
            text_color=TEXT,
            corner_radius=5,
            font=("Segoe UI Symbol", 16, "bold"),
        ).pack(side="left", padx=(0, 3))
        ctk.CTkButton(
            preview_rotation,
            text="↷",
            command=lambda: self.rotate_selected_pages(90),
            width=34,
            height=27,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_color="#CBD5E1",
            border_width=1,
            text_color=TEXT,
            corner_radius=5,
            font=("Segoe UI Symbol", 16, "bold"),
        ).pack(side="left", padx=(3, 0))
        ctk.CTkLabel(
            top_preview,
            textvariable=self.packet_filename_var,
            text_color=CARD_NAVY,
            font=("Segoe UI", 11, "bold"),
            anchor="w",
            justify="left",
            wraplength=780,
        ).grid(row=2, column=0, columnspan=3, sticky="ew", pady=(4, 0))
        self.preview_canvas = tk.Canvas(
            self.preview_card,
            background="#EAF2F8",
            highlightthickness=0,
            bd=0,
        )
        self.preview_canvas.grid(row=1, column=0, sticky="nsew", padx=(12, 0), pady=(0, 12))
        preview_scroll_style = ttk.Style()
        preview_scroll_style.configure(
            "Preview.Vertical.TScrollbar",
            background="#CBD5E1",
            troughcolor="#EAF2F8",
            bordercolor="#EAF2F8",
            arrowcolor=CARD_NAVY,
        )
        self.preview_scrollbar = ttk.Scrollbar(
            self.preview_card,
            orient="vertical",
            command=self.preview_canvas.yview,
            style="Preview.Vertical.TScrollbar",
        )
        self.preview_scrollbar.grid(row=1, column=1, sticky="ns", padx=(6, 12), pady=(0, 12))
        self.preview_canvas.configure(yscrollcommand=self.preview_scrollbar.set)
        self.preview_canvas.bind("<Configure>", self.on_preview_resize)
        self.preview_canvas.bind("<MouseWheel>", self.on_preview_mousewheel)
        self.preview_canvas.bind("<Button-4>", self.on_preview_mousewheel)
        self.preview_canvas.bind("<Button-5>", self.on_preview_mousewheel)
        self.root.bind("<Prior>", lambda _event: self.preview_canvas.yview_scroll(-1, "pages"))
        self.root.bind("<Next>", lambda _event: self.preview_canvas.yview_scroll(1, "pages"))
        self.root.bind("<Left>", lambda _event: self.preview_previous_page())
        self.root.bind("<Right>", lambda _event: self.preview_next_page())

        # Right-side task pane, like a Windows setup/utility sidebar.
        right_panel = ctk.CTkFrame(main, fg_color=APP_BG, corner_radius=0)
        right_panel.grid(row=0, column=2, sticky="nsew")
        right_panel.grid_columnconfigure(0, weight=1)
        right_panel.grid_rowconfigure(1, weight=1)

        self.action_card = self.card(right_panel)
        self.action_card.grid(row=0, column=0, sticky="ew")
        self.action_card.grid_columnconfigure(0, weight=1)
        self.action_card.grid_columnconfigure(1, weight=0)
        ctk.CTkLabel(
            self.action_card,
            textvariable=self.action_title_var,
            text_color=TEXT,
            font=("Segoe UI", 15, "bold"),
        ).grid(row=0, column=0, sticky="w", padx=12, pady=(10, 6))
        preferences_link = ctk.CTkLabel(
            self.action_card,
            text="Preferences",
            text_color=PRODUCT_BLUE,
            font=("Segoe UI", 10, "underline"),
            cursor="hand2",
        )
        preferences_link.grid(
            row=0,
            column=1,
            sticky="e",
            padx=(6, 12),
            pady=(10, 6),
        )
        preferences_link.bind(
            "<Button-1>",
            lambda _event: self.show_preferences(),
        )
        ctk.CTkLabel(
            self.action_card,
            text="Document filename",
            text_color=MUTED,
            font=("Segoe UI", 11, "bold"),
        ).grid(row=1, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 4))
        self.document_combo = ctk.CTkComboBox(
            self.action_card,
            variable=self.document_var,
            values=self.rules["document_types"],
            height=34,
            fg_color="white",
            border_color="#CFE0EA",
            button_color=PRODUCT_BLUE,
            button_hover_color="#176FCC",
            dropdown_fg_color="white",
            corner_radius=5,
        )
        self.document_combo.grid(row=2, column=0, columnspan=2, sticky="ew", padx=12, pady=(0, 8))

        button_grid = ctk.CTkFrame(self.action_card, fg_color="transparent")
        button_grid.grid(row=3, column=0, columnspan=2, sticky="ew", padx=12, pady=(0, 12))
        button_grid.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkButton(button_grid, text="Assign to Document", command=self.assign_to_document, fg_color=PRODUCT_BLUE, hover_color="#176FCC", corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        ctk.CTkButton(button_grid, text="Mark Unsorted", command=self.remove_assignments, fg_color="#FFFFFF", hover_color="#FBEAEA", border_color="#8A2020", border_width=1, text_color=WARNING, corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=1, column=0, sticky="ew", padx=(0, 5))
        ctk.CTkButton(button_grid, text="Rename Output", command=self.rename_document, fg_color="#FFFFFF", hover_color="#F8FAFC", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=1, column=1, sticky="ew", padx=(5, 0))
        ctk.CTkButton(button_grid, text="Save Adjustments", command=self.remember_correction, fg_color="#FFFFFF", hover_color="#EEF6FF", border_color=PRODUCT_BLUE, border_width=1, text_color=PRODUCT_BLUE, corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=2, column=0, sticky="ew", padx=(0, 5), pady=(6, 0))
        ctk.CTkButton(button_grid, text="Assignment Details", command=self.show_assignment_reason, fg_color="#FFFFFF", hover_color="#EEF6FF", border_color=PRODUCT_BLUE, border_width=1, text_color=PRODUCT_BLUE, corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=2, column=1, sticky="ew", padx=(5, 0), pady=(6, 0))
        ctk.CTkButton(button_grid, text="Undo Last Change", command=self.undo_last_change, fg_color="#FFFFFF", hover_color="#F8FAFC", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5, height=32, font=("Segoe UI", 11, "bold")).grid(row=3, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        self.watch_button = ctk.CTkButton(button_grid, text="Scanner Folder", command=self.choose_scanner_folder, fg_color="#FFFFFF", hover_color="#EAF7F0", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5, height=32, font=("Segoe UI", 11, "bold"))
        self.watch_button.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        self.watch_folder_label = ctk.CTkLabel(
            button_grid,
            text="Scanner folder watch is off",
            text_color=MUTED,
            font=("Segoe UI", 9),
            anchor="w",
            justify="left",
            wraplength=300,
        )
        self.watch_folder_label.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(3, 0))

        self.output_card = self.card(right_panel)
        self.output_card.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        self.output_card.grid_columnconfigure(0, weight=1)
        self.output_card.grid_rowconfigure(1, weight=1)
        out_header = ctk.CTkFrame(self.output_card, fg_color="transparent")
        out_header.grid(row=0, column=0, sticky="ew", padx=12, pady=(10, 6))
        out_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(out_header, text="Output PDFs", text_color=TEXT, font=("Segoe UI", 15, "bold")).grid(row=0, column=0, sticky="w")
        order_buttons = ctk.CTkFrame(out_header, fg_color="transparent")
        order_buttons.grid(row=0, column=1, sticky="e")
        ctk.CTkButton(order_buttons, text="Up", command=lambda: self.move_document(-1), width=48, height=28, fg_color="#FFFFFF", hover_color="#F8FAFC", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5).pack(side="left", padx=(0, 5))
        ctk.CTkButton(order_buttons, text="Down", command=lambda: self.move_document(1), width=64, height=28, fg_color="#FFFFFF", hover_color="#F8FAFC", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5).pack(side="left")
        self.output_scroll = ctk.CTkScrollableFrame(
            self.output_card,
            fg_color=CARD_BG,
            scrollbar_button_color="#CBD5E1",
            scrollbar_button_hover_color="#94A3B8",
        )
        self.output_scroll.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 8))


    def card(self, parent):
        return ctk.CTkFrame(parent, fg_color=CARD_BG, corner_radius=10, border_width=1, border_color=BORDER)

    def open_packet(self):
        selected = filedialog.askopenfilename(
            title="Choose a packet",
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")],
        )
        if not selected:
            return
        self.load_packet(Path(selected))

    def add_files(self):
        if self.analyzing:
            messagebox.showinfo(
                APP_TITLE,
                "Wait for the current analysis to finish before adding files.",
            )
            return
        selected = filedialog.askopenfilenames(
            title=(
                "Add files to the current packet"
                if self.reader
                else "Choose files for an ad hoc packet"
            ),
            filetypes=[
                (
                    "Supported documents and images",
                    " ".join(f"*{extension}" for extension in sorted(
                        SUPPORTED_INPUT_EXTENSIONS
                    )),
                ),
                ("PDF files", "*.pdf"),
                (
                    "Image files",
                    "*.png *.jpg *.jpeg *.jfif *.bmp *.tif *.tiff *.gif *.webp",
                ),
                (
                    "Office documents",
                    "*.doc *.docx *.rtf *.odt *.html *.htm "
                    "*.xls *.xlsx *.xlsm *.ods *.ppt *.pptx *.odp",
                ),
                ("Text files", "*.txt *.log *.csv *.md"),
                ("All files", "*.*"),
            ],
        )
        if selected:
            self.add_file_paths([Path(path) for path in selected])

    @staticmethod
    def image_frame_to_rgb(frame: Image.Image) -> Image.Image:
        frame = ImageOps.exif_transpose(frame)
        if frame.mode in ("RGBA", "LA") or (
            frame.mode == "P" and "transparency" in frame.info
        ):
            rgba = frame.convert("RGBA")
            background = Image.new("RGB", rgba.size, "white")
            background.paste(rgba, mask=rgba.getchannel("A"))
            return background
        return frame.convert("RGB")

    def convert_image_to_pdf(self, source: Path, destination: Path):
        with Image.open(source) as image:
            frames = [
                self.image_frame_to_rgb(frame.copy())
                for frame in ImageSequence.Iterator(image)
            ]
        if not frames:
            raise ValueError(f"{source.name} does not contain a readable image.")
        frames[0].save(
            destination,
            "PDF",
            resolution=150,
            save_all=True,
            append_images=frames[1:],
        )

    @staticmethod
    def load_text_font(size: int = 24):
        for font_path in (
            Path(os.environ.get("WINDIR", r"C:\Windows"))
            / "Fonts"
            / "segoeui.ttf",
            Path(os.environ.get("WINDIR", r"C:\Windows"))
            / "Fonts"
            / "arial.ttf",
        ):
            if font_path.exists():
                try:
                    return ImageFont.truetype(str(font_path), size)
                except Exception:
                    pass
        return ImageFont.load_default()

    def convert_text_to_pdf(self, source: Path, destination: Path):
        raw = source.read_bytes()
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = raw.decode("cp1252", errors="replace")
        font = self.load_text_font()
        page_size = (1275, 1650)
        margin = 90
        line_height = 34
        lines_per_page = max(1, (page_size[1] - margin * 2) // line_height)
        wrapped_lines: list[str] = []
        for original_line in text.expandtabs(4).splitlines() or [""]:
            wrapped = textwrap.wrap(
                original_line,
                width=95,
                replace_whitespace=False,
                drop_whitespace=False,
            )
            wrapped_lines.extend(wrapped or [""])
        pages = []
        for offset in range(0, max(len(wrapped_lines), 1), lines_per_page):
            page = Image.new("RGB", page_size, "white")
            draw = ImageDraw.Draw(page)
            for row, line in enumerate(
                wrapped_lines[offset : offset + lines_per_page]
            ):
                draw.text(
                    (margin, margin + row * line_height),
                    line,
                    fill="black",
                    font=font,
                )
            pages.append(page)
        pages[0].save(
            destination,
            "PDF",
            resolution=150,
            save_all=True,
            append_images=pages[1:],
        )

    @staticmethod
    def libreoffice_path() -> str | None:
        return find_program(
            "soffice.exe",
            [
                r"C:\Program Files\LibreOffice\program\soffice.exe",
                r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
            ],
        )

    def convert_office_with_microsoft(
        self,
        source: Path,
        destination: Path,
    ) -> bool:
        script_path = destination.parent / "convert-with-office.ps1"
        script_path.write_text(
            r'''param(
    [Parameter(Mandatory=$true)][string]$Source,
    [Parameter(Mandatory=$true)][string]$Destination,
    [Parameter(Mandatory=$true)][string]$Kind
)
$ErrorActionPreference = "Stop"
if ($Kind -eq "word") {
    $app = New-Object -ComObject Word.Application
    $app.Visible = $false
    $app.DisplayAlerts = 0
    try {
        $document = $app.Documents.Open($Source, $false, $true)
        try { $document.ExportAsFixedFormat($Destination, 17) }
        finally { $document.Close($false) }
    } finally { $app.Quit() }
}
elseif ($Kind -eq "spreadsheet") {
    $app = New-Object -ComObject Excel.Application
    $app.Visible = $false
    $app.DisplayAlerts = $false
    try {
        $workbook = $app.Workbooks.Open($Source, 0, $true)
        try { $workbook.ExportAsFixedFormat(0, $Destination) }
        finally { $workbook.Close($false) }
    } finally { $app.Quit() }
}
elseif ($Kind -eq "presentation") {
    $app = New-Object -ComObject PowerPoint.Application
    try {
        $presentation = $app.Presentations.Open($Source, $true, $true, $false)
        try { $presentation.SaveAs($Destination, 32) }
        finally { $presentation.Close() }
    } finally { $app.Quit() }
}
else { throw "Unsupported Microsoft Office conversion type." }
''',
            encoding="utf-8",
        )
        extension = source.suffix.lower()
        if extension in WORD_INPUT_EXTENSIONS:
            kind = "word"
        elif extension in SPREADSHEET_INPUT_EXTENSIONS:
            kind = "spreadsheet"
        else:
            kind = "presentation"
        result = subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(script_path),
                "-Source",
                str(source.resolve()),
                "-Destination",
                str(destination.resolve()),
                "-Kind",
                kind,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            timeout=120,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return (
            result.returncode == 0
            and destination.exists()
            and destination.stat().st_size > 0
        )

    def convert_office_to_pdf(self, source: Path, destination: Path):
        try:
            if self.convert_office_with_microsoft(source, destination):
                return
        except Exception:
            pass
        libreoffice = self.libreoffice_path()
        if libreoffice:
            result = subprocess.run(
                [
                    libreoffice,
                    "--headless",
                    "--convert-to",
                    "pdf",
                    "--outdir",
                    str(destination.parent),
                    str(source.resolve()),
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=120,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            generated = destination.parent / f"{source.stem}.pdf"
            if result.returncode == 0 and generated.exists():
                if generated != destination:
                    generated.replace(destination)
                return
        raise OfficeConverterUnavailable(
            f"{source.name} requires Microsoft Office or LibreOffice "
            "to convert it into a PDF."
        )

    def convert_input_to_pdf(
        self,
        source: Path,
        conversion_dir: Path,
        sequence: int,
    ) -> Path:
        extension = source.suffix.lower()
        if extension == ".pdf":
            PdfReader(str(source))
            return source
        destination = conversion_dir / f"{sequence:03d}-{source.stem}.pdf"
        if extension in IMAGE_INPUT_EXTENSIONS:
            self.convert_image_to_pdf(source, destination)
        elif extension in TEXT_INPUT_EXTENSIONS:
            self.convert_text_to_pdf(source, destination)
        elif extension in (
            WORD_INPUT_EXTENSIONS
            | SPREADSHEET_INPUT_EXTENSIONS
            | PRESENTATION_INPUT_EXTENSIONS
        ):
            self.convert_office_to_pdf(source, destination)
        else:
            raise ValueError(f"{source.name} is not a supported file type.")
        return destination

    def offer_office_converter_install(self):
        install = messagebox.askyesno(
            APP_TITLE,
            "Microsoft Office or LibreOffice is required to add this file type.\n\n"
            "Would you like to install LibreOffice now?\n\n"
            "After installation finishes, use Add Files again.",
        )
        if not install:
            return
        winget = shutil.which("winget.exe") or shutil.which("winget")
        if winget:
            try:
                subprocess.Popen(
                    [
                        winget,
                        "install",
                        "--id",
                        "TheDocumentFoundation.LibreOffice",
                        "--exact",
                        "--accept-package-agreements",
                        "--accept-source-agreements",
                    ],
                    creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0),
                )
                return
            except Exception:
                pass
        webbrowser.open("https://www.libreoffice.org/download/download-libreoffice/")

    def add_file_paths(self, selected_paths: list[Path]):
        if self.analyzing:
            messagebox.showinfo(
                APP_TITLE,
                "Wait for the current analysis to finish before adding files.",
            )
            return
        new_paths = [
            Path(path)
            for path in selected_paths
            if (
                Path(path).is_file()
                and Path(path).suffix.lower() in SUPPORTED_INPUT_EXTENSIONS
            )
        ]
        if not new_paths:
            messagebox.showwarning(
                APP_TITLE,
                "Choose at least one supported PDF, image, text, or Office file.",
            )
            return

        existing_page_count = len(self.reader.pages) if self.reader else 0

        source_paths = list(self.packet_source_paths) if self.reader else []
        source_paths.extend(new_paths)
        if not source_paths:
            source_paths = new_paths

        manual_dir = Path(tempfile.mkdtemp(prefix="packetflow_manual_"))
        conversion_dir = manual_dir / "converted"
        conversion_dir.mkdir()
        if self.reader:
            base_stem = self.packet_base_stem or self.current_packet_stem()
            added_count = max(len(source_paths) - 1, len(new_paths))
            display_name = (
                f"{base_stem} + {added_count} added file"
                + ("" if added_count == 1 else "s")
            )
        elif len(new_paths) == 1:
            base_stem = new_paths[0].stem
            display_name = new_paths[0].name
        else:
            base_stem = new_paths[0].stem
            display_name = (
                f"{new_paths[0].stem} + {len(new_paths) - 1} more files"
            )
        combined_path = manual_dir / safe_filename(display_name)
        added_pages_path = manual_dir / "newly-added-pages.pdf"
        source_page_ranges: list[tuple[int, int]] = []

        try:
            writer = PdfWriter()
            added_writer = PdfWriter()
            if self.reader:
                for page in self.reader.pages:
                    writer.add_page(copy.deepcopy(page))
            for sequence, path in enumerate(new_paths, start=1):
                converted_path = self.convert_input_to_pdf(
                    path,
                    conversion_dir,
                    sequence,
                )
                reader = PdfReader(str(converted_path))
                range_start = len(added_writer.pages)
                for page in reader.pages:
                    copied_page = copy.deepcopy(page)
                    writer.add_page(copied_page)
                    added_writer.add_page(copy.deepcopy(page))
                source_page_ranges.append(
                    (range_start, len(added_writer.pages))
                )
            if not writer.pages:
                raise ValueError("The selected files do not contain any pages.")
            if not added_writer.pages:
                raise ValueError(
                    "The newly selected files do not contain any pages."
                )
            with combined_path.open("wb") as handle:
                writer.write(handle)
            with added_pages_path.open("wb") as handle:
                added_writer.write(handle)
        except OfficeConverterUnavailable as exc:
            shutil.rmtree(manual_dir, ignore_errors=True)
            messagebox.showwarning(APP_TITLE, str(exc))
            self.offer_office_converter_install()
            return
        except Exception as exc:
            shutil.rmtree(manual_dir, ignore_errors=True)
            messagebox.showerror(
                APP_TITLE,
                "The selected files could not be added.\n\n" + str(exc),
            )
            return

        if self.reader and existing_page_count:
            self.start_incremental_analysis(
                added_pages_path=added_pages_path,
                combined_path=combined_path,
                manual_dir=manual_dir,
                source_paths=source_paths,
                display_name=display_name,
                base_stem=base_stem,
                source_page_ranges=source_page_ranges,
            )
        else:
            self.load_packet(
                combined_path,
                source_paths=source_paths,
                display_name=display_name,
                base_stem=base_stem,
                manual_packet_dir=manual_dir,
            )

    @staticmethod
    def inherit_added_file_assignments(
        assignments: list[Assignment],
        blank_pages: set[int],
        source_page_ranges: list[tuple[int, int]],
        rotations: list[int],
    ) -> list[Assignment]:
        updated = list(assignments)
        for range_start, range_end in source_page_ranges:
            pages = [
                page
                for page in range(range_start, range_end)
                if page not in blank_pages
            ]
            assigned_documents = {
                item.document
                for item in updated
                if range_start <= item.page_index < range_end
            }
            allowed_documents: set[str] | None = None
            if len(assigned_documents) == 1:
                allowed_documents = assigned_documents
            elif assigned_documents == {
                "Banking.pdf",
                "Viventium Direct Deposit.pdf",
            }:
                allowed_documents = assigned_documents
            if not allowed_documents:
                continue
            assigned_pages = {
                item.page_index
                for item in updated
                if range_start <= item.page_index < range_end
            }
            for page in pages:
                if page in assigned_pages:
                    continue
                for document in allowed_documents:
                    updated.append(
                        Assignment(
                            page,
                            document,
                            rotations[page],
                            None,
                        )
                    )
        return updated

    def start_incremental_analysis(
        self,
        added_pages_path: Path,
        combined_path: Path,
        manual_dir: Path,
        source_paths: list[Path],
        display_name: str,
        base_stem: str,
        source_page_ranges: list[tuple[int, int]],
    ):
        if self.analyzing or not self.reader:
            return
        old_page_count = len(self.reader.pages)
        old_manual_dir = self.manual_packet_dir
        append_work_dir = Path(
            tempfile.mkdtemp(prefix="packetflow_added_pages_")
        )
        self.analyzing = True
        self.set_busy(True)
        self.progress_var.set(0)
        self.progress.set(0)
        self.progress_label_var.set("0%")
        self.status_var.set("Analyzing newly added pages only...")

        def worker():
            try:
                def progress(value, text, page_index=None):
                    global_index = (
                        old_page_count + page_index
                        if page_index is not None
                        else None
                    )
                    self.worker_queue.put(
                        (
                            "progress",
                            value,
                            text.replace(
                                "packet pages",
                                "newly added pages",
                            ),
                            global_index,
                        )
                    )

                (
                    page_images,
                    ocr_texts,
                    assignments,
                    rotations,
                    blank_pages,
                    fingerprints,
                ) = self.analyzer.analyze(
                    added_pages_path,
                    append_work_dir,
                    progress,
                )
                assignments = self.inherit_added_file_assignments(
                    assignments,
                    blank_pages,
                    source_page_ranges,
                    rotations,
                )
                if self.setting_enabled("apply_remembered_corrections"):
                    assignments, memory_pages = self.apply_correction_memory(
                        ocr_texts,
                        assignments,
                        rotations,
                        blank_pages,
                    )
                else:
                    memory_pages = set()
                combined_reader = PdfReader(str(combined_path))
                self.worker_queue.put(
                    (
                        "append_complete",
                        {
                            "old_page_count": old_page_count,
                            "combined_path": combined_path,
                            "combined_reader": combined_reader,
                            "manual_dir": manual_dir,
                            "old_manual_dir": old_manual_dir,
                            "source_paths": source_paths,
                            "display_name": display_name,
                            "base_stem": base_stem,
                            "append_work_dir": append_work_dir,
                            "page_images": page_images,
                            "ocr_texts": ocr_texts,
                            "assignments": assignments,
                            "rotations": rotations,
                            "blank_pages": blank_pages,
                            "fingerprints": fingerprints,
                            "memory_pages": memory_pages,
                        },
                    )
                )
            except Exception:
                self.worker_queue.put(
                    (
                        "append_error",
                        traceback.format_exc(),
                        manual_dir,
                        append_work_dir,
                    )
                )

        threading.Thread(target=worker, daemon=True).start()

    def load_packet(
        self,
        selected: Path,
        from_watch: bool = False,
        source_paths: list[Path] | None = None,
        display_name: str | None = None,
        base_stem: str | None = None,
        manual_packet_dir: Path | None = None,
        preserved_state: dict | None = None,
    ):
        selected = Path(selected)
        if not selected.is_file() or selected.suffix.lower() != ".pdf":
            messagebox.showwarning(APP_TITLE, "Choose a valid PDF packet.")
            return
        try:
            reader = PdfReader(str(selected))
        except Exception as exc:
            if manual_packet_dir:
                shutil.rmtree(manual_packet_dir, ignore_errors=True)
            messagebox.showerror(APP_TITLE, f"Could not open that PDF:\n\n{exc}")
            return
        if self.pdf_path or self.reader or self.page_images or self.assignments:
            self.clear_loaded_packet("Loading the new packet...")
        self.pdf_path = selected
        self.reader = reader
        self.packet_source_paths = list(source_paths or [selected])
        self.packet_display_name = display_name or selected.name
        self.packet_base_stem = base_stem or selected.stem
        self.manual_packet_dir = manual_packet_dir
        self.pending_append_state = preserved_state
        self.export_packet_name = None
        self.packet_exported = False
        self.current_packet_from_watch = from_watch
        source_label = (
            ", ".join(path.name for path in self.packet_source_paths)
            if len(self.packet_source_paths) > 1
            else self.packet_display_name
        )
        self.packet_filename_var.set(f"Packet file(s): {source_label}")
        self.root.title(f"{self.packet_display_name} - {APP_TITLE}")
        self.status_var.set(
            f"Loaded {self.packet_display_name} ({len(self.reader.pages)} pages)."
        )
        self.start_analysis()

    def start_analysis(self):
        if not self.pdf_path or self.analyzing:
            return
        self.analyzing = True
        self.set_busy(True)
        self.progress_var.set(0)
        self.progress.set(0)
        self.progress_label_var.set("0%")
        self.assignments.clear(); self.page_images.clear(); self.ocr_texts.clear(); self.page_rotations.clear(); self.page_manual_rotations.clear(); self.blank_pages.clear(); self.page_fingerprints.clear()
        self.duplicate_pairs.clear(); self.low_confidence_pages.clear(); self.memory_applied_pages.clear()
        self.undo_stack.clear()
        self.selected_pages.clear(); self.selected_document = None; self.preview_page_position = 0
        self.clear_preview_cache()
        self.summary_var.set("Analyzing packet...")
        self.show_analyzing_placeholders()
        self.refresh_output_cards()
        self.refresh_preview()
        if self.work_dir and self.work_dir.exists():
            shutil.rmtree(self.work_dir, ignore_errors=True)
        for directory in self.additional_work_dirs:
            if directory.exists():
                shutil.rmtree(directory, ignore_errors=True)
        self.additional_work_dirs.clear()
        self.work_dir = Path(tempfile.mkdtemp(prefix="onboarding_packet_"))

        def worker():
            try:
                def progress(value, text, page_index=None):
                    self.worker_queue.put(("progress", value, text, page_index))
                result = self.analyzer.analyze(self.pdf_path, self.work_dir, progress)
                (
                    page_images,
                    ocr_texts,
                    assignments,
                    rotations,
                    blank_pages,
                    fingerprints,
                ) = result
                if self.setting_enabled("apply_remembered_corrections"):
                    assignments, memory_pages = self.apply_correction_memory(
                        ocr_texts,
                        assignments,
                        rotations,
                        blank_pages,
                    )
                else:
                    memory_pages = set()
                duplicates = (
                    self.find_duplicate_pairs(
                        ocr_texts,
                        fingerprints,
                        blank_pages,
                    )
                    if self.setting_enabled("show_duplicate_warnings")
                    else []
                )
                low_confidence = (
                    self.calculate_low_confidence_pages(
                        ocr_texts,
                        assignments,
                    )
                    if self.setting_enabled("show_low_confidence_warnings")
                    else set()
                )
                self.worker_queue.put(
                    (
                        "complete",
                        (
                            page_images,
                            ocr_texts,
                            assignments,
                            rotations,
                            blank_pages,
                            fingerprints,
                            duplicates,
                            low_confidence,
                            memory_pages,
                        ),
                    )
                )
            except Exception:
                self.worker_queue.put(("error", traceback.format_exc()))
        threading.Thread(target=worker, daemon=True).start()

    def show_analyzing_placeholders(self):
        self.clear_frame(self.pages_scroll)
        self.page_status_widgets.clear()
        if not self.reader:
            return
        for index in range(len(self.reader.pages)):
            self.add_page_card(index, "Analyzing...", "reading")

    def poll_worker_queue(self):
        poll_delay = 50 if self.analyzing else 120
        try:
            while True:
                message = self.worker_queue.get_nowait()
                kind = message[0]
                if kind == "progress":
                    value = message[1]
                    self.progress_var.set(value)
                    self.progress.set(max(0, min(1, value / 100)))
                    self.progress_label_var.set(f"{int(value)}%")
                    self.status_var.set(message[2])
                    # Match the original app behavior: each page changes from
                    # "Analyzing..." to "Read" as soon as that individual OCR
                    # worker finishes. Do not rebuild the full page list here;
                    # only update the one card that completed so the UI stays responsive.
                    if len(message) > 3 and message[3] is not None:
                        self.set_page_card_status(int(message[3]), "Read", "read")
                elif kind == "complete":
                    (
                        self.page_images,
                        self.ocr_texts,
                        self.assignments,
                        self.page_rotations,
                        self.blank_pages,
                        self.page_fingerprints,
                        self.duplicate_pairs,
                        self.low_confidence_pages,
                        self.memory_applied_pages,
                    ) = message[1]
                    self.page_manual_rotations = [0] * len(self.page_rotations)
                    if self.pending_append_state:
                        preserved = self.pending_append_state
                        old_count = int(preserved.get("page_count", 0))
                        old_assignments = preserved.get("assignments", [])
                        self.assignments = [
                            item
                            for item in self.assignments
                            if item.page_index >= old_count
                        ] + old_assignments
                        self.blank_pages = {
                            page for page in self.blank_pages if page >= old_count
                        } | set(preserved.get("blank_pages", set()))
                        old_manual_rotations = list(
                            preserved.get("manual_rotations", [])
                        )
                        for index, rotation in enumerate(old_manual_rotations):
                            if index < len(self.page_manual_rotations):
                                self.page_manual_rotations[index] = rotation
                        self.document_order = list(
                            preserved.get("document_order", [])
                        )
                        self.custom_document_types = set(
                            preserved.get("custom_document_types", set())
                        )
                        self.pending_append_state = None
                    else:
                        self.document_order = []
                    self.sync_document_order()
                    self.analyzing = False
                    self.set_busy(False)
                    self.progress_var.set(100); self.progress.set(1); self.progress_label_var.set("100%")
                    grouped_count = len(self.grouped_assignments())
                    merged_file_count = len(
                        {
                            assignment.page_index
                            for assignment in self.assignments
                            if assignment.page_index not in self.blank_pages
                        }
                    )
                    self.status_var.set(
                        f"Merged {merged_file_count} files into "
                        f"{grouped_count} Output PDFs."
                    )
                    self.notify_user(
                        "Packet Ready for Review",
                        (
                            f"{self.packet_display_name or (self.pdf_path.name if self.pdf_path else 'A packet')} "
                            f"was merged into {grouped_count} Output PDFs."
                        ),
                    )
                    self.update_summary()
                    self.refresh_all_views()
                    if self.page_images:
                        self.selected_pages = {0}
                        self.refresh_page_cards()
                        self.on_page_selected()
                    if (
                        self.current_packet_from_watch
                        and self.setting_enabled(
                            "automatically_export_scanner_packets"
                        )
                    ):
                        self.root.after(
                            150,
                            lambda: self.export_pdfs(automatic=True),
                        )
                elif kind == "append_complete":
                    result = message[1]
                    old_page_count = result["old_page_count"]
                    shifted_assignments = [
                        Assignment(
                            item.page_index + old_page_count,
                            item.document,
                            item.rotation,
                            item.sequence,
                        )
                        for item in result["assignments"]
                    ]
                    shifted_blank_pages = {
                        page + old_page_count
                        for page in result["blank_pages"]
                    }
                    shifted_memory_pages = {
                        page + old_page_count
                        for page in result["memory_pages"]
                    }
                    self.pdf_path = result["combined_path"]
                    self.reader = result["combined_reader"]
                    self.packet_source_paths = list(result["source_paths"])
                    self.packet_display_name = result["display_name"]
                    self.packet_base_stem = result["base_stem"]
                    self.manual_packet_dir = result["manual_dir"]
                    self.packet_exported = False
                    self.current_packet_from_watch = False
                    self.page_images.extend(result["page_images"])
                    self.ocr_texts.extend(result["ocr_texts"])
                    self.page_rotations.extend(result["rotations"])
                    self.page_manual_rotations.extend(
                        [0] * len(result["rotations"])
                    )
                    self.page_fingerprints.extend(result["fingerprints"])
                    self.assignments.extend(shifted_assignments)
                    self.blank_pages.update(shifted_blank_pages)
                    self.memory_applied_pages.update(shifted_memory_pages)
                    self.additional_work_dirs.append(
                        result["append_work_dir"]
                    )
                    old_manual_dir = result.get("old_manual_dir")
                    if (
                        old_manual_dir
                        and old_manual_dir != self.manual_packet_dir
                        and old_manual_dir.exists()
                    ):
                        shutil.rmtree(old_manual_dir, ignore_errors=True)
                        if old_manual_dir.exists():
                            self.retired_manual_dirs.append(old_manual_dir)

                    self.duplicate_pairs = (
                        self.find_duplicate_pairs(
                            self.ocr_texts,
                            self.page_fingerprints,
                            self.blank_pages,
                        )
                        if self.setting_enabled("show_duplicate_warnings")
                        else []
                    )
                    self.low_confidence_pages = (
                        self.calculate_low_confidence_pages(
                            self.ocr_texts,
                            self.assignments,
                        )
                        if self.setting_enabled(
                            "show_low_confidence_warnings"
                        )
                        else set()
                    )
                    self.sync_document_order()
                    self.undo_stack.clear()
                    self.analyzing = False
                    self.set_busy(False)
                    self.progress_var.set(100)
                    self.progress.set(1)
                    self.progress_label_var.set("100%")
                    added_count = len(result["ocr_texts"])
                    self.packet_filename_var.set(
                        "Packet file(s): "
                        + ", ".join(
                            path.name
                            for path in self.packet_source_paths
                        )
                    )
                    self.root.title(
                        f"{self.packet_display_name} - {APP_TITLE}"
                    )
                    self.status_var.set(
                        f"Added and analyzed {added_count} new page"
                        + ("" if added_count == 1 else "s")
                        + "; existing pages were not re-analyzed."
                    )
                    self.update_summary()
                    self.clear_preview_cache()
                    self.refresh_all_views()
                    if added_count:
                        self.selected_document = None
                        self.selected_pages = {old_page_count}
                        self.preview_page_position = 0
                        self.refresh_page_cards()
                        self.on_page_selected()
                elif kind == "append_error":
                    self.analyzing = False
                    self.set_busy(False)
                    self.progress_var.set(0)
                    self.progress.set(0)
                    self.progress_label_var.set("0%")
                    shutil.rmtree(message[2], ignore_errors=True)
                    shutil.rmtree(message[3], ignore_errors=True)
                    self.status_var.set(
                        "The added files could not be analyzed."
                    )
                    messagebox.showerror(
                        APP_TITLE,
                        "The added files could not be analyzed.\n\n"
                        + message[1],
                    )
                elif kind == "error":
                    self.analyzing = False
                    self.set_busy(False)
                    self.progress_var.set(0); self.progress.set(0); self.progress_label_var.set("0%")
                    self.status_var.set("Analysis failed.")
                    self.summary_var.set("Analysis failed")
                    messagebox.showerror(APP_TITLE, "The packet could not be analyzed.\n\n" + message[1])
        except queue.Empty:
            pass
        self.root.after(poll_delay, self.poll_worker_queue)

    def set_busy(self, busy: bool):
        self.open_button.configure(state="disabled" if busy else "normal")
        if hasattr(self, "add_files_button"):
            self.add_files_button.configure(state="disabled" if busy else "normal")
        can_export = (not busy and bool(self.assignments))
        self.export_button.configure(
            state="normal" if can_export else "disabled",
            fg_color="#F8FAFC" if can_export else "#E9EEF5",
            text_color=TEXT if can_export else MUTED,
        )
        self.review_button.configure(
            state="normal" if can_export else "disabled",
            text_color=TEXT if can_export else MUTED,
        )

    def expected_indicators_for_document(self, document: str) -> list[tuple[str, list[str]]]:
        """Return user-facing expected indicators for confidence explanations.

        Each tuple is (display name, OCR phrases). The display name is what staff
        see in Assignment Details; phrases are the words PacketFlow looks
        for in OCR text. These are intentionally business-document indicators,
        not scan-quality warnings, so the user sees what was missing.
        """
        doc = safe_filename(document).lower()
        mapping: dict[str, list[tuple[str, list[str]]]] = {
            "job application.pdf": [
                ("Job application heading", ["job application"]),
                ("Employee availability sheet", ["employee availability sheet"]),
                ("Work reference section", ["work reference", "personal references"]),
                ("Employment/handbook acknowledgement", ["handbook acknowledgement", "acknowledges receipt", "employee handbook"]),
                ("Compensation agreement", ["compensation agreement", "non-exempt compensation agreement"]),
                ("Job description / duties acknowledgement", ["job description", "duties and responsibilities"]),
            ],
            "form i-9 employment eligibility verification.pdf": [
                ("Form I-9 heading", ["form i-9", "employment eligibility verification"]),
                ("Department of Homeland Security / USCIS wording", ["department of homeland security", "citizenship and immigration services", "uscis"]),
                ("Employee information / attestation area", ["employee information", "employee attestation", "citizenship or immigration status"]),
                ("Employer review / verification area", ["employer review", "authorized representative", "document title"]),
                ("Supporting identity/work document", ["driver's license", "drivers license", "social security", "passport", "permanent resident", "employment authorization"]),
            ],
            "mbc authorization.pdf": [
                ("Maine Background Check Center wording", ["maine background check center", "background check center"]),
                ("Authorization and release wording", ["authorization and release", "authorization release"]),
                ("Applicant signature area", ["signature of applicant", "applicant signature"]),
            ],
            "child protective services authorization.pdf": [
                ("Child protective services wording", ["child protective services", "child abuse and neglect"]),
                ("Authorization/release wording", ["authorization release", "authorization and release"]),
                ("Child and family services wording", ["child and family services"]),
            ],
            "confirmation - child abuse registry background check request.pdf": [
                ("Child abuse background check confirmation", ["child abuse background check confirmation"]),
                ("Registry/background check request wording", ["registry", "background check request"]),
            ],
            "orientation agenda.pdf": [
                ("Orientation agenda heading", ["orientation agenda"]),
                ("Welcome/congratulations wording", ["welcome to our team", "congratulations"]),
            ],
            "time recording.pdf": [
                ("Recording of time worked heading", ["recording of time worked"]),
                ("Time worked / timesheet wording", ["time worked", "timesheet", "time recording"]),
            ],
            "interview statement.pdf": [
                ("Interview statement heading", ["interview statement"]),
                ("Interviewed by field", ["interviewed by"]),
                ("Strengths/weaknesses questions", ["what are your strengths", "what are your weaknesses"]),
            ],
            "federal w-4 withholding.pdf": [
                ("Form W-4 heading", ["form w-4", "employee's withholding certificate", "employee’s withholding certificate"]),
                ("IRS/Treasury wording", ["internal revenue", "treasury"]),
                ("Multiple jobs / worksheet area", ["multiple jobs worksheet", "step 2"]),
            ],
            "payroll.pdf": [
                ("Maine W-4ME / payroll form", ["w-4me", "withholding allowance certificate", "payroll"]),
                ("Employee/tax withholding wording", ["employee", "withholding"]),
            ],
            "viventium direct deposit.pdf": [
                ("Direct deposit wording", ["direct deposit"]),
                ("Viventium payroll wording", ["viventium"]),
                ("Authorization/agreement wording", ["authorization agreement", "direct deposit authorization"]),
            ],
            "banking.pdf": [
                ("Banking/check evidence", ["routing number", "voided check", "checking account", "savings account", "pay to the", "linked banking/check page"]),
            ],
            "cherkr authorization.pdf": [
                ("CHERKR / consumer report wording", ["cherkr", "consumer report"]),
                ("Candidate disclosure wording", ["candidate disclosure"]),
            ],
            "auto enrollment opt out.pdf": [
                ("Auto enrollment wording", ["auto enrol", "auto enrollment"]),
                ("Opt-out wording", ["opt out", "opt-out"]),
            ],
            "employee choice acknowledgement waiver.pdf": [
                ("Waiver / employee choice wording", ["waiver", "employee choice"]),
                ("Decline coverage wording", ["decline all coverage", "decline coverage"]),
            ],
            "birth and marriage certificates.pdf": [
                ("Birth or marriage certificate wording", ["certificate of live birth", "certificate of marriage", "vital records"]),
            ],
        }
        return mapping.get(doc, [])

    def i9_confidence_indicators_for_text(self, normalized_text: str) -> list[tuple[str, list[str]]]:
        """Use the right confidence checklist for either I-9 forms or I-9 IDs.

        I-9 exports often contain pages that are not the I-9 form itself:
        driver's licenses, Social Security cards, passports, and other accepted
        identity/work-authorization documents. Those supporting pages should not
        lose confidence just because they do not contain I-9 form wording.
        """
        form_indicators = [
            ("Form I-9 heading", ["form i-9", "employment eligibility verification"]),
            ("Department of Homeland Security / USCIS wording", ["department of homeland security", "citizenship and immigration services", "uscis"]),
            ("Employee information / attestation area", ["employee information", "employee attestation", "citizenship or immigration status"]),
            ("Employer review / verification area", ["employer review", "authorized representative", "document title"]),
        ]

        def has_any(phrases: tuple[str, ...]) -> bool:
            return any(phrase in normalized_text for phrase in phrases)

        has_i9_form_evidence = (
            "form i-9" in normalized_text
            or "employment eligibility verification" in normalized_text
            or (
                "department of homeland security" in normalized_text
                and has_any((
                    "employee attestation",
                    "employer review",
                    "authorized representative",
                ))
            )
        )
        if has_i9_form_evidence:
            return form_indicators

        support_indicators: list[tuple[str, list[str]]] = []

        license_details = (
            "dl. no",
            "class",
            "expires",
            "issued",
            "endorsements",
            "restrictions",
        )
        license_detail_count = sum(
            detail in normalized_text for detail in license_details
        )
        has_license_heading = has_any((
            "driver's license",
            "driver'slicense",
            "driver'siicense",
            "drivers license",
            "driver licence",
            "driver's licence",
            "permis de conduire",
        ))
        has_ocr_tolerant_license_evidence = (
            license_detail_count >= 3
            and has_any((
                "not intended for federal",
                "motor vehicles",
                "class:",
                "gender",
                "height",
                "eyes",
            ))
        )
        if (
            (has_license_heading and license_detail_count >= 1)
            or has_ocr_tolerant_license_evidence
        ):
            license_identity_phrases = [
                "driver's license",
                "drivers license",
                "driver licence",
                "driver's licence",
                "permis de conduire",
            ]
            if has_ocr_tolerant_license_evidence:
                license_identity_phrases.extend(
                    [
                        "not intended for federal",
                        "motor vehicles",
                        "class:",
                        "gender",
                    ]
                )
            support_indicators.extend(
                [
                    ("Driver's license / state ID", license_identity_phrases),
                    ("License details", list(license_details)),
                ]
            )

        if (
            "social security administration" in normalized_text
            or (
                ("social security" in normalized_text or "ocial secur" in normalized_text)
                and ("signature" in normalized_text or "established" in normalized_text)
            )
        ) and not has_any((
            "not valid for employment",
            "valid for work only with ins authorization",
            "valid for work only with dhs authorization",
        )):
            support_indicators.extend(
                [
                    ("Social Security card", ["social security", "social security administration", "ocial secur"]),
                    ("Social Security card detail", ["signature", "established", "administration"]),
                ]
            )

        passport_details = (
            "nationality",
            "passport no",
            "passport number",
            "date of expiry",
            "date of expiration",
            "expiration date",
            "issuing country",
            "place of birth",
        )
        if "passport" in normalized_text and has_any(passport_details):
            support_indicators.extend(
                [
                    ("Passport", ["passport", "passport card"]),
                    ("Passport detail", list(passport_details)),
                ]
            )

        if has_any(("permanent resident card", "alien registration receipt card", "i-551", "1-551")):
            support_indicators.append(
                ("Permanent resident / I-551 evidence", ["permanent resident card", "alien registration", "i-551", "1-551", "resident since", "card expires"])
            )

        if has_any(("employment authorization card", "employment authorization document", "i-766", "1-766")):
            support_indicators.append(
                ("Employment authorization document", ["employment authorization card", "employment authorization document", "i-766", "1-766", "uscis", "category", "card expires"])
            )

        if (
            "passport" in normalized_text
            and has_any(("i-94", "1-94", "arrival/departure record", "arrival-departure record"))
            and has_any(("employment authorized", "authorized to work", "class of admission", "admit until", "refugee", "asylee"))
        ):
            support_indicators.append(
                ("Passport with I-94/work authorization", ["passport", "i-94", "1-94", "arrival/departure record", "employment authorized", "authorized to work", "class of admission"])
            )

        if has_any((
            "government identification card",
            "government id card",
            "personal identity verification",
            "piv card",
            "common access card",
            "cac card",
            "state identification card",
            "state id card",
        )):
            support_indicators.append(
                ("Government or state identification", ["government identification card", "government id card", "state identification card", "state id card", "piv card", "common access card"])
            )

        other_id_groups = [
            ("School ID", ("school identification card", "school id card", "student identification card", "student id card")),
            ("Voter registration card", ("voter registration card", "voter's registration card", "voters registration card")),
            ("Military ID / draft record", ("uniformed services identification", "military identification card", "military id card", "draft record", "department of defense identification", "dod identification card")),
            ("Merchant mariner credential", ("merchant mariner card", "merchant mariner credential", "united states coast guard")),
            ("Native American tribal document", ("native american tribal document", "tribal identification card", "tribal enrollment card", "certificate of degree of indian blood")),
            ("Citizen/resident ID card", ("i-197", "1-197", "i-179", "1-179", "citizen identification", "resident citizen")),
            ("DHS citizenship/travel document", ("refugee travel document", "reentry permit", "re-entry permit", "certificate of citizenship", "certificate of naturalization", "n-560", "n-561", "n-550", "n-570")),
            ("Minor identity record", ("school record", "school report card", "student report card", "clinic record", "doctor record", "hospital record", "day care record", "nursery school record")),
            ("Replacement document receipt", ("receipt", "replacement", "lost", "stolen", "damaged", "form i-797c", "notice of action", "adit stamp", "refugee stamp")),
        ]
        for display, phrases in other_id_groups:
            if has_any(phrases):
                support_indicators.append((display, list(phrases)))

        return support_indicators or form_indicators

    def direct_deposit_confidence_indicators_for_text(self, normalized_text: str) -> list[tuple[str, list[str]]]:
        """Use a generic direct-deposit checklist unless Viventium text exists.

        Some packets contain a Viventium form, while others contain a bank's
        direct-deposit authorization plus a voided check/account screenshot.
        The generic bank form is still a complete direct-deposit document even
        when it does not contain the Viventium name.
        """
        indicators = [
            ("Direct deposit wording", ["direct deposit"]),
            ("Authorization/agreement wording", ["authorization agreement", "direct deposit authorization", "direct deposit authorization form"]),
        ]
        if "linked banking/check page" in normalized_text:
            indicators.append(
                ("Linked banking/check page", ["linked banking/check page"])
            )
        if "viventium" in normalized_text:
            indicators.append(
                ("Viventium payroll wording", ["viventium"])
            )
        return indicators

    def custom_rule_indicators_for_document(self, document: str) -> list[tuple[str, list[str]]]:
        indicators: list[tuple[str, list[str]]] = []
        for rule in self.rules.get("custom_rules", []):
            if safe_filename(str(rule.get("document", ""))) == safe_filename(document):
                for keyword in rule.get("keywords", []):
                    keyword = str(keyword).strip()
                    if keyword:
                        indicators.append((keyword, [keyword.lower()]))
        return indicators

    @staticmethod
    def indicator_present(normalized_text: str, phrases: list[str]) -> bool:
        return any(str(phrase).lower() in normalized_text for phrase in phrases if str(phrase).strip())

    def confidence_context_text(self, assignment: Assignment, page_text: str) -> tuple[str, bool]:
        """Return the text used for confidence scoring.

        Some outputs are intentionally multi-page packets. A continuation page
        in a Job Application should not lose confidence just because the
        compensation agreement, references, or handbook acknowledgement appear
        on other pages in the same exported PDF.
        """
        normalized_document = safe_filename(assignment.document).lower()
        if normalized_document in {
            "banking.pdf",
            "viventium direct deposit.pdf",
        }:
            all_assignments = getattr(self, "assignments", [])
            page_documents = {
                safe_filename(item.document).lower()
                for item in all_assignments
                if item.page_index == assignment.page_index
            }
            linked_documents = {
                "banking.pdf",
                "viventium direct deposit.pdf",
            }
            if linked_documents.issubset(page_documents):
                direct_deposit_pages = sorted(
                    {
                        item.page_index
                        for item in all_assignments
                        if safe_filename(item.document).lower()
                        == "viventium direct deposit.pdf"
                        and item.page_index != assignment.page_index
                        and item.page_index
                        not in getattr(self, "blank_pages", set())
                        and item.page_index
                        < len(getattr(self, "ocr_texts", []))
                        and "direct deposit"
                        in self.ocr_texts[item.page_index].lower()
                    }
                )
                nearby_pages = [
                    page
                    for page in direct_deposit_pages
                    if abs(page - assignment.page_index) <= 2
                ]
                if nearby_pages:
                    combined_text = "\n".join(
                        [page_text]
                        + [self.ocr_texts[page] for page in nearby_pages]
                        + ["linked banking/check page"]
                    )
                    return combined_text, True
            return page_text, False

        if normalized_document not in {"job application.pdf"}:
            return page_text, False

        normalized_page = re.sub(r"\s+", " ", page_text.lower())
        indicators = self.expected_indicators_for_document(assignment.document)
        page_hits = sum(
            1
            for _display, phrases in indicators
            if self.indicator_present(normalized_page, phrases)
        )
        readable_words = re.findall(r"[a-z]{3,}", normalized_page)
        if (
            "__sparse_scan__" in normalized_page
            or (len(readable_words) < 6 and page_hits == 0)
        ):
            return page_text, False

        assignments = [
            item
            for item in getattr(self, "assignments", [])
            if safe_filename(item.document).lower() == normalized_document
            and item.page_index not in getattr(self, "blank_pages", set())
            and item.page_index < len(getattr(self, "ocr_texts", []))
        ]
        page_indexes = sorted({item.page_index for item in assignments})
        if len(page_indexes) < 2:
            return page_text, False

        combined_text = "\n".join(self.ocr_texts[index] for index in page_indexes)
        normalized_combined = re.sub(r"\s+", " ", combined_text.lower())
        combined_hits = sum(
            1
            for _display, phrases in indicators
            if self.indicator_present(normalized_combined, phrases)
        )
        if combined_hits >= 2 and combined_hits > page_hits:
            return combined_text, True
        return page_text, False

    def assignment_confidence_details(self, assignment: Assignment) -> dict:
        page_text = self.ocr_texts[assignment.page_index] if assignment.page_index < len(self.ocr_texts) else ""
        text, used_group_context = self.confidence_context_text(assignment, page_text)
        normalized = re.sub(r"\s+", " ", text.lower())
        normalized_document = safe_filename(assignment.document).lower()
        restricted_social_security_card = (
            normalized_document == "form i-9 employment eligibility verification.pdf"
            and "social security" in normalized
            and any(
                restriction in normalized
                for restriction in (
                    "not valid for employment",
                    "valid for work only with ins authorization",
                    "valid for work only with dhs authorization",
                )
            )
        )
        indicators = self.custom_rule_indicators_for_document(assignment.document)
        if normalized_document == "form i-9 employment eligibility verification.pdf":
            indicators.extend(self.i9_confidence_indicators_for_text(normalized))
        elif normalized_document == "viventium direct deposit.pdf":
            indicators.extend(self.direct_deposit_confidence_indicators_for_text(normalized))
        else:
            indicators.extend(self.expected_indicators_for_document(assignment.document))

        matched: list[str] = []
        missing: list[str] = []
        for display, phrases in indicators:
            if self.indicator_present(normalized, phrases):
                if display not in matched:
                    matched.append(display)
            else:
                if display not in missing:
                    missing.append(display)

        # Add broad positive evidence so the user sees what PacketFlow did find,
        # but do not use scan-quality notes as the main explanation.
        fallback_terms = [
            "form i-9", "employment eligibility verification", "job application",
            "employee availability sheet", "work reference", "time recording",
            "recording of time worked", "direct deposit", "viventium", "form w-4",
            "w-4me", "background check", "child abuse", "orientation agenda",
            "interview statement", "waiver", "auto enrol", "routing number",
            "voided check", "social security", "driver's license", "drivers license",
            "passport", "permanent resident", "employment authorization",
        ]
        for term in fallback_terms:
            if term in normalized and term not in matched:
                matched.append(term)

        remembered = assignment.page_index in self.memory_applied_pages
        if used_group_context and "Multi-page document evidence found" not in matched:
            matched.insert(0, "Multi-page document evidence found")
        if remembered and "Remembered correction" not in matched:
            matched.insert(0, "Remembered correction")

        if indicators:
            total = len(indicators)
            found = sum(1 for display, phrases in indicators if self.indicator_present(normalized, phrases))
            # A complete match is 100%. Points are removed only when expected
            # evidence is missing or a specific warning condition is present.
            score = 100
            missing_count = max(0, total - found)
            score -= missing_count * 4
            if found == 0 and not remembered:
                score = 62
            elif found == 1 and total >= 4 and not remembered:
                score = min(score, 78)
            score = max(55, min(100, score))
        else:
            # Unknown/custom document without configured expected indicators.
            raw = self.analyzer.orientation_score(text) if text else 0
            if remembered:
                score = 97
            elif raw >= 120:
                score = 92
            elif raw >= 75:
                score = 84
            elif raw >= 45:
                score = 72
            else:
                score = 62
        if restricted_social_security_card and not remembered:
            score = min(score, 62)

        reductions: list[tuple[str, int]] = []
        for item in missing:
            reductions.append((f"Missing expected indicator: {item}", 4))
        if restricted_social_security_card:
            reductions.append(
                ("Social Security card contains an employment restriction", 16)
            )
        if not matched and not remembered:
            reductions.append(("No strong document-specific indicator was isolated", 12))

        return {
            "score": score,
            "matched": matched,
            "missing": missing,
            "reductions": reductions,
            "remembered": remembered,
            "indicator_count": len(indicators),
            "matched_indicator_count": len([m for m in matched if m not in fallback_terms]),
        }

    def assignment_confidence_score(self, assignment: Assignment) -> int:
        return int(self.assignment_confidence_details(assignment)["score"])

    def confidence_label_for_assignments(self, assignments: list[Assignment]) -> tuple[str, str]:
        if not assignments:
            return "No confidence", MUTED
        score = min(self.assignment_confidence_score(item) for item in assignments)
        if score >= 95:
            return f"✓ Very High Confidence ({score}%)", SUCCESS_GREEN
        if score >= 85:
            return f"✓ High Confidence ({score}%)", SUCCESS_GREEN
        if score >= 70:
            return f"⚠ Medium Confidence ({score}%)", "#C78B22"
        return f"⚠ Review Recommended ({score}%)", WARNING

    def update_packet_stats(self):
        if not self.page_images:
            self.packet_stats_var.set("Open a packet to begin")
            return
        page_count = len(self.page_images)
        assigned_pages = {a.page_index for a in self.assignments if a.page_index not in self.blank_pages}
        unsorted = page_count - len(self.blank_pages) - len(assigned_pages)
        pdf_count = len(self.grouped_assignments())
        lower_conf = sum(1 for item in self.assignments if self.assignment_confidence_score(item) < 85)
        self.packet_stats_var.set(
            f"{page_count} pages · {pdf_count} PDFs · {unsorted} unsorted · "
            f"{len(self.blank_pages)} blank removed · {lower_conf} needs review · "
            f"{len(self.duplicate_pairs)} duplicate pairs"
        )

    def show_assignment_reason(self):
        if not self.selected_pages:
            messagebox.showinfo("Assignment Details", "Select a page first.")
            return
        page = min(self.selected_pages)
        page_assignments = [a for a in self.assignments if a.page_index == page]
        docs = [a.document for a in page_assignments]
        if page in self.blank_pages:
            messagebox.showinfo(
                "Assignment Details",
                f"Page {page + 1} is marked as a blank scanner page and is removed from export.",
            )
            return
        if not docs:
            messagebox.showinfo(
                "Assignment Details",
                f"Page {page + 1} is currently unsorted. Assign it, then use Save Adjustments if you want future packets to remember the correction.",
            )
            return

        lines: list[str] = [
            f"Page {page + 1}",
            "",
            "Assigned To:",
            ", ".join(dict.fromkeys(docs)),
            "",
        ]
        for assignment_index, assignment in enumerate(page_assignments):
            if assignment_index:
                lines.append("")
            details = self.assignment_confidence_details(assignment)
            score = details["score"]
            if score >= 95:
                band = "Very High"
            elif score >= 85:
                band = "High"
            elif score >= 70:
                band = "Medium"
            else:
                band = "Review Recommended"

            lines.append(f"Confidence: {score}% ({band})")
            lines.append("")

            matched = details.get("matched", [])
            lines.append("Detected Indicators:")
            for item in matched[:12]:
                lines.append(f"✓ {item}")
            if not matched:
                lines.append("- No strong evidence isolated")
            lines.append("")

            missing = details.get("missing", [])
            if missing:
                deduction_by_item = {}
                for reason, points in details.get("reductions", []):
                    prefix = "Missing expected indicator: "
                    if str(reason).startswith(prefix):
                        deduction_by_item[str(reason)[len(prefix):]] = points
                lines.append("Missing Checklist:")
                for item in missing[:12]:
                    points = deduction_by_item.get(item, 4)
                    lines.append(f"⚠ {item} (-{points}%)")
                lines.append("")

        messagebox.showinfo("Assignment Details", "\n".join(lines).strip())

    def update_summary(self):
        if not self.page_images:
            self.summary_var.set("No packet loaded")
            self.update_packet_stats()
            return
        page_count = len(self.page_images)
        assigned_pages = {a.page_index for a in self.assignments if a.page_index not in self.blank_pages}
        unsorted_count = page_count - len(self.blank_pages) - len(assigned_pages)
        pdf_count = len(self.grouped_assignments())
        self.summary_var.set(f"{pdf_count} PDFs · {len(assigned_pages)} sorted · {unsorted_count} unsorted · {len(self.blank_pages)} blank")
        self.update_packet_stats()

    def clear_preview_cache(self):
        self.preview_cache.clear(); self.preview_cache_size = (0, 0); self.preview_photo = None; self.preview_image_refs = []; self.preview_page_offsets = []

    def refresh_all_views(self):
        self.refresh_page_cards(); self.refresh_output_cards(); self.refresh_preview(); self.update_summary(); self.set_busy(False)

    def clear_frame(self, frame):
        for child in frame.winfo_children():
            child.destroy()

    def page_label_for(self, index):
        docs = [a.document for a in self.assignments if a.page_index == index]
        if index in self.blank_pages:
            return "BLANK PAGE", "blank"
        if docs:
            display_docs = [
                self.page_display_document_name(index, document)
                for document in dict.fromkeys(docs)
            ]
            return "; ".join(dict.fromkeys(display_docs)), "sorted"
        return "UNSORTED", "unsorted"

    def page_display_document_name(self, index: int, document: str) -> str:
        if (
            safe_filename(document).lower()
            != "form i-9 employment eligibility verification.pdf"
            or index >= len(self.ocr_texts)
        ):
            return document

        normalized = re.sub(r"\s+", " ", self.ocr_texts[index].lower())
        if (
            "form i-9" in normalized
            or "employment eligibility verification" in normalized
            or (
                "department of homeland security" in normalized
                and any(
                    phrase in normalized
                    for phrase in (
                        "employee attestation",
                        "employer review",
                        "authorized representative",
                    )
                )
            )
        ):
            return document

        indicators = self.i9_confidence_indicators_for_text(normalized)
        if indicators and not any(
            display == "Form I-9 heading" for display, _phrases in indicators
        ):
            return "Identification.pdf"
        return document

    def refresh_page_cards(self):
        self.clear_frame(self.pages_scroll)
        self.page_status_widgets.clear()
        for index in range(len(self.page_images)):
            label, state = self.page_label_for(index)
            self.add_page_card(index, label, state)

    def page_state_style(self, state):
        color_map = {
            "sorted": SUCCESS_GREEN,
            "unsorted": "#8A2020",
            "blank": "#CBD5E1",
            "reading": BRIGHT_BLUE,
            "read": PRODUCT_BLUE,
        }
        text_map = {"sorted": "✓", "unsorted": "!", "blank": "–", "reading": "…", "read": "✓"}
        text_color = NAVY if state == "sorted" else "white"
        label_color = WARNING if state == "unsorted" else MUTED
        return color_map.get(state, BRIGHT_BLUE), text_map.get(state, ""), text_color, label_color

    def compact_page_parts(self, index, label, state):
        # Windows setup/file-list style: dense, readable, no decorative graphics.
        status_map = {
            "sorted": "READ",
            "unsorted": "UNSORTED",
            "blank": "BLANK",
            "reading": "READING",
            "read": "READ",
        }
        status = status_map.get(state, "")
        short_label = label.replace(".pdf", "")
        if len(short_label) > 24:
            short_label = short_label[:21] + "..."
        return status, f"Page {index + 1:<3} {short_label}"

    def add_page_card(self, index, label, state):
        selected = index in self.selected_pages
        _badge_color, _badge_text, _badge_text_color, label_color = self.page_state_style(state)

        bg = "#EAF2FF" if selected else "#FFFFFF"
        row = ctk.CTkFrame(
            self.pages_scroll,
            fg_color=bg,
            corner_radius=0,
            border_width=0,
            height=21,
        )
        row.pack(fill="x", padx=0, pady=0)
        row.pack_propagate(False)

        status_text, detail_text = self.compact_page_parts(index, label, state)
        status_line = ctk.CTkLabel(
            row,
            text=status_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
            font=("Segoe UI", 10, "bold"),
            width=68,
            anchor="w",
        )
        status_line.pack(side="left", padx=(4, 0), pady=0)
        detail_line = ctk.CTkLabel(
            row,
            text=detail_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
            font=("Segoe UI", 10),
            anchor="w",
        )
        detail_line.pack(side="left", fill="x", expand=True, pady=0)

        self.page_status_widgets[index] = {
            "card": row,
            "status": status_line,
            "detail": detail_line,
        }
        status_line.bind("<Button-1>", lambda e, i=index: self.toggle_page_selection(i, e))
        detail_line.bind("<Button-1>", lambda e, i=index: self.toggle_page_selection(i, e))
        row.bind("<Button-1>", lambda e, i=index: self.toggle_page_selection(i, e))

    def set_page_card_status(self, index, label, state):
        widgets = self.page_status_widgets.get(index)
        if not widgets:
            return
        _badge_color, _badge_text, _badge_text_color, label_color = self.page_state_style(state)
        status_text, detail_text = self.compact_page_parts(index, label, state)
        widgets["status"].configure(
            text=status_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
        )
        widgets["detail"].configure(
            text=detail_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
        )
        try:
            self.pages_scroll.update_idletasks()
        except Exception:
            pass

    def toggle_page_selection(self, index, event=None):
        ctrl = bool(event and (event.state & 0x0004))
        shift = bool(event and (event.state & 0x0001))
        if shift and self.selected_pages:
            start = min(self.selected_pages)
            self.selected_pages = set(range(min(start,index), max(start,index)+1))
        elif ctrl:
            if index in self.selected_pages:
                self.selected_pages.remove(index)
            else:
                self.selected_pages.add(index)
        else:
            self.selected_pages = {index}
        self.preview_page_position = 0
        self.on_page_selected()
        self.refresh_page_cards()

    def grouped_assignments(self) -> dict[str, list[Assignment]]:
        grouped: dict[str, list[Assignment]] = {}
        for assignment in self.assignments:
            if assignment.page_index in self.blank_pages:
                continue
            grouped.setdefault(assignment.document, []).append(assignment)
        for values in grouped.values():
            values.sort(key=lambda item: (item.sequence is None, item.sequence if item.sequence is not None else item.page_index, item.page_index))
        self.sync_document_order(grouped)
        return {document: grouped[document] for document in self.document_order if document in grouped}

    def sync_document_order(self, grouped: dict[str, list[Assignment]] | None = None):
        if grouped is None:
            grouped = {}
            for assignment in self.assignments:
                grouped.setdefault(assignment.document, []).append(assignment)
        current_documents = set(grouped)
        self.document_order = [document for document in self.document_order if document in current_documents]
        remembered = (
            [
                document
                for document in self.preferred_document_order
                if document in current_documents
            ]
            if self.setting_enabled("apply_remembered_pdf_order")
            else []
        )
        defaults = [
            document
            for document in self.rules["document_types"]
            if document in current_documents
        ]
        extras = sorted(
            current_documents
            .difference(remembered)
            .difference(defaults)
            .difference(self.document_order),
            key=str.lower,
        )
        for document in remembered + defaults + extras:
            if document not in self.document_order:
                self.document_order.append(document)

    def refresh_output_cards(self):
        self.clear_frame(self.output_scroll)
        self.output_row_widgets = {}
        grouped = self.grouped_assignments()
        if not grouped:
            ctk.CTkLabel(
                self.output_scroll,
                text="No output PDFs yet.",
                text_color=MUTED,
                font=("Segoe UI", 11),
            ).pack(anchor="w", padx=8, pady=6)
            return

        for number, (document, assignments) in enumerate(grouped.items(), start=1):
            selected = document == self.selected_document
            bg = "#EAF2FF" if selected else "#FFFFFF"
            border = PRODUCT_BLUE if selected else BORDER
            frame = ctk.CTkFrame(
                self.output_scroll,
                fg_color=bg,
                corner_radius=5,
                border_width=1,
                border_color=border,
            )
            # Keep the bordered/padded look, but make each row much tighter than
            # the earlier large card version.
            frame.pack(fill="x", padx=3, pady=1)
            frame.grid_columnconfigure(0, weight=1)

            # Compact bordered output row. Use explicit short label heights
            # because CTkLabel defaults to a taller control that creates a
            # large visual gap between the PDF name and page list.
            ctk.CTkLabel(
                frame,
                text=f"{number}.  {document}",
                text_color=PRODUCT_BLUE,
                font=("Segoe UI", 10, "bold" if selected else "normal"),
                anchor="w",
                height=16,
            ).grid(row=0, column=0, sticky="ew", padx=(8, 6), pady=(2, 0))

            pages = ", ".join(str(a.page_number) for a in assignments)
            page_word = "Page" if len(assignments) == 1 else "Pages"
            ctk.CTkLabel(
                frame,
                text=f"{len(assignments)} {page_word}: {pages}",
                text_color=MUTED,
                font=("Segoe UI", 9),
                anchor="w",
                height=15,
            ).grid(row=1, column=0, sticky="ew", padx=(8, 6), pady=(0, 0))

            confidence_text, confidence_color = self.confidence_label_for_assignments(assignments)
            learned_pages = sorted(
                a.page_number for a in assignments if a.page_index in self.memory_applied_pages
            )
            learned_text = (
                f"  ·  ✓ Learned: {', '.join(map(str, learned_pages))}"
                if learned_pages
                else ""
            )
            ctk.CTkLabel(
                frame,
                text=confidence_text + learned_text,
                text_color=confidence_color if not learned_pages else SUCCESS_GREEN,
                font=("Segoe UI", 9, "bold"),
                anchor="w",
                height=15,
            ).grid(row=2, column=0, sticky="ew", padx=(8, 6), pady=(0, 2))

            self.output_row_widgets[document] = frame
            self.bind_output_row(frame, document)
            for child in frame.winfo_children():
                self.bind_output_row(child, document)

    def bind_output_row(self, widget, document: str):
        # Click to select. Reordering is handled by the Move Up / Move Down
        # buttons because drag reordering was unreliable in this scroll frame.
        widget.bind("<Button-1>", lambda e, d=document: self.on_output_selected(d))

    def on_output_drag_start(self, event, document: str):
        self.dragging_document = document
        self.on_output_selected(document)

    def on_output_drag_motion(self, event, document: str):
        # Keep the selected row visible while dragging. Reordering happens on release.
        self.dragging_document = document

    def on_output_drag_release(self, event, document: str):
        dragging = self.dragging_document or document
        self.dragging_document = None
        if dragging not in self.document_order:
            return

        target = self.output_document_at_pointer()
        if not target or target == dragging or target not in self.document_order:
            return

        old_index = self.document_order.index(dragging)
        new_index = self.document_order.index(target)
        self.document_order.pop(old_index)
        if old_index < new_index:
            new_index -= 1
        self.document_order.insert(new_index, dragging)
        self.selected_document = dragging
        self.refresh_output_cards()

    def output_document_at_pointer(self) -> str | None:
        pointer_y = self.root.winfo_pointery()
        closest_doc = None
        closest_distance = 10**9
        for document, frame in self.output_row_widgets.items():
            try:
                top = frame.winfo_rooty()
                bottom = top + frame.winfo_height()
                mid = (top + bottom) / 2
            except Exception:
                continue
            if top <= pointer_y <= bottom:
                return document
            distance = abs(pointer_y - mid)
            if distance < closest_distance:
                closest_distance = distance
                closest_doc = document
        return closest_doc

    def selected_page_indices(self) -> list[int]:
        return sorted(self.selected_pages)

    def selected_nonblank_page_indices(self) -> list[int]:
        selected = self.selected_page_indices()
        nonblank = [index for index in selected if index not in self.blank_pages]
        if selected and not nonblank:
            messagebox.showinfo(APP_TITLE, "Blank pages are always removed and cannot be assigned to a PDF.")
        return nonblank

    def on_page_selected(self, _event=None):
        selected = self.selected_page_indices()
        if not selected:
            return
        self.selected_document = None
        first = selected[0]
        matches = [a for a in self.assignments if a.page_index == first]
        if matches:
            self.document_var.set(matches[0].document)
        elif first in self.blank_pages:
            self.document_var.set("BLANK PAGE")
        else:
            self.document_var.set("UNSORTED")
        self.refresh_output_cards()
        self.refresh_preview(reset_scroll=True)

    def on_output_selected(self, document):
        self.selected_document = document
        self.document_var.set(document)
        self.selected_pages = {a.page_index for a in self.assignments if a.document == document}
        self.preview_page_position = 0
        self.refresh_output_cards(); self.refresh_page_cards(); self.refresh_preview(reset_scroll=True)

    def move_document(self, direction: int):
        document = self.selected_document
        if not document:
            messagebox.showwarning(APP_TITLE, "Select an output PDF to move.")
            return
        self.sync_document_order()
        if document not in self.document_order:
            return
        old_index = self.document_order.index(document)
        new_index = old_index + direction
        if new_index < 0 or new_index >= len(self.document_order):
            return
        self.push_undo("move output PDF")
        self.document_order[old_index], self.document_order[new_index] = self.document_order[new_index], self.document_order[old_index]
        self.refresh_output_cards()

    def on_preview_resize(self, _event=None):
        canvas_width = max(self.preview_canvas.winfo_width() - 24, 200)
        canvas_height = max(self.preview_canvas.winfo_height() - 24, 200)
        if (canvas_width, canvas_height) != self.preview_cache_size:
            self.clear_preview_cache(); self.preview_cache_size = (canvas_width, canvas_height)
        self.refresh_preview()

    def on_preview_mousewheel(self, event):
        if not self.preview_pages():
            return
        if getattr(event, "num", None) == 4:
            self.preview_canvas.yview_scroll(-3, "units")
        elif getattr(event, "num", None) == 5:
            self.preview_canvas.yview_scroll(3, "units")
        else:
            delta = getattr(event, "delta", 0)
            self.preview_canvas.yview_scroll(int(-1 * (delta / 120)), "units")

    def preview_pages(self) -> list[int]:
        """Pages currently available in the preview.

        When an Output PDF is selected, this returns every source page that belongs
        to that output document in the same order it will export. That lets the
        preview step through all pages in a multi-page output PDF instead of only
        showing the first selected page.
        """
        if self.selected_document:
            grouped = self.grouped_assignments()
            if self.selected_document in grouped:
                return [assignment.page_index for assignment in grouped[self.selected_document]]
        return self.selected_page_indices()

    def update_preview_nav(self, pages: list[int]):
        if not pages:
            self.preview_nav_var.set("")
            try:
                self.preview_prev_button.configure(state="disabled")
                self.preview_next_button.configure(state="disabled")
            except Exception:
                pass
            return
        self.preview_page_position = max(0, min(self.preview_page_position, len(pages) - 1))
        if len(pages) == 1:
            self.preview_nav_var.set(f"Page {pages[0] + 1}")
        else:
            self.preview_nav_var.set(
                f"{self.preview_page_position + 1} of {len(pages)}  ·  Page {pages[self.preview_page_position] + 1}"
            )
        try:
            self.preview_prev_button.configure(state="normal" if self.preview_page_position > 0 else "disabled")
            self.preview_next_button.configure(state="normal" if self.preview_page_position < len(pages) - 1 else "disabled")
        except Exception:
            pass

    def preview_previous_page(self):
        pages = self.preview_pages()
        if not pages:
            return
        self.preview_page_position = max(0, self.preview_page_position - 1)
        self.refresh_preview(reset_scroll=True)

    def preview_next_page(self):
        pages = self.preview_pages()
        if not pages:
            return
        self.preview_page_position = min(len(pages) - 1, self.preview_page_position + 1)
        self.refresh_preview(reset_scroll=True)

    def refresh_preview(self, reset_scroll: bool = False):
        pages = self.preview_pages()
        self.preview_canvas.delete("all")
        self.preview_image_refs = []
        self.preview_page_offsets = []
        if not pages or not self.page_images:
            self.preview_nav_var.set("")
            try:
                self.preview_prev_button.configure(state="disabled")
                self.preview_next_button.configure(state="disabled")
            except Exception:
                pass
            self.preview_canvas.configure(scrollregion=(0, 0, self.preview_canvas.winfo_width(), self.preview_canvas.winfo_height()))
            self.preview_canvas.create_text(max(self.preview_canvas.winfo_width() // 2, 120), max(self.preview_canvas.winfo_height() // 2, 120), text="Select a page to preview it.", fill=MUTED, font=("Segoe UI", 14))
            return

        # Show every page in the selected Output PDF stacked vertically, like a
        # PDF viewer. The left/right buttons still jump between pages, but the
        # mouse wheel can now scroll naturally from page 1 through the last page.
        self.update_preview_nav(pages)
        canvas_width = max(self.preview_canvas.winfo_width() - 34, 200)
        canvas_height = max(self.preview_canvas.winfo_height() - 24, 200)
        y = 12
        gap = 18
        max_image_width = 0

        for position, page_index in enumerate(pages):
            manual_rotation = (
                self.page_manual_rotations[page_index]
                if page_index < len(self.page_manual_rotations)
                else 0
            )
            cache_key = (page_index, canvas_width, manual_rotation)
            if cache_key not in self.preview_cache:
                image = Image.open(self.page_images[page_index]).convert("RGB")
                if manual_rotation:
                    image = image.rotate(-manual_rotation, expand=True)
                scale = canvas_width / max(image.width, 1)
                new_width = max(1, int(image.width * scale))
                new_height = max(1, int(image.height * scale))
                image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
                self.preview_cache[cache_key] = ImageTk.PhotoImage(image)
                # Evict the least-recently-used entry when the cache is full.
                if len(self.preview_cache) > self._preview_cache_max:
                    self.preview_cache.popitem(last=False)
            else:
                # Move the hit entry to the most-recently-used end.
                self.preview_cache.move_to_end(cache_key)

            photo = self.preview_cache[cache_key]
            self.preview_image_refs.append(photo)
            self.preview_page_offsets.append(y)

            image_width = photo.width()
            image_height = photo.height()
            max_image_width = max(max_image_width, image_width)
            x = max(self.preview_canvas.winfo_width() // 2, image_width // 2 + 10)

            if len(pages) > 1:
                self.preview_canvas.create_text(
                    14,
                    y,
                    text=f"Page {position + 1} of {len(pages)}  ·  Source page {page_index + 1}",
                    anchor="nw",
                    fill=MUTED,
                    font=("Segoe UI", 10, "bold"),
                )
                y += 22

            self.preview_canvas.create_image(x, y, image=photo, anchor="n")
            y += image_height + gap

        scroll_height = max(y, self.preview_canvas.winfo_height())
        self.preview_canvas.configure(
            scrollregion=(0, 0, max(self.preview_canvas.winfo_width(), max_image_width + 20), scroll_height)
        )

        if reset_scroll and self.preview_page_offsets:
            target_y = self.preview_page_offsets[self.preview_page_position]
            max_scroll = max(scroll_height - canvas_height, 1)
            self.preview_canvas.yview_moveto(max(0, min(target_y / max_scroll, 1)))

    def normalized_document_name(self) -> str | None:
        name = self.document_var.get().strip()
        if not name:
            messagebox.showwarning(APP_TITLE, "Choose or enter a document name first.")
            return None
        alias = re.sub(r"\s+", " ", name.casefold()).removesuffix(".pdf").strip()
        if alias in {
            "direct deposit",
            "direct deposit authorization",
            "direct deposit authorization form",
            "direct deposit form",
        }:
            return "Viventium Direct Deposit.pdf"
        return safe_filename(name)

    def effective_page_rotation(self, page_index: int) -> int:
        automatic = (
            self.page_rotations[page_index]
            if page_index < len(self.page_rotations)
            else 0
        )
        manual = (
            self.page_manual_rotations[page_index]
            if page_index < len(self.page_manual_rotations)
            else 0
        )
        return (automatic + manual) % 360

    def push_undo(self, description: str):
        # deque(maxlen=20) automatically drops the oldest entry when full —
        # no manual pop(0) needed (and pop(0) on a list was O(n) anyway).
        self.undo_stack.append(
            {
                "description": description,
                "assignments": [
                    Assignment(
                        item.page_index,
                        item.document,
                        item.rotation,
                        item.sequence,
                    )
                    for item in self.assignments
                ],
                "document_order": list(self.document_order),
                "manual_rotations": list(self.page_manual_rotations),
                "selected_pages": set(self.selected_pages),
                "selected_document": self.selected_document,
                "custom_document_types": set(self.custom_document_types),
            }
        )

    def undo_last_change(self):
        if not self.undo_stack:
            messagebox.showinfo(APP_TITLE, "There is no change to undo.")
            return
        state = self.undo_stack.pop()
        self.assignments = state["assignments"]
        self.document_order = state["document_order"]
        self.page_manual_rotations = state["manual_rotations"]
        self.selected_pages = state["selected_pages"]
        self.selected_document = state["selected_document"]
        self.custom_document_types = state["custom_document_types"]
        self.refresh_document_choices()
        self.clear_preview_cache()
        self.refresh_all_views()
        self.status_var.set(f"Undid: {state['description']}.")

    def rotate_selected_pages(self, degrees: int):
        pages = self.selected_nonblank_page_indices()
        if not pages:
            return
        self.push_undo(
            "rotate selected pages right" if degrees > 0 else "rotate selected pages left"
        )
        if len(self.page_manual_rotations) < len(self.page_rotations):
            self.page_manual_rotations.extend(
                [0] * (len(self.page_rotations) - len(self.page_manual_rotations))
            )
        for page in pages:
            self.page_manual_rotations[page] = (
                self.page_manual_rotations[page] + degrees
            ) % 360
            effective_rotation = self.effective_page_rotation(page)
            for assignment in self.assignments:
                if assignment.page_index == page:
                    assignment.rotation = effective_rotation
        self.clear_preview_cache()
        self.refresh_all_views()
        direction = "right" if degrees > 0 else "left"
        self.status_var.set(
            f"Rotated {len(pages)} selected page"
            + ("" if len(pages) == 1 else "s")
            + f" {direction}."
        )

    def refresh_document_choices(self):
        choices = list(self.rules["document_types"])
        for document in sorted(self.custom_document_types, key=str.lower):
            if document not in choices:
                choices.append(document)
        self.document_combo.configure(values=choices)

    def assign_to_document(self):
        pages = self.selected_nonblank_page_indices()
        document = self.normalized_document_name()
        if not pages or not document:
            return
        self.push_undo("assign selected pages")
        self.assignments = [item for item in self.assignments if item.page_index not in pages]
        for page in pages:
            self.assignments.append(
                Assignment(
                    page,
                    document,
                    self.effective_page_rotation(page),
                    None,
                )
            )
            if document == "Banking.pdf":
                self.assignments.append(
                    Assignment(
                        page,
                        "Viventium Direct Deposit.pdf",
                        self.effective_page_rotation(page),
                        None,
                    )
                )
        self.refresh_all_views()
        if document == "Banking.pdf":
            self.status_var.set(
                "Assigned to Banking and automatically included with Direct Deposit."
            )
        else:
            self.status_var.set("Assigned to document.")

    def remove_assignments(self):
        pages = self.selected_page_indices()
        if not pages:
            return
        self.push_undo("mark selected pages unsorted")
        self.assignments = [item for item in self.assignments if item.page_index not in pages]
        self.selected_document = None
        self.document_var.set("UNSORTED")
        self.refresh_all_views(); self.status_var.set("Selected pages marked as unsorted.")

    def rename_document(self):
        old_name = self.selected_document
        if not old_name:
            messagebox.showwarning(APP_TITLE, "Select an output PDF to rename.")
            return
        new_name = simpledialog.askstring(APP_TITLE, "New PDF filename:", initialvalue=old_name)
        if not new_name:
            return
        new_name = safe_filename(new_name)
        self.push_undo("rename output")
        for assignment in self.assignments:
            if assignment.document == old_name:
                assignment.document = new_name
        if old_name in self.custom_document_types:
            self.custom_document_types.remove(old_name)
            self.custom_document_types.add(new_name)
            self.refresh_document_choices()
        if old_name in self.document_order:
            self.document_order[self.document_order.index(old_name)] = new_name
        self.selected_document = new_name
        self.refresh_all_views(); self.document_var.set(new_name)

    def remember_correction(self):
        pages = self.selected_nonblank_page_indices()
        document = self.normalized_document_name() if pages else None
        remembered = 0
        learned_rules = 0
        learned_phrases: list[str] = []
        document_added = False
        if document:
            for page in pages:
                signature = self.correction_signature(self.ocr_texts[page])
                if len(signature) < 12:
                    continue
                self.correction_memory = [
                    entry
                    for entry in self.correction_memory
                    if entry.get("signature") != signature
                ]
                self.correction_memory.append(
                    {"document": document, "signature": signature}
                )
                remembered += 1
            if (
                remembered
                and document not in self.rules["document_types"]
            ):
                self.rules["document_types"].append(document)
                self.custom_document_types.discard(document)
                document_added = True
            learned_rules, learned_phrases = self.learn_document_rules(
                document,
                pages,
            )

        self.sync_document_order()
        order_saved = bool(self.document_order)
        if order_saved:
            self.preferred_document_order = list(self.document_order)

        if not remembered and not learned_rules and not order_saved:
            messagebox.showwarning(
                APP_TITLE,
                "There is not enough readable, stable text to learn this page, "
                "and there is no output order to remember.",
            )
            return
        rules_saved = (
            self.save_rules()
            if document_added or learned_rules
            else True
        )
        if rules_saved and self.save_correction_memory():
            saved_parts = []
            if remembered:
                saved_parts.append(
                    f"{remembered} page correction"
                    + ("" if remembered == 1 else "s")
                )
            if document_added:
                saved_parts.append(f"{document} in this profile")
            if learned_rules:
                saved_parts.append(
                    f"{learned_rules} recognition rule"
                    + ("" if learned_rules == 1 else "s")
                )
            if order_saved:
                saved_parts.append("the current PDF output order")
            self.status_var.set(
                "Remembered "
                + " and ".join(saved_parts)
                + " for future packets."
            )
            if learned_rules:
                phrase_preview = "\n".join(
                    f"  - {phrase}" for phrase in learned_phrases[:5]
                )
                messagebox.showinfo(
                    APP_TITLE,
                    "PacketFlow learned how to recognize this document in "
                    f"the {self.active_profile_name} profile.\n\n"
                    "Identifying phrases saved:\n"
                    + phrase_preview
                    + "\n\nYou can edit or remove this rule in "
                    "Preferences > Manage Document Rules.",
                )
            if pages and not remembered and not learned_rules:
                messagebox.showinfo(
                    APP_TITLE,
                    "The selected page did not contain enough readable text for "
                    "template matching. The PDF output order was still saved.",
                )

    def show_memory_manager(self):
        proceed = messagebox.askyesno(
            APP_TITLE,
            "Open remembered settings?\n\n"
            "Deleting remembered page corrections or the saved PDF order affects "
            "future packets. The current packet will not be changed.\n\n"
            "Continue?",
        )
        if not proceed:
            return
        window = ctk.CTkToplevel(self.root)
        window.title("Remembered Settings")
        window.geometry("470x310")
        window.resizable(False, False)
        window.transient(self.root)
        window.grab_set()

        ctk.CTkLabel(
            window,
            text="Remembered Settings",
            text_color=CARD_NAVY,
            font=("Segoe UI", 18, "bold"),
        ).pack(anchor="w", padx=20, pady=(18, 5))
        summary_var = tk.StringVar()

        def update_summary():
            summary_var.set(
                f"Saved page corrections: {len(self.correction_memory)}\n"
                f"Saved PDF order entries: {len(self.preferred_document_order)}"
            )

        def clear_page_corrections():
            if not messagebox.askyesno(
                APP_TITLE,
                "Delete all remembered page assignments?\n\n"
                "This cannot be undone.",
                parent=window,
            ):
                return
            self.correction_memory = []
            self.save_correction_memory()
            update_summary()

        def clear_output_order():
            if not messagebox.askyesno(
                APP_TITLE,
                "Delete the remembered Output PDFs order?\n\n"
                "Future packets will return to the default order.",
                parent=window,
            ):
                return
            self.preferred_document_order = []
            self.save_correction_memory()
            update_summary()

        def clear_everything():
            if not messagebox.askyesno(
                APP_TITLE,
                "Delete every remembered correction and the saved PDF order?\n\n"
                "This cannot be undone.",
                parent=window,
            ):
                return
            self.correction_memory = []
            self.preferred_document_order = []
            self.save_correction_memory()
            update_summary()

        ctk.CTkLabel(
            window,
            textvariable=summary_var,
            text_color=TEXT,
            font=("Segoe UI", 12),
            justify="left",
        ).pack(anchor="w", padx=20, pady=(5, 14))
        update_summary()

        ctk.CTkButton(
            window,
            text="Clear Page Corrections",
            command=clear_page_corrections,
            fg_color="#FFFFFF",
            hover_color="#FFF8E8",
            border_width=1,
            border_color="#C78B22",
            text_color="#7A5418",
            height=34,
        ).pack(fill="x", padx=20, pady=4)
        ctk.CTkButton(
            window,
            text="Clear Saved PDF Order",
            command=clear_output_order,
            fg_color="#FFFFFF",
            hover_color="#FFF8E8",
            border_width=1,
            border_color="#C78B22",
            text_color="#7A5418",
            height=34,
        ).pack(fill="x", padx=20, pady=4)
        ctk.CTkButton(
            window,
            text="Clear All Remembered Settings",
            command=clear_everything,
            fg_color="#FFFFFF",
            hover_color="#FBEAEA",
            border_width=1,
            border_color=WARNING,
            text_color=WARNING,
            height=34,
        ).pack(fill="x", padx=20, pady=4)
        ctk.CTkButton(
            window,
            text="Close",
            command=window.destroy,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
            height=34,
        ).pack(fill="x", padx=20, pady=(12, 16))

    @staticmethod
    def format_page_list(pages, limit: int = 18) -> str:
        values = [str(page) for page in pages]
        if len(values) <= limit:
            return ", ".join(values) if values else "None"
        return ", ".join(values[:limit]) + f", and {len(values) - limit} more"

    def review_details(self) -> dict:
        grouped = self.grouped_assignments()
        found = set(grouped)
        expected = self.rules.get("expected_document_types", [])
        found_expected = [document for document in expected if document in found]
        missing = [document for document in expected if document not in found]
        assigned_by_page: dict[int, list[str]] = {}
        for assignment in self.assignments:
            if assignment.page_index in self.blank_pages:
                continue
            assigned_by_page.setdefault(assignment.page_index, []).append(
                assignment.document
            )
        unsorted = [
            index + 1
            for index in range(len(self.reader.pages) if self.reader else 0)
            if index not in self.blank_pages and index not in assigned_by_page
        ]
        multiple = {
            index + 1: list(dict.fromkeys(documents))
            for index, documents in assigned_by_page.items()
            if len(set(documents)) > 1
        }
        return {
            "grouped": grouped,
            "found_expected": found_expected,
            "missing": missing,
            "unsorted": unsorted,
            "multiple": multiple,
            "duplicates": [
                (left + 1, right + 1) for left, right in self.duplicate_pairs
            ],
            "low_confidence": sorted(
                page + 1 for page in self.low_confidence_pages
            ),
            "blank": sorted(page + 1 for page in self.blank_pages),
            "rotated": [
                index + 1
                for index in range(len(self.page_rotations))
                if self.effective_page_rotation(index)
            ],
            "memory": sorted(page + 1 for page in self.memory_applied_pages),
        }

    def build_review_summary(self) -> str:
        details = self.review_details()
        found_names = list(details["grouped"])
        lines = [
            "EXPECTED DOCUMENT CHECKLIST",
            f"Profile: {self.active_profile_name}",
            f"Found: {len(found_names)} output PDFs",
        ]
        if details["found_expected"]:
            lines.append("Found expected:")
            lines.extend(
                f"  - {name}" for name in details["found_expected"]
            )
        else:
            lines.append("Found expected: None")
        if details["missing"]:
            lines.append("Missing expected:")
            lines.extend(f"  - {name}" for name in details["missing"])
        else:
            lines.append("Missing expected: None")

        lines.extend(
            [
                "",
                "PAGE REVIEW",
                "Unsorted pages: "
                + self.format_page_list(details["unsorted"]),
                "Blank pages removed: "
                + self.format_page_list(details["blank"]),
                "Pages rotated for orientation: "
                + self.format_page_list(details["rotated"]),
                "Remembered corrections applied: "
                + self.format_page_list(details["memory"]),
            ]
        )
        if self.setting_enabled("show_low_confidence_warnings"):
            lines.append(
                "Low-confidence pages: "
                + self.format_page_list(details["low_confidence"])
            )
        if self.setting_enabled("show_duplicate_warnings"):
            if details["duplicates"]:
                duplicate_text = ", ".join(
                    f"{left}/{right}" for left, right in details["duplicates"]
                )
                lines.append(
                    "Suspected duplicate page pairs: " + duplicate_text
                )
            else:
                lines.append("Suspected duplicate page pairs: None")
        if details["multiple"]:
            multiple_text = "; ".join(
                f"{page}: {', '.join(documents)}"
                for page, documents in details["multiple"].items()
            )
            lines.append("Pages used in multiple PDFs: " + multiple_text)
        else:
            lines.append("Pages used in multiple PDFs: None")
        return "\n".join(lines)

    def show_packet_review(self):
        if not self.reader:
            return
        self.show_review_dialog(confirm=False)

    def show_review_dialog(self, confirm: bool) -> bool:
        summary = self.build_review_summary()
        lines = summary.splitlines()
        body_font = tkfont.Font(family="Segoe UI", size=11)
        longest_line = max(
            (body_font.measure(line) for line in lines),
            default=520,
        )
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        window_width = min(
            max(620, longest_line + 90),
            max(620, screen_width - 120),
        )
        window_height = min(
            max(460, len(lines) * 22 + (150 if confirm else 120)),
            max(460, screen_height - 140),
        )

        result = {"accepted": False}
        window = ctk.CTkToplevel(self.root)
        window.title("Review Packet")
        window.geometry(f"{window_width}x{window_height}")
        window.minsize(620, 460)
        window.transient(self.root)
        window.grab_set()

        ctk.CTkLabel(
            window,
            text="Packet Review",
            text_color=CARD_NAVY,
            font=("Segoe UI", 19, "bold"),
        ).pack(anchor="w", padx=20, pady=(16, 8))

        review_text = ctk.CTkTextbox(
            window,
            wrap="none",
            fg_color="#FFFFFF",
            text_color=TEXT,
            border_width=1,
            border_color=BORDER,
            font=("Segoe UI", 11),
        )
        review_text.pack(fill="both", expand=True, padx=20, pady=(0, 12))
        review_text.insert("1.0", summary)
        review_text.configure(state="disabled")

        def finish(accepted: bool):
            result["accepted"] = accepted
            window.destroy()

        button_row = ctk.CTkFrame(window, fg_color="transparent")
        button_row.pack(fill="x", padx=20, pady=(0, 16))
        if self.duplicate_pairs:
            ctk.CTkButton(
                button_row,
                text="Review Duplicates",
                command=self.show_duplicate_review,
                fg_color="#FFFFFF",
                hover_color="#FFF8E8",
                border_width=1,
                border_color="#C78B22",
                text_color="#7A5418",
                width=145,
            ).pack(side="left")
        if confirm:
            ctk.CTkButton(
                button_row,
                text="Cancel",
                command=lambda: finish(False),
                fg_color="#FFFFFF",
                hover_color="#F8FAFC",
                border_width=1,
                border_color="#CBD5E1",
                text_color=TEXT,
                width=110,
            ).pack(side="right")
            ctk.CTkButton(
                button_row,
                text="Continue with Export",
                command=lambda: finish(True),
                fg_color=PRODUCT_BLUE,
                hover_color=SUCCESS_GREEN,
                width=165,
            ).pack(side="right", padx=(0, 8))
            window.protocol("WM_DELETE_WINDOW", lambda: finish(False))
        else:
            ctk.CTkButton(
                button_row,
                text="Close",
                command=lambda: finish(True),
                fg_color=PRODUCT_BLUE,
                hover_color=SUCCESS_GREEN,
                width=110,
            ).pack(side="right")
            window.protocol("WM_DELETE_WINDOW", lambda: finish(True))

        window.update_idletasks()
        x = max(0, (screen_width - window.winfo_width()) // 2)
        y = max(0, (screen_height - window.winfo_height()) // 2)
        window.geometry(f"+{x}+{y}")
        self.root.wait_window(window)
        return result["accepted"]

    @staticmethod
    def suggest_packet_name(stem: str) -> str:
        raw = re.sub(r"\s+", " ", stem.strip())
        raw = re.sub(
            r"(?i)[ _-]+(?:scan|packet)?[ _-]*\d+$",
            "",
            raw,
        ).strip(" _-")
        underscore_parts = [part for part in raw.split("_") if part]
        if (
            "_" in raw
            and len(underscore_parts) == 2
            and all(part.isalpha() and part.isupper() for part in underscore_parts)
        ):
            raw = f"{underscore_parts[1]} {underscore_parts[0]}"
        else:
            raw = re.sub(r"[_-]+", " ", raw)
        return " ".join(
            word if word.isupper() and len(word) <= 4 else word.title()
            for word in raw.split()
        )

    def current_packet_stem(self) -> str:
        if self.packet_base_stem:
            return self.packet_base_stem
        if self.packet_display_name:
            display_name = self.packet_display_name.strip()
            if display_name.lower().endswith(".pdf"):
                return Path(display_name).stem
            return display_name
        if self.pdf_path:
            return self.pdf_path.stem
        return "Ad Hoc Packet"

    def confirm_packet_name(self) -> str | None:
        if not self.pdf_path:
            return None
        packet_stem = self.current_packet_stem()
        original = safe_folder_name(packet_stem)
        suggested = safe_folder_name(self.suggest_packet_name(packet_stem))
        if self.export_packet_name:
            return self.export_packet_name
        if suggested == original:
            self.export_packet_name = original
            return original
        answer = messagebox.askyesnocancel(
            APP_TITLE,
            "Use this cleaned packet name for the output folder and PDF prefix?\n\n"
            f"{suggested}\n\n"
            f"Yes: use {suggested}\n"
            f"No: keep {original}",
        )
        if answer is None:
            return None
        self.export_packet_name = suggested if answer else original
        return self.export_packet_name

    def cleanup_work_files(self):
        self.clear_preview_cache()
        if self.work_dir and self.work_dir.exists():
            shutil.rmtree(self.work_dir, ignore_errors=True)
        self.work_dir = None
        for directory in self.additional_work_dirs:
            if directory.exists():
                shutil.rmtree(directory, ignore_errors=True)
        self.additional_work_dirs.clear()
        if self.manual_packet_dir and self.manual_packet_dir.exists():
            shutil.rmtree(self.manual_packet_dir, ignore_errors=True)
        self.manual_packet_dir = None
        for directory in self.retired_manual_dirs:
            if directory.exists():
                shutil.rmtree(directory, ignore_errors=True)
        self.retired_manual_dirs.clear()
        self.page_images = []

    def clear_loaded_packet(self, status: str = "Open a PDF packet to begin."):
        self.cleanup_work_files()
        self.pdf_path = None
        self.reader = None
        self.packet_source_paths = []
        self.packet_display_name = None
        self.packet_base_stem = None
        self.pending_append_state = None
        self.export_packet_name = None
        self.packet_exported = True
        self.current_packet_from_watch = False
        self.assignments.clear()
        self.ocr_texts.clear()
        self.page_rotations.clear()
        self.page_manual_rotations.clear()
        self.blank_pages.clear()
        self.page_fingerprints.clear()
        self.duplicate_pairs.clear()
        self.low_confidence_pages.clear()
        self.memory_applied_pages.clear()
        self.document_order.clear()
        self.custom_document_types.clear()
        self.undo_stack.clear()
        self.selected_pages.clear()
        self.selected_document = None
        self.preview_page_position = 0
        self.document_var.set("")
        self.packet_filename_var.set("Original PDF: No packet selected")
        self.root.title(APP_TITLE)
        self.progress_var.set(0)
        self.progress.set(0)
        self.progress_label_var.set("0%")
        self.refresh_document_choices()
        self.refresh_all_views()
        self.status_var.set(status)

    def choose_output_folder(self, packet_name: str) -> Path | None:
        if not self.pdf_path:
            return None
        source_parent = (
            self.packet_source_paths[0].parent
            if self.packet_source_paths
            else self.pdf_path.parent
        )
        initial_folder = self.export_parent_folder or source_parent
        selected = filedialog.askdirectory(
            title=f"Choose where to save the {packet_name} folder",
            initialdir=str(initial_folder),
            mustexist=True,
        )
        if not selected:
            return None
        chosen_folder = Path(selected)
        if chosen_folder.name.casefold() == packet_name.casefold():
            self.export_parent_folder = chosen_folder.parent
            destination = chosen_folder
        else:
            self.export_parent_folder = chosen_folder
            destination = chosen_folder / packet_name
        if self.setting_enabled("remember_last_export_location"):
            self.settings["last_export_location"] = str(self.export_parent_folder)
            self.save_settings()
        return destination

    def export_to_last_location(self):
        if not self.export_parent_folder or not self.export_parent_folder.is_dir():
            messagebox.showinfo(APP_TITLE, "No previous export folder is saved yet.")
            return
        if not self.reader or not self.pdf_path or not self.assignments:
            return
        packet_name = self.confirm_packet_name()
        if not packet_name:
            return
        destination = self.export_parent_folder / packet_name
        self.export_pdfs(automatic=False, destination_override=destination)

    def show_duplicate_review(self):
        if not self.duplicate_pairs:
            messagebox.showinfo(APP_TITLE, "No suspected duplicate pages were found.")
            return
        window = ctk.CTkToplevel(self.root)
        window.title("Duplicate Page Review")
        window.geometry("980x680")
        window.minsize(860, 560)
        window.transient(self.root)
        window.grab_set()
        ctk.CTkLabel(window, text="Suspected Duplicate Pages", text_color=CARD_NAVY, font=("Segoe UI", 19, "bold")).pack(anchor="w", padx=18, pady=(16, 4))
        ctk.CTkLabel(window, text="Compare the page images. If one is truly a duplicate, select it in the main page list and mark it unsorted before export.", text_color=MUTED, font=("Segoe UI", 11), wraplength=900, justify="left").pack(anchor="w", padx=18, pady=(0, 10))
        scroll = ctk.CTkScrollableFrame(window, fg_color="#FFFFFF", border_width=1, border_color=BORDER)
        scroll.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        self._duplicate_review_images = []
        for left, right in self.duplicate_pairs:
            row = ctk.CTkFrame(scroll, fg_color="#F8FAFC", corner_radius=6, border_width=1, border_color=BORDER)
            row.pack(fill="x", padx=8, pady=8)
            ctk.CTkLabel(row, text=f"Pages {left + 1} and {right + 1}", text_color=TEXT, font=("Segoe UI", 13, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", padx=10, pady=(8, 5))
            for col, page_index in enumerate((left, right)):
                try:
                    img = Image.open(self.page_images[page_index]).convert("RGB")
                    img.thumbnail((360, 460))
                    photo = ImageTk.PhotoImage(img)
                    self._duplicate_review_images.append(photo)
                    label = ctk.CTkLabel(row, image=photo, text="")
                    label.grid(row=1, column=col, padx=10, pady=(0, 6))
                    ctk.CTkLabel(row, text=f"Page {page_index + 1}", text_color=MUTED, font=("Segoe UI", 11, "bold")).grid(row=2, column=col, pady=(0, 8))
                except Exception:
                    ctk.CTkLabel(row, text=f"Page {page_index + 1} preview unavailable", text_color=WARNING).grid(row=1, column=col, padx=10, pady=10)
        ctk.CTkButton(window, text="Close", command=window.destroy, fg_color=PRODUCT_BLUE, hover_color=SUCCESS_GREEN, width=110).pack(anchor="e", padx=18, pady=(0, 16))

    def export_pdfs(self, automatic: bool = False, destination_override: Path | None = None):
        if not self.reader or not self.pdf_path or not self.assignments:
            return
        if automatic:
            packet_name = safe_folder_name(
                self.suggest_packet_name(self.current_packet_stem())
            ) or safe_folder_name(self.current_packet_stem())
            self.export_packet_name = packet_name
        else:
            packet_name = self.confirm_packet_name()
        if not packet_name:
            return
        destination = destination_override or self.choose_output_folder(packet_name)
        if not destination:
            return
        ordered_groups = list(self.grouped_assignments().items())
        target_names = [
            safe_filename(f"{packet_name} - {document}")
            for document, _assignments in ordered_groups
        ]
        target_names.append("Export Audit Log.txt")
        if not automatic:
            if not self.show_review_dialog(confirm=True):
                return
        if destination.exists():
            existing_files = [
                path.name for path in destination.iterdir() if path.is_file()
            ]
            replacements = [
                name for name in target_names if name in existing_files
            ]
            preserved = [
                name
                for name in existing_files
                if name not in replacements
            ]
            message = (
                "The output folder already exists:\n\n"
                + str(destination)
                + "\n\nFiles that will be replaced:\n"
                + ("\n".join(f"  - {name}" for name in replacements) or "  None")
                + "\n\nOther existing files that will remain untouched:\n"
                + (
                    "\n".join(f"  - {name}" for name in preserved[:12])
                    or "  None"
                )
            )
            if len(preserved) > 12:
                message += f"\n  - and {len(preserved) - 12} more"
            message += "\n\nContinue?"
            proceed = messagebox.askyesno(APP_TITLE, message)
            if not proceed:
                return
        try:
            destination.mkdir(parents=True, exist_ok=True)
            written = []
            newest_time = time.time()
            for order_index, (document, assignments) in enumerate(ordered_groups):
                writer = PdfWriter()
                for assignment in assignments:
                    page = copy.deepcopy(self.reader.pages[assignment.page_index])
                    if assignment.rotation:
                        page.rotate(assignment.rotation)
                    writer.add_page(page)
                output_path = destination / safe_filename(f"{packet_name} - {document}")
                with output_path.open("wb") as handle:
                    writer.write(handle)
                modified_time = newest_time - (order_index * 60)
                os.utime(output_path, (modified_time, modified_time))
                written.append(output_path.name)
            # lightweight audit trail
            audit_path = destination / "Export Audit Log.txt"
            with audit_path.open("w", encoding="utf-8") as audit:
                audit.write(
                    f"Packet: {self.packet_display_name or self.pdf_path.name}\n"
                    f"Profile: {self.active_profile_name}\n"
                    f"Exported: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                )
                if self.packet_source_paths:
                    audit.write("Source PDFs:\n")
                    for source_path in self.packet_source_paths:
                        audit.write(f"  - {source_path.name}\n")
                    audit.write("\n")
                for document, assignments in ordered_groups:
                    audit.write(f"{document}: pages {', '.join(str(a.page_number) for a in assignments)}\n")
                audit.write("\n" + self.build_review_summary() + "\n")
            audit_time = newest_time - (len(ordered_groups) * 60)
            os.utime(audit_path, (audit_time, audit_time))
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Export failed:\n\n{exc}")
            return
        export_status = (
            f"Exported {len(written)} PDFs + Export Audit Log.txt to {destination}."
        )
        self.clear_loaded_packet(export_status)
        report = (
            f"Finished. Exported {len(written)} PDFs to:\n\n{destination}\n\n"
            + "\n".join(f"  - {name}" for name in written)
            + "\n  - Export Audit Log.txt\n\n"
            + "Temporary OCR images have been deleted.\n\n"
            + "Open the output folder now?"
        )
        if automatic:
            self.notify_user(
                "Packet Exported",
                f"Exported {len(written)} PDFs to {destination}.",
            )
        elif messagebox.askyesno(APP_TITLE, report):
            try:
                os.startfile(destination)
            except Exception as exc:
                messagebox.showerror(
                    APP_TITLE,
                    "The folder could not be opened.\n\n" + str(exc),
                )
        self.root.after(250, self.process_watch_queue)

    def close(self):
        if not self.exiting:
            self.minimize_to_tray()
            self.status_var.set("Still running. Use the tray menu to exit.")
            self.notify_user(
                "Still Running",
                "PacketFlow is running in the system tray.",
            )
            return
        self.exit_application()


def main():
    configure_windows_app_identity()
    if not acquire_single_instance():
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showinfo(
                APP_TITLE,
                "PacketFlow is already running.",
            )
            root.destroy()
        except Exception:
            pass
        return
    root = ctk.CTk()
    app = PacketSorterApp(root)
    if not (app.setting_enabled("start_minimized_to_tray") and app.watch_enabled):
        root.after(100, lambda: root.state("zoomed"))
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        report_fatal_error(exc)
        raise
