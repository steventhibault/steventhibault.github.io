PACKETFLOW
Onboarding Document Processor
OCR + document classification + review before export

START
Double-click "Start PacketFlow.cmd".

INSTALL ON A COMPUTER
For a normal installed copy with a desktop shortcut, double-click
"Install PacketFlow.cmd". The installer places PacketFlow in the current
Windows user's local Programs folder, creates a desktop shortcut, and runs the
normal dependency check.

FIRST RUN REQUIREMENTS
The launcher checks for:
- Python 3.10 or newer
- Pillow, pypdf, customtkinter, windnd, and pystray
- Tesseract OCR
- Poppler PDF tools

If anything is missing, the launcher explains what is missing and attempts to
help install it or opens the correct download page.

BASIC WORKFLOW
1. Click Open Packet and select a PDF.
   You can also drag and drop a PDF onto the app window.
2. Wait while PacketFlow reads the pages.
3. Review the suggested PDF names and page groupings.
4. Select one or more pages to assign, rename, save adjustments, rotate, or mark unsorted.
5. Arrange the Output PDFs list with Move Up and Move Down.
6. Click Review Packet to inspect warnings.
7. Click Export PDFs and choose the destination folder.

After successful export, the completed packet is cleared from the processor so
it is ready for the next scan.

REVIEW AND TRUST FEATURES
PacketFlow includes document-level review features without using a single
overall packet-quality percentage:

- Header Statistics
  The header now shows a compact packet status line such as page count, PDF
count, unsorted count, blank pages removed, low-confidence pages, and duplicate
pairs. This gives supervisors a fast packet health check without opening a
separate screen.

- Confidence Meter
  Each output PDF row shows High, Medium, or Low Confidence with a percentage.
This helps reviewers know which documents need attention first.

- Assignment Details
  Click Assignment Details after selecting a page to review the classification.
The dialog shows the assigned document, confidence level, detected indicators,
and any missing checklist items with the confidence deduction beside each item.

- Save Adjustments
  After manually correcting pages, click Save Adjustments to save the correction
and learn recognition phrases for future packets. This improves future sorting
without editing code.

- Learned Badge
  Output rows show a Learned indicator when a page was assigned using remembered
correction memory. This makes it clear when PacketFlow reused a past correction.

- Duplicate Compare
  Review Packet includes a Review Duplicates option when suspected duplicates
are found. It opens a side-by-side preview of matching pages so staff can decide
what to keep or mark unsorted.

- Rule Export Metadata
  Exported rule profiles now include metadata fields such as schema_version,
profile_name, exported_at, and exported_by so teams can track which profile was
shared or installed.

CLASSIFIER TESTS
Double-click "Run Classifier Tests.cmd" to run the automated regression suite.
The tests use synthetic OCR text rather than employee documents. They cover
I-9 and identification documents, direct deposit and banking behavior, custom
rules, learned corrections, added multi-page files, blank pages, rotations,
document ordering, and forms that should intentionally remain unsorted.

HEADER AND BRANDING
This rebuild keeps the original PacketFlow logo and keeps the header wording:

Onboarding Document Processor
OCR + document classification + review before export

The removed "Intelligent Document Processing" subtitle was not kept.
The extra "Export to Last" header button was removed to reduce clutter.

SCANNER FOLDER WATCH
Click Scanner Folder and choose the folder used by the scanning program.
While PacketFlow remains open, new PDFs are detected and analyzed automatically.

- PDFs already in the folder when watching starts are ignored.
- A new PDF must remain unchanged for several checks before it is opened.
- This prevents reading a scan while it is still being written.
- Incoming PDFs wait while another packet is being analyzed.
- Automatic export can still be enabled in Preferences.
- The app can start with Windows and run minimized to the tray.

PREFERENCES
Preferences can turn these operational features on or off:
- Pause scanner folder watching
- Start with Windows
- Start minimized to tray
- Show packet-ready notifications
- Open and maximize for new scans
- Automatically start export after scanner analysis
- Apply remembered page corrections
- Apply remembered PDF order
- Remember the last export location
- Show duplicate-page warnings
- Show low-confidence warnings

CUSTOMIZATION
PacketFlow supports separate rule profiles for workflows such as HR,
Onboarding, Accounting, Operations, Customer Service, or client-specific use.

Profiles can be created, copied, renamed, switched, deleted, exported, and
imported. Each profile keeps its own:
- Document types
- Expected checklist
- Recognition phrases
- Learned custom rules
- Remembered corrections
- Preferred PDF output order

Manage Document Rules lets users create output PDF names and OCR matching rules
without changing the program code. Custom rules run before the built-in
onboarding starter profile.

REVIEW AND SAFETY
PacketFlow always keeps human review in the workflow.

Review Packet reports:
- Expected documents found or missing
- Unsorted pages
- Low-confidence scans
- Suspected duplicate pages
- Pages used in multiple PDFs
- Blank pages removed
- Automatic or manual rotations
- Remembered corrections applied
- Packet Quality score

Export always displays the review before writing files. If the output folder
already exists, PacketFlow lists files that will be replaced and confirms that
unrelated files will remain untouched.

IMPORTANT BEHAVIOR
- The app never divides a source page. If one scan page contains two documents,
it should be rescanned correctly.
- Blank scanner pages are removed automatically.
- Upside-down scans are detected, shown upright, and exported upright.
- Banking/check pages can be included in both Banking.pdf and Viventium Direct
Deposit.pdf when appropriate.
- I-9 pages are grouped with qualifying support documents from official I-9
Lists A, B, and C.
- All export filenames are normalized with a clean .pdf suffix.

OUTPUT ORDER
The PDFs are written in the order shown in the Output PDFs list. Modification
times are staggered one minute apart so Windows File Explorer can show the same
order when sorted by Date modified descending.

TROUBLESHOOTING
Use "Run app directly - show errors.cmd" to launch PacketFlow in a console if it
will not open normally. Fatal startup errors are written to the PacketFlow error
log in the current user's APPDATA PacketFlow folder when available.

UNINSTALL
Use "Uninstall_PacketFlow.cmd" to remove the installed copy and shortcut.

ASSIGNMENT DETAILS UPDATE
The Assignment Details tool explains confidence without duplicate sections. It is designed to answer the practical review question: "What was detected and what is missing?"

For each selected page, Assignment Details shows:
- Assigned document name
- Final confidence percentage and band
- Detected indicators found on the page
- Missing checklist items with deductions shown inline, such as Employee availability sheet (-4%)

Examples of missing expected indicators include:
- Employee availability sheet
- Work reference section
- Compensation agreement
- Supporting identity/work document for I-9 packets
- Authorization and release wording for background-check forms
- Direct deposit authorization wording

PacketFlow intentionally prioritizes document-specific missing indicators over
generic scan-quality warnings. Missing checklist items show their deduction
inline so staff can quickly see what lowered confidence.

CONFIDENCE BANDS
- 95-100%: Very High Confidence
- 85-94%: High Confidence
- 70-84%: Medium Confidence
- Below 70%: Review Recommended

The packet header statistics now count pages needing review based on confidence
below the High Confidence range, rather than only generic OCR quality checks.
