from __future__ import annotations

import importlib.util
import sys
import tempfile
import types
import unittest
from pathlib import Path

from pypdf import PdfWriter


# The classifier itself does not use the UI toolkit. This small fallback lets
# the tests run in a development environment before optional UI packages are
# installed.
if importlib.util.find_spec("customtkinter") is None:
    sys.modules["customtkinter"] = types.ModuleType("customtkinter")

from app import Assignment, PacketAnalyzer, PacketSorterApp
from email_intake import (
    GraphOutlookIntake,
    LocalOutlookIntake,
    ProcessedMessageStore,
    email_body_pdf_name,
    html_to_text,
    render_email_body_pdf,
)
from directory_audit import (
    audit_directory,
    document_for_filename,
    format_audit_report,
)


def documents_for_page(
    assignments: list[Assignment],
    page_index: int,
) -> set[str]:
    return {
        assignment.document
        for assignment in assignments
        if assignment.page_index == page_index
    }


class PacketAnalyzerClassificationTests(unittest.TestCase):
    def setUp(self):
        self.analyzer = PacketAnalyzer(
            {
                "document_types": [],
                "expected_document_types": [],
                "custom_rules": [],
            }
        )

    def classify(
        self,
        *texts: str,
        rotations: list[int] | None = None,
        blank_pages: set[int] | None = None,
    ) -> list[Assignment]:
        return self.analyzer.classify_pages(
            list(texts),
            rotations=rotations,
            blank_pages=blank_pages,
        )

    def test_blank_pages_are_never_classified(self):
        assignments = self.classify(
            "Orientation Agenda",
            "Job Application",
            blank_pages={0},
        )

        self.assertEqual(documents_for_page(assignments, 0), set())
        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Job Application.pdf"},
        )

    def test_detected_rotation_is_preserved_on_assignment(self):
        assignments = self.classify(
            "Orientation Agenda",
            rotations=[180],
        )

        self.assertEqual(len(assignments), 1)
        self.assertEqual(assignments[0].rotation, 180)

    def test_custom_all_rule_requires_every_keyword(self):
        self.analyzer.rules["custom_rules"] = [
            {
                "document": "Non-Disclosure Agreement.pdf",
                "keywords": ["confidential information", "covenant not to disclose"],
                "match_mode": "all",
            }
        ]

        matched = self.classify(
            "CONFIDENTIAL INFORMATION and covenant not to disclose"
        )
        not_matched = self.classify("Confidential information only")

        self.assertEqual(
            documents_for_page(matched, 0),
            {"Non-Disclosure Agreement.pdf"},
        )
        self.assertEqual(documents_for_page(not_matched, 0), set())

    def test_custom_any_rule_accepts_one_keyword(self):
        self.analyzer.rules["custom_rules"] = [
            {
                "document": "Safety Training.pdf",
                "keywords": ["safety orientation", "workplace safety"],
                "match_mode": "any",
            }
        ]

        assignments = self.classify("Annual workplace safety review")

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Safety Training.pdf"},
        )

    def test_custom_rules_take_priority_over_built_in_rules(self):
        self.analyzer.rules["custom_rules"] = [
            {
                "document": "Accounting Authorization.pdf",
                "keywords": ["direct deposit authorization form"],
                "match_mode": "all",
            }
        ]

        assignments = self.classify("Direct Deposit Authorization Form")

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Accounting Authorization.pdf"},
        )

    def test_custom_banking_rule_also_adds_direct_deposit_output(self):
        self.analyzer.rules["custom_rules"] = [
            {
                "document": "Banking.pdf",
                "keywords": ["bank account verification"],
                "match_mode": "all",
            }
        ]

        assignments = self.classify("Bank Account Verification")

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Banking.pdf", "Viventium Direct Deposit.pdf"},
        )

    def test_non_disclosure_agreement_is_detected(self):
        for text in (
            "NON-DISCLOSURE AGREEMENT (NDA)",
            "Nondisclosure Agreement between the parties",
        ):
            with self.subTest(text=text):
                assignments = self.classify(text)
                self.assertEqual(
                    documents_for_page(assignments, 0),
                    {"Non-Disclosure Agreement.pdf"},
                )

    def test_i9_form_is_detected(self):
        assignments = self.classify(
            "Form I-9 Employment Eligibility Verification "
            "Department of Homeland Security"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Form I-9 Employment Eligibility Verification.pdf"},
        )

    def test_driver_license_is_grouped_with_i9(self):
        assignments = self.classify(
            "Driver's License DL. No 123456 Class C Expires 2028"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Form I-9 Employment Eligibility Verification.pdf"},
        )

    def test_passport_is_grouped_with_i9(self):
        assignments = self.classify(
            "United States of America Passport Nationality USA "
            "Passport No 123456 Date of Expiration 2028"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Form I-9 Employment Eligibility Verification.pdf"},
        )

    def test_other_supported_i9_identification_is_detected(self):
        samples = (
            "Social Security Administration signature",
            "Permanent Resident Card Resident Since 2020 Card Expires 2030",
            "Employment Authorization Card USCIS Category Card Expires 2028",
            "Passport I-94 Arrival/Departure Record Class of Admission "
            "Employment Authorized",
            "Government Identification Card Date of Birth Photograph",
            "School Identification Card Student",
            "Voter Registration Card",
            "United States Uniformed Services Identification",
            "United States Coast Guard Merchant Mariner Credential",
            "Native American Tribal Document",
            "Canada Driver's Licence Class C Expires 2028",
            "I-197 Citizen Identification Card",
            "I-179 Resident Citizen Identification Card",
            "Certificate of Naturalization",
        )
        for text in samples:
            with self.subTest(text=text):
                assignments = self.classify(text)
                self.assertEqual(
                    documents_for_page(assignments, 0),
                    {"Form I-9 Employment Eligibility Verification.pdf"},
                )

    def test_minor_identity_record_requires_i9_adjacency(self):
        assignments = self.classify(
            "Form I-9 Department of Homeland Security",
            "School Record Student Report Card",
        )
        standalone = self.classify("School Record Student Report Card")

        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Form I-9 Employment Eligibility Verification.pdf"},
        )
        self.assertEqual(documents_for_page(standalone, 0), set())

    def test_replacement_receipt_requires_i9_adjacency(self):
        assignments = self.classify(
            "Form I-9 Department of Homeland Security",
            "Receipt for replacement document lost stolen Form I-797C",
        )

        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Form I-9 Employment Eligibility Verification.pdf"},
        )

    def test_restricted_social_security_card_is_not_accepted(self):
        assignments = self.classify(
            "Social Security Administration Not Valid for Employment"
        )

        self.assertEqual(documents_for_page(assignments, 0), set())

    def test_birth_certificate_is_in_birth_records_and_i9(self):
        assignments = self.classify(
            "Certificate of Live Birth Date of Birth Place of Birth"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {
                "Birth and Marriage Certificates.pdf",
                "Form I-9 Employment Eligibility Verification.pdf",
            },
        )

    def test_vital_record_birth_certificate_is_in_birth_records_and_i9(self):
        assignments = self.classify(
            "Certification of Vital Record State of Maine "
            "Certified Abstract of a Certificate of Live Birth"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {
                "Birth and Marriage Certificates.pdf",
                "Form I-9 Employment Eligibility Verification.pdf",
            },
        )

    def test_vague_vital_record_wording_is_not_treated_as_birth_certificate(self):
        assignments = self.classify(
            "Certification of Vital Record State of Maine Records Office"
        )

        self.assertEqual(documents_for_page(assignments, 0), set())

    def test_marriage_certificate_is_not_added_to_i9(self):
        assignments = self.classify(
            "Certificate of Marriage Vital Records Party A Party B"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Birth and Marriage Certificates.pdf"},
        )

    def test_mixed_i9_and_orientation_page_is_left_unsorted(self):
        assignments = self.classify(
            "Form I-9 Department of Homeland Security Orientation Agenda"
        )

        self.assertEqual(documents_for_page(assignments, 0), set())

    def test_orientation_agenda_is_detected(self):
        assignments = self.classify("Orientation Agenda")

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Orientation Agenda.pdf"},
        )

    def test_interview_statement_is_detected(self):
        assignments = self.classify(
            "Interview Statement Interviewed By "
            "What are your strengths? What are your weaknesses?"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Interview Statement.pdf"},
        )

    def test_job_application_pages_are_detected(self):
        samples = (
            "Job Application",
            "Employee Availability Sheet",
            "Work Reference",
            "Handbook Acknowledgement Form",
            "The job description provides a framework for the job",
        )
        for text in samples:
            with self.subTest(text=text):
                assignments = self.classify(text)
                self.assertEqual(
                    documents_for_page(assignments, 0),
                    {"Job Application.pdf"},
                )

    def test_federal_w4_is_detected(self):
        assignments = self.classify(
            "Form W-4 Employee's Withholding Certificate "
            "Internal Revenue Service Treasury"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Federal W-4 Withholding.pdf"},
        )

    def test_time_recording_is_detected(self):
        assignments = self.classify("Recording of Time Worked")

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Time Recording.pdf"},
        )

    def test_maine_payroll_withholding_is_detected(self):
        assignments = self.classify(
            "W-4ME Maine Withholding Allowance Certificate"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Payroll.pdf"},
        )

    def test_direct_deposit_form_does_not_duplicate_into_banking(self):
        assignments = self.classify(
            "TD Bank Direct Deposit Authorization Form Payroll Compensation"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Viventium Direct Deposit.pdf"},
        )

    def test_generic_direct_deposit_words_are_not_enough(self):
        assignments = self.classify("Direct Deposit")

        self.assertEqual(documents_for_page(assignments, 0), set())

    def test_check_or_account_page_goes_to_banking_and_direct_deposit(self):
        assignments = self.classify(
            "Voided Check Routing Number 011000015 Checking Account 1234"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Banking.pdf", "Viventium Direct Deposit.pdf"},
        )

    def test_sparse_page_after_direct_deposit_is_treated_as_banking(self):
        assignments = self.classify(
            "Employee Direct Deposit Authorization",
            "__SPARSE_SCAN__ account image",
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Viventium Direct Deposit.pdf"},
        )
        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Banking.pdf", "Viventium Direct Deposit.pdf"},
        )

    def test_legacy_paypro_payroll_is_ignored(self):
        assignments = self.classify(
            "PayPro Payroll Card Mailing Address Net Pay Employee Signature"
        )

        self.assertEqual(documents_for_page(assignments, 0), set())

    def test_auto_enrollment_opt_out_is_detected(self):
        assignments = self.classify(
            "Automatic Auto Enrollment Plan Opt Out Election"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Auto Enrollment Opt Out.pdf"},
        )

    def test_employee_choice_waiver_is_detected(self):
        assignments = self.classify(
            "Employee Choice Acknowledgement Waiver Form Decline All Coverage"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Employee Choice Acknowledgement Waiver.pdf"},
        )

    def test_background_and_child_protection_forms_are_detected(self):
        samples = {
            "CHERKR consumer report candidate disclosure":
                "CHERKR Authorization.pdf",
            "Maine Background Check Center authorization and release":
                "MBC Authorization.pdf",
            "Application fee paid for Maine criminal background check":
                "MBC Payment.pdf",
            "Child abuse background check confirmation":
                "Confirmation - Child Abuse Registry Background Check Request.pdf",
            "Child abuse and neglect records information":
                "Child Protective Services Authorization.pdf",
        }
        for text, expected in samples.items():
            with self.subTest(expected=expected):
                assignments = self.classify(text)
                self.assertEqual(
                    documents_for_page(assignments, 0),
                    {expected},
                )

    def test_document_sequences_keep_i9_and_job_pages_in_order(self):
        i9_form = self.analyzer.document_sequence(
            "Form I-9 Employment Eligibility Verification.pdf",
            "form i-9",
        )
        i9_id = self.analyzer.document_sequence(
            "Form I-9 Employment Eligibility Verification.pdf",
            "driver's license",
        )
        application = self.analyzer.document_sequence(
            "Job Application.pdf",
            "job application",
        )
        handbook = self.analyzer.document_sequence(
            "Job Application.pdf",
            "handbook acknowledgement form",
        )

        self.assertLess(i9_form, i9_id)
        self.assertLess(application, handbook)


class AddedFileInheritanceTests(unittest.TestCase):
    def test_single_detected_document_is_inherited_by_remaining_file_pages(self):
        assignments = PacketSorterApp.inherit_added_file_assignments(
            [Assignment(0, "Non-Disclosure Agreement.pdf")],
            blank_pages=set(),
            source_page_ranges=[(0, 2)],
            rotations=[0, 0],
        )

        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Non-Disclosure Agreement.pdf"},
        )

    def test_banking_pair_is_inherited_by_remaining_file_pages(self):
        assignments = PacketSorterApp.inherit_added_file_assignments(
            [
                Assignment(0, "Banking.pdf"),
                Assignment(0, "Viventium Direct Deposit.pdf"),
            ],
            blank_pages=set(),
            source_page_ranges=[(0, 2)],
            rotations=[0, 180],
        )

        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Banking.pdf", "Viventium Direct Deposit.pdf"},
        )
        inherited = [
            assignment
            for assignment in assignments
            if assignment.page_index == 1
        ]
        self.assertTrue(all(item.rotation == 180 for item in inherited))

    def test_ambiguous_file_does_not_inherit_assignments(self):
        assignments = PacketSorterApp.inherit_added_file_assignments(
            [
                Assignment(0, "Job Application.pdf"),
                Assignment(0, "Interview Statement.pdf"),
            ],
            blank_pages=set(),
            source_page_ranges=[(0, 2)],
            rotations=[0, 0],
        )

        self.assertEqual(documents_for_page(assignments, 1), set())

    def test_blank_continuation_page_is_not_inherited(self):
        assignments = PacketSorterApp.inherit_added_file_assignments(
            [Assignment(0, "Non-Disclosure Agreement.pdf")],
            blank_pages={1},
            source_page_ranges=[(0, 2)],
            rotations=[0, 0],
        )

        self.assertEqual(documents_for_page(assignments, 1), set())


class I9ConfidenceTests(unittest.TestCase):
    def setUp(self):
        self.app = PacketSorterApp.__new__(PacketSorterApp)
        self.app.rules = {
            "document_types": [],
            "expected_document_types": [],
            "custom_rules": [],
        }
        self.app.analyzer = PacketAnalyzer(self.app.rules)
        self.app.memory_applied_pages = set()

    def details_for(self, text: str) -> dict:
        self.app.ocr_texts = [text]
        return self.app.assignment_confidence_details(
            Assignment(
                0,
                "Form I-9 Employment Eligibility Verification.pdf",
            )
        )

    def test_standalone_driver_license_has_high_confidence(self):
        details = self.details_for(
            "Driver's License DL. No 123456 Class C Expires 2028"
        )

        self.assertEqual(details["score"], 100)
        self.assertIn("Driver's license / state ID", details["matched"])
        self.assertNotIn("Form I-9 heading", details["missing"])

    def test_driver_license_with_missed_heading_uses_license_fields(self):
        details = self.details_for(
            "USA Maine NOT INTENDED FOR FEDERAL PURPOSES "
            "2072168 expires 04/20/2030 issued 09/13/2024 "
            "gender F height 5-08 eyes BLU class C "
            "endorsements none restrictions none __SPARSE_SCAN__"
        )

        self.assertEqual(details["score"], 100)
        self.assertIn("Driver's license / state ID", details["matched"])
        self.assertIn("License details", details["matched"])
        self.assertNotIn("Form I-9 heading", details["missing"])

    def test_standalone_social_security_card_has_high_confidence(self):
        details = self.details_for(
            "Social Security Administration Social Security signature"
        )

        self.assertEqual(details["score"], 100)
        self.assertIn("Social Security card", details["matched"])
        self.assertNotIn("Form I-9 heading", details["missing"])

    def test_driver_license_and_social_security_on_same_page_are_high_confidence(self):
        details = self.details_for(
            "Driver's License DL. No 123456 Class C Expires 2028 "
            "Social Security Administration Social Security signature"
        )

        self.assertEqual(details["score"], 100)
        self.assertIn("Driver's license / state ID", details["matched"])
        self.assertIn("Social Security card", details["matched"])
        self.assertEqual(details["missing"], [])

    def test_standalone_passport_has_high_confidence(self):
        details = self.details_for(
            "United States of America Passport Nationality USA "
            "Passport No 123456 Date of Expiration 2028"
        )

        self.assertEqual(details["score"], 100)
        self.assertIn("Passport", details["matched"])
        self.assertNotIn("Form I-9 heading", details["missing"])

    def test_other_standalone_i9_documents_have_high_confidence(self):
        samples = (
            "Permanent Resident Card Resident Since 2020 Card Expires 2030",
            "Employment Authorization Card USCIS Category Card Expires 2028",
            "Voter Registration Card",
            "United States Coast Guard Merchant Mariner Credential",
            "Certificate of Naturalization",
        )
        for text in samples:
            with self.subTest(text=text):
                details = self.details_for(text)
                self.assertEqual(details["score"], 100)
                self.assertNotIn("Form I-9 heading", details["missing"])

    def test_unreadable_id_page_still_receives_low_confidence(self):
        details = self.details_for("__SPARSE_SCAN__ unreadable card image")

        self.assertLess(details["score"], 70)
        self.assertIn("Form I-9 heading", details["missing"])

    def test_restricted_social_security_card_is_not_high_confidence(self):
        details = self.details_for(
            "Social Security Administration Social Security "
            "Not Valid for Employment"
        )

        self.assertLess(details["score"], 70)

    def test_actual_i9_form_uses_i9_form_checklist(self):
        details = self.details_for(
            "Form I-9 Employment Eligibility Verification "
            "Department of Homeland Security Employee Information "
            "Employee Attestation Employer Review Authorized Representative "
            "Foreign Passport Number Social Security Number "
            "Permanent Resident Employment Authorization"
        )

        self.assertEqual(details["score"], 100)
        self.assertIn("Form I-9 heading", details["matched"])
        self.assertIn(
            "Department of Homeland Security / USCIS wording",
            details["matched"],
        )
        self.assertNotIn("passport", details["matched"])
        self.assertNotIn("social security", details["matched"])
        self.assertNotIn("permanent resident", details["matched"])
        self.assertNotIn("employment authorization", details["matched"])

    def test_i9_acceptable_document_list_does_not_report_actual_id_evidence(self):
        details = self.details_for(
            "Lists of Acceptable Documents Documents that Establish Identity "
            "Documents that Establish Employment Authorization "
            "Foreign Passport Number Social Security Number "
            "Permanent Resident Card Employment Authorization Document"
        )

        self.assertIn("Form I-9 heading", details["missing"])
        self.assertNotIn("Passport", details["matched"])
        self.assertNotIn("Social Security card", details["matched"])
        self.assertNotIn("Permanent resident / I-551 evidence", details["matched"])
        self.assertNotIn("Employment authorization document", details["matched"])

    def test_generic_receipt_wording_is_not_replacement_document_evidence(self):
        details = self.details_for(
            "Acknowledges receipt of the handbook and agreement to follow policy"
        )

        self.assertNotIn("Replacement document receipt", details["matched"])

    def test_generic_coast_guard_wording_is_not_merchant_mariner_evidence(self):
        details = self.details_for("United States Coast Guard safety notice")

        self.assertNotIn("Merchant mariner credential", details["matched"])


class OutputCompletenessTests(unittest.TestCase):
    def setUp(self):
        self.app = PacketSorterApp.__new__(PacketSorterApp)
        self.app.rules = {
            "document_types": [],
            "expected_document_types": [],
            "custom_rules": [],
        }
        self.app.analyzer = PacketAnalyzer(self.app.rules)
        self.app.memory_applied_pages = set()
        self.app.blank_pages = set()
        self.app.assignments = []

    def i9_assignments(self) -> list[Assignment]:
        return [
            Assignment(
                index,
                "Form I-9 Employment Eligibility Verification.pdf",
            )
            for index in range(len(self.app.ocr_texts))
        ]

    def test_i9_form_without_ids_is_a_fail(self):
        self.app.ocr_texts = [
            "Form I-9 Employment Eligibility Verification "
            "Department of Homeland Security Employee Attestation "
            "Employer Review Authorized Representative"
        ]
        assignments = self.i9_assignments()
        self.app.assignments = assignments

        details = self.app.output_completeness_details(assignments)
        label, _color = self.app.confidence_label_for_assignments(assignments)

        self.assertFalse(details["complete"])
        self.assertIn("Missing 2 forms of identification", details["issues"])
        self.assertTrue(label.startswith("FAIL"))

    def test_i9_form_with_one_id_is_a_fail(self):
        self.app.ocr_texts = [
            "Form I-9 Employment Eligibility Verification "
            "Department of Homeland Security",
            "Driver's License DL. No 123456 Class C Expires 2028",
        ]
        assignments = self.i9_assignments()
        self.app.assignments = assignments

        details = self.app.output_completeness_details(assignments)

        self.assertFalse(details["complete"])
        self.assertIn("Missing 1 form of identification", details["issues"])

    def test_i9_form_with_two_ids_is_complete(self):
        self.app.ocr_texts = [
            "Form I-9 Employment Eligibility Verification "
            "Department of Homeland Security",
            "Driver's License DL. No 123456 Class C Expires 2028 "
            "Social Security Administration Social Security signature",
        ]
        assignments = self.i9_assignments()
        self.app.assignments = assignments

        details = self.app.output_completeness_details(assignments)
        label, _color = self.app.confidence_label_for_assignments(assignments)

        self.assertTrue(details["complete"])
        self.assertFalse(label.startswith("FAIL"))

    def test_passport_with_i94_counts_as_one_id(self):
        self.app.ocr_texts = [
            "Form I-9 Employment Eligibility Verification "
            "Department of Homeland Security",
            "Passport No 123456 Nationality USA I-94 Arrival/Departure Record "
            "Employment Authorized Class of Admission",
        ]
        assignments = self.i9_assignments()
        self.app.assignments = assignments

        details = self.app.output_completeness_details(assignments)

        self.assertFalse(details["complete"])
        self.assertIn("Missing 1 form of identification", details["issues"])

    def test_birth_certificate_counts_as_one_of_two_ids(self):
        self.app.ocr_texts = [
            "Form I-9 Employment Eligibility Verification "
            "Department of Homeland Security",
            "Certificate of Live Birth Date of Birth Place of Birth",
            "Driver's License DL. No 123456 Class C Expires 2028",
        ]
        assignments = self.i9_assignments()
        self.app.assignments = assignments

        details = self.app.output_completeness_details(assignments)

        self.assertTrue(details["complete"])

    def test_direct_deposit_requires_form_and_banking_evidence(self):
        self.app.ocr_texts = [
            "Employee Direct Deposit Authorization Form Authorization Agreement"
        ]
        assignments = [Assignment(0, "Viventium Direct Deposit.pdf")]
        self.app.assignments = assignments

        missing_banking = self.app.output_completeness_details(assignments)

        self.app.ocr_texts.append("__SPARSE_SCAN__")
        assignments.append(Assignment(1, "Viventium Direct Deposit.pdf"))
        self.app.assignments = assignments + [Assignment(1, "Banking.pdf")]
        complete = self.app.output_completeness_details(assignments)

        self.assertFalse(missing_banking["complete"])
        self.assertIn(
            "Banking or checking-account evidence is missing",
            missing_banking["issues"],
        )
        self.assertTrue(complete["complete"])

    def test_job_application_requires_all_expected_sections(self):
        self.app.ocr_texts = [
            "Job Application Employee Availability Sheet Work Reference "
            "Handbook Acknowledgement Employee Handbook "
            "Non-Exempt Compensation Agreement "
            "Job Description Duties and Responsibilities"
        ]
        assignments = [Assignment(0, "Job Application.pdf")]
        self.app.assignments = assignments

        complete = self.app.output_completeness_details(assignments)
        self.app.ocr_texts = [
            "Job Application Employee Availability Sheet Work Reference "
            "Handbook Acknowledgement Employee Handbook "
            "Job Description Duties and Responsibilities"
        ]
        missing = self.app.output_completeness_details(assignments)

        self.assertTrue(complete["complete"])
        self.assertFalse(missing["complete"])
        self.assertIn("Compensation agreement", missing["issues"][0])

    def test_mbc_requires_signed_pages_but_not_instructions(self):
        self.app.ocr_texts = [
            "Notification and Authorization and Release",
            "Authorization and Release by the Applicant Signature of Applicant",
            "Voluntary Consent for Disclosure",
        ]
        assignments = [
            Assignment(index, "MBC Authorization.pdf")
            for index in range(3)
        ]
        self.app.assignments = assignments

        complete = self.app.output_completeness_details(assignments)
        shortened = self.app.output_completeness_details(assignments[:2])

        self.assertTrue(complete["complete"])
        self.assertFalse(shortened["complete"])
        self.assertIn("Voluntary consent page", shortened["issues"][0])

    def test_w4_form_is_complete_without_instruction_pages(self):
        self.app.ocr_texts = [
            "Form W-4 Employee's Withholding Certificate Department of Treasury"
        ]
        assignments = [Assignment(0, "Federal W-4 Withholding.pdf")]
        self.app.assignments = assignments

        details = self.app.output_completeness_details(assignments)

        self.assertTrue(details["complete"])


class JobApplicationConfidenceTests(unittest.TestCase):
    def setUp(self):
        self.app = PacketSorterApp.__new__(PacketSorterApp)
        self.app.rules = {
            "document_types": [],
            "expected_document_types": [],
            "custom_rules": [],
        }
        self.app.analyzer = PacketAnalyzer(self.app.rules)
        self.app.memory_applied_pages = set()
        self.app.blank_pages = set()

    def test_continuation_page_uses_multi_page_job_application_context(self):
        self.app.ocr_texts = [
            "Job Application Employee Availability Sheet",
            "Work Reference Personal References",
            "Handbook Acknowledgement Form Employee Handbook",
            "Non-Exempt Compensation Agreement Compensation Agreement",
            "The job description provides a framework for the job duties and responsibilities",
            "Are you 18 years or older? Phone number email address emergency contact",
        ]
        self.app.assignments = [
            Assignment(index, "Job Application.pdf")
            for index in range(len(self.app.ocr_texts))
        ]

        details = self.app.assignment_confidence_details(
            Assignment(5, "Job Application.pdf")
        )
        label, _color = self.app.confidence_label_for_assignments(
            self.app.assignments
        )

        self.assertGreaterEqual(details["score"], 90)
        self.assertIn("Multi-page document evidence found", details["matched"])
        self.assertNotIn("Compensation agreement", details["missing"])
        self.assertIn("High Confidence", label)

    def test_single_unexplained_job_application_page_still_gets_review_score(self):
        self.app.ocr_texts = [
            "Are you 18 years or older? Phone number email address emergency contact"
        ]
        self.app.assignments = [Assignment(0, "Job Application.pdf")]

        details = self.app.assignment_confidence_details(
            Assignment(0, "Job Application.pdf")
        )

        self.assertLess(details["score"], 70)
        self.assertIn("Compensation agreement", details["missing"])

    def test_generic_words_do_not_become_explanation_hits(self):
        self.app.ocr_texts = [
            "Background check driver's license social security passport receipt"
        ]
        self.app.assignments = [Assignment(0, "Job Application.pdf")]

        details = self.app.assignment_confidence_details(
            Assignment(0, "Job Application.pdf")
        )

        self.assertEqual(details["matched"], [])
        self.assertEqual(details["matched_indicator_count"], 0)

    def test_sparse_job_application_page_does_not_borrow_group_confidence(self):
        self.app.ocr_texts = [
            "Job Application Employee Availability Sheet",
            "Work Reference Personal References",
            "Non-Exempt Compensation Agreement Compensation Agreement",
            "__SPARSE_SCAN__",
        ]
        self.app.assignments = [
            Assignment(index, "Job Application.pdf")
            for index in range(len(self.app.ocr_texts))
        ]

        details = self.app.assignment_confidence_details(
            Assignment(3, "Job Application.pdf")
        )

        self.assertLess(details["score"], 70)
        self.assertNotIn("Multi-page document evidence found", details["matched"])


class DirectDepositConfidenceTests(unittest.TestCase):
    def setUp(self):
        self.app = PacketSorterApp.__new__(PacketSorterApp)
        self.app.rules = {
            "document_types": [],
            "expected_document_types": [],
            "custom_rules": [],
        }
        self.app.analyzer = PacketAnalyzer(self.app.rules)
        self.app.memory_applied_pages = set()
        self.app.blank_pages = set()

    def test_attached_check_uses_direct_deposit_form_context(self):
        self.app.ocr_texts = [
            "Viventium Payroll Employee Direct Deposit Authorization "
            "Authorization Agreement",
            "__SPARSE_SCAN__",
        ]
        self.app.assignments = [
            Assignment(0, "Viventium Direct Deposit.pdf"),
            Assignment(1, "Banking.pdf"),
            Assignment(1, "Viventium Direct Deposit.pdf"),
        ]

        banking = self.app.assignment_confidence_details(
            Assignment(1, "Banking.pdf")
        )
        direct_deposit = self.app.assignment_confidence_details(
            Assignment(1, "Viventium Direct Deposit.pdf")
        )
        output_label, _color = self.app.confidence_label_for_assignments(
            [
                Assignment(0, "Viventium Direct Deposit.pdf"),
                Assignment(1, "Viventium Direct Deposit.pdf"),
            ]
        )

        self.assertEqual(banking["score"], 100)
        self.assertEqual(direct_deposit["score"], 100)
        self.assertIn("Multi-page document evidence found", banking["matched"])
        self.assertNotIn("Review Recommended", output_label)

    def test_separate_check_page_can_follow_direct_deposit_form(self):
        self.app.ocr_texts = [
            "Employee Direct Deposit Authorization Form Authorization Agreement",
            "unrelated separator page",
            "__SPARSE_SCAN__",
        ]
        self.app.assignments = [
            Assignment(0, "Viventium Direct Deposit.pdf"),
            Assignment(2, "Banking.pdf"),
            Assignment(2, "Viventium Direct Deposit.pdf"),
        ]

        details = self.app.assignment_confidence_details(
            Assignment(2, "Viventium Direct Deposit.pdf")
        )

        self.assertEqual(details["score"], 100)

    def test_unlinked_sparse_banking_page_stays_low_confidence(self):
        self.app.ocr_texts = ["__SPARSE_SCAN__"]
        self.app.assignments = [Assignment(0, "Banking.pdf")]

        details = self.app.assignment_confidence_details(
            Assignment(0, "Banking.pdf")
        )

        self.assertLess(details["score"], 70)
        self.assertNotIn("Multi-page document evidence found", details["matched"])


class PageDisplayLabelTests(unittest.TestCase):
    def setUp(self):
        self.app = PacketSorterApp.__new__(PacketSorterApp)
        self.app.rules = {
            "document_types": [],
            "expected_document_types": [],
            "custom_rules": [],
        }
        self.app.analyzer = PacketAnalyzer(self.app.rules)
        self.app.blank_pages = set()

    def test_i9_support_page_displays_as_identification(self):
        self.app.ocr_texts = [
            "Form I-9 Employment Eligibility Verification Department of Homeland Security",
            "USA Maine NOT INTENDED FOR FEDERAL PURPOSES "
            "2072168 expires 04/20/2030 issued 09/13/2024 "
            "gender F height 5-08 eyes BLU class C "
            "endorsements none restrictions none __SPARSE_SCAN__",
        ]
        self.app.assignments = [
            Assignment(
                0,
                "Form I-9 Employment Eligibility Verification.pdf",
            ),
            Assignment(
                1,
                "Form I-9 Employment Eligibility Verification.pdf",
            ),
        ]

        i9_label, i9_state = self.app.page_label_for(0)
        id_label, id_state = self.app.page_label_for(1)

        self.assertEqual(
            i9_label,
            "Form I-9 Employment Eligibility Verification.pdf",
        )
        self.assertEqual(id_label, "Identification.pdf")
        self.assertEqual(i9_state, "sorted")
        self.assertEqual(id_state, "sorted")
        self.assertEqual(
            {assignment.document for assignment in self.app.assignments},
            {"Form I-9 Employment Eligibility Verification.pdf"},
        )

    def test_identification_label_is_shown_without_pdf_suffix_in_left_pane(self):
        status, detail = self.app.compact_page_parts(
            3,
            "Identification.pdf",
            "sorted",
        )

        self.assertEqual(status, "READ")
        self.assertIn("Identification", detail)
        self.assertNotIn(".pdf", detail)

    def test_non_i9_document_label_is_unchanged(self):
        self.app.ocr_texts = ["Orientation Agenda"]
        self.app.assignments = [Assignment(0, "Orientation Agenda.pdf")]

        label, state = self.app.page_label_for(0)

        self.assertEqual(label, "Orientation Agenda.pdf")
        self.assertEqual(state, "sorted")

    def test_birth_certificate_displays_as_identification_but_keeps_both_outputs(self):
        self.app.ocr_texts = [
            "Certification of Vital Record State of Maine "
            "Certified Abstract of a Certificate of Live Birth"
        ]
        self.app.assignments = [
            Assignment(0, "Birth and Marriage Certificates.pdf"),
            Assignment(
                0,
                "Form I-9 Employment Eligibility Verification.pdf",
            ),
        ]

        label, state = self.app.page_label_for(0)

        self.assertEqual(label, "Identification.pdf")
        self.assertEqual(state, "sorted")
        self.assertEqual(
            {assignment.document for assignment in self.app.assignments},
            {
                "Birth and Marriage Certificates.pdf",
                "Form I-9 Employment Eligibility Verification.pdf",
            },
        )


class CorrectionMemoryTests(unittest.TestCase):
    def setUp(self):
        self.app = PacketSorterApp.__new__(PacketSorterApp)
        self.text = (
            "employee confidential information agreement owner recipient "
            "business purpose disclosure covenant consent materials records "
            "signature effective date obligations remedies provisions notice"
        )

    def remember(self, document: str):
        self.app.correction_memory = [
            {
                "document": document,
                "signature": self.app.correction_signature(self.text),
            }
        ]

    def test_remembered_assignment_replaces_classifier_result(self):
        self.remember("Non-Disclosure Agreement.pdf")

        assignments, applied = self.app.apply_correction_memory(
            [self.text],
            [Assignment(0, "Job Application.pdf")],
            rotations=[0],
            blank_pages=set(),
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Non-Disclosure Agreement.pdf"},
        )
        self.assertEqual(applied, {0})

    def test_remembered_banking_assignment_adds_both_outputs(self):
        self.remember("Banking.pdf")

        assignments, applied = self.app.apply_correction_memory(
            [self.text],
            [],
            rotations=[180],
            blank_pages=set(),
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Banking.pdf", "Viventium Direct Deposit.pdf"},
        )
        self.assertEqual(applied, {0})
        self.assertTrue(all(item.rotation == 180 for item in assignments))

    def test_correction_memory_does_not_apply_to_blank_pages(self):
        self.remember("Non-Disclosure Agreement.pdf")

        assignments, applied = self.app.apply_correction_memory(
            [self.text],
            [],
            rotations=[0],
            blank_pages={0},
        )

        self.assertEqual(assignments, [])
        self.assertEqual(applied, set())


class OutlookEmailFilingTests(unittest.TestCase):
    def setUp(self):
        self.app = PacketSorterApp.__new__(PacketSorterApp)
        self.app.settings = {
            "outlook_approved_senders": "clearance@example.com",
            "outlook_required_keywords": "clearance, background check",
            "outlook_employee_folder_root": "",
            "outlook_needs_review_folder": "",
        }
        self.app.write_email_filing_audit = lambda *args, **kwargs: None

    def test_employee_folder_match_uses_current_folder_names(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            employee = root / "Ketia Otshudi"
            employee.mkdir()

            match = self.app.match_employee_folder(
                "The background check clearance for Ketia Otshudi is attached.",
                root,
            )

            self.assertEqual(match["status"], "matched")
            self.assertEqual(match["folder"], employee)

    def test_employee_folder_match_updates_when_folder_is_added(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            body = "Clearance received for Paula Lemieux."

            first_match = self.app.match_employee_folder(body, root)
            (root / "Paula Lemieux").mkdir()
            second_match = self.app.match_employee_folder(body, root)

            self.assertEqual(first_match["status"], "not_found")
            self.assertEqual(second_match["status"], "matched")

    def test_employee_folder_match_supports_last_comma_first(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            employee = root / "Otshudi, Ketia - PCA"
            employee.mkdir()

            match = self.app.match_employee_folder(
                "Clearance received for Ketia Otshudi.",
                root,
            )

            self.assertEqual(match["status"], "matched")
            self.assertEqual(match["folder"], employee)

    def test_employee_folder_match_does_not_scan_employee_subfolders(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            employee = root / "Ketia Otshudi"
            employee.mkdir()
            (employee / "Paula Lemieux").mkdir()

            match = self.app.match_employee_folder(
                "Clearance received for Paula Lemieux.",
                root,
            )

            self.assertEqual(match["status"], "not_found")

    def test_ambiguous_employee_folder_match_goes_to_review(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            (root / "Ketia Otshudi").mkdir()
            (root / "2026 - Ketia Otshudi").mkdir()

            match = self.app.match_employee_folder(
                "Clearance received for Ketia Otshudi.",
                root,
            )

            self.assertEqual(match["status"], "ambiguous")

    def test_email_filters_require_sender_and_keyword(self):
        self.assertTrue(
            self.app.email_matches_filing_filters(
                "clearance@example.com",
                "Background check complete",
                "Ketia Otshudi",
            )
        )
        self.assertFalse(
            self.app.email_matches_filing_filters(
                "unknown@example.com",
                "Background check complete",
                "Ketia Otshudi",
            )
        )
        self.assertFalse(
            self.app.email_matches_filing_filters(
                "clearance@example.com",
                "Hello",
                "Ketia Otshudi",
            )
        )

    def test_pdf_attachment_is_saved_to_matching_employee_folder(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            employee = root / "Ketia Otshudi"
            employee.mkdir()
            attachment = root / "clearance.pdf"
            attachment.write_bytes(b"%PDF-1.4 test")

            result = self.app.file_outlook_pdf_attachments(
                "clearance@example.com",
                "Background check clearance",
                "Ketia Otshudi",
                [attachment],
                root,
            )

            self.assertEqual(result["status"], "filed")
            self.assertEqual(result["folder"], employee)
            self.assertTrue((employee / "Ketia Otshudi - Clearance.pdf").exists())

    def test_unmatched_pdf_attachment_is_copied_to_needs_review(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            attachment = root / "clearance.pdf"
            attachment.write_bytes(b"%PDF-1.4 test")

            result = self.app.file_outlook_pdf_attachments(
                "clearance@example.com",
                "Background check clearance",
                "Unknown Person",
                [attachment],
                root,
            )

            self.assertEqual(result["status"], "needs_review")
            self.assertEqual(result["reason"], "No matching employee folder")
            self.assertTrue(
                (root / "Needs Review" / "Needs Review - Clearance.pdf").exists()
            )

    def test_pdf_attachment_name_uses_employee_folder_and_matched_keyword(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            employee = root / "Ketia Otshudi"
            employee.mkdir()
            attachment = root / "random-download-name.pdf"
            attachment.write_bytes(b"%PDF-1.4 test")

            result = self.app.file_outlook_pdf_attachments(
                "clearance@example.com",
                "Background check complete",
                "Results for Ketia Otshudi are ready.",
                [attachment],
                root,
            )

            self.assertEqual(result["status"], "filed")
            self.assertTrue(
                (employee / "Ketia Otshudi - Background Check.pdf").exists()
            )


class OutlookGraphIntakeTests(unittest.TestCase):
    def test_html_email_body_is_converted_to_searchable_text(self):
        text = html_to_text(
            "<html><body><p>Applicant:&nbsp;<b>Ketia Otshudi</b></p></body></html>"
        )

        self.assertEqual(text, "Applicant: Ketia Otshudi")

    def test_processed_message_store_prevents_duplicate_processing(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            state_path = Path(temp_dir) / "email_intake_state.json"
            store = ProcessedMessageStore(state_path)
            store.add("message-1")
            reloaded = ProcessedMessageStore(state_path)

            self.assertTrue(reloaded.contains("message-1"))
            self.assertFalse(reloaded.contains("message-2"))

    def test_email_body_renders_to_pdf(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            destination = Path(temp_dir) / "clearance.pdf"

            render_email_body_pdf(
                destination,
                "clearance@example.com",
                "Background Check Clearance",
                "2026-06-08T14:30:00Z",
                "Applicant: Ketia Otshudi\n\nStatus: Cleared",
            )

            self.assertTrue(destination.exists())
            self.assertTrue(destination.read_bytes().startswith(b"%PDF"))

    def test_email_body_pdf_filename_uses_date_and_subject(self):
        filename = email_body_pdf_name(
            "Background Check: Ketia Otshudi",
            "2026-06-08T14:30:00Z",
        )

        self.assertEqual(
            filename,
            "2026-06-08 - Background Check_ Ketia Otshudi.pdf",
        )

    def test_graph_intake_skips_processed_message_ids_but_allows_read_messages(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            state = ProcessedMessageStore(Path(temp_dir) / "state.json")
            state.add("already-done")
            intake = GraphOutlookIntake.__new__(GraphOutlookIntake)
            intake.state = state
            intake.messages = lambda limit=25: [
                {
                    "id": "already-done",
                    "isRead": False,
                    "subject": "Background check clearance",
                    "from": {"emailAddress": {"address": "clearance@example.com"}},
                    "body": {"content": "Ketia Otshudi"},
                    "hasAttachments": True,
                },
                {
                    "id": "read-message",
                    "isRead": True,
                    "subject": "Background check clearance",
                    "from": {"emailAddress": {"address": "clearance@example.com"}},
                    "body": {"content": "Ketia Otshudi"},
                    "hasAttachments": True,
                },
            ]
            intake.attachment_files = lambda message_id, temp_dir: []
            intake.mark_processed = lambda message_id: None

            summary = intake.process_now(lambda *_args: {"status": "filed"})

            self.assertEqual(summary.scanned, 2)
            self.assertEqual(summary.skipped, 1)
            self.assertEqual(summary.filed, 1)

    def test_graph_intake_marks_filed_message_processed(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            state = ProcessedMessageStore(Path(temp_dir) / "state.json")
            intake = GraphOutlookIntake.__new__(GraphOutlookIntake)
            intake.state = state
            intake.messages = lambda limit=25: [
                {
                    "id": "message-1",
                    "isRead": False,
                    "subject": "Background check clearance",
                    "from": {"emailAddress": {"address": "clearance@example.com"}},
                    "body": {"content": "<p>Ketia Otshudi</p>"},
                    "hasAttachments": False,
                }
            ]
            marked: list[str] = []
            intake.mark_processed = lambda message_id: marked.append(message_id)
            received_attachments: list[Path] = []

            def filer(_sender, _subject, _body, attachments):
                received_attachments.extend(attachments)
                self.assertEqual(len(attachments), 1)
                self.assertEqual(attachments[0].suffix.lower(), ".pdf")
                self.assertTrue(attachments[0].exists())
                return {"status": "filed"}

            summary = intake.process_now(filer)

            self.assertEqual(summary.filed, 1)
            self.assertEqual(marked, ["message-1"])
            self.assertEqual(len(received_attachments), 1)

    def test_existing_pdf_attachment_prevents_extra_body_pdf(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            state = ProcessedMessageStore(Path(temp_dir) / "state.json")
            existing_pdf = Path(temp_dir) / "attached-clearance.pdf"
            existing_pdf.write_bytes(b"%PDF-1.4 attachment")
            intake = GraphOutlookIntake.__new__(GraphOutlookIntake)
            intake.state = state
            intake.messages = lambda limit=25: [
                {
                    "id": "message-2",
                    "isRead": False,
                    "subject": "Background check clearance",
                    "receivedDateTime": "2026-06-08T14:30:00Z",
                    "from": {"emailAddress": {"address": "clearance@example.com"}},
                    "body": {"content": "<p>Ketia Otshudi is cleared.</p>"},
                    "hasAttachments": True,
                }
            ]
            intake.attachment_files = (
                lambda message_id, output_dir: [existing_pdf]
            )
            intake.mark_processed = lambda message_id: None

            def filer(_sender, _subject, _body, attachments):
                self.assertEqual(attachments, [existing_pdf])
                return {"status": "filed"}

            summary = intake.process_now(filer)

            self.assertEqual(summary.filed, 1)

    def test_approved_sender_matches_by_domain_not_just_full_address(self):
        """A domain entry like 'example.com' should match any @example.com sender."""
        app = PacketSorterApp.__new__(PacketSorterApp)
        app.settings = {
            "outlook_approved_senders": "example.com",
            "outlook_required_keywords": "clearance",
        }
        self.assertTrue(
            app.email_matches_filing_filters(
                "hr-automation@example.com",
                "Clearance received",
                "body text",
            )
        )
        self.assertFalse(
            app.email_matches_filing_filters(
                "hr-automation@other.com",
                "Clearance received",
                "body text",
            )
        )
        self.assertFalse(
            app.email_matches_filing_filters(
                "hr-automation@fakeexample.com",
                "Clearance received",
                "body text",
            )
        )

    def test_approved_sender_exact_address_does_not_match_substrings(self):
        app = PacketSorterApp.__new__(PacketSorterApp)
        app.settings = {
            "outlook_approved_senders": "clearance@example.com",
            "outlook_required_keywords": "clearance",
        }

        self.assertTrue(
            app.email_matches_filing_filters(
                "clearance@example.com",
                "Clearance received",
                "body text",
            )
        )
        self.assertFalse(
            app.email_matches_filing_filters(
                "not-clearance@example.com",
                "Clearance received",
                "body text",
            )
        )

    def test_email_keyword_label_capitalises_acronyms(self):
        """email_keyword_filename_label should capitalise known acronyms."""
        app = PacketSorterApp.__new__(PacketSorterApp)
        app.settings = {}
        self.assertEqual(
            app.email_keyword_filename_label("mbc clearance"),
            "MBC Clearance",
        )
        self.assertEqual(
            app.email_keyword_filename_label("background check"),
            "Background Check",
        )
        self.assertEqual(
            app.email_keyword_filename_label("i-9 verification"),
            "I-9 Verification",
        )

    def test_email_filing_pdf_name_uses_employee_and_keyword(self):
        """email_filing_pdf_name should combine folder name with matched keyword label."""
        app = PacketSorterApp.__new__(PacketSorterApp)
        app.settings = {
            "outlook_required_keywords": "mbc clearance, background check",
        }
        name = app.email_filing_pdf_name(
            "Ketia Otshudi",
            "MBC Clearance Ready",
            "The MBC Clearance for Ketia is attached.",
        )
        self.assertEqual(name, "Ketia Otshudi - MBC Clearance.pdf")

    def test_processed_message_store_trims_oldest_not_alphabetically_last(self):
        """ProcessedMessageStore must drop the oldest IDs, not a random alphabetical slice."""
        with tempfile.TemporaryDirectory() as temp_dir:
            store = ProcessedMessageStore(Path(temp_dir) / "state.json")
            # Add IDs whose alphabetical last-N slice would keep different ones
            # than insertion-order last-N.  Use prefixes that sort differently
            # from insertion order.
            ids_in_order = [f"z-message-{i:04d}" for i in range(10)] + \
                           [f"a-message-{i:04d}" for i in range(10)]
            for mid in ids_in_order:
                store._ids[mid] = None  # bypass save for speed

            # Manually cap to 15 entries (last 15 by insertion)
            store.MAX_IDS = 15
            store.save()

            reloaded = ProcessedMessageStore(Path(temp_dir) / "state.json")
            saved_ids = list(reloaded._ids.keys())

            # The 5 oldest (first inserted) should be gone
            for dropped in ids_in_order[:5]:
                self.assertNotIn(dropped, saved_ids, msg=f"{dropped} should have been trimmed")
            # The 15 most-recently-added should be present
            for kept in ids_in_order[5:]:
                self.assertIn(kept, saved_ids, msg=f"{kept} should have been kept")


class LocalOutlookIntakeTests(unittest.TestCase):
    def test_local_intake_initializes_without_entra_credentials(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            intake = LocalOutlookIntake(
                {
                    "outlook_connection_method": "local",
                    "outlook_mail_folder": "Inbox",
                    "outlook_processed_folder": "PacketFlow Processed",
                },
                Path(temp_dir),
            )

            self.assertEqual(intake.mail_folder, "Inbox")
            self.assertEqual(intake.profile_name, "")

    def test_local_intake_uses_optional_profile_name(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            intake = LocalOutlookIntake(
                {"outlook_local_profile_name": "Office Profile"},
                Path(temp_dir),
            )

            self.assertEqual(intake.profile_name, "Office Profile")

    def test_local_intake_processes_unread_message_body_pdf(self):
        class FakeAttachmentCollection:
            Count = 0

        class FakeMessage:
            Subject = "Background check clearance"
            Body = "Ketia Otshudi is cleared."
            HTMLBody = ""
            SenderEmailAddress = "clearance@example.com"
            Sender = None
            Attachments = FakeAttachmentCollection()
            EntryID = "local-message-1"
            UnRead = True
            MessageClass = "IPM.Note"
            ReceivedTime = "2026-06-08 14:30"

            def Save(self):
                pass

            def Move(self, _folder):
                self.moved = True

        class FakeItems:
            def __init__(self, messages):
                self.messages = messages
                self.Count = len(messages)

            def Sort(self, *_args):
                pass

            def Item(self, index):
                return self.messages[index - 1]

        class FakeFolder:
            def __init__(self, messages):
                self.Items = FakeItems(messages)

        with tempfile.TemporaryDirectory() as temp_dir:
            intake = LocalOutlookIntake(
                {
                    "outlook_mail_folder": "Inbox",
                    "outlook_processed_folder": "",
                },
                Path(temp_dir),
            )
            message = FakeMessage()
            intake.namespace = lambda: object()
            intake.source_folder = lambda _namespace: FakeFolder([message])
            intake.processed_outlook_folder = lambda _namespace: None
            received_attachments: list[Path] = []

            def filer(_sender, _subject, _body, attachments):
                received_attachments.extend(attachments)
                return {"status": "filed"}

            summary = intake.process_now(filer)

            self.assertEqual(summary.filed, 1)
            self.assertFalse(message.UnRead)
            self.assertEqual(len(received_attachments), 1)
            self.assertEqual(received_attachments[0].suffix.lower(), ".pdf")

    def test_local_intake_processes_read_message_if_not_already_recorded(self):
        class FakeAttachmentCollection:
            Count = 0

        class FakeMessage:
            Subject = "Background check clearance"
            Body = "Ketia Otshudi is cleared."
            HTMLBody = ""
            SenderEmailAddress = "clearance@example.com"
            Sender = None
            Attachments = FakeAttachmentCollection()
            EntryID = "local-message-read"
            UnRead = False
            MessageClass = "IPM.Note"
            ReceivedTime = "2026-06-08 14:30"

            def Save(self):
                pass

            def Move(self, _folder):
                pass

        class FakeItems:
            Count = 1

            def Sort(self, *_args):
                pass

            def Item(self, _index):
                return FakeMessage()

        class FakeFolder:
            Items = FakeItems()

        with tempfile.TemporaryDirectory() as temp_dir:
            intake = LocalOutlookIntake(
                {
                    "outlook_mail_folder": "Inbox",
                    "outlook_processed_folder": "",
                },
                Path(temp_dir),
            )
            intake.namespace = lambda: object()
            intake.source_folder = lambda _namespace: FakeFolder()
            intake.processed_outlook_folder = lambda _namespace: None

            summary = intake.process_now(lambda *_args: {"status": "filed"})

            self.assertEqual(summary.filed, 1)


class DirectoryAuditTests(unittest.TestCase):
    document_types = [
        "Orientation Agenda.pdf",
        "Form I-9 Employment Eligibility Verification.pdf",
        "Viventium Direct Deposit.pdf",
        "Job Application.pdf",
    ]

    @staticmethod
    def make_pdf(path: Path, pages: int = 1):
        writer = PdfWriter()
        for _index in range(pages):
            writer.add_blank_page(width=612, height=792)
        with path.open("wb") as handle:
            writer.write(handle)

    def test_exported_filename_is_mapped_to_document_type(self):
        document, prefix = document_for_filename(
            "Ketia Otshudi - Orientation Agenda.pdf",
            self.document_types,
        )

        self.assertEqual(document, "Orientation Agenda.pdf")
        self.assertEqual(prefix, "Ketia Otshudi")

    def test_clean_packet_folder_has_no_findings(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            packet = root / "Ketia Otshudi"
            packet.mkdir()
            self.make_pdf(
                packet / "Ketia Otshudi - Orientation Agenda.pdf",
                1,
            )
            self.make_pdf(
                packet
                / "Ketia Otshudi - Form I-9 Employment Eligibility Verification.pdf",
                3,
            )
            self.make_pdf(
                packet / "Ketia Otshudi - Viventium Direct Deposit.pdf",
                2,
            )

            result = audit_directory(
                root,
                self.document_types,
                [
                    "Orientation Agenda.pdf",
                    "Form I-9 Employment Eligibility Verification.pdf",
                    "Viventium Direct Deposit.pdf",
                ],
            )

            self.assertEqual(result.errors, [])
            self.assertEqual(result.warnings, [])

    def test_missing_output_and_incomplete_i9_are_errors(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            packet = root / "Ketia Otshudi"
            packet.mkdir()
            (packet / "Export Audit Log.txt").write_text(
                "PacketFlow",
                encoding="utf-8",
            )
            self.make_pdf(
                packet
                / "Ketia Otshudi - Form I-9 Employment Eligibility Verification.pdf",
                1,
            )

            result = audit_directory(
                root,
                self.document_types,
                [
                    "Orientation Agenda.pdf",
                    "Form I-9 Employment Eligibility Verification.pdf",
                ],
            )
            messages = [finding.message for finding in result.errors]

            self.assertIn(
                "Missing expected output: Orientation Agenda.pdf",
                messages,
            )
            self.assertIn(
                "I-9 output must contain the form plus two identification pages",
                messages,
            )

    def test_corrupt_pdf_and_duplicate_output_type_are_errors(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            packet = root / "Ketia Otshudi"
            packet.mkdir()
            (packet / "Export Audit Log.txt").write_text(
                "PacketFlow",
                encoding="utf-8",
            )
            corrupt = packet / "Ketia Otshudi - Orientation Agenda.pdf"
            corrupt.write_bytes(b"not a pdf")
            self.make_pdf(packet / "Copy - Orientation Agenda.pdf", 1)

            result = audit_directory(
                root,
                self.document_types,
                ["Orientation Agenda.pdf"],
            )
            messages = [finding.message for finding in result.errors]

            self.assertTrue(
                any(message.startswith("PDF cannot be opened") for message in messages)
            )
            self.assertTrue(
                any(message.startswith("Duplicate output type") for message in messages)
            )

    def test_identical_pdf_content_is_a_warning(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            first = root / "First"
            second = root / "Second"
            first.mkdir()
            second.mkdir()
            source = first / "one.pdf"
            duplicate = second / "two.pdf"
            self.make_pdf(source, 1)
            duplicate.write_bytes(source.read_bytes())

            result = audit_directory(root, self.document_types, [])

            self.assertTrue(
                any(
                    finding.message.startswith(
                        "Identical PDF content appears more than once"
                    )
                    for finding in result.warnings
                )
            )

    def test_empty_directory_reports_warning(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            result = audit_directory(
                Path(temp_dir),
                self.document_types,
                [],
            )
            report = format_audit_report(result)

            self.assertIn("No PDF files were found", report)

    def test_folder_with_mixed_prefixes_is_not_treated_as_packet(self):
        """A folder whose PDFs have different employee prefixes should not trigger
        missing-document errors — it is a shared folder, not a single packet."""
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            shared = root / "HR Shared"
            shared.mkdir()
            # Two PDFs from different packets — different name prefixes
            self.make_pdf(shared / "Alice Smith - Orientation Agenda.pdf", 1)
            self.make_pdf(shared / "Bob Jones - Orientation Agenda.pdf", 1)

            result = audit_directory(
                root,
                self.document_types,
                ["Orientation Agenda.pdf", "Form I-9 Employment Eligibility Verification.pdf"],
            )

            # Mixed prefixes → not a packet folder → no "Missing expected output" errors
            missing_errors = [
                f for f in result.errors
                if "Missing expected output" in f.message
            ]
            self.assertEqual(
                missing_errors,
                [],
                "Shared folder with mixed name prefixes should not generate missing-document errors",
            )

    def test_folder_with_export_audit_log_is_always_treated_as_packet(self):
        """Export Audit Log.txt is the definitive PacketFlow marker regardless of prefix."""
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            packet = root / "Ketia Otshudi"
            packet.mkdir()
            (packet / "Export Audit Log.txt").write_text("PacketFlow", encoding="utf-8")
            # Only one PDF — still treated as a packet because of the log
            self.make_pdf(packet / "Ketia Otshudi - Orientation Agenda.pdf", 1)

            result = audit_directory(
                root,
                self.document_types,
                ["Orientation Agenda.pdf", "Form I-9 Employment Eligibility Verification.pdf"],
            )

            missing_errors = [
                f for f in result.errors
                if "Missing expected output" in f.message
            ]
            self.assertTrue(
                any("Form I-9" in e.message for e in missing_errors),
                "Folder with Export Audit Log should still report missing required documents",
            )


if __name__ == "__main__":
    unittest.main()
