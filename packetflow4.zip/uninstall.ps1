$ErrorActionPreference = "Stop"

Add-Type -AssemblyName PresentationFramework

function Show-Info([string]$Message, [string]$Title = "PacketFlow") {
    [System.Windows.MessageBox]::Show(
        $Message, $Title,
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Information
    ) | Out-Null
}
function Show-ErrorMessage([string]$Message) {
    [System.Windows.MessageBox]::Show(
        $Message, "PacketFlow Uninstaller",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Error
    ) | Out-Null
}
function Ask-YesNo([string]$Message, [string]$Title = "PacketFlow Uninstaller") {
    $answer = [System.Windows.MessageBox]::Show(
        $Message, $Title,
        [System.Windows.MessageBoxButton]::YesNo,
        [System.Windows.MessageBoxImage]::Warning
    )
    return $answer -eq [System.Windows.MessageBoxResult]::Yes
}

$InstallDirectory  = Join-Path $env:LOCALAPPDATA "Programs\PacketFlow"
$AppDataDirectory  = Join-Path $env:APPDATA "PacketFlow"
$Desktop           = [Environment]::GetFolderPath("Desktop")
$ShortcutPath      = Join-Path $Desktop "PacketFlow.lnk"
$StartupKey        = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$StartupValueName  = "PacketFlow"

# ── Confirm ────────────────────────────────────────────────────────────────
if (-not (Test-Path -LiteralPath $InstallDirectory)) {
    Show-Info "PacketFlow does not appear to be installed at:`n`n$InstallDirectory`n`nNothing was removed."
    exit 0
}

$keepData = Ask-YesNo (
    "This will remove PacketFlow from:`n`n$InstallDirectory`n`n" +
    "Do you want to keep your personal data (rules, correction memory, settings)?`n`n" +
    "Click Yes to keep your data, No to delete everything."
)

$confirmed = Ask-YesNo (
    "Are you sure you want to uninstall PacketFlow?" +
    $(if ($keepData) { "`n`nYour rules and settings will be kept." } else { "`n`nAll data will be permanently deleted." })
)
if (-not $confirmed) {
    Show-Info "Uninstall cancelled."
    exit 0
}

# ── Remove startup registration ────────────────────────────────────────────
try {
    if (Get-ItemProperty -Path $StartupKey -Name $StartupValueName -ErrorAction SilentlyContinue) {
        Remove-ItemProperty -Path $StartupKey -Name $StartupValueName -Force
    }
} catch {
    # Non-fatal — continue
}

# ── Remove desktop shortcut ────────────────────────────────────────────────
if (Test-Path -LiteralPath $ShortcutPath) {
    try { Remove-Item -LiteralPath $ShortcutPath -Force } catch {}
}

# ── Remove install directory ───────────────────────────────────────────────
try {
    Remove-Item -LiteralPath $InstallDirectory -Recurse -Force
} catch {
    Show-ErrorMessage "Could not fully remove the install folder:`n`n$($_.Exception.Message)`n`nYou may need to delete it manually:`n$InstallDirectory"
    exit 1
}

# ── Optionally remove app data ─────────────────────────────────────────────
if (-not $keepData) {
    if (Test-Path -LiteralPath $AppDataDirectory) {
        try {
            Remove-Item -LiteralPath $AppDataDirectory -Recurse -Force
        } catch {
            # Non-fatal — data folder removal failure shouldn't block completion
        }
    }
}

# ── Done ───────────────────────────────────────────────────────────────────
$dataNote = if ($keepData) {
    "`n`nYour rules and settings were kept at:`n$AppDataDirectory"
} else {
    ""
}
Show-Info "PacketFlow has been uninstalled successfully.$dataNote"
