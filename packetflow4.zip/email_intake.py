from __future__ import annotations

import base64
import html
import json
import re
import tempfile
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable


GRAPH_BASE = "https://graph.microsoft.com/v1.0"
SCOPES = ["User.Read", "Mail.ReadWrite"]


class EmailIntakeError(RuntimeError):
    pass


class EmailIntakeConfigurationError(EmailIntakeError):
    pass


class EmailIntakeDependencyError(EmailIntakeError):
    pass


@dataclass
class IntakeSummary:
    scanned: int = 0
    filed: int = 0
    needs_review: int = 0
    ignored: int = 0
    skipped: int = 0
    errors: list[str] = field(default_factory=list)


def html_to_text(value: str) -> str:
    text = html.unescape(value or "")
    text = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", text)
    text = re.sub(r"(?i)<br\s*/?>", "\n", text)
    text = re.sub(r"(?i)</p\s*>", "\n", text)
    text = re.sub(r"<[^>]+>", " ", text)
    text = text.replace("\xa0", " ")
    return re.sub(r"\s+", " ", text).strip()


def extract_html_links(value: str) -> list[str]:
    """Return href URLs from an HTML email body.

    Outlook Body text loses the target behind links like "here". PacketFlow
    appends the raw href values to the searchable body so downstream rules can
    download linked PDFs when the visible text is only "here".
    """
    links: list[str] = []
    patterns = (
        r'(?is)<a\b[^>]*?href="([^"]+)"',
        r"(?is)<a\b[^>]*?href='([^']+)'",
    )
    for pattern in patterns:
        for match in re.finditer(pattern, value or ""):
            url = html.unescape(match.group(1)).strip()
            if url and url not in links:
                links.append(url)
    return links


def linked_pdf_name_from_url(url: str, fallback_index: int) -> str:
    parsed = urllib.parse.urlparse(url)
    raw_name = Path(urllib.parse.unquote(parsed.path)).name
    if not raw_name or "." not in raw_name:
        raw_name = f"Linked Report {fallback_index}.pdf"
    if Path(raw_name).suffix.lower() != ".pdf":
        raw_name = f"{Path(raw_name).stem or 'Linked Report'} {fallback_index}.pdf"
    return safe_attachment_name(raw_name)


def download_linked_pdfs(body: str, temp_dir: Path) -> list[Path]:
    """Download PDF reports linked inside an email body.

    Maine CPS/CARB emails often include a "download here" hyperlink instead of
    a PDF attachment. Outlook gives PacketFlow the URL, so we fetch it and treat
    the downloaded report exactly like an attachment.
    """
    urls: list[str] = []
    for match in re.finditer(r"https?://[^\s<>\"']+", body or "", flags=re.IGNORECASE):
        url = html.unescape(match.group(0)).strip().rstrip(".)]")
        if url and url not in urls:
            urls.append(url)

    downloaded: list[Path] = []
    for index, url in enumerate(urls, start=1):
        parsed = urllib.parse.urlparse(url)
        if parsed.scheme.lower() not in {"http", "https"}:
            continue
        request = urllib.request.Request(
            url,
            headers={
                "User-Agent": "PacketFlow/1.0",
                "Accept": "application/pdf,text/html,*/*",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                content = response.read()
                content_type = str(response.headers.get("Content-Type", "")).lower()
                disposition = str(response.headers.get("Content-Disposition", ""))
        except (OSError, urllib.error.URLError, urllib.error.HTTPError):
            continue

        looks_pdf = content.startswith(b"%PDF") or "application/pdf" in content_type
        if not looks_pdf:
            continue

        name_match = re.search(r'filename\*?=(?:UTF-8\'\')?["\']?([^"\';]+)', disposition, flags=re.I)
        filename = urllib.parse.unquote(name_match.group(1)) if name_match else linked_pdf_name_from_url(url, index)
        destination = temp_dir / safe_attachment_name(filename)
        if destination.exists():
            destination = temp_dir / f"{destination.stem} ({index}){destination.suffix}"
        destination.write_bytes(content)
        downloaded.append(destination)
    return downloaded

def safe_attachment_name(value: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "_", Path(value or "").name).strip()
    return name or "Outlook Attachment.pdf"


def email_body_pdf_name(subject: str, received_date: str = "") -> str:
    date_part = str(received_date)[:10]
    subject_part = re.sub(r'[<>:"/\\|?*]', "_", subject or "Email").strip()
    subject_part = re.sub(r"\s+", " ", subject_part)[:90] or "Email"
    prefix = f"{date_part} - " if date_part else ""
    return f"{prefix}{subject_part}.pdf"


def render_email_body_pdf(
    destination: Path,
    sender: str,
    subject: str,
    received_date: str,
    body: str,
):
    """Render an email body to a readable letter-sized PDF without printing."""
    from PIL import Image, ImageDraw, ImageFont

    width, height = 1700, 2200
    margin = 130
    line_spacing = 14
    try:
        regular = ImageFont.truetype("arial.ttf", 34)
        bold = ImageFont.truetype("arialbd.ttf", 36)
        title_font = ImageFont.truetype("arialbd.ttf", 45)
    except OSError:
        regular = ImageFont.load_default()
        bold = regular
        title_font = regular

    def wrap_text(value: str, font, max_width: int) -> list[str]:
        lines: list[str] = []
        paragraphs = re.split(r"\n\s*\n|\r\n\s*\r\n", value.strip())
        for paragraph in paragraphs:
            words = re.sub(r"\s+", " ", paragraph).strip().split()
            if not words:
                lines.append("")
                continue
            current = words[0]
            for word in words[1:]:
                candidate = f"{current} {word}"
                # getlength() was removed in Pillow 10.0; use the ImageDraw
                # textlength() method which works on Pillow 9.2+.
                try:
                    measured = ImageDraw.Draw(Image.new("RGB", (1, 1))).textlength(
                        candidate, font=font
                    )
                except AttributeError:
                    # Pillow < 9.2 fallback — should not occur on supported installs
                    measured = font.getlength(candidate)  # type: ignore[attr-defined]
                if measured <= max_width:
                    current = candidate
                else:
                    lines.append(current)
                    current = word
            lines.append(current)
            lines.append("")
        return lines or [""]

    header_rows = [
        ("From", sender or "Unknown sender"),
        ("Subject", subject or "(No subject)"),
        ("Received", received_date or "Unknown"),
    ]
    body_lines = wrap_text(body or "(Email body was empty.)", regular, width - 2 * margin)
    pages: list[Image.Image] = []

    def new_page() -> tuple[Image.Image, ImageDraw.ImageDraw, int]:
        page = Image.new("RGB", (width, height), "white")
        draw = ImageDraw.Draw(page)
        draw.text((margin, margin), "Outlook Email", fill="#0F172A", font=title_font)
        draw.line(
            (margin, margin + 72, width - margin, margin + 72),
            fill="#CBD5E1",
            width=3,
        )
        return page, draw, margin + 110

    page, draw, y = new_page()
    for label, value in header_rows:
        draw.text((margin, y), f"{label}:", fill="#0F172A", font=bold)
        try:
            label_width = draw.textlength(f"{label}: ", font=bold)
        except AttributeError:
            label_width = bold.getlength(f"{label}: ")  # type: ignore[attr-defined]
        wrapped = wrap_text(value, regular, width - 2 * margin - int(label_width))
        for line_index, line in enumerate(wrapped):
            x = margin + int(label_width) if line_index == 0 else margin + 165
            draw.text((x, y), line, fill="#0F172A", font=regular)
            y += 52
        y += 8

    y += 24
    draw.line((margin, y, width - margin, y), fill="#CBD5E1", width=2)
    y += 35

    for line in body_lines:
        line_height = 50 if line else 28
        if y + line_height > height - margin:
            pages.append(page)
            page, draw, y = new_page()
        if line:
            draw.text((margin, y), line, fill="#111827", font=regular)
        y += line_height + line_spacing
    pages.append(page)

    destination.parent.mkdir(parents=True, exist_ok=True)
    pages[0].save(
        destination,
        "PDF",
        resolution=150.0,
        save_all=True,
        append_images=pages[1:],
    )


class ProcessedMessageStore:
    """Tracks message IDs that have already been filed so they are never processed twice.

    IDs are stored in insertion order.  When the store grows beyond MAX_IDS
    the oldest entries (the ones filed earliest) are dropped — not a random
    alphabetical slice, which is what sorted(set)[-N:] would do with GUIDs.
    """

    MAX_IDS = 5000

    def __init__(self, path: Path):
        self.path = path
        # Use a dict as an ordered set: keys are IDs, values are None.
        # dict preserves insertion order in Python 3.7+ and gives O(1) lookup.
        self._ids: dict[str, None] = {}
        self.load()

    def load(self):
        if not self.path.exists():
            return
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            for item in data.get("processed_message_ids", []):
                raw = str(item).strip()
                if raw:
                    self._ids[raw] = None
        except Exception:
            self._ids = {}

    def save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        # Keep the most-recently-added IDs when the list exceeds MAX_IDS.
        ids_to_save = list(self._ids)[-self.MAX_IDS:]
        self.path.write_text(
            json.dumps({"processed_message_ids": ids_to_save}, indent=2),
            encoding="utf-8",
        )

    def contains(self, message_id: str) -> bool:
        return message_id in self._ids

    def add(self, message_id: str):
        if message_id:
            # Move to end if already present (refreshes recency), else insert.
            self._ids.pop(message_id, None)
            self._ids[message_id] = None
            self.save()


class GraphOutlookIntake:
    def __init__(
        self,
        settings: dict,
        app_data_dir: Path,
        auth_prompt: Callable[[dict], None] | None = None,
        allow_interactive_auth: bool = True,
    ):
        self.settings = settings
        self.app_data_dir = app_data_dir
        self.auth_prompt = auth_prompt
        self.allow_interactive_auth = allow_interactive_auth
        self.client_id = str(settings.get("outlook_graph_client_id", "")).strip()
        if not self.client_id:
            raise EmailIntakeConfigurationError(
                "Microsoft application ID is required before Outlook can connect."
            )
        self.tenant_id = str(
            settings.get("outlook_tenant_id", "organizations")
        ).strip() or "organizations"
        self.mail_folder = str(settings.get("outlook_mail_folder", "Inbox")).strip() or "Inbox"
        self.processed_folder = str(
            settings.get("outlook_processed_folder", "PacketFlow Processed")
        ).strip()
        self.state = ProcessedMessageStore(
            self.app_data_dir / "email_intake_state.json"
        )
        self.cache_path = self.app_data_dir / "email_intake_token_cache.json"
        # SECURITY NOTE: this file contains MSAL OAuth refresh tokens in plain
        # JSON (the default MSAL Python serialisation format).  It should not
        # be shared, copied to a network drive, or included in backups that
        # leave the machine.  For stronger at-rest protection, the optional
        # msal-extensions package provides OS keychain/Credential-Manager
        # encryption; add it to requirements.txt and swap in
        # PersistedTokenCache if your deployment requires it.
        self._session = None
        self._processed_folder_id: str | None = None

    def import_graph_dependencies(self):
        try:
            import msal
            import requests
        except ImportError as exc:
            raise EmailIntakeDependencyError(
                "The Microsoft Outlook email libraries are missing. "
                "Run Start PacketFlow.cmd so it can install msal and requests."
            ) from exc
        return msal, requests

    def access_token(self) -> str:
        msal, _requests = self.import_graph_dependencies()
        cache = msal.SerializableTokenCache()
        if self.cache_path.exists():
            cache.deserialize(self.cache_path.read_text(encoding="utf-8"))
        app = msal.PublicClientApplication(
            self.client_id,
            authority=f"https://login.microsoftonline.com/{self.tenant_id}",
            token_cache=cache,
        )
        accounts = app.get_accounts()
        result = None
        if accounts:
            result = app.acquire_token_silent(SCOPES, account=accounts[0])
        if not result:
            if not self.allow_interactive_auth:
                raise EmailIntakeConfigurationError(
                    "Microsoft Outlook needs an initial manual sign-in. "
                    "Click Check Outlook Now once to connect it."
                )
            flow = app.initiate_device_flow(scopes=SCOPES)
            if "user_code" not in flow:
                raise EmailIntakeError("Microsoft sign-in could not be started.")
            if self.auth_prompt:
                self.auth_prompt(flow)
            else:
                webbrowser.open(flow.get("verification_uri", "https://microsoft.com/devicelogin"))
            result = app.acquire_token_by_device_flow(flow)
        if cache.has_state_changed:
            self.cache_path.write_text(cache.serialize(), encoding="utf-8")
        if "access_token" not in result:
            raise EmailIntakeError(
                result.get("error_description")
                or "Microsoft sign-in did not return an access token."
            )
        return result["access_token"]

    def session(self):
        if self._session is None:
            _msal, requests = self.import_graph_dependencies()
            self._session = requests.Session()
            self._session.headers.update({
                "Authorization": f"Bearer {self.access_token()}",
                "Accept": "application/json",
            })
        return self._session

    def graph_get(self, url: str, **params) -> dict:
        response = self.session().get(url, params=params or None, timeout=30)
        if response.status_code >= 400:
            raise EmailIntakeError(f"Microsoft Graph error: {response.text}")
        return response.json()

    def graph_post(self, url: str, payload: dict | None = None) -> dict:
        response = self.session().post(url, json=payload or {}, timeout=30)
        if response.status_code >= 400:
            raise EmailIntakeError(f"Microsoft Graph error: {response.text}")
        return response.json() if response.text else {}

    def graph_patch(self, url: str, payload: dict):
        response = self.session().patch(url, json=payload, timeout=30)
        if response.status_code >= 400:
            raise EmailIntakeError(f"Microsoft Graph error: {response.text}")

    def mail_folder_endpoint(self) -> str:
        if self.mail_folder.lower() == "inbox":
            return f"{GRAPH_BASE}/me/mailFolders/inbox"
        escaped = self.mail_folder.replace("'", "''")
        data = self.graph_get(
            f"{GRAPH_BASE}/me/mailFolders",
            **{"$filter": f"displayName eq '{escaped}'", "$top": "1"},
        )
        values = data.get("value", [])
        if not values:
            raise EmailIntakeConfigurationError(
                f"Outlook folder was not found: {self.mail_folder}"
            )
        return f"{GRAPH_BASE}/me/mailFolders/{values[0]['id']}"

    def processed_folder_id(self) -> str | None:
        if not self.processed_folder:
            return None
        if self._processed_folder_id:
            return self._processed_folder_id
        escaped = self.processed_folder.replace("'", "''")
        data = self.graph_get(
            f"{GRAPH_BASE}/me/mailFolders",
            **{"$filter": f"displayName eq '{escaped}'", "$top": "1"},
        )
        values = data.get("value", [])
        if values:
            self._processed_folder_id = values[0]["id"]
            return self._processed_folder_id
        created = self.graph_post(
            f"{GRAPH_BASE}/me/mailFolders",
            {"displayName": self.processed_folder},
        )
        self._processed_folder_id = created.get("id")
        return self._processed_folder_id

    def messages(self, limit: int = 25) -> Iterable[dict]:
        endpoint = self.mail_folder_endpoint()
        data = self.graph_get(
            f"{endpoint}/messages",
            **{
                "$top": str(limit),
                "$orderby": "receivedDateTime desc",
                "$select": "id,subject,body,from,hasAttachments,isRead,receivedDateTime",
            },
        )
        return data.get("value", [])

    def attachment_files(self, message_id: str, temp_dir: Path) -> list[Path]:
        data = self.graph_get(f"{GRAPH_BASE}/me/messages/{message_id}/attachments")
        files: list[Path] = []
        for attachment in data.get("value", []):
            if attachment.get("@odata.type") != "#microsoft.graph.fileAttachment":
                continue
            name = safe_attachment_name(attachment.get("name", ""))
            if Path(name).suffix.lower() != ".pdf":
                continue
            content = attachment.get("contentBytes")
            if not content:
                continue
            destination = temp_dir / name
            destination.write_bytes(base64.b64decode(content))
            files.append(destination)
        return files

    def mark_processed(self, message_id: str):
        self.state.add(message_id)
        self.graph_patch(
            f"{GRAPH_BASE}/me/messages/{message_id}",
            {"isRead": True},
        )
        folder_id = self.processed_folder_id()
        if folder_id:
            self.graph_post(
                f"{GRAPH_BASE}/me/messages/{message_id}/move",
                {"destinationId": folder_id},
            )

    def process_now(
        self,
        filer: Callable[[str, str, str, list[Path]], dict],
        limit: int = 25,
    ) -> IntakeSummary:
        summary = IntakeSummary()
        with tempfile.TemporaryDirectory() as temp_name:
            temp_dir = Path(temp_name)
            for message in self.messages(limit=limit):
                summary.scanned += 1
                message_id = message.get("id", "")
                subject = message.get("subject") or ""
                try:
                    if self.state.contains(message_id):
                        summary.skipped += 1
                        continue
                    sender = (
                        message.get("from", {})
                        .get("emailAddress", {})
                        .get("address", "")
                    )
                    raw_body = message.get("body", {}).get("content", "") or ""
                    body = html_to_text(raw_body)
                    links = extract_html_links(raw_body)
                    if links:
                        body = (body + "\n\nLinked URLs:\n" + "\n".join(links)).strip()
                    if not message.get("hasAttachments"):
                        attachments = []
                    else:
                        attachments = self.attachment_files(message_id, temp_dir)
                    attachments.extend(download_linked_pdfs(body, temp_dir))
                    if not attachments and body:
                        body_pdf = temp_dir / email_body_pdf_name(
                            subject,
                            message.get("receivedDateTime", ""),
                        )
                        render_email_body_pdf(
                            body_pdf,
                            sender,
                            subject,
                            message.get("receivedDateTime", ""),
                            body,
                        )
                        attachments = [body_pdf]
                    result = filer(sender, subject, body, attachments)
                    status = result.get("status")
                    if status == "ignored":
                        summary.ignored += 1
                        continue
                    if status == "filed":
                        summary.filed += 1
                        try:
                            self.mark_processed(message_id)
                        except EmailIntakeError as exc:
                            summary.errors.append(
                                f"{subject or message_id}: saved, but Outlook "
                                f"could not mark it processed ({exc})"
                            )
                    elif status == "needs_review":
                        summary.needs_review += 1
                        try:
                            self.mark_processed(message_id)
                        except EmailIntakeError as exc:
                            summary.errors.append(
                                f"{subject or message_id}: sent to review, but "
                                f"Outlook could not mark it processed ({exc})"
                            )
                    else:
                        summary.errors.append(subject or message_id)
                except Exception as exc:
                    summary.errors.append(
                        f"{subject or message_id or 'Unknown email'}: {exc}"
                    )
        return summary


class LocalOutlookIntake:
    """Use the local Windows Outlook profile through Classic Outlook COM."""

    def __init__(
        self,
        settings: dict,
        app_data_dir: Path,
    ):
        self.settings = settings
        self.app_data_dir = app_data_dir
        self.mail_folder = str(settings.get("outlook_mail_folder", "Inbox")).strip() or "Inbox"
        self.processed_folder = str(
            settings.get("outlook_processed_folder", "PacketFlow Processed")
        ).strip()
        self.profile_name = str(
            settings.get("outlook_local_profile_name", "")
        ).strip()
        self.state = ProcessedMessageStore(
            self.app_data_dir / "email_intake_state.json"
        )

    def import_local_dependencies(self):
        try:
            import win32com.client
        except ImportError as exc:
            raise EmailIntakeDependencyError(
                "The local Outlook email library is missing. "
                "Run Start PacketFlow.cmd so it can install pywin32."
            ) from exc
        return win32com.client

    def namespace(self):
        # IMPORTANT: win32com requires the calling thread to be initialized as
        # a COM Single-Threaded Apartment (STA).  This method must always be
        # called from the main UI thread.  Moving it to a background thread
        # will silently corrupt COM state or raise cryptic errors.
        # If threading is ever added here, call pythoncom.CoInitialize() at
        # the top of the worker thread and CoUninitialize() when it exits.
        win32com_client = self.import_local_dependencies()
        try:
            try:
                outlook = win32com_client.GetActiveObject(
                    "Outlook.Application"
                )
            except Exception:
                outlook = win32com_client.Dispatch("Outlook.Application")
            namespace = outlook.GetNamespace("MAPI")
            namespace.Logon(self.profile_name, "", False, False)
            return namespace
        except Exception as exc:
            raise EmailIntakeError(
                "PacketFlow could not connect to the local Outlook profile.\n\n"
                "Open Classic Outlook and confirm it is connected to your "
                "mailbox, then try again. If this computer uses New Outlook, "
                "select Microsoft Entra / New Outlook in Preferences instead."
            ) from exc

    @staticmethod
    def folder_by_name(parent_folder, folder_name: str):
        for index in range(1, parent_folder.Folders.Count + 1):
            folder = parent_folder.Folders.Item(index)
            if str(folder.Name).lower() == folder_name.lower():
                return folder
        return None

    def source_folder(self, namespace):
        inbox = namespace.GetDefaultFolder(6)
        if self.mail_folder.lower() == "inbox":
            return inbox
        folder = self.folder_by_name(inbox.Parent, self.mail_folder)
        if folder is None:
            folder = self.folder_by_name(inbox, self.mail_folder)
        if folder is None:
            raise EmailIntakeConfigurationError(
                f"Local Outlook folder was not found: {self.mail_folder}"
            )
        return folder

    def processed_outlook_folder(self, namespace):
        if not self.processed_folder:
            return None
        inbox = namespace.GetDefaultFolder(6)
        folder = self.folder_by_name(inbox.Parent, self.processed_folder)
        if folder is not None:
            return folder
        return inbox.Parent.Folders.Add(self.processed_folder)

    @staticmethod
    def message_sender(message) -> str:
        try:
            sender = str(message.SenderEmailAddress or "")
            if sender.startswith("/O=") and message.Sender is not None:
                exchange_user = message.Sender.GetExchangeUser()
                if exchange_user is not None:
                    return str(exchange_user.PrimarySmtpAddress or sender)
            return sender
        except Exception:
            return ""

    @staticmethod
    def message_body(message) -> str:
        plain_body = ""
        html_body = ""
        try:
            plain_body = str(message.Body or "").strip()
        except Exception:
            plain_body = ""
        try:
            html_body = str(message.HTMLBody or "")
        except Exception:
            html_body = ""
        links = extract_html_links(html_body)
        if links:
            return (plain_body + "\n\nLinked URLs:\n" + "\n".join(links)).strip()
        if plain_body:
            return plain_body
        return html_to_text(html_body) if html_body else ""

    def attachment_files(self, message, temp_dir: Path) -> list[Path]:
        files: list[Path] = []
        try:
            count = int(message.Attachments.Count)
        except Exception:
            return files
        for index in range(1, count + 1):
            attachment = message.Attachments.Item(index)
            name = safe_attachment_name(str(attachment.FileName or ""))
            if Path(name).suffix.lower() != ".pdf":
                continue
            destination = temp_dir / name
            attachment.SaveAsFile(str(destination))
            files.append(destination)
        return files

    def mark_processed(self, message, message_id: str, processed_folder):
        self.state.add(message_id)
        message.UnRead = False
        try:
            message.Save()
        except Exception:
            pass
        if processed_folder is not None:
            message.Move(processed_folder)

    def process_now(
        self,
        filer: Callable[[str, str, str, list[Path]], dict],
        limit: int = 25,
    ) -> IntakeSummary:
        summary = IntakeSummary()
        try:
            namespace = self.namespace()
            folder = self.source_folder(namespace)
            processed_folder = self.processed_outlook_folder(namespace)
            messages = folder.Items
            messages.Sort("[ReceivedTime]", True)
        except EmailIntakeError:
            raise
        except Exception as exc:
            raise EmailIntakeError(
                "PacketFlow opened Outlook, but the mailbox is not connected.\n\n"
                "Open Classic Outlook, wait until the Inbox finishes loading, "
                "and click Check Outlook Now again. New Outlook does not expose "
                "a local profile to PacketFlow; use Microsoft Entra / New "
                "Outlook mode for that version."
            ) from exc
        with tempfile.TemporaryDirectory() as temp_name:
            temp_dir = Path(temp_name)
            try:
                message_count = min(int(messages.Count), limit)
            except Exception:
                message_count = limit
            for index in range(1, message_count + 1):
                message = messages.Item(index)
                summary.scanned += 1
                subject = str(getattr(message, "Subject", "") or "")
                try:
                    message_class = str(getattr(message, "MessageClass", "") or "")
                    if message_class and not message_class.startswith("IPM.Note"):
                        summary.skipped += 1
                        continue
                    message_id = str(getattr(message, "EntryID", "") or "")
                    if self.state.contains(message_id):
                        summary.skipped += 1
                        continue
                    sender = self.message_sender(message)
                    body = self.message_body(message)
                    attachments = self.attachment_files(message, temp_dir)
                    attachments.extend(download_linked_pdfs(body, temp_dir))
                    received = str(getattr(message, "ReceivedTime", "") or "")
                    if not attachments and body:
                        body_pdf = temp_dir / email_body_pdf_name(
                            subject,
                            received,
                        )
                        render_email_body_pdf(
                            body_pdf,
                            sender,
                            subject,
                            received,
                            body,
                        )
                        attachments = [body_pdf]
                    result = filer(sender, subject, body, attachments)
                    status = result.get("status")
                    if status == "ignored":
                        summary.ignored += 1
                        continue
                    if status == "filed":
                        summary.filed += 1
                        try:
                            self.mark_processed(message, message_id, processed_folder)
                        except Exception as exc:
                            summary.errors.append(
                                f"{subject or message_id}: saved, but Outlook "
                                f"could not mark it processed ({exc})"
                            )
                    elif status == "needs_review":
                        summary.needs_review += 1
                        try:
                            self.mark_processed(message, message_id, processed_folder)
                        except Exception as exc:
                            summary.errors.append(
                                f"{subject or message_id}: sent to review, but "
                                f"Outlook could not mark it processed ({exc})"
                            )
                    else:
                        summary.errors.append(subject or message_id)
                except Exception as exc:
                    summary.errors.append(
                        f"{subject or 'Unknown email'}: {exc}"
                    )
        return summary
