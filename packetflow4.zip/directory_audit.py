from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from pathlib import Path

from pypdf import PdfReader


@dataclass
class AuditFinding:
    level: str
    folder: Path
    message: str
    file: Path | None = None


@dataclass
class DirectoryAuditResult:
    root: Path
    folders_scanned: int = 0
    pdfs_scanned: int = 0
    findings: list[AuditFinding] = field(default_factory=list)

    @property
    def errors(self) -> list[AuditFinding]:
        return [item for item in self.findings if item.level == "ERROR"]

    @property
    def warnings(self) -> list[AuditFinding]:
        return [item for item in self.findings if item.level == "WARNING"]


def document_for_filename(
    filename: str,
    document_types: list[str],
) -> tuple[str | None, str]:
    lower_name = filename.lower()
    for document in sorted(document_types, key=len, reverse=True):
        lower_document = document.lower()
        if lower_name == lower_document:
            return document, ""
        suffix = " - " + lower_document
        if lower_name.endswith(suffix):
            return document, filename[: -len(suffix)]
    return None, ""


def pdf_page_count(path: Path) -> tuple[int | None, str | None]:
    try:
        reader = PdfReader(str(path), strict=False)
        if reader.is_encrypted:
            try:
                result = reader.decrypt("")
            except Exception:
                result = 0
            if not result:
                return None, "PDF is encrypted and cannot be opened"
        page_count = len(reader.pages)
        if page_count == 0:
            return 0, "PDF contains no pages"
        return page_count, None
    except Exception as exc:
        return None, f"PDF cannot be opened: {exc}"


def file_digest(path: Path) -> str | None:
    try:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()
    except OSError:
        return None


def audit_directory(
    root: Path,
    document_types: list[str],
    expected_documents: list[str],
) -> DirectoryAuditResult:
    root = Path(root)
    result = DirectoryAuditResult(root=root)
    if not root.is_dir():
        result.findings.append(
            AuditFinding("ERROR", root, "Selected directory does not exist")
        )
        return result

    pdfs_by_folder: dict[Path, list[Path]] = {}
    try:
        for pdf in root.rglob("*.pdf"):
            if pdf.is_file():
                pdfs_by_folder.setdefault(pdf.parent, []).append(pdf)
    except OSError as exc:
        result.findings.append(
            AuditFinding("ERROR", root, f"Directory could not be scanned: {exc}")
        )
        return result

    result.folders_scanned = len(pdfs_by_folder)
    if not pdfs_by_folder:
        result.findings.append(
            AuditFinding("WARNING", root, "No PDF files were found")
        )
        return result
    digests: dict[str, list[Path]] = {}

    for folder, pdfs in sorted(pdfs_by_folder.items()):
        recognized: dict[str, list[tuple[Path, int | None]]] = {}
        prefixes: set[str] = set()
        has_export_log = (folder / "Export Audit Log.txt").exists()

        for pdf in sorted(pdfs):
            result.pdfs_scanned += 1
            if pdf.stat().st_size == 0:
                result.findings.append(
                    AuditFinding(
                        "ERROR",
                        folder,
                        "PDF file is empty",
                        pdf,
                    )
                )
                continue

            page_count, error = pdf_page_count(pdf)
            if error:
                result.findings.append(
                    AuditFinding("ERROR", folder, error, pdf)
                )

            document, prefix = document_for_filename(pdf.name, document_types)
            if document:
                recognized.setdefault(document, []).append((pdf, page_count))
                if prefix:
                    prefixes.add(prefix)
            elif "_" in pdf.stem or pdf.stem.isupper():
                result.findings.append(
                    AuditFinding(
                        "WARNING",
                        folder,
                        "Filename does not follow the current PacketFlow naming format",
                        pdf,
                    )
                )

            digest = file_digest(pdf)
            if digest:
                digests.setdefault(digest, []).append(pdf)

        # Determine whether this folder looks like a PacketFlow export.
        # A folder qualifies if it has an Export Audit Log (definitive), OR if
        # all recognized PDFs share exactly one packet-name prefix (e.g. every
        # file starts with "PAULA LEMIEUX - ").  The old heuristic (3+ recognized
        # PDFs regardless of prefix) produced false-positive errors in shared HR
        # directories that happen to contain several PacketFlow-named files that
        # are not part of a single packet.
        single_prefix = len(prefixes) == 1 and len(recognized) >= 2
        packetflow_folder = has_export_log or single_prefix
        if not packetflow_folder:
            continue

        for document, entries in recognized.items():
            if len(entries) > 1:
                names = ", ".join(path.name for path, _count in entries)
                result.findings.append(
                    AuditFinding(
                        "ERROR",
                        folder,
                        f"Duplicate output type {document}: {names}",
                    )
                )

        missing = [
            document
            for document in expected_documents
            if document not in recognized
        ]
        for document in missing:
            result.findings.append(
                AuditFinding(
                    "ERROR",
                    folder,
                    f"Missing expected output: {document}",
                )
            )

        if len(prefixes) > 1:
            result.findings.append(
                AuditFinding(
                    "WARNING",
                    folder,
                    "Exported PDF filenames use different packet-name prefixes: "
                    + ", ".join(sorted(prefixes)),
                )
            )

        structural_minimums = {
            "Form I-9 Employment Eligibility Verification.pdf": (
                3,
                "I-9 output must contain the form plus two identification pages",
            ),
            "MBC Authorization.pdf": (
                3,
                "MBC Authorization appears to be missing a required signed page",
            ),
            "Viventium Direct Deposit.pdf": (
                2,
                "Direct Deposit output must contain the form and banking evidence",
            ),
        }
        for document, (minimum, message) in structural_minimums.items():
            entries = recognized.get(document, [])
            if len(entries) != 1:
                continue
            path, page_count = entries[0]
            if page_count is not None and page_count < minimum:
                result.findings.append(
                    AuditFinding("ERROR", folder, message, path)
                )

    for paths in digests.values():
        if len(paths) < 2:
            continue
        names = ", ".join(str(path.relative_to(root)) for path in paths)
        result.findings.append(
            AuditFinding(
                "WARNING",
                root,
                "Identical PDF content appears more than once: " + names,
            )
        )

    return result


def format_audit_report(result: DirectoryAuditResult) -> str:
    lines = [
        "PACKETFLOW DIRECTORY AUDIT",
        f"Directory: {result.root}",
        f"Folders containing PDFs: {result.folders_scanned}",
        f"PDFs scanned: {result.pdfs_scanned}",
        f"Errors: {len(result.errors)}",
        f"Warnings: {len(result.warnings)}",
        "",
    ]
    if not result.findings:
        lines.append("No errors or warnings were found.")
        return "\n".join(lines)

    for level in ("ERROR", "WARNING"):
        findings = [item for item in result.findings if item.level == level]
        if not findings:
            continue
        lines.append(level + "S")
        for item in findings:
            location = item.file or item.folder
            lines.append(f"- {location}: {item.message}")
        lines.append("")
    return "\n".join(lines).rstrip()
