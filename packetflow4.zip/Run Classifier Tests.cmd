@echo off
setlocal
cd /d "%~dp0"
echo Running PacketFlow classifier tests...
echo.
py -3 -m unittest discover -s tests -v
if errorlevel 1 (
  echo.
  echo One or more tests failed. Review the results above.
) else (
  echo.
  echo All classifier tests passed.
)
echo.
pause
