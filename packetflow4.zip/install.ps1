$ErrorActionPreference = "Stop"

$SourceDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDirectory = Join-Path $env:LOCALAPPDATA "Programs\PacketFlow"
$Desktop = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $Desktop "PacketFlow.lnk"

try {
    $sourceResolved = [System.IO.Path]::GetFullPath($SourceDirectory)
    $installResolved = [System.IO.Path]::GetFullPath($InstallDirectory)

    if ($sourceResolved -ne $installResolved) {
        $preservedFiles = @{}
        foreach ($fileName in @("settings.json", "correction_memory.json", "rules.json")) {
            $existingPath = Join-Path $InstallDirectory $fileName
            if (Test-Path -LiteralPath $existingPath) {
                $preservedFiles[$fileName] = [System.IO.File]::ReadAllText($existingPath)
            }
        }
        New-Item -ItemType Directory -Path $InstallDirectory -Force | Out-Null
        Get-ChildItem -LiteralPath $SourceDirectory -Force |
            Copy-Item -Destination $InstallDirectory -Recurse -Force
        foreach ($fileName in $preservedFiles.Keys) {
            [System.IO.File]::WriteAllText(
                (Join-Path $InstallDirectory $fileName),
                $preservedFiles[$fileName],
                [System.Text.UTF8Encoding]::new($false)
            )
        }
    }
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($ShortcutPath)
    $shortcut.TargetPath = Join-Path $InstallDirectory "Start PacketFlow.cmd"
    $shortcut.WorkingDirectory = $InstallDirectory
    $shortcut.Description = "PacketFlow Document Processor"
    $shortcut.IconLocation = Join-Path $InstallDirectory "packetflow.ico"
    $shortcut.Save()

    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show(
        "PacketFlow was installed.`n`nA shortcut was added to the desktop. The app will now check this computer for its required components.",
        "PacketFlow",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Information
    ) | Out-Null

    Start-Process -FilePath (Join-Path $InstallDirectory "Start PacketFlow.cmd") -WorkingDirectory $InstallDirectory
}
catch {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show(
        "The app could not be installed.`n`n$($_.Exception.Message)",
        "PacketFlow",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Error
    ) | Out-Null
    exit 1
}
