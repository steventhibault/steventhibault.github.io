@echo off
setlocal
cd /d "%~dp0"
echo Running PacketFlow directly...
echo.
py -3 app.py
if errorlevel 1 (
  echo.
  echo App closed with an error. Copy/screenshot the error above.
)
echo.
pause
