PACKETFLOW
Intake Processor
OCR + document classification + review before export

START
Double-click "Start PacketFlow.cmd".

INSTALL ON A COMPUTER
For a normal installed copy with a desktop shortcut, double-click
"Install PacketFlow.cmd". The installer places PacketFlow in the current
Windows user's local Programs folder, creates a desktop shortcut, and runs the
normal dependency check.

FIRST RUN REQUIREMENTS
The launcher checks for:
- Python 3.10 or newer
- Pillow, pypdf, customtkinter, windnd, and pystray
- Tesseract OCR
- Poppler PDF tools

If anything is missing, the launcher explains what is missing and attempts to
help install it or opens the correct download page.

BASIC WORKFLOW
1. Click Open Packet and select a PDF.
   You can also drag and drop a PDF onto the app window.
2. Wait while PacketFlow reads the pages.
3. Review the suggested PDF names and page groupings.
4. Select one or more pages to assign, rename, save adjustments, rotate, or mark unsorted.
5. Arrange the Output PDFs list with Move Up and Move Down.
6. Click Review Packet to inspect warnings.
7. Click Export PDFs and choose the destination folder.

After successful export, the completed packet is cleared from the processor so
it is ready for the next scan.

REVIEW AND TRUST FEATURES
PacketFlow includes document-level review features without using a single
overall packet-quality percentage:

- Header Statistics
  The header now shows a compact packet status line such as page count, PDF
count, unsorted count, blank pages removed, low-confidence pages, and duplicate
pairs. This gives supervisors a fast packet health check without opening a
separate screen.

- Confidence Meter
  Each output PDF row shows High, Medium, or Low Confidence with a percentage.
This helps reviewers know which documents need attention first.

- Assignment Details
  Click Assignment Details after selecting a page to review the classification.
The dialog shows the assigned document, confidence level, detected indicators,
and any missing checklist items with the confidence deduction beside each item.

- Save Adjustments
  After manually correcting pages, click Save Adjustments to save the correction
and learn recognition phrases for future packets. This improves future sorting
without editing code.

- Learned Badge
  Output rows show a Learned indicator when a page was assigned using remembered
correction memory. This makes it clear when PacketFlow reused a past correction.

- Duplicate Compare
  Review Packet includes a Review Duplicates option when suspected duplicates
are found. It opens a side-by-side preview of matching pages so staff can decide
what to keep or mark unsorted.

- Rule Export Metadata
  Exported rule profiles now include metadata fields such as schema_version,
profile_name, exported_at, and exported_by so teams can track which profile was
shared or installed.

CLASSIFIER TESTS
Double-click "Run Classifier Tests.cmd" to run the automated regression suite.
The tests use synthetic OCR text rather than employee documents. They cover
I-9 and identification documents, direct deposit and banking behavior, custom
rules, learned corrections, added multi-page files, blank pages, rotations,
document ordering, and forms that should intentionally remain unsorted.

HEADER AND BRANDING
This rebuild keeps the original PacketFlow logo and keeps the header wording:

Intake Processor
OCR + document classification + review before export

The removed "Intelligent Document Processing" subtitle was not kept.
The extra "Export to Last" header button was removed to reduce clutter.

SCANNER FOLDER WATCH
Click Scanner Folder and choose the folder used by the scanning program.
While PacketFlow remains open, new PDFs are detected and analyzed automatically.

- PDFs already in the folder when watching starts are ignored.
- A new PDF must remain unchanged for several checks before it is opened.
- This prevents reading a scan while it is still being written.
- Incoming PDFs wait while another packet is being analyzed.
- Automatic export can still be enabled in Settings.
- The app can start with Windows and run minimized to the tray.

SETTINGS
Settings can turn these operational features on or off:
- Pause scanner folder watching
- Start with Windows
- Start minimized to tray
- Show packet-ready notifications
- Open and maximize for new scans
- Automatically start export after scanner analysis
- Apply remembered page corrections
- Apply remembered PDF order
- Remember the last export location
- Show duplicate-page warnings
- Show low-confidence warnings

CUSTOMIZATION
PacketFlow supports separate rule profiles for workflows such as HR,
Onboarding, Accounting, Operations, Customer Service, or client-specific use.

Profiles can be created, copied, renamed, switched, deleted, exported, and
imported. Each profile keeps its own:
- Document types
- Expected checklist
- Recognition phrases
- Learned custom rules
- Remembered corrections
- Preferred PDF output order

Manage Document Rules lets users create output PDF names and OCR matching rules
without changing the program code. Custom rules run before the built-in
onboarding starter profile.

REVIEW AND SAFETY
PacketFlow always keeps human review in the workflow.

Review Packet reports:
- Expected documents found or missing
- Unsorted pages
- Low-confidence scans
- Suspected duplicate pages
- Pages used in multiple PDFs
- Blank pages removed
- Automatic or manual rotations
- Remembered corrections applied
- Packet Quality score

Export always displays the review before writing files. If the output folder
already exists, PacketFlow lists files that will be replaced and confirms that
unrelated files will remain untouched.

IMPORTANT BEHAVIOR
- The app never divides a source page. If one scan page contains two documents,
it should be rescanned correctly.
- Blank scanner pages are removed automatically.
- Upside-down scans are detected, shown upright, and exported upright.
- Banking/check pages can be included in both Banking.pdf and Viventium Direct
Deposit.pdf when appropriate.
- I-9 output requires the I-9 form plus two recognized identification pages.
- All export filenames are normalized with a clean .pdf suffix.

OUTPUT ORDER
The PDFs are written in the order shown in the Output PDFs list. Modification
times are staggered one minute apart so Windows File Explorer can show the same
order when sorted by Date modified descending.

TROUBLESHOOTING
Use "Run app directly - show errors.cmd" to launch PacketFlow in a console if it
will not open normally. Fatal startup errors are written to the PacketFlow error
log in the current user's APPDATA PacketFlow folder when available.

UNINSTALL
Use "Uninstall_PacketFlow.cmd" to remove the installed copy and shortcut.

ASSIGNMENT DETAILS UPDATE
The Assignment Details tool explains confidence without duplicate sections. It is designed to answer the practical review question: "What was detected and what is missing?"

For each selected page, Assignment Details shows:
- Assigned document name
- Final confidence percentage and band
- Detected indicators found on the page
- Missing checklist items with deductions shown inline, such as Employee availability sheet (-4%)

Examples of missing expected indicators include:
- Employee availability sheet
- Work reference section
- Compensation agreement
- Supporting identity/work document for I-9 packets
- Authorization and release wording for background-check forms
- Direct deposit authorization wording

PacketFlow intentionally prioritizes document-specific missing indicators over
generic scan-quality warnings. Missing checklist items show their deduction
inline so staff can quickly see what lowered confidence.

CONFIDENCE BANDS
- 95-100%: Very High Confidence
- 85-94%: High Confidence
- 70-84%: Medium Confidence
- Below 70%: Review Recommended

The packet header statistics now count pages needing review based on confidence
below the High Confidence range, rather than only generic OCR quality checks.

OUTLOOK EMAIL FILING
Settings includes an optional Outlook Email Filing setup screen.

The employee folder directory is scanned each time an email is matched, so new
or renamed employee folders are recognized automatically. The employee's first
and last name must appear in the email body. PDF attachments or a PDF made from
the email body are saved only when exactly one employee folder matches. Missing
or duplicate matches are copied to Needs Review instead of being guessed.

Auto Detect is the default connection. PacketFlow uses Microsoft Entra/New
Outlook first when that setup is available, then falls back to the local Classic
Outlook profile. Local Outlook Profile and Microsoft Entra / New Outlook can
also be selected manually when an office wants to force one method.

OUTLOOK EMAIL FILING
PacketFlow can check Outlook automatically while the program is running.

1. Open Settings > Email Filing.
2. Choose one connection method:
   - Auto Detect is recommended. It tries New Outlook/Entra when configured,
     then falls back to the local Classic Outlook profile.
   - Local Outlook Profile uses the signed-in Classic Outlook Windows profile
     and does not require Microsoft application or tenant credentials.
   - Microsoft Entra / New Outlook uses Microsoft Graph. It requires an
     application ID, tenant ID, and Microsoft account authorization.
3. Choose the employee folder directory.
4. Enter approved senders and required clearance keywords.
5. Leave Check Outlook automatically enabled for normal use, or click
   Check Outlook Now for an immediate deeper check.

The Entra/New Outlook method opens Microsoft's device sign-in page and displays
a code on its first check. Local profile mode does not display a Microsoft
sign-in prompt. Automatic checks run every 2 minutes by default and inspect the
newest 10 messages. Check Outlook Now inspects the newest 100 messages.
If an email has a PDF attachment, PacketFlow saves that attachment. If it does
not have a PDF attachment, PacketFlow converts the email body into a PDF that
includes the sender, subject, received date, and message text. Completed emails
are marked read, moved into PacketFlow Processed, and recorded by message ID so
they are not filed twice.

Microsoft 365 administrator setup is only required for the Microsoft Entra /
New Outlook connection:
- Register PacketFlow as a Microsoft Entra public client application.
- Enable public client/device-code authentication.
- Add delegated Microsoft Graph permissions User.Read and Mail.ReadWrite.
- Supply the Application (client) ID and Directory (tenant) ID to PacketFlow.

Local Outlook Profile requirements:
- Classic Outlook for Windows must be installed and configured.
- Leave the local profile-name field blank to use the default Outlook profile.
- Select Microsoft Entra / New Outlook instead if the computer only has New
  Outlook.

DIRECTORY AUDIT
Use Audit Folder in the top toolbar to check an entire directory and all PDF
folders beneath it. The audit is read-only and does not rename, move, or delete
anything.

Errors include:
- Corrupt, unreadable, encrypted, empty, or zero-page PDFs
- Missing expected PacketFlow output PDFs
- Duplicate output types in one packet folder
- I-9 PDFs with fewer than three pages
- MBC Authorization PDFs missing the minimum signed-page count
- Direct Deposit PDFs missing the form or banking-page count

Warnings include:
- Identical PDF files found more than once
- Mixed packet-name prefixes
- Older underscore or all-cap filename formats

The audit runs in the background and saves a text report in the current user's
APPDATA PacketFlow folder. A copy can be saved anywhere from the results window.


EMAIL CHECK PERFORMANCE
Outlook checks now run in the background so the main PacketFlow window stays responsive while mail is scanned.
