@echo off
setlocal
cd /d "%~dp0"
echo Running PacketFlow classifier tests...
echo.

:: Verify at least one test file exists before attempting discovery
if not exist "test_classifier.py" (
  echo ERROR: test_classifier.py was not found in %~dp0
  echo Make sure Run_Classifier_Tests.cmd is in the same folder as the app.
  echo.
  pause
  exit /b 1
)

py -3 -m unittest test_classifier -v
set TEST_EXIT=%errorlevel%

:: Detect the silent-import-failure case: if py itself is missing or the
:: module failed to load, errorlevel is still 0 but nothing ran.
:: Re-run with --tb-style flag isn't available in unittest, so we do a quick
:: import check to surface dependency errors explicitly.
if %TEST_EXIT% EQU 0 (
  py -3 -c "import test_classifier" 2>nul
  if errorlevel 1 (
    echo.
    echo WARNING: test_classifier.py could not be imported.
    echo Run "py -3 -c \"import test_classifier\"" in a console to see the error.
    set TEST_EXIT=1
  )
)

echo.
if %TEST_EXIT% EQU 0 (
  echo All classifier tests passed.
) else (
  echo One or more tests failed. Review the results above.
)
echo.
pause
exit /b %TEST_EXIT%
