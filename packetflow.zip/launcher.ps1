param([switch]$CheckOnly)

$ErrorActionPreference = "Stop"
$AppDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$AppScript = Join-Path $AppDirectory "app.py"
$RequirementsPath = Join-Path $AppDirectory "requirements.txt"

Add-Type -AssemblyName PresentationFramework

function Show-Info([string]$Message, [string]$Title = "CareCo PacketFlow") {
    [System.Windows.MessageBox]::Show($Message, $Title, [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Information) | Out-Null
}
function Show-ErrorMessage([string]$Message) {
    [System.Windows.MessageBox]::Show($Message, "CareCo PacketFlow", [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Error) | Out-Null
}
function Ask-YesNo([string]$Message) {
    $answer = [System.Windows.MessageBox]::Show($Message, "CareCo PacketFlow", [System.Windows.MessageBoxButton]::YesNo, [System.Windows.MessageBoxImage]::Warning)
    return $answer -eq [System.Windows.MessageBoxResult]::Yes
}
function Test-PythonExecutable([string]$Path) {
    if (-not $Path -or -not (Test-Path -LiteralPath $Path)) { return $false }
    try {
        $version = & $Path -c "import sys; print(int(sys.version_info >= (3, 10)))" 2>$null
        return $LASTEXITCODE -eq 0 -and ($version | Select-Object -Last 1) -eq "1"
    } catch { return $false }
}
function Find-Python {
    $candidates = New-Object System.Collections.Generic.List[string]
    foreach ($commandName in @("python.exe", "python3.exe")) {
        $command = Get-Command $commandName -ErrorAction SilentlyContinue
        if ($command) { $candidates.Add($command.Source) }
    }
    $pyLauncher = Get-Command "py.exe" -ErrorAction SilentlyContinue
    if ($pyLauncher) {
        try {
            $launchedPath = & $pyLauncher.Source -3 -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $launchedPath) { $candidates.Add(($launchedPath | Select-Object -Last 1)) }
        } catch {}
    }
    foreach ($root in @((Join-Path $env:LOCALAPPDATA "Programs\Python"), $env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if ($root -and (Test-Path -LiteralPath $root)) {
            Get-ChildItem -LiteralPath $root -Directory -Filter "Python*" -ErrorAction SilentlyContinue |
                Sort-Object Name -Descending |
                ForEach-Object {
                    $candidate = Join-Path $_.FullName "python.exe"
                    if (Test-Path -LiteralPath $candidate) { $candidates.Add($candidate) }
            }
        }
    }
    # Codex desktop keeps its bundled Python outside the usual installation
    # folders. This fallback is harmless on ordinary office computers.
    $codexPython = Join-Path $env:USERPROFILE ".cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
    if (Test-Path -LiteralPath $codexPython) {
        $candidates.Add($codexPython)
    }
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (Test-PythonExecutable $candidate) { return $candidate }
    }
    return $null
}
function Find-Program([string]$Name, [string[]]$Patterns) {
    $command = Get-Command $Name -ErrorAction SilentlyContinue
    if ($command) { return $command.Source }
    foreach ($pattern in $Patterns) {
        if (-not $pattern) { continue }
        $matches = Get-ChildItem -Path $pattern -File -ErrorAction SilentlyContinue | Sort-Object FullName -Descending
        if ($matches) { return $matches[0].FullName }
    }
    return $null
}
function Get-MissingPythonPackages([string]$PythonPath) {
    if (-not $PythonPath) { return @() }
    $code = @'
import importlib.util
packages = [('Pillow','PIL'),('pypdf','pypdf'),('customtkinter','customtkinter'),('windnd','windnd'),('pystray','pystray')]
missing = [name for name, module in packages if importlib.util.find_spec(module) is None]
print('\n'.join(missing))
'@
    $output = & $PythonPath -c $code 2>$null
    if ($LASTEXITCODE -ne 0) { return @("Pillow", "pypdf", "customtkinter", "windnd", "pystray") }
    return @($output | Where-Object { $_ -and $_.Trim() })
}
function Refresh-ProcessPath {
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path = "$machinePath;$userPath"
}
function Install-WithWinget([string]$PackageId, [string]$DisplayName) {
    try {
        $process = Start-Process -FilePath "winget.exe" -ArgumentList @("install", "--id", $PackageId, "--exact", "--accept-package-agreements", "--accept-source-agreements") -Wait -PassThru
        return $process.ExitCode -eq 0
    } catch {
        Show-ErrorMessage "Windows could not install $DisplayName automatically.`n`n$($_.Exception.Message)"
        return $false
    }
}
function Open-ManualInstallPages([string[]]$MissingItems) {
    if ($MissingItems -contains "Python 3.10 or newer") { Start-Process "https://www.python.org/downloads/windows/" }
    if ($MissingItems -contains "Tesseract OCR") { Start-Process "https://github.com/UB-Mannheim/tesseract/wiki" }
    if ($MissingItems -contains "Poppler PDF tools") { Start-Process "https://github.com/oschwartz10612/poppler-windows/releases" }
}

$python = Find-Python
$tesseract = Find-Program "tesseract.exe" @("$env:ProgramFiles\Tesseract-OCR\tesseract.exe", "${env:ProgramFiles(x86)}\Tesseract-OCR\tesseract.exe")
$pdftoppm = Find-Program "pdftoppm.exe" @("$env:ProgramFiles\poppler-*\Library\bin\pdftoppm.exe", "$env:ProgramFiles\poppler\Library\bin\pdftoppm.exe", "${env:ProgramFiles(x86)}\poppler-*\Library\bin\pdftoppm.exe")
$missingPackages = @(Get-MissingPythonPackages $python)

$missing = New-Object System.Collections.Generic.List[string]
if (-not $python) { $missing.Add("Python 3.10 or newer") }
if (-not $tesseract) { $missing.Add("Tesseract OCR") }
if (-not $pdftoppm) { $missing.Add("Poppler PDF tools") }
foreach ($package in $missingPackages) { $missing.Add("Python package: $package") }

if ($CheckOnly) {
    if ($missing.Count -eq 0) {
        Write-Output "READY"
        Write-Output "Python=$python"
        Write-Output "Tesseract=$tesseract"
        Write-Output "Poppler=$pdftoppm"
        exit 0
    }
    Write-Output "MISSING"
    $missing | ForEach-Object { Write-Output $_ }
    exit 2
}

if ($missing.Count -gt 0) {
    $message = "This computer is missing software required by CareCo PacketFlow:`n`n"
    $message += ($missing | ForEach-Object { " - $_" }) -join "`n"
    $message += "`n`nWould you like to install the missing items now?"
    if (-not (Ask-YesNo $message)) {
        Show-Info "Nothing was installed. Run the launcher again after the required software is available."
        exit 2
    }

    $missingSystemSoftware = @($missing | Where-Object { -not $_.StartsWith("Python package:") })
    $winget = Get-Command "winget.exe" -ErrorAction SilentlyContinue
    if ($missingSystemSoftware.Count -gt 0 -and -not $winget) {
        Open-ManualInstallPages $missing
        Show-Info ("Automatic installation is not available on this computer.`n`n" +
            "The required download pages have been opened. Install the missing items, then run the app again.`n`n" +
            "During Python installation, select the option to add Python to PATH.")
        exit 2
    }

    if (-not $python) { Install-WithWinget "Python.Python.3.12" "Python" | Out-Null }
    if (-not $tesseract) { Install-WithWinget "tesseract-ocr.tesseract" "Tesseract OCR" | Out-Null }
    if (-not $pdftoppm) { Install-WithWinget "oschwartz10612.Poppler" "Poppler PDF tools" | Out-Null }

    Refresh-ProcessPath
    $python = Find-Python
    if (-not $python) {
        Show-ErrorMessage "Python still could not be found after installation. Restart Windows, then run the launcher again."
        exit 2
    }

    $missingPackages = @(Get-MissingPythonPackages $python)
    if ($missingPackages.Count -gt 0) {
        try {
            & $python -m pip install --user --disable-pip-version-check --upgrade pip
            if (Test-Path -LiteralPath $RequirementsPath) {
                & $python -m pip install --user --disable-pip-version-check -r $RequirementsPath
            } else {
                $packageArgs = @($missingPackages)
                & $python -m pip install --user --disable-pip-version-check @packageArgs
            }
            if ($LASTEXITCODE -ne 0) { throw "pip returned exit code $LASTEXITCODE" }
        } catch {
            Show-ErrorMessage ("Python was found, but the required libraries could not be installed.`n`n" +
                "Try running this manually in Command Prompt:`n`n" +
                "py -3 -m pip install --user Pillow pypdf customtkinter windnd pystray`n`n" +
                "$($_.Exception.Message)")
            exit 2
        }
    }

    Refresh-ProcessPath
    Show-Info "Installation has finished. The app will start now."
}

# Re-check core external tools after install/refresh.
$tesseract = Find-Program "tesseract.exe" @("$env:ProgramFiles\Tesseract-OCR\tesseract.exe", "${env:ProgramFiles(x86)}\Tesseract-OCR\tesseract.exe")
$pdftoppm = Find-Program "pdftoppm.exe" @("$env:ProgramFiles\poppler-*\Library\bin\pdftoppm.exe", "$env:ProgramFiles\poppler\Library\bin\pdftoppm.exe", "${env:ProgramFiles(x86)}\poppler-*\Library\bin\pdftoppm.exe")
if (-not $tesseract -or -not $pdftoppm) {
    $stillMissing = @()
    if (-not $tesseract) { $stillMissing += "Tesseract OCR" }
    if (-not $pdftoppm) { $stillMissing += "Poppler PDF tools" }
    Open-ManualInstallPages $stillMissing
    Show-Info ("These required tools still could not be found:`n`n - " + ($stillMissing -join "`n - ") + "`n`nInstall them, then run this launcher again.")
    exit 2
}

$pythonDirectory = Split-Path -Parent $python
$pythonw = Join-Path $pythonDirectory "pythonw.exe"
if (-not (Test-Path -LiteralPath $pythonw)) { $pythonw = $python }

try {
    Start-Process -FilePath $pythonw -ArgumentList ('"{0}"' -f $AppScript) -WorkingDirectory $AppDirectory
} catch {
    Show-ErrorMessage "The app could not be started.`n`n$($_.Exception.Message)"
    exit 1
}
