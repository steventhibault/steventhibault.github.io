$ErrorActionPreference = "Stop"

$SourceDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDirectory = Join-Path $env:LOCALAPPDATA "Programs\CareCo PacketFlow"
$OldInstallDirectories = @(
    (Join-Path $env:LOCALAPPDATA "Programs\CareCo Onboarding Packet Processor"),
    (Join-Path $env:LOCALAPPDATA "Programs\CareCo Onboarding Packet Sorter")
)
$Desktop = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $Desktop "CareCo PacketFlow.lnk"
$OldShortcutPaths = @(
    (Join-Path $Desktop "CareCo Onboarding Packet Processor.lnk"),
    (Join-Path $Desktop "CareCo Onboarding Packet Sorter.lnk")
)

try {
    $sourceResolved = [System.IO.Path]::GetFullPath($SourceDirectory)
    $installResolved = [System.IO.Path]::GetFullPath($InstallDirectory)

    if ($sourceResolved -ne $installResolved) {
        New-Item -ItemType Directory -Path $InstallDirectory -Force | Out-Null
        Get-ChildItem -LiteralPath $SourceDirectory -Force |
            Copy-Item -Destination $InstallDirectory -Recurse -Force
    }
    $newMemoryPath = Join-Path $InstallDirectory "correction_memory.json"
    $newSettingsPath = Join-Path $InstallDirectory "settings.json"
    foreach ($oldInstallDirectory in $OldInstallDirectories) {
        $oldMemoryPath = Join-Path $oldInstallDirectory "correction_memory.json"
        $oldSettingsPath = Join-Path $oldInstallDirectory "settings.json"
        if (
            -not (Test-Path -LiteralPath $newMemoryPath) -and
            (Test-Path -LiteralPath $oldMemoryPath)
        ) {
            Copy-Item -LiteralPath $oldMemoryPath -Destination $newMemoryPath
        }
        if (
            -not (Test-Path -LiteralPath $newSettingsPath) -and
            (Test-Path -LiteralPath $oldSettingsPath)
        ) {
            Copy-Item -LiteralPath $oldSettingsPath -Destination $newSettingsPath
        }
    }

    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($ShortcutPath)
    $shortcut.TargetPath = Join-Path $InstallDirectory "Start CareCo PacketFlow.cmd"
    $shortcut.WorkingDirectory = $InstallDirectory
    $shortcut.Description = "CareCo PacketFlow"
    $shortcut.IconLocation = Join-Path $InstallDirectory "careco-packetflow.ico"
    $shortcut.Save()
    foreach ($oldShortcutPath in $OldShortcutPaths) {
        if (Test-Path -LiteralPath $oldShortcutPath) {
            Remove-Item -LiteralPath $oldShortcutPath -Force
        }
    }

    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show(
        "CareCo PacketFlow was installed.`n`nA shortcut was added to the desktop. The app will now check this computer for its required components.",
        "CareCo PacketFlow",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Information
    ) | Out-Null

    Start-Process -FilePath (Join-Path $InstallDirectory "Start CareCo PacketFlow.cmd") -WorkingDirectory $InstallDirectory
}
catch {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show(
        "The app could not be installed.`n`n$($_.Exception.Message)",
        "CareCo PacketFlow",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Error
    ) | Out-Null
    exit 1
}
