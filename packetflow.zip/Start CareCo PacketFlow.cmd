@echo off
setlocal
set "APP_DIR=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%APP_DIR%launcher.ps1"
if errorlevel 1 (
  echo.
  echo The app did not start successfully. Press any key to close this window.
  pause >nul
)
exit /b %errorlevel%
