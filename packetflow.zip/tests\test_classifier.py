from __future__ import annotations

import importlib.util
import sys
import types
import unittest


# The classifier itself does not use the UI toolkit. This small fallback lets
# the tests run in a development environment before optional UI packages are
# installed.
if importlib.util.find_spec("customtkinter") is None:
    sys.modules["customtkinter"] = types.ModuleType("customtkinter")

from app import Assignment, PacketAnalyzer, PacketSorterApp


def documents_for_page(
    assignments: list[Assignment],
    page_index: int,
) -> set[str]:
    return {
        assignment.document
        for assignment in assignments
        if assignment.page_index == page_index
    }


class PacketAnalyzerClassificationTests(unittest.TestCase):
    def setUp(self):
        self.analyzer = PacketAnalyzer(
            {
                "document_types": [],
                "expected_document_types": [],
                "custom_rules": [],
            }
        )

    def classify(
        self,
        *texts: str,
        rotations: list[int] | None = None,
        blank_pages: set[int] | None = None,
    ) -> list[Assignment]:
        return self.analyzer.classify_pages(
            list(texts),
            rotations=rotations,
            blank_pages=blank_pages,
        )

    def test_blank_pages_are_never_classified(self):
        assignments = self.classify(
            "Orientation Agenda",
            "Job Application",
            blank_pages={0},
        )

        self.assertEqual(documents_for_page(assignments, 0), set())
        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Job Application.pdf"},
        )

    def test_detected_rotation_is_preserved_on_assignment(self):
        assignments = self.classify(
            "Orientation Agenda",
            rotations=[180],
        )

        self.assertEqual(len(assignments), 1)
        self.assertEqual(assignments[0].rotation, 180)

    def test_custom_all_rule_requires_every_keyword(self):
        self.analyzer.rules["custom_rules"] = [
            {
                "document": "Non-Disclosure Agreement.pdf",
                "keywords": ["confidential information", "covenant not to disclose"],
                "match_mode": "all",
            }
        ]

        matched = self.classify(
            "CONFIDENTIAL INFORMATION and covenant not to disclose"
        )
        not_matched = self.classify("Confidential information only")

        self.assertEqual(
            documents_for_page(matched, 0),
            {"Non-Disclosure Agreement.pdf"},
        )
        self.assertEqual(documents_for_page(not_matched, 0), set())

    def test_custom_any_rule_accepts_one_keyword(self):
        self.analyzer.rules["custom_rules"] = [
            {
                "document": "Safety Training.pdf",
                "keywords": ["safety orientation", "workplace safety"],
                "match_mode": "any",
            }
        ]

        assignments = self.classify("Annual workplace safety review")

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Safety Training.pdf"},
        )

    def test_custom_rules_take_priority_over_built_in_rules(self):
        self.analyzer.rules["custom_rules"] = [
            {
                "document": "Accounting Authorization.pdf",
                "keywords": ["direct deposit authorization form"],
                "match_mode": "all",
            }
        ]

        assignments = self.classify("Direct Deposit Authorization Form")

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Accounting Authorization.pdf"},
        )

    def test_custom_banking_rule_also_adds_direct_deposit_output(self):
        self.analyzer.rules["custom_rules"] = [
            {
                "document": "Banking.pdf",
                "keywords": ["bank account verification"],
                "match_mode": "all",
            }
        ]

        assignments = self.classify("Bank Account Verification")

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Banking.pdf", "Viventium Direct Deposit.pdf"},
        )

    def test_non_disclosure_agreement_is_detected(self):
        for text in (
            "NON-DISCLOSURE AGREEMENT (NDA)",
            "Nondisclosure Agreement between the parties",
        ):
            with self.subTest(text=text):
                assignments = self.classify(text)
                self.assertEqual(
                    documents_for_page(assignments, 0),
                    {"Non-Disclosure Agreement.pdf"},
                )

    def test_i9_form_is_detected(self):
        assignments = self.classify(
            "Form I-9 Employment Eligibility Verification "
            "Department of Homeland Security"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Form I-9 Employment Eligibility Verification.pdf"},
        )

    def test_driver_license_is_grouped_with_i9(self):
        assignments = self.classify(
            "Driver's License DL. No 123456 Class C Expires 2028"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Form I-9 Employment Eligibility Verification.pdf"},
        )

    def test_passport_is_grouped_with_i9(self):
        assignments = self.classify(
            "United States of America Passport Nationality USA "
            "Passport No 123456 Date of Expiration 2028"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Form I-9 Employment Eligibility Verification.pdf"},
        )

    def test_other_supported_i9_identification_is_detected(self):
        samples = (
            "Social Security Administration signature",
            "Permanent Resident Card Resident Since 2020 Card Expires 2030",
            "Employment Authorization Card USCIS Category Card Expires 2028",
            "Passport I-94 Arrival/Departure Record Class of Admission "
            "Employment Authorized",
            "Government Identification Card Date of Birth Photograph",
            "School Identification Card Student",
            "Voter Registration Card",
            "United States Uniformed Services Identification",
            "United States Coast Guard Merchant Mariner Credential",
            "Native American Tribal Document",
            "Canada Driver's Licence Class C Expires 2028",
            "I-197 Citizen Identification Card",
            "I-179 Resident Citizen Identification Card",
            "Certificate of Naturalization",
        )
        for text in samples:
            with self.subTest(text=text):
                assignments = self.classify(text)
                self.assertEqual(
                    documents_for_page(assignments, 0),
                    {"Form I-9 Employment Eligibility Verification.pdf"},
                )

    def test_minor_identity_record_requires_i9_adjacency(self):
        assignments = self.classify(
            "Form I-9 Department of Homeland Security",
            "School Record Student Report Card",
        )
        standalone = self.classify("School Record Student Report Card")

        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Form I-9 Employment Eligibility Verification.pdf"},
        )
        self.assertEqual(documents_for_page(standalone, 0), set())

    def test_replacement_receipt_requires_i9_adjacency(self):
        assignments = self.classify(
            "Form I-9 Department of Homeland Security",
            "Receipt for replacement document lost stolen Form I-797C",
        )

        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Form I-9 Employment Eligibility Verification.pdf"},
        )

    def test_restricted_social_security_card_is_not_accepted(self):
        assignments = self.classify(
            "Social Security Administration Not Valid for Employment"
        )

        self.assertEqual(documents_for_page(assignments, 0), set())

    def test_birth_certificate_stays_separate_from_i9(self):
        assignments = self.classify(
            "Certificate of Live Birth Date of Birth Place of Birth"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Birth and Marriage Certificates.pdf"},
        )

    def test_mixed_i9_and_orientation_page_is_left_unsorted(self):
        assignments = self.classify(
            "Form I-9 Department of Homeland Security Orientation Agenda"
        )

        self.assertEqual(documents_for_page(assignments, 0), set())

    def test_orientation_agenda_is_detected(self):
        assignments = self.classify("Orientation Agenda")

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Orientation Agenda.pdf"},
        )

    def test_interview_statement_is_detected(self):
        assignments = self.classify(
            "Interview Statement Interviewed By "
            "What are your strengths? What are your weaknesses?"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Interview Statement.pdf"},
        )

    def test_job_application_pages_are_detected(self):
        samples = (
            "Job Application",
            "Employee Availability Sheet",
            "Work Reference",
            "Handbook Acknowledgement Form",
            "The job description provides a framework for the job",
        )
        for text in samples:
            with self.subTest(text=text):
                assignments = self.classify(text)
                self.assertEqual(
                    documents_for_page(assignments, 0),
                    {"Job Application.pdf"},
                )

    def test_federal_w4_is_detected(self):
        assignments = self.classify(
            "Form W-4 Employee's Withholding Certificate "
            "Internal Revenue Service Treasury"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Federal W-4 Withholding.pdf"},
        )

    def test_time_recording_is_detected(self):
        assignments = self.classify("Recording of Time Worked")

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Time Recording.pdf"},
        )

    def test_maine_payroll_withholding_is_detected(self):
        assignments = self.classify(
            "W-4ME Maine Withholding Allowance Certificate"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Payroll.pdf"},
        )

    def test_direct_deposit_form_does_not_duplicate_into_banking(self):
        assignments = self.classify(
            "TD Bank Direct Deposit Authorization Form Payroll Compensation"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Viventium Direct Deposit.pdf"},
        )

    def test_generic_direct_deposit_words_are_not_enough(self):
        assignments = self.classify("Direct Deposit")

        self.assertEqual(documents_for_page(assignments, 0), set())

    def test_check_or_account_page_goes_to_banking_and_direct_deposit(self):
        assignments = self.classify(
            "Voided Check Routing Number 011000015 Checking Account 1234"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Banking.pdf", "Viventium Direct Deposit.pdf"},
        )

    def test_sparse_page_after_direct_deposit_is_treated_as_banking(self):
        assignments = self.classify(
            "Employee Direct Deposit Authorization",
            "__SPARSE_SCAN__ account image",
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Viventium Direct Deposit.pdf"},
        )
        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Banking.pdf", "Viventium Direct Deposit.pdf"},
        )

    def test_legacy_paypro_payroll_is_ignored(self):
        assignments = self.classify(
            "PayPro Payroll Card Mailing Address Net Pay Employee Signature"
        )

        self.assertEqual(documents_for_page(assignments, 0), set())

    def test_auto_enrollment_opt_out_is_detected(self):
        assignments = self.classify(
            "Automatic Auto Enrollment Plan Opt Out Election"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Auto Enrollment Opt Out.pdf"},
        )

    def test_employee_choice_waiver_is_detected(self):
        assignments = self.classify(
            "Employee Choice Acknowledgement Waiver Form Decline All Coverage"
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Employee Choice Acknowledgement Waiver.pdf"},
        )

    def test_background_and_child_protection_forms_are_detected(self):
        samples = {
            "CHERKR consumer report candidate disclosure":
                "CHERKR Authorization.pdf",
            "Maine Background Check Center authorization and release":
                "MBC Authorization.pdf",
            "Application fee paid for Maine criminal background check":
                "MBC Payment.pdf",
            "Child abuse background check confirmation":
                "Confirmation - Child Abuse Registry Background Check Request.pdf",
            "Child abuse and neglect records information":
                "Child Protective Services Authorization.pdf",
        }
        for text, expected in samples.items():
            with self.subTest(expected=expected):
                assignments = self.classify(text)
                self.assertEqual(
                    documents_for_page(assignments, 0),
                    {expected},
                )

    def test_document_sequences_keep_i9_and_job_pages_in_order(self):
        i9_form = self.analyzer.document_sequence(
            "Form I-9 Employment Eligibility Verification.pdf",
            "form i-9",
        )
        i9_id = self.analyzer.document_sequence(
            "Form I-9 Employment Eligibility Verification.pdf",
            "driver's license",
        )
        application = self.analyzer.document_sequence(
            "Job Application.pdf",
            "job application",
        )
        handbook = self.analyzer.document_sequence(
            "Job Application.pdf",
            "handbook acknowledgement form",
        )

        self.assertLess(i9_form, i9_id)
        self.assertLess(application, handbook)


class AddedFileInheritanceTests(unittest.TestCase):
    def test_single_detected_document_is_inherited_by_remaining_file_pages(self):
        assignments = PacketSorterApp.inherit_added_file_assignments(
            [Assignment(0, "Non-Disclosure Agreement.pdf")],
            blank_pages=set(),
            source_page_ranges=[(0, 2)],
            rotations=[0, 0],
        )

        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Non-Disclosure Agreement.pdf"},
        )

    def test_banking_pair_is_inherited_by_remaining_file_pages(self):
        assignments = PacketSorterApp.inherit_added_file_assignments(
            [
                Assignment(0, "Banking.pdf"),
                Assignment(0, "Viventium Direct Deposit.pdf"),
            ],
            blank_pages=set(),
            source_page_ranges=[(0, 2)],
            rotations=[0, 180],
        )

        self.assertEqual(
            documents_for_page(assignments, 1),
            {"Banking.pdf", "Viventium Direct Deposit.pdf"},
        )
        inherited = [
            assignment
            for assignment in assignments
            if assignment.page_index == 1
        ]
        self.assertTrue(all(item.rotation == 180 for item in inherited))

    def test_ambiguous_file_does_not_inherit_assignments(self):
        assignments = PacketSorterApp.inherit_added_file_assignments(
            [
                Assignment(0, "Job Application.pdf"),
                Assignment(0, "Interview Statement.pdf"),
            ],
            blank_pages=set(),
            source_page_ranges=[(0, 2)],
            rotations=[0, 0],
        )

        self.assertEqual(documents_for_page(assignments, 1), set())

    def test_blank_continuation_page_is_not_inherited(self):
        assignments = PacketSorterApp.inherit_added_file_assignments(
            [Assignment(0, "Non-Disclosure Agreement.pdf")],
            blank_pages={1},
            source_page_ranges=[(0, 2)],
            rotations=[0, 0],
        )

        self.assertEqual(documents_for_page(assignments, 1), set())


class CorrectionMemoryTests(unittest.TestCase):
    def setUp(self):
        self.app = PacketSorterApp.__new__(PacketSorterApp)
        self.text = (
            "employee confidential information agreement owner recipient "
            "business purpose disclosure covenant consent materials records "
            "signature effective date obligations remedies provisions notice"
        )

    def remember(self, document: str):
        self.app.correction_memory = [
            {
                "document": document,
                "signature": self.app.correction_signature(self.text),
            }
        ]

    def test_remembered_assignment_replaces_classifier_result(self):
        self.remember("Non-Disclosure Agreement.pdf")

        assignments, applied = self.app.apply_correction_memory(
            [self.text],
            [Assignment(0, "Job Application.pdf")],
            rotations=[0],
            blank_pages=set(),
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Non-Disclosure Agreement.pdf"},
        )
        self.assertEqual(applied, {0})

    def test_remembered_banking_assignment_adds_both_outputs(self):
        self.remember("Banking.pdf")

        assignments, applied = self.app.apply_correction_memory(
            [self.text],
            [],
            rotations=[180],
            blank_pages=set(),
        )

        self.assertEqual(
            documents_for_page(assignments, 0),
            {"Banking.pdf", "Viventium Direct Deposit.pdf"},
        )
        self.assertEqual(applied, {0})
        self.assertTrue(all(item.rotation == 180 for item in assignments))

    def test_correction_memory_does_not_apply_to_blank_pages(self):
        self.remember("Non-Disclosure Agreement.pdf")

        assignments, applied = self.app.apply_correction_memory(
            [self.text],
            [],
            rotations=[0],
            blank_pages={0},
        )

        self.assertEqual(assignments, [])
        self.assertEqual(applied, set())


if __name__ == "__main__":
    unittest.main()
