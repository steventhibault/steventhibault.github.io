@echo off
setlocal
set "APP_DIR=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%APP_DIR%install.ps1"
if errorlevel 1 (
  echo.
  echo Installation did not finish successfully. Press any key to close.
  pause >nul
)
exit /b %errorlevel%
