$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Iss = Join-Path $Root "installer\PacketFlow.iss"
$Candidates = @(
    "$env:ProgramFiles(x86)\Inno Setup 6\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
)
$Iscc = $Candidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $Iscc) {
    Write-Host "Inno Setup 6 was not found." -ForegroundColor Yellow
    Write-Host "Install it, then rerun Build PacketFlow Setup.cmd." -ForegroundColor Yellow
    Write-Host "The source and double-click PacketFlow Setup.cmd installer remain usable without this optional EXE build step."
    exit 2
}
if (-not (Test-Path -LiteralPath (Join-Path $Root "runtime\python\python.exe"))) {
    Write-Host "Note: runtime\python\python.exe is not staged." -ForegroundColor Yellow
    Write-Host "The EXE will be a bootstrap installer: it can install missing dependencies through the PacketFlow launcher."
    Write-Host "Stage an isolated runtime under runtime\ before building when you want a fully bundled offline installer."
}
& $Iscc $Iss
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Write-Host "Built installer under Output\." -ForegroundColor Green
