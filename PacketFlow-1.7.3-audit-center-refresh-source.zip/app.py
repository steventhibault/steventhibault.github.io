from __future__ import annotations

import collections
import csv
import copy
import ctypes
import difflib
import glob
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import platform
import zipfile
import tempfile
import textwrap
import threading
import time
import traceback
from datetime import datetime, timedelta
from importlib import metadata as importlib_metadata
import winreg
import webbrowser
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
import tkinter as tk
import tkinter.font as tkfont
from tkinter import filedialog, messagebox, simpledialog, ttk

from PIL import (
    Image,
    ImageDraw,
    ImageFilter,
    ImageFont,
    ImageOps,
    ImageSequence,
    ImageStat,
    ImageTk,
)
from pypdf import PdfReader, PdfWriter

from packet_ledger import PacketLedger


APP_TITLE = "PacketFlow"
APP_VERSION = "1.7.3-audit-center-refresh"
APP_DIR = Path(__file__).resolve().parent

# User-writable data directory – falls back to APP_DIR when %APPDATA% is unavailable
# (e.g. portable/USB installs). Mutable user state, including editable rules,
# lives in AppData so installing an update does not overwrite local customization.
_APPDATA_ROOT = os.environ.get("APPDATA", "")
APP_DATA_DIR: Path = (
    Path(_APPDATA_ROOT) / "PacketFlow"
    if _APPDATA_ROOT
    else APP_DIR
)
try:
    APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    APP_DATA_DIR = APP_DIR

DEFAULT_RULES_PATH = APP_DIR / "rules.json"
RULES_PATH = APP_DATA_DIR / "rules.json"
CORRECTION_MEMORY_PATH = APP_DATA_DIR / "correction_memory.json"
SETTINGS_PATH = APP_DATA_DIR / "settings.json"
ERROR_LOG_PATH = APP_DATA_DIR / "PacketFlow Error Log.txt"
EMAIL_FILING_AUDIT_PATH = APP_DATA_DIR / "Email Filing Audit Log.txt"
PACKET_LEDGER_PATH = APP_DATA_DIR / "PacketFlow Ledger.sqlite3"
APP_ICON_PATH = APP_DIR / "packetflow.ico"
APP_ICON_PNG_PATH = APP_DIR / "packetflow-icon.png"
APP_USER_MODEL_ID = "PacketFlow.DocumentProcessor"


def ensure_user_rules_file() -> Path:
    """Create the editable AppData rules file without overwriting user customizations.

    Older PacketFlow builds kept rules.json beside the program files.  Deployment
    releases keep mutable rules in AppData so installing an update replaces code
    without replacing document rules or workflow templates.
    """
    try:
        APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
        if not RULES_PATH.exists():
            if DEFAULT_RULES_PATH.exists():
                shutil.copy2(DEFAULT_RULES_PATH, RULES_PATH)
            else:
                RULES_PATH.write_text(
                    json.dumps({"schema_version": 3, "active_profile": "Onboarding", "profiles": {}}, indent=2),
                    encoding="utf-8",
                )
    except Exception:
        # Portable/developer fallback. The normal Windows deployment always has
        # a writable AppData directory, but do not block startup in unusual cases.
        return DEFAULT_RULES_PATH
    return RULES_PATH


ACTIVE_RULES_PATH = ensure_user_rules_file()

# Visual theme
COLOR_BG = "#f4f6f9"
COLOR_SURFACE = "#ffffff"
COLOR_ACCENT = "#1d4ed8"
COLOR_ACCENT_HOVER = "#1e40af"
COLOR_TEXT = "#111827"
COLOR_MUTED = "#6b7280"
COLOR_PREVIEW_BG = "#e5e7eb"
COLOR_SORTED = "#166534"
COLOR_UNSORTED = "#b45309"
COLOR_BLANK = "#9ca3af"
COLOR_READING = "#2563eb"

OCR_WORKERS = min(8, max(2, os.cpu_count() or 4))
TESSERACT_BASE_ARGS = ["--oem", "1", "-c", "preserve_interword_spaces=1"]
IMAGE_INPUT_EXTENSIONS = {
    ".png",
    ".jpg",
    ".jpeg",
    ".jfif",
    ".bmp",
    ".tif",
    ".tiff",
    ".gif",
    ".webp",
}
TEXT_INPUT_EXTENSIONS = {".txt", ".log", ".csv", ".md"}
WORD_INPUT_EXTENSIONS = {".doc", ".docx", ".rtf", ".odt", ".html", ".htm"}
SPREADSHEET_INPUT_EXTENSIONS = {".xls", ".xlsx", ".xlsm", ".ods"}
PRESENTATION_INPUT_EXTENSIONS = {".ppt", ".pptx", ".odp"}
SUPPORTED_INPUT_EXTENSIONS = (
    {".pdf"}
    | IMAGE_INPUT_EXTENSIONS
    | TEXT_INPUT_EXTENSIONS
    | WORD_INPUT_EXTENSIONS
    | SPREADSHEET_INPUT_EXTENSIONS
    | PRESENTATION_INPUT_EXTENSIONS
)


from core.packet_analyzer import Assignment, PacketAnalyzer
from core.learning import CorrectionMemoryMixin
from core.confidence import ConfidenceMixin
from audit.workflow import AuditWorkflowMixin
from ui.management_windows import ManagementWindowsMixin
from integrations.email_workflow import EmailWorkflowMixin
from integrations.document_conversion import DocumentConversionMixin, OfficeConverterUnavailable

from core.utils import safe_filename, safe_folder_name

def configure_windows_app_identity():
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
            APP_USER_MODEL_ID
        )
    except Exception:
        pass


def acquire_single_instance() -> bool:
    global INSTANCE_MUTEX_HANDLE
    kernel32 = ctypes.windll.kernel32
    kernel32.CreateMutexW.restype = ctypes.c_void_p
    kernel32.CreateMutexW.argtypes = [
        ctypes.c_void_p,
        ctypes.c_int,
        ctypes.c_wchar_p,
    ]
    handle = kernel32.CreateMutexW(None, False, INSTANCE_MUTEX_NAME)
    if not handle:
        return True
    INSTANCE_MUTEX_HANDLE = handle
    return kernel32.GetLastError() != 183


def report_fatal_error(exc: BaseException):
    details = (
        f"{APP_TITLE} could not start.\n\n"
        f"{''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))}"
    )
    try:
        ERROR_LOG_PATH.write_text(details, encoding="utf-8")
    except Exception:
        pass
    try:
        messagebox.showerror(
            APP_TITLE,
            "PacketFlow could not start.\n\n"
            f"{exc}\n\n"
            f"Details were saved to:\n{ERROR_LOG_PATH}",
        )
    except Exception:
        pass




try:
    import customtkinter as ctk
except ImportError as exc:
    raise SystemExit("Missing required package: customtkinter. Run Start PacketFlow.cmd so it can install dependencies.") from exc

try:
    import windnd
except ImportError:
    windnd = None

try:
    import pystray
except ImportError:
    pystray = None


DEFAULT_SETTINGS = {
    "watch_enabled": False,
    "watch_folder": "",
    "start_with_windows": False,
    "start_minimized_to_tray": False,
    "show_notifications": True,
    "open_window_when_scanner_file_detected": True,
    "automatically_export_scanner_packets": False,
    "apply_remembered_corrections": True,
    "apply_remembered_pdf_order": True,
    "remember_last_export_location": True,
    "last_export_location": "",
    "show_duplicate_warnings": True,
    "show_low_confidence_warnings": True,
    "scan_quality_checks_enabled": True,
    "scan_quality_sensitivity": "standard",
    "organization_name": "",
    "header_title": "Intake Processor",
    "branding_logo": "packetflow-logo.png",
    "outlook_email_filing_enabled": False,
    "outlook_automatic_check_enabled": True,
    "outlook_check_interval_minutes": 2,
    "outlook_connection_method": "auto",
    "outlook_local_profile_name": "",
    "outlook_employee_folder_root": "",
    "outlook_needs_review_folder": "",
    "outlook_approved_senders": "",
    "outlook_required_keywords": "clearance, background check",
    "outlook_save_pdf_attachments": True,
    "outlook_graph_client_id": "",
    "outlook_tenant_id": "organizations",
    "outlook_mail_folder": "Inbox",
    "outlook_processed_folder": "PacketFlow Processed",
    "last_audit_directory": "",
    "audit_scope_mode": "all",
    "audit_recent_days": 90,
    "audit_custom_start_date": "",
    "audit_custom_end_date": "",
    "audit_remember_scope": False,
}

STARTUP_VALUE_NAME = "PacketFlow"
OLD_STARTUP_VALUE_NAMES = ()
STARTUP_REGISTRY_PATH = r"Software\Microsoft\Windows\CurrentVersion\Run"
INSTANCE_MUTEX_NAME = "Local\\PacketFlowDocumentProcessor"
INSTANCE_MUTEX_HANDLE = None

# Product palette
NAVY = "#071B3A"
HEADER_BG = "#C2F1F9"
CARD_NAVY = "#112C6B"
PRODUCT_BLUE = "#1E88E5"
BRIGHT_BLUE = "#4DA3FF"
SUCCESS_GREEN = "#63C393"
APP_BG = "#F3F5F7"
CARD_BG = "#FFFFFF"
BORDER = "#DDE5EE"
TEXT = "#0F172A"
MUTED = "#64748B"
WARNING = "#8A2020"
DANGER = "#DC2626"
BLANK = "#94A3B8"


class PacketSorterApp(DocumentConversionMixin, EmailWorkflowMixin, ManagementWindowsMixin, AuditWorkflowMixin, CorrectionMemoryMixin, ConfidenceMixin):
    def __init__(self, root: ctk.CTk):
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")
        self.root = root
        self.root.title(APP_TITLE)
        self.window_icon = None
        self.apply_window_icon()
        self.root.after(250, self.apply_window_icon)
        self.root.after(1000, self.apply_window_icon)
        self.root.geometry("1440x900")
        self.root.minsize(1180, 760)
        self.root.configure(fg_color=APP_BG)
        # Open maximized/full-screen-window style on Windows so the PDF preview
        # has as much room as possible without hiding the taskbar.
        try:
            self.root.state("zoomed")
        except Exception:
            try:
                self.root.attributes("-zoomed", True)
            except Exception:
                pass

        self.rules = self.load_rules()
        self.analyzer = PacketAnalyzer(self.rules)
        self.pdf_path: Path | None = None
        self.reader: PdfReader | None = None
        self.packet_source_paths: list[Path] = []
        self.packet_display_name: str | None = None
        self.packet_base_stem: str | None = None
        self.manual_packet_dir: Path | None = None
        self.retired_manual_dirs: list[Path] = []
        self.pending_append_state: dict | None = None
        self.work_dir: Path | None = None
        self.additional_work_dirs: list[Path] = []
        self.page_images: list[Path] = []
        self.ocr_texts: list[str] = []
        self.page_rotations: list[int] = []
        self.page_manual_rotations: list[int] = []
        self.blank_pages: set[int] = set()
        self.page_fingerprints: list[int] = []
        self.assignments: list[Assignment] = []
        self.document_order: list[str] = []
        self.duplicate_pairs: list[tuple[int, int]] = []
        self.low_confidence_pages: set[int] = set()
        self.page_quality_warnings: dict[int, list[str]] = {}
        self.memory_applied_pages: set[int] = set()
        self.preferred_document_order: list[str] = []
        self.correction_memory = self.load_correction_memory()
        self.settings = self.load_settings()
        self.ledger = self.initialize_packet_ledger()
        self.export_packet_name: str | None = None
        saved_export_location = self.settings.get("last_export_location", "")
        self.export_parent_folder: Path | None = (
            Path(saved_export_location)
            if saved_export_location and Path(saved_export_location).is_dir()
            else None
        )
        self.packet_exported = True
        self.current_packet_from_watch = False
        self.exiting = False
        self.tray_icon = None
        self.undo_stack: collections.deque[dict] = collections.deque(maxlen=20)
        self.custom_document_types: set[str] = set()
        self.watch_folder: Path | None = None
        configured_watch_folder = self.settings.get("watch_folder")
        if configured_watch_folder:
            self.watch_folder = Path(configured_watch_folder)
        self.watch_enabled = bool(
            self.settings.get("watch_enabled")
            and self.watch_folder
            and self.watch_folder.is_dir()
        )
        self.watch_known_files: set[Path] = set()
        self.watch_candidates: dict[Path, tuple[int, float, int]] = {}
        self.watch_queue: list[Path] = []
        self.preview_photo = None
        self.preview_image_refs: list[ImageTk.PhotoImage] = []
        self.preview_page_offsets: list[int] = []
        # LRU cache for rendered page thumbnails.  48 entries covers a
        # 24-page packet viewed at two zoom levels before eviction begins.
        # Using an OrderedDict lets us do O(1) move-to-end on cache hit and
        # O(1) popitem(last=False) eviction, with no extra dependencies.
        self.preview_cache: collections.OrderedDict[
            tuple[int, int, int], ImageTk.PhotoImage
        ] = collections.OrderedDict()
        self._preview_cache_max = 48
        self.preview_cache_size = (0, 0)
        self.analyzing = False
        self.directory_audit_running = False
        self.outlook_check_running = False
        self.outlook_auto_check_after_id = None
        self.outlook_last_check_text = "Not checked yet this session"
        self.outlook_next_check_text = "Not scheduled"
        self.worker_queue: queue.Queue = queue.Queue()
        self.selected_pages: set[int] = set()
        self.selected_document: str | None = None
        self.preview_page_position = 0
        self.preview_nav_var = tk.StringVar(value="")
        self.page_status_widgets: dict[int, dict[str, object]] = {}
        self.output_row_widgets: dict[str, object] = {}
        self.dragging_document: str | None = None

        self.status_var = tk.StringVar(value="Open a PDF packet to begin.")
        self.summary_var = tk.StringVar(value="No packet loaded")
        self.packet_filename_var = tk.StringVar(value="Original PDF: No packet selected")
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_label_var = tk.StringVar(value="0%")
        self.packet_stats_var = tk.StringVar(value="Open a packet to begin")
        self.document_var = tk.StringVar()
        self.action_title_var = tk.StringVar(
            value=f"Assign Selected Pages · {self.active_profile_name}"
        )

        self.build_ui()
        self.bind_shortcuts()
        self.bind_file_drop()
        self.initialize_tray()
        self.initialize_watch_folder()
        self.update_startup_registration()
        self.root.after(80, self.poll_worker_queue)
        self.root.after(1500, self.poll_watch_folder)
        self.schedule_outlook_auto_check(initial=True)
        self.root.after(800, self.update_review_queue_badge)
        if self.setting_enabled("start_minimized_to_tray") and self.watch_enabled:
            self.root.after(250, self.minimize_to_tray)

    def apply_window_icon(self):
        if APP_ICON_PATH.exists():
            try:
                self.root.wm_iconbitmap(str(APP_ICON_PATH))
                self.root.wm_iconbitmap(default=str(APP_ICON_PATH))
            except Exception:
                pass
        if APP_ICON_PNG_PATH.exists():
            try:
                self.window_icon = tk.PhotoImage(file=str(APP_ICON_PNG_PATH))
                self.root.iconphoto(True, self.window_icon)
            except Exception:
                self.window_icon = None

    def load_rules(self) -> dict:
        with ACTIVE_RULES_PATH.open("r", encoding="utf-8") as handle:
            stored = json.load(handle)
        if isinstance(stored.get("profiles"), dict) and stored["profiles"]:
            self.rule_profiles = {
                str(name): self.normalize_rule_profile(profile)
                for name, profile in stored["profiles"].items()
                if str(name).strip() and isinstance(profile, dict)
            }
            requested = str(stored.get("active_profile", "")).strip()
            self.active_profile_name = (
                requested
                if requested in self.rule_profiles
                else next(iter(self.rule_profiles))
            )
        else:
            self.active_profile_name = "Onboarding"
            self.rule_profiles = {
                self.active_profile_name: self.normalize_rule_profile(stored)
            }
        return self.rule_profiles[self.active_profile_name]

    @staticmethod
    def normalize_rule_profile(profile: dict) -> dict:
        document_types = [str(item) for item in profile.get("document_types", []) if str(item).strip()]
        expected_documents = [str(item) for item in profile.get("expected_document_types", []) if str(item).strip()]
        raw_templates = profile.get("workflow_templates", {})
        workflow_templates: dict[str, dict] = {}
        if isinstance(raw_templates, dict):
            for raw_name, raw_template in raw_templates.items():
                name = str(raw_name).strip()
                if not name or not isinstance(raw_template, dict):
                    continue
                raw_documents = raw_template.get("documents", {})
                documents: dict[str, dict[str, str]] = {}
                if isinstance(raw_documents, dict):
                    for document in document_types:
                        raw_entry = raw_documents.get(document, {})
                        if isinstance(raw_entry, str):
                            raw_entry = {"status": raw_entry}
                        if not isinstance(raw_entry, dict):
                            raw_entry = {}
                        status = str(raw_entry.get("status", "optional")).strip().lower()
                        if status not in {"required", "optional", "conditional", "expected_later"}:
                            status = "optional"
                        documents[document] = {
                            "status": status,
                            "note": str(raw_entry.get("note", "")).strip()[:500],
                        }
                else:
                    documents = {}
                for document in document_types:
                    documents.setdefault(
                        document,
                        {
                            "status": "required" if document in expected_documents else "optional",
                            "note": "",
                        },
                    )
                workflow_templates[name] = {
                    "description": str(raw_template.get("description", "")).strip()[:500],
                    "documents": documents,
                }
        if not workflow_templates:
            standard_template = {
                "description": "Default checklist migrated from the existing profile.",
                "documents": {
                    document: {
                        "status": "required" if document in expected_documents else "optional",
                        "note": "",
                    }
                    for document in document_types
                },
            }
            workflow_templates["Standard Onboarding"] = standard_template
            for starter_name in (
                "PCA Onboarding",
                "PSS Onboarding",
                "CNA Onboarding",
                "Office Employee",
                "Rehire",
                "Contractor",
                "Annual Renewal",
            ):
                starter = copy.deepcopy(standard_template)
                starter["description"] = (
                    "Starter checklist copied from Standard Onboarding. "
                    "Review and customize requirements before using this template."
                )
                workflow_templates[starter_name] = starter
        requested_default = str(profile.get("default_workflow_template", "")).strip()
        default_template = requested_default if requested_default in workflow_templates else next(iter(workflow_templates))
        return {
            "document_types": document_types,
            "expected_document_types": expected_documents,
            "custom_rules": list(profile.get("custom_rules", [])),
            "workflow_templates": workflow_templates,
            "default_workflow_template": default_template,
        }

    def active_workflow_template_name(self) -> str:
        templates = self.rules.get("workflow_templates", {})
        requested = str(self.rules.get("default_workflow_template", "")).strip()
        return requested if requested in templates else (next(iter(templates)) if templates else "Standard Onboarding")

    def write_packet_metadata(
        self,
        destination: Path,
        workflow_template: str = "",
        waived_documents: dict[str, str] | None = None,
    ) -> None:
        """Write metadata only. Never include OCR text or sensitive document contents."""
        template_name = workflow_template or self.active_workflow_template_name()
        metadata = {
            "schema_version": 1,
            "profile": self.active_profile_name,
            "workflow_template": template_name,
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "waived_documents": {},
        }
        sidecar = Path(destination) / ".packetflow.json"
        existing = {}
        if sidecar.exists():
            try:
                loaded = json.loads(sidecar.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    existing = loaded
            except Exception:
                existing = {}
        if waived_documents is not None:
            metadata["waived_documents"] = {
                str(document): str(reason).strip()[:500]
                for document, reason in waived_documents.items()
                if str(document).strip() and str(reason).strip()
            }
        elif isinstance(existing.get("waived_documents"), dict):
            metadata["waived_documents"] = existing["waived_documents"]
        sidecar.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
        self.ledger_call(
            "set_employee_packet_template",
            destination,
            employee=Path(destination).name,
            profile=self.active_profile_name,
            workflow_template=template_name,
        )

    def save_rules(self) -> bool:
        try:
            documents = [str(item) for item in self.rules.setdefault("document_types", []) if str(item).strip()]
            expected = set(str(item) for item in self.rules.setdefault("expected_document_types", []) if str(item).strip())
            templates = self.rules.setdefault("workflow_templates", {})
            if not isinstance(templates, dict) or not templates:
                templates = {
                    "Standard Onboarding": {
                        "description": "Default checklist migrated from the existing profile.",
                        "documents": {},
                    }
                }
                self.rules["workflow_templates"] = templates
            for template in templates.values():
                if not isinstance(template, dict):
                    continue
                template_documents = template.setdefault("documents", {})
                if not isinstance(template_documents, dict):
                    template_documents = {}
                    template["documents"] = template_documents
                for document in documents:
                    template_documents.setdefault(
                        document,
                        {"status": "required" if document in expected else "optional", "note": ""},
                    )
            if self.rules.get("default_workflow_template") not in templates:
                self.rules["default_workflow_template"] = next(iter(templates))
            self.rule_profiles[self.active_profile_name] = self.rules
            ACTIVE_RULES_PATH.write_text(
                json.dumps(
                    {
                        "schema_version": 3,
                        "active_profile": self.active_profile_name,
                        "profiles": self.rule_profiles,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
            self.analyzer.rules = self.rules
            self.refresh_document_choices()
            return True
        except Exception as exc:
            messagebox.showerror(
                APP_TITLE,
                "The document rules could not be saved.\n\n" + str(exc),
            )
            return False

    def switch_rule_profile(self, profile_name: str) -> bool:
        if profile_name not in self.rule_profiles:
            return False
        if hasattr(self, "correction_memory_profiles"):
            self.correction_memory_profiles[self.active_profile_name] = {
                "corrections": self.correction_memory,
                "output_order": self.preferred_document_order,
            }
        self.rule_profiles[self.active_profile_name] = self.rules
        self.active_profile_name = profile_name
        self.rules = self.rule_profiles[profile_name]
        self.analyzer.rules = self.rules
        if hasattr(self, "correction_memory_profiles"):
            memory = self.correction_memory_profiles.get(profile_name, {})
            self.correction_memory = list(memory.get("corrections", []))
            self.preferred_document_order = [
                safe_filename(str(document))
                for document in memory.get("output_order", [])
                if str(document).strip()
            ]
        self.custom_document_types.clear()
        if hasattr(self, "action_title_var"):
            self.action_title_var.set(
                f"Assign Selected Pages · {self.active_profile_name}"
            )
        self.refresh_document_choices()
        if self.pdf_path:
            self.status_var.set(
                f"Profile changed to {profile_name}. Reanalyzing the loaded packet..."
            )
            self.root.after(100, self.start_analysis)
        else:
            self.status_var.set(f"Active profile: {profile_name}")
        rules_saved = self.save_rules()
        memory_saved = (
            self.save_correction_memory()
            if hasattr(self, "correction_memory_profiles")
            else True
        )
        return rules_saved and memory_saved

    def load_settings(self) -> dict:
        settings = dict(DEFAULT_SETTINGS)
        if not SETTINGS_PATH.exists():
            return settings
        try:
            data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                settings.update(data)
            return settings
        except Exception:
            return settings

    def setting_enabled(self, name: str) -> bool:
        return bool(self.settings.get(name, DEFAULT_SETTINGS.get(name, False)))

    def save_settings(self) -> bool:
        try:
            self.settings["watch_enabled"] = self.watch_enabled
            self.settings["watch_folder"] = (
                str(self.watch_folder) if self.watch_folder else ""
            )
            if (
                self.setting_enabled("remember_last_export_location")
                and self.export_parent_folder
            ):
                self.settings["last_export_location"] = str(
                    self.export_parent_folder
                )
            SETTINGS_PATH.write_text(
                json.dumps(self.settings, indent=2),
                encoding="utf-8",
            )
            return True
        except Exception as exc:
            messagebox.showerror(
                APP_TITLE,
                "The program settings could not be saved.\n\n" + str(exc),
            )
            return False

    def initialize_packet_ledger(self) -> PacketLedger | None:
        try:
            return PacketLedger(PACKET_LEDGER_PATH)
        except Exception as exc:
            try:
                with ERROR_LOG_PATH.open("a", encoding="utf-8") as log:
                    log.write(
                        f"\n{time.strftime('%Y-%m-%d %H:%M:%S')} | "
                        f"Packet ledger unavailable: {exc}\n"
                    )
            except OSError:
                pass
            return None

    def ledger_call(self, method_name: str, *args, **kwargs):
        """Call the optional local ledger without interrupting document work."""
        ledger = getattr(self, "ledger", None)
        if not ledger:
            return None
        try:
            method = getattr(ledger, method_name)
            return method(*args, **kwargs)
        except Exception as exc:
            try:
                with ERROR_LOG_PATH.open("a", encoding="utf-8") as log:
                    log.write(
                        f"\n{time.strftime('%Y-%m-%d %H:%M:%S')} | "
                        f"Packet ledger {method_name} failed: {exc}\n"
                    )
            except OSError:
                pass
            return None

    def update_review_queue_badge(self):
        """Show unresolved-item count on the single Audit Center toolbar button."""
        button = getattr(self, "audit_center_button", None)
        if button is None:
            return
        count = self.ledger_call("count_open_review_items") or 0
        label = "Audit" if not count else f"Audit ({count})"
        try:
            button.configure(
                text=label,
                text_color=(WARNING if count else TEXT),
            )
        except Exception:
            pass

    def startup_command(self) -> str:
        launcher = APP_DIR / "launcher.ps1"
        return (
            'powershell.exe -NoProfile -WindowStyle Hidden '
            f'-ExecutionPolicy Bypass -File "{launcher}"'
        )

    def update_startup_registration(self) -> bool:
        try:
            with winreg.CreateKey(
                winreg.HKEY_CURRENT_USER,
                STARTUP_REGISTRY_PATH,
            ) as key:
                for old_name in OLD_STARTUP_VALUE_NAMES:
                    try:
                        winreg.DeleteValue(key, old_name)
                    except FileNotFoundError:
                        pass
                if self.setting_enabled("start_with_windows"):
                    winreg.SetValueEx(
                        key,
                        STARTUP_VALUE_NAME,
                        0,
                        winreg.REG_SZ,
                        self.startup_command(),
                    )
                else:
                    try:
                        winreg.DeleteValue(key, STARTUP_VALUE_NAME)
                    except FileNotFoundError:
                        pass
            return True
        except Exception as exc:
            messagebox.showerror(
                APP_TITLE,
                "The Windows startup setting could not be changed.\n\n"
                + str(exc),
            )
            return False

    def initialize_tray(self):
        if pystray is None or not APP_ICON_PNG_PATH.exists():
            return
        try:
            image = Image.open(APP_ICON_PNG_PATH).convert("RGBA")
            menu = pystray.Menu(
                pystray.MenuItem(
                    "Open Processor",
                    lambda _icon, _item: self.root.after(0, self.show_window),
                    default=True,
                ),
                pystray.MenuItem(
                    "Scanner Folder",
                    lambda _icon, _item: self.root.after(
                        0, self.choose_scanner_folder
                    ),
                ),
                pystray.MenuItem(
                    "Open Scanner Folder",
                    lambda _icon, _item: self.root.after(
                        0, self.open_watch_folder
                    ),
                ),
                pystray.MenuItem(
                    "Preferences",
                    lambda _icon, _item: self.root.after(
                        0, self.show_preferences
                    ),
                ),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem(
                    "Exit",
                    lambda _icon, _item: self.root.after(
                        0, self.exit_application
                    ),
                ),
            )
            self.tray_icon = pystray.Icon(
                "packetflow",
                image,
                APP_TITLE,
                menu,
            )
            self.tray_icon.run_detached()
        except Exception:
            self.tray_icon = None

    def show_window(self):
        self.root.deiconify()
        try:
            self.root.state("zoomed")
        except Exception:
            pass
        self.root.lift()
        self.root.focus_force()

    def minimize_to_tray(self):
        if self.tray_icon is None:
            self.root.iconify()
            return
        self.root.withdraw()

    def notify_user(self, title: str, message: str):
        if not self.setting_enabled("show_notifications"):
            return
        if self.tray_icon is not None:
            try:
                self.tray_icon.notify(message, title)
                return
            except Exception:
                pass
        try:
            self.root.bell()
        except Exception:
            pass

    def open_watch_folder(self):
        if not self.watch_folder or not self.watch_folder.is_dir():
            messagebox.showinfo(
                APP_TITLE,
                "No scanner folder is currently configured.",
            )
            return
        try:
            os.startfile(self.watch_folder)
        except Exception as exc:
            messagebox.showerror(
                APP_TITLE,
                "The scanner folder could not be opened.\n\n" + str(exc),
            )

    def exit_application(self):
        self.exiting = True
        self.save_settings()
        self.cleanup_work_files()
        if self.tray_icon is not None:
            try:
                self.tray_icon.stop()
            except Exception:
                pass
        self.root.destroy()

    def show_preferences(self):
        window = ctk.CTkToplevel(self.root)
        window.title("Settings")
        window.geometry("980x700")
        window.minsize(900, 620)
        window.transient(self.root)
        window.grab_set()

        header = ctk.CTkFrame(window, fg_color="transparent")
        header.pack(fill="x", padx=22, pady=(18, 8))
        ctk.CTkLabel(
            header,
            text="⚙ Settings",
            text_color=CARD_NAVY,
            font=("Segoe UI", 22, "bold"),
        ).pack(anchor="w")
        ctk.CTkLabel(
            header,
            text="Settings are grouped by workflow so scanner intake, email filing, rules, learning, and branding are easier to manage.",
            text_color=MUTED,
            font=("Segoe UI", 11),
            wraplength=900,
            justify="left",
        ).pack(anchor="w", pady=(2, 0))

        body = ctk.CTkFrame(window, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=20, pady=(0, 12))
        body.grid_columnconfigure(1, weight=1)
        body.grid_rowconfigure(0, weight=1)

        nav = ctk.CTkFrame(
            body,
            width=210,
            fg_color="#FFFFFF",
            border_width=1,
            border_color=BORDER,
            corner_radius=8,
        )
        nav.grid(row=0, column=0, sticky="nsw", padx=(0, 12))
        nav.grid_propagate(False)

        content_shell = ctk.CTkFrame(
            body,
            fg_color="#FFFFFF",
            border_width=1,
            border_color=BORDER,
            corner_radius=8,
        )
        content_shell.grid(row=0, column=1, sticky="nsew")
        content_shell.grid_rowconfigure(1, weight=1)
        content_shell.grid_columnconfigure(0, weight=1)

        section_title_var = tk.StringVar(value="General")
        section_help_var = tk.StringVar(value="Basic startup, notifications, and export behavior.")

        # Keep the Settings page heading in its own fixed header frame.
        # The previous version placed the title and help labels in the same
        # grid cell with different sticky/padding values. On some Windows
        # scaling/font combinations, that caused clipped black text fragments
        # to appear above every Settings category.
        section_header = ctk.CTkFrame(content_shell, fg_color="transparent")
        section_header.grid(row=0, column=0, sticky="ew", padx=18, pady=(16, 8))
        section_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            section_header,
            textvariable=section_title_var,
            text_color=CARD_NAVY,
            font=("Segoe UI", 18, "bold"),
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(
            section_header,
            textvariable=section_help_var,
            text_color=MUTED,
            font=("Segoe UI", 10),
            wraplength=650,
            justify="left",
        ).grid(row=1, column=0, sticky="w", pady=(2, 0))

        content_area = ctk.CTkScrollableFrame(
            content_shell,
            fg_color="transparent",
        )
        content_area.grid(row=1, column=0, sticky="nsew", padx=12, pady=(0, 12))

        scanner_path_var = tk.StringVar(
            value=str(self.watch_folder) if self.watch_folder else "No folder selected"
        )
        pause_watch_var = tk.BooleanVar(value=not self.watch_enabled)

        option_specs = {
            "start_with_windows": (
                "Start with Windows",
                "Launch PacketFlow when this Windows user signs in.",
            ),
            "start_minimized_to_tray": (
                "Start minimized to tray",
                "Begin in the system tray when scanner watching is enabled.",
            ),
            "show_notifications": (
                "Show notifications",
                "Display a Windows tray notification after analysis finishes.",
            ),
            "open_window_when_scanner_file_detected": (
                "Open and maximize for new scans",
                "Bring PacketFlow forward when a new scanner PDF is loaded.",
            ),
            "automatically_export_scanner_packets": (
                "Automatically start export for new scans",
                "After scanner analysis, go directly to the save-location dialog.",
            ),
            "apply_remembered_corrections": (
                "Apply remembered page corrections",
                "Reuse approved assignments for matching forms.",
            ),
            "apply_remembered_pdf_order": (
                "Apply remembered PDF order",
                "Use the saved output order on future packets.",
            ),
            "remember_last_export_location": (
                "Remember last export location",
                "Start the folder browser at the most recently used location.",
            ),
            "show_duplicate_warnings": (
                "Show duplicate-page warnings",
                "Include suspected duplicate scans in the review summary.",
            ),
            "show_low_confidence_warnings": (
                "Show low-confidence warnings",
                "Include faint or weakly recognized pages in the review summary.",
            ),
            "scan_quality_checks_enabled": (
                "Check scan quality during processing",
                "Flag obvious blur, darkness, overexposure, low resolution, severe skew, and edge clipping before export. This does not inspect signatures or dates.",
            ),
        }
        variables: dict[str, tk.BooleanVar] = {
            name: tk.BooleanVar(value=self.setting_enabled(name))
            for name in option_specs
        }

        scan_quality_sensitivity_var = tk.StringVar(
            value=(
                "Strict"
                if str(self.settings.get("scan_quality_sensitivity", "standard")).lower() == "strict"
                else "Standard"
            )
        )

        email_enabled_var = tk.BooleanVar(
            value=self.setting_enabled("outlook_email_filing_enabled")
        )
        email_automatic_var = tk.BooleanVar(
            value=self.setting_enabled("outlook_automatic_check_enabled")
        )
        try:
            saved_email_interval = int(
                self.settings.get("outlook_check_interval_minutes", 2) or 2
            )
        except (TypeError, ValueError):
            saved_email_interval = 2
        email_interval_var = tk.StringVar(
            value=f"{saved_email_interval} minutes"
        )
        connection_method_var = tk.StringVar(
            value={
                "local": "Local Outlook Profile",
                "entra": "Microsoft 365 / New Outlook",
                "auto": "Auto Detect",
            }.get(str(self.settings.get("outlook_connection_method", "auto")), "Auto Detect")
        )
        email_root_var = tk.StringVar(
            value=self.settings.get("outlook_employee_folder_root", "") or "No folder selected"
        )
        email_review_var = tk.StringVar(
            value=self.settings.get("outlook_needs_review_folder", "") or "Use employee root folder"
        )
        email_mail_folder_var = tk.StringVar(
            value=self.settings.get("outlook_mail_folder", "Inbox")
        )
        email_processed_folder_var = tk.StringVar(
            value=self.settings.get("outlook_processed_folder", "PacketFlow Processed")
        )
        email_local_profile_var = tk.StringVar(
            value=self.settings.get("outlook_local_profile_name", "")
        )
        email_client_id_var = tk.StringVar(
            value=self.settings.get("outlook_graph_client_id", "")
        )
        email_tenant_id_var = tk.StringVar(
            value=self.settings.get("outlook_tenant_id", "organizations")
        )
        email_approved_box: ctk.CTkTextbox | None = None
        email_keywords_box: ctk.CTkTextbox | None = None
        email_text_values = {
            "approved": self.settings.get("outlook_approved_senders", ""),
            "keywords": self.settings.get("outlook_required_keywords", ""),
        }

        selected_section = tk.StringVar(value="General")
        nav_buttons: dict[str, ctk.CTkButton] = {}

        def clear_content():
            nonlocal email_approved_box, email_keywords_box
            if (
                email_approved_box is not None
                and email_approved_box.winfo_exists()
            ):
                email_text_values["approved"] = email_approved_box.get(
                    "1.0",
                    "end",
                ).strip()
            if (
                email_keywords_box is not None
                and email_keywords_box.winfo_exists()
            ):
                email_text_values["keywords"] = email_keywords_box.get(
                    "1.0",
                    "end",
                ).strip()
            for child in content_area.winfo_children():
                child.destroy()
            email_approved_box = None
            email_keywords_box = None

        def card(parent, title: str | None = None, help_text: str | None = None):
            frame = ctk.CTkFrame(
                parent,
                fg_color="#F8FAFC",
                border_width=1,
                border_color="#E2E8F0",
                corner_radius=8,
            )
            frame.pack(fill="x", padx=4, pady=7)
            if title:
                ctk.CTkLabel(
                    frame,
                    text=title,
                    text_color=TEXT,
                    font=("Segoe UI", 13, "bold"),
                ).pack(anchor="w", padx=12, pady=(10, 1))
            if help_text:
                ctk.CTkLabel(
                    frame,
                    text=help_text,
                    text_color=MUTED,
                    font=("Segoe UI", 10),
                    wraplength=650,
                    justify="left",
                ).pack(anchor="w", padx=12, pady=(0, 8))
            return frame

        def add_switch(parent, setting_name: str):
            label, description = option_specs[setting_name]
            row = ctk.CTkFrame(parent, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=5)
            row.grid_columnconfigure(0, weight=1)
            ctk.CTkSwitch(
                row,
                text=label,
                variable=variables[setting_name],
                text_color=TEXT,
                font=("Segoe UI", 12, "bold"),
                progress_color=SUCCESS_GREEN,
                button_color=PRODUCT_BLUE,
            ).grid(row=0, column=0, sticky="w")
            ctk.CTkLabel(
                row,
                text=description,
                text_color=MUTED,
                font=("Segoe UI", 10),
                wraplength=620,
                justify="left",
                anchor="w",
            ).grid(row=1, column=0, sticky="w", padx=(28, 0), pady=(1, 0))

        def add_action_button(parent, text: str, command, accent: str = PRODUCT_BLUE):
            return ctk.CTkButton(
                parent,
                text=text,
                command=command,
                fg_color="#FFFFFF",
                hover_color="#EEF6FF",
                border_color=accent,
                border_width=1,
                text_color=accent,
                corner_radius=5,
                height=32,
                font=("Segoe UI", 11, "bold"),
            )

        def browse_folder(variable: tk.StringVar, title: str, setting_name: str | None = None):
            selected = filedialog.askdirectory(
                title=title,
                initialdir=str(Path.home()),
                mustexist=True,
                parent=window,
            )
            if not selected:
                return
            variable.set(selected)
            if setting_name == "watch_folder":
                pause_watch_var.set(False)

        def labeled_entry(parent, label: str, variable: tk.StringVar, help_text: str = ""):
            ctk.CTkLabel(
                parent,
                text=label,
                text_color=TEXT,
                font=("Segoe UI", 12, "bold"),
            ).pack(anchor="w", padx=12, pady=(9, 2))
            ctk.CTkEntry(parent, textvariable=variable).pack(fill="x", padx=12, pady=(0, 3))
            if help_text:
                ctk.CTkLabel(
                    parent,
                    text=help_text,
                    text_color=MUTED,
                    font=("Segoe UI", 10),
                    wraplength=650,
                    justify="left",
                ).pack(anchor="w", padx=12, pady=(0, 4))

        def render_general():
            clear_content()
            section_title_var.set("General")
            section_help_var.set("Basic startup, notifications, and export behavior.")
            general_card = card(content_area, "Startup and notifications")
            for name in (
                "start_with_windows",
                "start_minimized_to_tray",
                "show_notifications",
                "remember_last_export_location",
            ):
                add_switch(general_card, name)
            ctk.CTkLabel(
                content_area,
                text=(
                    "Always enabled: blank-page removal, privacy cleanup, audit log, "
                    "existing-file protection, orientation checks, and waiting for scanner files to finish."
                ),
                text_color="#7A5418",
                fg_color="#FFF8E8",
                corner_radius=6,
                font=("Segoe UI", 10),
                wraplength=680,
                justify="left",
            ).pack(fill="x", padx=4, pady=(8, 10), ipady=8)

        def render_document_processing():
            clear_content()
            section_title_var.set("Document Processing")
            section_help_var.set("OCR behavior, profiles, document rules, and review warnings.")
            profile_card = card(
                content_area,
                "Profiles and rules",
                f"Active profile: {self.active_profile_name}. Use profiles for onboarding, HR, accounting, operations, or client-specific workflows.",
            )
            button_row = ctk.CTkFrame(profile_card, fg_color="transparent")
            button_row.pack(fill="x", padx=12, pady=(0, 12))
            button_row.grid_columnconfigure((0, 1), weight=1)
            add_action_button(button_row, "Manage Document Rules", self.show_rule_manager).grid(
                row=0, column=0, sticky="ew", padx=(0, 6)
            )
            add_action_button(button_row, "Manage Profiles", self.show_rule_manager).grid(
                row=0, column=1, sticky="ew", padx=(6, 0)
            )
            warning_card = card(content_area, "Review warnings")
            for name in ("show_duplicate_warnings", "show_low_confidence_warnings"):
                add_switch(warning_card, name)
            quality_card = card(
                content_area,
                "Scan-quality pre-flight checks",
                "Runs during the normal OCR pass. Standard is recommended. Signature and date validation are not included in this release, and parent or guardian fields are never required.",
            )
            add_switch(quality_card, "scan_quality_checks_enabled")
            sensitivity_row = ctk.CTkFrame(quality_card, fg_color="transparent")
            sensitivity_row.pack(fill="x", padx=12, pady=(0, 12))
            ctk.CTkLabel(
                sensitivity_row,
                text="Sensitivity",
                text_color=TEXT,
                font=("Segoe UI", 11, "bold"),
            ).pack(side="left", padx=(28, 10))
            ctk.CTkOptionMenu(
                sensitivity_row,
                variable=scan_quality_sensitivity_var,
                values=["Standard", "Strict"],
                width=145,
                fg_color=PRODUCT_BLUE,
                button_color=PRODUCT_BLUE,
                button_hover_color=SUCCESS_GREEN,
            ).pack(side="left")

        def render_email_filing():
            nonlocal email_approved_box, email_keywords_box
            clear_content()
            section_title_var.set("Email Filing")
            section_help_var.set("Outlook/Gmail-via-Outlook intake, employee folder routing, keywords, and review handling.")
            main_card = card(
                content_area,
                "Email intake",
                "Use Local Outlook Profile for Classic Outlook. Microsoft 365 / New Outlook fields are hidden unless that method is selected.",
            )
            ctk.CTkSwitch(
                main_card,
                text="Enable email filing",
                variable=email_enabled_var,
                text_color=TEXT,
                font=("Segoe UI", 12, "bold"),
                progress_color=SUCCESS_GREEN,
                button_color=PRODUCT_BLUE,
            ).pack(anchor="w", padx=12, pady=(4, 8))
            ctk.CTkSwitch(
                main_card,
                text="Check Outlook automatically",
                variable=email_automatic_var,
                text_color=TEXT,
                font=("Segoe UI", 12, "bold"),
                progress_color=SUCCESS_GREEN,
                button_color=PRODUCT_BLUE,
            ).pack(anchor="w", padx=12, pady=(0, 4))
            ctk.CTkOptionMenu(
                main_card,
                values=["2 minutes", "5 minutes", "10 minutes", "15 minutes"],
                variable=email_interval_var,
                width=135,
                height=28,
                fg_color="#FFFFFF",
                button_color=PRODUCT_BLUE,
                button_hover_color=SUCCESS_GREEN,
                text_color=TEXT,
            ).pack(anchor="w", padx=40, pady=(0, 4))
            ctk.CTkLabel(
                main_card,
                text=(
                    "Automatic checks inspect the newest 10 messages. "
                    "Check Outlook Now inspects the newest 100."
                ),
                text_color=MUTED,
                font=("Segoe UI", 10),
                wraplength=620,
                justify="left",
            ).pack(anchor="w", padx=40, pady=(0, 8))
            ctk.CTkLabel(
                main_card,
                text=(
                    f"Last check: {self.outlook_last_check_text}\n"
                    f"Next automatic check: {self.outlook_next_check_text}"
                ),
                text_color=MUTED,
                font=("Segoe UI", 10),
                wraplength=620,
                justify="left",
            ).pack(anchor="w", padx=40, pady=(0, 8))
            ctk.CTkLabel(
                main_card,
                text="Connection method",
                text_color=TEXT,
                font=("Segoe UI", 12, "bold"),
            ).pack(anchor="w", padx=12, pady=(2, 3))
            connection_selector = ctk.CTkSegmentedButton(
                main_card,
                values=["Auto Detect", "Local Outlook Profile", "Microsoft 365 / New Outlook"],
                variable=connection_method_var,
                selected_color=PRODUCT_BLUE,
                selected_hover_color=PRODUCT_BLUE,
                unselected_color="#FFFFFF",
                unselected_hover_color="#EEF6FF",
                text_color=TEXT,
            )
            connection_selector.pack(fill="x", padx=12, pady=(0, 8))
            connection_selector.configure(
                command=lambda _value: render_email_filing()
            )

            folder_card = card(content_area, "Folders")
            folder_card.grid_columnconfigure(0, weight=1)
            row1 = ctk.CTkFrame(folder_card, fg_color="transparent")
            row1.pack(fill="x", padx=12, pady=(4, 8))
            row1.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(row1, text="Employee folder root", text_color=TEXT, font=("Segoe UI", 12, "bold")).grid(row=0, column=0, sticky="w")
            ctk.CTkLabel(row1, textvariable=email_root_var, text_color=MUTED, font=("Segoe UI", 10), wraplength=520, justify="left").grid(row=1, column=0, sticky="w")
            ctk.CTkButton(row1, text="Browse", command=lambda: browse_folder(email_root_var, "Choose the employee folder root", "outlook_employee_folder_root"), width=84, height=28, fg_color="#FFFFFF", hover_color="#EEF6FF", border_width=1, border_color="#CBD5E1", text_color=TEXT).grid(row=0, column=1, rowspan=2, padx=(10, 0))

            row2 = ctk.CTkFrame(folder_card, fg_color="transparent")
            row2.pack(fill="x", padx=12, pady=(4, 10))
            row2.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(row2, text="Needs Review folder", text_color=TEXT, font=("Segoe UI", 12, "bold")).grid(row=0, column=0, sticky="w")
            ctk.CTkLabel(row2, textvariable=email_review_var, text_color=MUTED, font=("Segoe UI", 10), wraplength=520, justify="left").grid(row=1, column=0, sticky="w")
            ctk.CTkButton(row2, text="Browse", command=lambda: browse_folder(email_review_var, "Choose the Needs Review folder", "outlook_needs_review_folder"), width=84, height=28, fg_color="#FFFFFF", hover_color="#EEF6FF", border_width=1, border_color="#CBD5E1", text_color=TEXT).grid(row=0, column=1, rowspan=2, padx=(10, 0))

            monitor_card = card(content_area, "Mailbox and matching")
            labeled_entry(monitor_card, "Outlook folder to monitor", email_mail_folder_var, "Example: Inbox, Background Checks, or another Outlook folder name.")
            labeled_entry(monitor_card, "Move completed emails to", email_processed_folder_var)
            ctk.CTkLabel(monitor_card, text="Approved senders", text_color=TEXT, font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=12, pady=(9, 2))
            email_approved_box = ctk.CTkTextbox(monitor_card, height=58)
            email_approved_box.pack(fill="x", padx=12, pady=(0, 3))
            email_approved_box.insert("1.0", email_text_values["approved"])
            ctk.CTkLabel(monitor_card, text="Leave blank to allow any sender. Separate senders or domains with commas or new lines.", text_color=MUTED, font=("Segoe UI", 10), wraplength=650, justify="left").pack(anchor="w", padx=12, pady=(0, 4))
            ctk.CTkLabel(monitor_card, text="Required email keywords", text_color=TEXT, font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=12, pady=(9, 2))
            email_keywords_box = ctk.CTkTextbox(monitor_card, height=58)
            email_keywords_box.pack(fill="x", padx=12, pady=(0, 8))
            email_keywords_box.insert("1.0", email_text_values["keywords"])

            advanced_card = card(content_area, "Advanced connection fields")
            selected_method = connection_method_var.get()
            if selected_method in {"Auto Detect", "Local Outlook Profile"}:
                labeled_entry(
                    advanced_card,
                    "Local Outlook profile name",
                    email_local_profile_var,
                    "Usually leave blank. PacketFlow will use the current/default Classic Outlook profile.",
                )
            if selected_method in {"Auto Detect", "Microsoft 365 / New Outlook"}:
                labeled_entry(
                    advanced_card,
                    "Microsoft application ID",
                    email_client_id_var,
                    "Only needed for Microsoft 365 / New Outlook cloud mode.",
                )
                labeled_entry(
                    advanced_card,
                    "Microsoft directory / tenant ID",
                    email_tenant_id_var,
                    "Usually 'organizations'.",
                )

            action_row = ctk.CTkFrame(content_area, fg_color="transparent")
            action_row.pack(fill="x", padx=4, pady=(4, 12))
            action_row.grid_columnconfigure(0, weight=1)
            add_action_button(
                action_row,
                "Check Outlook Now",
                lambda: check_outlook_from_preferences(),
            ).grid(row=0, column=0, sticky="ew")

        def render_scanner_watch():
            clear_content()
            section_title_var.set("Scanner Watch Folder")
            section_help_var.set("Automatic intake from the folder where your scanner saves PDFs.")
            scanner_card = card(content_area, "Scanner source folder")
            scanner_card.grid_columnconfigure(0, weight=1)
            row = ctk.CTkFrame(scanner_card, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=(4, 10))
            row.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(row, text="Scanner folder", text_color=TEXT, font=("Segoe UI", 12, "bold")).grid(row=0, column=0, sticky="w")
            ctk.CTkLabel(row, textvariable=scanner_path_var, text_color=MUTED, font=("Segoe UI", 10), wraplength=520, justify="left").grid(row=1, column=0, sticky="w")
            ctk.CTkButton(row, text="Browse", command=lambda: browse_folder(scanner_path_var, "Choose the scanner's PDF destination folder", "watch_folder"), width=84, height=28, fg_color="#FFFFFF", hover_color="#EEF6FF", border_width=1, border_color="#CBD5E1", text_color=TEXT).grid(row=0, column=1, rowspan=2, padx=(10, 0))

            pause_card = card(content_area, "Folder monitoring")
            ctk.CTkSwitch(
                pause_card,
                text="Pause scanner folder watching",
                variable=pause_watch_var,
                text_color=TEXT,
                font=("Segoe UI", 12, "bold"),
                progress_color="#C78B22",
                button_color=PRODUCT_BLUE,
            ).pack(anchor="w", padx=12, pady=(6, 2))
            ctk.CTkLabel(
                pause_card,
                text="Turn this on to stop automatic scanner intake without changing the selected folder.",
                text_color=MUTED,
                font=("Segoe UI", 10),
                wraplength=650,
                justify="left",
            ).pack(anchor="w", padx=40, pady=(0, 8))
            for name in (
                "open_window_when_scanner_file_detected",
                "automatically_export_scanner_packets",
            ):
                add_switch(pause_card, name)

        def render_learning():
            clear_content()
            section_title_var.set("Learning & Automation")
            section_help_var.set("Remembered corrections, learned output order, and memory tools.")
            learning_card = card(content_area, "Remembered behavior")
            for name in ("apply_remembered_corrections", "apply_remembered_pdf_order"):
                add_switch(learning_card, name)
            manage_card = card(content_area, "Manage learning memory", "Review, export, or clear remembered corrections and preferred output order.")
            add_action_button(manage_card, "Manage Remembered Settings", self.show_memory_manager, "#7A5418").pack(fill="x", padx=12, pady=(0, 12))

        def render_branding():
            clear_content()
            section_title_var.set("Branding")
            section_help_var.set("Organization name, header title, logo, and visual customization.")
            branding_card = card(content_area, "Branding tools")
            add_action_button(branding_card, "Customize Branding", self.show_branding_manager).pack(fill="x", padx=12, pady=(4, 12))
            ctk.CTkLabel(
                branding_card,
                text="Current header title: " + str(
                    self.settings.get(
                        "header_title",
                        "Intake Processor",
                    )
                ),
                text_color=MUTED,
                font=("Segoe UI", 10),
                wraplength=650,
                justify="left",
            ).pack(anchor="w", padx=12, pady=(0, 10))

        def open_diagnostic_path(path: Path):
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                if not path.exists():
                    path.write_text("", encoding="utf-8")
                if os.name == "nt":
                    os.startfile(str(path))
                else:
                    webbrowser.open(path.as_uri())
            except Exception as exc:
                messagebox.showerror(APP_TITLE, f"Could not open:\n{path}\n\n{exc}", parent=window)

        def render_advanced():
            clear_content()
            section_title_var.set("Advanced")
            section_help_var.set("Diagnostics, logs, dependency checks, and support tools.")
            advanced_card = card(content_area, "Diagnostics")
            ctk.CTkLabel(
                advanced_card,
                text=f"PacketFlow version: {APP_VERSION}\nRules file: {ACTIVE_RULES_PATH}\nSettings file: {SETTINGS_PATH}\nError log: {ERROR_LOG_PATH}\nEmail audit log: {EMAIL_FILING_AUDIT_PATH}\nLocal packet ledger: {PACKET_LEDGER_PATH}",
                text_color=MUTED,
                font=("Segoe UI", 10),
                wraplength=650,
                justify="left",
            ).pack(anchor="w", padx=12, pady=(4, 10))
            action_row = ctk.CTkFrame(advanced_card, fg_color="transparent")
            action_row.pack(fill="x", padx=12, pady=(0, 12))
            action_row.grid_columnconfigure((0, 1, 2), weight=1)
            add_action_button(action_row, "Open Error Log", lambda: open_diagnostic_path(ERROR_LOG_PATH)).grid(row=0, column=0, sticky="ew", padx=(0, 6))
            add_action_button(action_row, "Open Email Audit Log", lambda: open_diagnostic_path(EMAIL_FILING_AUDIT_PATH)).grid(row=0, column=1, sticky="ew", padx=6)
            add_action_button(action_row, "Open Audit Center", self.show_audit_center).grid(row=0, column=2, sticky="ew", padx=(6, 0))
            add_action_button(advanced_card, "Open Packet History", self.show_packet_history).pack(fill="x", padx=12, pady=(0, 8))
            add_action_button(advanced_card, "Export Redacted Diagnostics ZIP", self.export_diagnostics_zip).pack(fill="x", padx=12, pady=(0, 12))

        renderers = {
            "General": render_general,
            "Document Processing": render_document_processing,
            "Email Filing": render_email_filing,
            "Scanner Watch Folder": render_scanner_watch,
            "Learning & Automation": render_learning,
            "Branding": render_branding,
            "Advanced": render_advanced,
        }
        section_help = {
            "General": "Basic startup, notifications, and export behavior.",
            "Document Processing": "OCR behavior, profiles, document rules, and review warnings.",
            "Email Filing": "Outlook/Gmail-via-Outlook intake, employee folder routing, keywords, and review handling.",
            "Scanner Watch Folder": "Automatic intake from the folder where your scanner saves PDFs.",
            "Learning & Automation": "Remembered corrections, learned output order, and memory tools.",
            "Branding": "Organization name, header title, logo, and visual customization.",
            "Advanced": "Diagnostics, logs, dependency checks, and support tools.",
        }

        def select_section(name: str):
            selected_section.set(name)
            for section_name, button in nav_buttons.items():
                if section_name == name:
                    button.configure(fg_color=PRODUCT_BLUE, text_color="#FFFFFF", hover_color=PRODUCT_BLUE)
                else:
                    button.configure(fg_color="transparent", text_color=TEXT, hover_color="#EEF6FF")
            section_help_var.set(section_help.get(name, ""))
            renderers[name]()

        nav_title = ctk.CTkLabel(
            nav,
            text="Settings",
            text_color=CARD_NAVY,
            font=("Segoe UI", 14, "bold"),
        )
        nav_title.pack(anchor="w", padx=14, pady=(14, 6))
        for section_name in renderers:
            button = ctk.CTkButton(
                nav,
                text=section_name,
                command=lambda value=section_name: select_section(value),
                anchor="w",
                height=34,
                corner_radius=6,
                fg_color="transparent",
                hover_color="#EEF6FF",
                text_color=TEXT,
                font=("Segoe UI", 11, "bold"),
            )
            button.pack(fill="x", padx=10, pady=2)
            nav_buttons[section_name] = button

        def store_email_preferences() -> bool:
            if email_enabled_var.get() and not str(email_root_var.get()).strip().lower().startswith("no folder"):
                self.settings["outlook_employee_folder_root"] = str(email_root_var.get()).strip()
            if email_enabled_var.get() and not str(self.settings.get("outlook_employee_folder_root", "")).strip():
                messagebox.showwarning(
                    "Email Filing",
                    "Choose the employee folder root before enabling email filing.",
                    parent=window,
                )
                select_section("Email Filing")
                return False
            self.settings["outlook_email_filing_enabled"] = bool(email_enabled_var.get())
            self.settings["outlook_automatic_check_enabled"] = bool(
                email_automatic_var.get()
            )
            try:
                interval_minutes = int(email_interval_var.get().split()[0])
            except (TypeError, ValueError, IndexError):
                interval_minutes = 2
            self.settings["outlook_check_interval_minutes"] = max(
                2,
                min(15, interval_minutes),
            )
            self.settings["outlook_connection_method"] = {
                "Local Outlook Profile": "local",
                "Microsoft 365 / New Outlook": "entra",
                "Auto Detect": "auto",
            }.get(connection_method_var.get(), "auto")
            self.settings["outlook_mail_folder"] = str(email_mail_folder_var.get()).strip() or "Inbox"
            self.settings["outlook_processed_folder"] = str(email_processed_folder_var.get()).strip() or "PacketFlow Processed"
            self.settings["outlook_local_profile_name"] = str(email_local_profile_var.get()).strip()
            self.settings["outlook_graph_client_id"] = str(email_client_id_var.get()).strip()
            self.settings["outlook_tenant_id"] = str(email_tenant_id_var.get()).strip() or "organizations"
            if email_approved_box is not None and email_approved_box.winfo_exists():
                email_text_values["approved"] = email_approved_box.get(
                    "1.0",
                    "end",
                ).strip()
            if email_keywords_box is not None and email_keywords_box.winfo_exists():
                email_text_values["keywords"] = email_keywords_box.get(
                    "1.0",
                    "end",
                ).strip()
            self.settings["outlook_approved_senders"] = email_text_values[
                "approved"
            ]
            self.settings["outlook_required_keywords"] = email_text_values[
                "keywords"
            ]
            current_review = str(email_review_var.get()).strip()
            if current_review and current_review != "Use employee root folder":
                self.settings["outlook_needs_review_folder"] = current_review
            return True

        def check_outlook_from_preferences():
            if not store_email_preferences():
                return
            self.save_settings()
            self.check_outlook_now(parent=window)

        def save_preferences():
            if not store_email_preferences():
                return
            requested_watch = not pause_watch_var.get()
            scanner_path_text = str(scanner_path_var.get()).strip()
            selected_watch_folder = (
                Path(scanner_path_text)
                if scanner_path_text
                and scanner_path_text != "No folder selected"
                else None
            )
            if requested_watch and selected_watch_folder is None:
                selected = filedialog.askdirectory(
                    title="Choose the scanner's PDF destination folder",
                    initialdir=str(
                        self.pdf_path.parent if self.pdf_path else Path.home()
                    ),
                    mustexist=True,
                    parent=window,
                )
                if not selected:
                    select_section("Scanner Watch Folder")
                    return
                selected_watch_folder = Path(selected)
                scanner_path_var.set(str(selected_watch_folder))
            self.watch_folder = selected_watch_folder
            for name, variable in variables.items():
                self.settings[name] = bool(variable.get())
            self.settings["scan_quality_sensitivity"] = scan_quality_sensitivity_var.get().strip().lower()
            self.settings["watch_enabled"] = requested_watch
            self.settings["watch_folder"] = str(self.watch_folder) if self.watch_folder else ""
            self.watch_enabled = bool(
                requested_watch
                and self.watch_folder
                and self.watch_folder.is_dir()
            )
            if not self.watch_enabled:
                self.watch_candidates.clear()
                self.watch_queue.clear()
            if not self.setting_enabled("remember_last_export_location"):
                self.settings["last_export_location"] = ""
                self.export_parent_folder = None
            self.initialize_watch_folder()
            if not self.update_startup_registration():
                return
            if self.save_settings():
                self.update_watch_button()
                self.schedule_outlook_auto_check(initial=True)
                window.destroy()
                self.status_var.set("Settings saved.")

        select_section("General")

        button_row = ctk.CTkFrame(window, fg_color="transparent")
        button_row.pack(fill="x", padx=20, pady=(0, 16))
        ctk.CTkButton(
            button_row,
            text="Cancel",
            command=window.destroy,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
            width=120,
        ).pack(side="right")
        ctk.CTkButton(
            button_row,
            text="Save Settings",
            command=save_preferences,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
            width=160,
        ).pack(side="right", padx=(0, 8))

    def show_branding_manager(self):
        window = ctk.CTkToplevel(self.root)
        window.title("Customize Branding")
        window.geometry("590x390")
        window.transient(self.root)
        window.grab_set()

        ctk.CTkLabel(
            window,
            text="Customize Branding",
            text_color=CARD_NAVY,
            font=("Segoe UI", 20, "bold"),
        ).pack(anchor="w", padx=22, pady=(18, 4))
        ctk.CTkLabel(
            window,
            text="These settings affect this computer only.",
            text_color=MUTED,
            font=("Segoe UI", 11),
        ).pack(anchor="w", padx=22, pady=(0, 14))

        organization_var = tk.StringVar(
            value=self.settings.get("organization_name", "")
        )
        title_var = tk.StringVar(
            value=self.settings.get(
                "header_title",
                "Intake Processor",
            )
        )
        selected_logo = {
            "path": None,
            "reset": False,
        }
        logo_name_var = tk.StringVar(
            value=self.settings.get("branding_logo", "packetflow-logo.png")
        )

        form = ctk.CTkFrame(window, fg_color="#FFFFFF")
        form.pack(fill="both", expand=True, padx=20, pady=(0, 12))
        ctk.CTkLabel(
            form,
            text="Organization name",
            text_color=TEXT,
            font=("Segoe UI", 11, "bold"),
        ).pack(anchor="w", padx=12, pady=(12, 4))
        ctk.CTkEntry(form, textvariable=organization_var).pack(
            fill="x",
            padx=12,
        )
        ctk.CTkLabel(
            form,
            text="Header title",
            text_color=TEXT,
            font=("Segoe UI", 11, "bold"),
        ).pack(anchor="w", padx=12, pady=(12, 4))
        ctk.CTkEntry(form, textvariable=title_var).pack(fill="x", padx=12)
        ctk.CTkLabel(
            form,
            text="Header logo",
            text_color=TEXT,
            font=("Segoe UI", 11, "bold"),
        ).pack(anchor="w", padx=12, pady=(12, 4))
        logo_row = ctk.CTkFrame(form, fg_color="transparent")
        logo_row.pack(fill="x", padx=12, pady=(0, 12))
        ctk.CTkLabel(
            logo_row,
            textvariable=logo_name_var,
            text_color=MUTED,
            anchor="w",
        ).pack(side="left", fill="x", expand=True)

        def choose_logo():
            chosen = filedialog.askopenfilename(
                title="Choose a header logo",
                filetypes=[
                    ("Image files", "*.png;*.jpg;*.jpeg;*.webp"),
                    ("All files", "*.*"),
                ],
                parent=window,
            )
            if not chosen:
                return
            selected_logo["path"] = Path(chosen)
            selected_logo["reset"] = False
            logo_name_var.set(Path(chosen).name)

        def reset_logo():
            selected_logo["path"] = None
            selected_logo["reset"] = True
            logo_name_var.set("packetflow-logo.png")

        ctk.CTkButton(
            logo_row,
            text="Choose Logo",
            command=choose_logo,
            width=100,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
        ).pack(side="left", padx=(8, 5))
        ctk.CTkButton(
            logo_row,
            text="Use Default",
            command=reset_logo,
            width=96,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
        ).pack(side="left")

        def save_branding():
            logo_name = self.settings.get(
                "branding_logo",
                "packetflow-logo.png",
            )
            if selected_logo["reset"]:
                logo_name = "packetflow-logo.png"
            elif selected_logo["path"]:
                source = selected_logo["path"]
                suffix = source.suffix.lower()
                if suffix not in (".png", ".jpg", ".jpeg", ".webp"):
                    messagebox.showwarning(
                        APP_TITLE,
                        "Choose a PNG, JPG, JPEG, or WebP logo.",
                        parent=window,
                    )
                    return
                logo_name = "customer-logo" + suffix
                try:
                    shutil.copy2(source, APP_DIR / logo_name)
                except Exception as exc:
                    messagebox.showerror(
                        APP_TITLE,
                        "The logo could not be saved.\n\n" + str(exc),
                        parent=window,
                    )
                    return
            self.settings["organization_name"] = organization_var.get().strip()
            self.settings["header_title"] = (
                title_var.get().strip() or "Intake Processor"
            )
            self.settings["branding_logo"] = logo_name
            if self.save_settings():
                self.apply_branding()
                window.destroy()
                self.status_var.set("Branding updated.")

        buttons = ctk.CTkFrame(window, fg_color="transparent")
        buttons.pack(fill="x", padx=20, pady=(0, 16))
        ctk.CTkButton(
            buttons,
            text="Cancel",
            command=window.destroy,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
            width=110,
        ).pack(side="right")
        ctk.CTkButton(
            buttons,
            text="Save Branding",
            command=save_branding,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
            width=140,
        ).pack(side="right", padx=(0, 8))

    def apply_branding(self):
        if hasattr(self, "header_title_label"):
            self.header_title_label.configure(
                text=self.settings.get(
                    "header_title",
                    "Intake Processor",
                )
            )
        organization = self.settings.get("organization_name", "").strip()
        if hasattr(self, "header_subtitle_label"):
            self.header_subtitle_label.configure(
                text=organization
                or "OCR + document classification + review before export"
            )
        if hasattr(self, "logo_label"):
            logo_path = APP_DIR / self.settings.get(
                "branding_logo",
                "packetflow-logo.png",
            )
            try:
                image = Image.open(logo_path)
                target_w = min(260, image.width)
                target_h = max(1, int(target_w * image.height / image.width))
                if target_h > 56:
                    target_h = 56
                    target_w = max(
                        1,
                        int(target_h * image.width / image.height),
                    )
                self.logo_img = ctk.CTkImage(
                    light_image=image,
                    dark_image=image,
                    size=(target_w, target_h),
                )
                self.logo_label.configure(text="", image=self.logo_img)
            except Exception:
                self.logo_label.configure(
                    text="PacketFlow",
                    image=None,
                )

    @staticmethod
    def suggested_rule_keywords(text: str) -> list[str]:
        title_terms = {
            "acknowledgment",
            "agreement",
            "application",
            "authorization",
            "certificate",
            "consent",
            "disclosure",
            "eligibility",
            "enrollment",
            "notice",
            "payroll",
            "policy",
            "statement",
            "verification",
            "waiver",
        }
        generic_phrases = {
            "employee signature",
            "employer signature",
            "please print",
            "print name",
            "signature date",
            "today date",
        }
        candidates = []
        seen = set()
        for position, raw_line in enumerate(text.splitlines()[:80]):
            line = re.sub(r"\s+", " ", raw_line.strip().lower())
            if not 8 <= len(line) <= 100:
                continue
            if len(re.findall(r"[a-z]{3,}", line)) < 2:
                continue
            if any(phrase in line for phrase in generic_phrases):
                continue
            if re.search(r"\b\d{3}[-.\s]\d{2}[-.\s]\d{4}\b", line):
                continue
            if re.search(r"\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b", line):
                continue
            if re.search(r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\b", line):
                continue
            if sum(character.isdigit() for character in line) > 3:
                continue
            if "_" in line or line.count(".") > 4:
                continue
            if line in seen:
                continue
            seen.add(line)
            words = set(re.findall(r"[a-z]{3,}", line))
            score = max(0, 30 - position)
            score += 25 * len(words & title_terms)
            score += 10 if len(line) <= 60 else 0
            score += 15 if raw_line.strip().isupper() else 0
            candidates.append((score, position, line))
        candidates.sort(key=lambda item: (-item[0], item[1]))
        return [line for _score, _position, line in candidates[:5]]

    def learn_document_rules(
        self,
        document: str,
        pages: list[int],
    ) -> tuple[int, list[str]]:
        learned = 0
        learned_phrases: list[str] = []
        rules = self.rules.setdefault("custom_rules", [])
        for page in pages:
            if page >= len(self.ocr_texts):
                continue
            suggestions = self.suggested_rule_keywords(self.ocr_texts[page])
            if not suggestions:
                continue
            keywords = suggestions[:2]
            normalized_keywords = {
                re.sub(r"\s+", " ", keyword.strip().lower())
                for keyword in keywords
            }
            duplicate = any(
                str(rule.get("document", "")).casefold()
                == document.casefold()
                and {
                    re.sub(r"\s+", " ", str(keyword).strip().lower())
                    for keyword in rule.get("keywords", [])
                }
                == normalized_keywords
                for rule in rules
            )
            if duplicate:
                continue
            rules.append(
                {
                    "document": document,
                    "expected": False,
                    "match_mode": "all",
                    "keywords": keywords,
                    "sample_filename": "Learned from reviewed packet",
                    "source": "learned",
                }
            )
            learned += 1
            learned_phrases.extend(keywords)
        return learned, list(dict.fromkeys(learned_phrases))

    def show_rule_manager(self):
        window = ctk.CTkToplevel(self.root)
        window.title("Document Rules")
        window.geometry("820x590")
        window.minsize(700, 500)
        window.transient(self.root)
        window.grab_set()

        ctk.CTkLabel(
            window,
            text="Document Rules",
            text_color=CARD_NAVY,
            font=("Segoe UI", 20, "bold"),
        ).pack(anchor="w", padx=22, pady=(18, 3))
        ctk.CTkLabel(
            window,
            text=(
                "Custom rules run before the built-in starter rules. Use distinctive "
                "phrases that are printed consistently on the form."
            ),
            text_color=MUTED,
            font=("Segoe UI", 11),
            wraplength=760,
            justify="left",
        ).pack(anchor="w", padx=22, pady=(0, 12))

        profile_row = ctk.CTkFrame(
            window,
            fg_color="#F8FAFC",
            corner_radius=6,
        )
        profile_row.pack(fill="x", padx=20, pady=(0, 10))
        ctk.CTkLabel(
            profile_row,
            text="Active profile",
            text_color=TEXT,
            font=("Segoe UI", 11, "bold"),
        ).pack(side="left", padx=(10, 8), pady=9)
        profile_var = tk.StringVar(value=self.active_profile_name)
        profile_combo = ctk.CTkComboBox(
            profile_row,
            variable=profile_var,
            values=list(self.rule_profiles),
            state="readonly",
            width=180,
        )
        profile_combo.pack(side="left", pady=8)

        rule_list = tk.Listbox(
            window,
            font=("Segoe UI", 11),
            activestyle="none",
            selectmode="browse",
        )
        rule_list.pack(fill="both", expand=True, padx=20, pady=(0, 10))

        def refresh_rules(select_index: int | None = None):
            rule_list.delete(0, tk.END)
            for rule in self.rules.get("custom_rules", []):
                expected = "Expected" if rule.get("expected") else "Optional"
                source = (
                    "Learned"
                    if rule.get("source") == "learned"
                    else "Custom"
                )
                mode = str(rule.get("match_mode", "all")).upper()
                keywords = "; ".join(rule.get("keywords", []))
                rule_list.insert(
                    tk.END,
                    f"{rule.get('document', '')}  |  {source}  |  {expected}  |  "
                    f"Match {mode}: {keywords}",
                )
            if select_index is not None and rule_list.size():
                selected = min(select_index, rule_list.size() - 1)
                rule_list.selection_set(selected)
                rule_list.see(selected)

        def selected_rule_index() -> int | None:
            selection = rule_list.curselection()
            return int(selection[0]) if selection else None

        def refresh_profiles():
            profile_combo.configure(values=list(self.rule_profiles))
            profile_var.set(self.active_profile_name)

        def profile_change_allowed() -> bool:
            if self.analyzing:
                messagebox.showwarning(
                    APP_TITLE,
                    "Wait for the current analysis to finish before changing profiles.",
                    parent=window,
                )
                return False
            if self.pdf_path:
                messagebox.showwarning(
                    APP_TITLE,
                    "Export the loaded packet before changing profiles. This keeps "
                    "one packet from being reviewed under two different workflows.",
                    parent=window,
                )
                return False
            return True

        def activate_profile(profile_name: str):
            if profile_name == self.active_profile_name:
                return
            if not profile_change_allowed():
                profile_var.set(self.active_profile_name)
                return
            if self.switch_rule_profile(profile_name):
                refresh_profiles()
                refresh_rules()

        profile_combo.configure(command=activate_profile)

        def unique_profile_name(name: str, excluding: str | None = None) -> bool:
            normalized = name.casefold()
            return not any(
                existing.casefold() == normalized and existing != excluding
                for existing in self.rule_profiles
            )

        def create_profile():
            if not profile_change_allowed():
                return
            name = simpledialog.askstring(
                APP_TITLE,
                "New profile name:",
                parent=window,
            )
            if not name:
                return
            name = re.sub(r"\s+", " ", name.strip())
            if not unique_profile_name(name):
                messagebox.showwarning(
                    APP_TITLE,
                    "A profile with that name already exists.",
                    parent=window,
                )
                return
            copy_current = messagebox.askyesno(
                APP_TITLE,
                f"Copy the current {self.active_profile_name} profile?\n\n"
                "Choose No to start with a blank profile.",
                parent=window,
            )
            self.rule_profiles[self.active_profile_name] = self.rules
            self.rule_profiles[name] = (
                copy.deepcopy(self.rules)
                if copy_current
                else {
                    "document_types": [],
                    "expected_document_types": [],
                    "custom_rules": [],
                }
            )
            self.switch_rule_profile(name)
            refresh_profiles()
            refresh_rules()

        def duplicate_profile():
            if not profile_change_allowed():
                return
            name = simpledialog.askstring(
                APP_TITLE,
                "Name for the copied profile:",
                initialvalue=f"{self.active_profile_name} Copy",
                parent=window,
            )
            if not name:
                return
            name = re.sub(r"\s+", " ", name.strip())
            if not unique_profile_name(name):
                messagebox.showwarning(
                    APP_TITLE,
                    "A profile with that name already exists.",
                    parent=window,
                )
                return
            self.rule_profiles[self.active_profile_name] = self.rules
            self.rule_profiles[name] = copy.deepcopy(self.rules)
            self.switch_rule_profile(name)
            refresh_profiles()
            refresh_rules()

        def rename_profile():
            old_name = self.active_profile_name
            name = simpledialog.askstring(
                APP_TITLE,
                "Rename profile:",
                initialvalue=old_name,
                parent=window,
            )
            if not name:
                return
            name = re.sub(r"\s+", " ", name.strip())
            if name == old_name:
                return
            if not unique_profile_name(name, excluding=old_name):
                messagebox.showwarning(
                    APP_TITLE,
                    "A profile with that name already exists.",
                    parent=window,
                )
                return
            renamed = {}
            for profile_name, profile in self.rule_profiles.items():
                renamed[name if profile_name == old_name else profile_name] = profile
            self.rule_profiles = renamed
            self.active_profile_name = name
            self.rules = self.rule_profiles[name]
            self.analyzer.rules = self.rules
            self.action_title_var.set(f"Assign Selected Pages · {name}")
            if old_name in self.correction_memory_profiles:
                self.correction_memory_profiles[name] = (
                    self.correction_memory_profiles.pop(old_name)
                )
            self.save_rules()
            self.save_correction_memory()
            refresh_profiles()
            refresh_rules()

        def delete_profile():
            if not profile_change_allowed():
                return
            if len(self.rule_profiles) <= 1:
                messagebox.showwarning(
                    APP_TITLE,
                    "PacketFlow must keep at least one profile.",
                    parent=window,
                )
                return
            deleting = self.active_profile_name
            if not messagebox.askyesno(
                APP_TITLE,
                f"Delete the {deleting} profile?\n\n"
                "Its document rules cannot be recovered unless previously exported.",
                parent=window,
            ):
                return
            del self.rule_profiles[deleting]
            self.correction_memory_profiles.pop(deleting, None)
            next_profile = next(iter(self.rule_profiles))
            self.active_profile_name = next_profile
            self.rules = self.rule_profiles[next_profile]
            self.analyzer.rules = self.rules
            self.action_title_var.set(
                f"Assign Selected Pages · {next_profile}"
            )
            memory = self.correction_memory_profiles.get(next_profile, {})
            self.correction_memory = list(memory.get("corrections", []))
            self.preferred_document_order = [
                safe_filename(str(document))
                for document in memory.get("output_order", [])
                if str(document).strip()
            ]
            self.custom_document_types.clear()
            self.save_rules()
            self.save_correction_memory()
            refresh_profiles()
            refresh_rules()

        ctk.CTkButton(
            profile_row,
            text="New",
            command=create_profile,
            width=58,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color=PRODUCT_BLUE,
            text_color=PRODUCT_BLUE,
        ).pack(side="left", padx=(8, 4), pady=8)
        ctk.CTkButton(
            profile_row,
            text="Duplicate",
            command=duplicate_profile,
            width=82,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
        ).pack(side="left", padx=4, pady=8)
        ctk.CTkButton(
            profile_row,
            text="Rename",
            command=rename_profile,
            width=72,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
        ).pack(side="left", padx=4, pady=8)
        ctk.CTkButton(
            profile_row,
            text="Delete",
            command=delete_profile,
            width=66,
            fg_color="#FFFFFF",
            hover_color="#FBEAEA",
            border_width=1,
            border_color=WARNING,
            text_color=WARNING,
        ).pack(side="left", padx=(4, 10), pady=8)

        def open_rule_editor(
            rule: dict | None = None,
            sample_path: Path | None = None,
        ):
            editor = ctk.CTkToplevel(window)
            editor.title("Document Recognition Rule")
            editor.geometry("620x520")
            editor.transient(window)
            editor.grab_set()

            existing = dict(rule or {})
            default_document = (
                safe_filename(sample_path.stem)
                if sample_path
                else ""
            )
            if default_document and not default_document.lower().endswith(".pdf"):
                default_document += ".pdf"
            document_var = tk.StringVar(
                value=existing.get("document", default_document)
            )
            mode_var = tk.StringVar(
                value=existing.get("match_mode", "all").title()
            )
            expected_var = tk.BooleanVar(
                value=bool(existing.get("expected", False))
            )

            ctk.CTkLabel(
                editor,
                text="Output PDF name",
                font=("Segoe UI", 11, "bold"),
                text_color=TEXT,
            ).pack(anchor="w", padx=20, pady=(18, 4))
            ctk.CTkEntry(
                editor,
                textvariable=document_var,
            ).pack(fill="x", padx=20)

            ctk.CTkLabel(
                editor,
                text="Identifying phrases (one per line)",
                font=("Segoe UI", 11, "bold"),
                text_color=TEXT,
            ).pack(anchor="w", padx=20, pady=(14, 4))
            keyword_box = ctk.CTkTextbox(editor, height=210)
            keyword_box.pack(fill="both", expand=True, padx=20)
            keywords = list(existing.get("keywords", []))
            if sample_path:
                try:
                    reader = PdfReader(str(sample_path))
                    sample_text = "\n".join(
                        page.extract_text() or ""
                        for page in reader.pages[:5]
                    )
                    if sample_text.strip():
                        keywords = self.suggested_rule_keywords(sample_text)
                    else:
                        messagebox.showinfo(
                            APP_TITLE,
                            "The sample appears to be image-only. Enter two or more "
                            "distinctive phrases printed on the form. PacketFlow will "
                            "use OCR when processing real packets.",
                            parent=editor,
                        )
                except Exception as exc:
                    messagebox.showwarning(
                        APP_TITLE,
                        "The sample could not be read automatically.\n\n"
                        + str(exc),
                        parent=editor,
                    )
            keyword_box.insert("1.0", "\n".join(keywords))

            options = ctk.CTkFrame(editor, fg_color="transparent")
            options.pack(fill="x", padx=20, pady=12)
            ctk.CTkLabel(
                options,
                text="Match mode",
                text_color=TEXT,
                font=("Segoe UI", 11, "bold"),
            ).pack(side="left")
            ctk.CTkComboBox(
                options,
                variable=mode_var,
                values=["All", "Any"],
                width=100,
                state="readonly",
            ).pack(side="left", padx=(8, 20))
            ctk.CTkSwitch(
                options,
                text="Expected in every packet",
                variable=expected_var,
                progress_color=SUCCESS_GREEN,
                button_color=PRODUCT_BLUE,
            ).pack(side="left")

            def save_rule():
                raw_document = document_var.get().strip()
                entered_keywords = [
                    re.sub(r"\s+", " ", line.strip().lower())
                    for line in keyword_box.get("1.0", "end").splitlines()
                    if line.strip()
                ]
                entered_keywords = list(dict.fromkeys(entered_keywords))
                if not raw_document or len(entered_keywords) < 1:
                    messagebox.showwarning(
                        APP_TITLE,
                        "Enter an output PDF name and at least one identifying phrase.",
                        parent=editor,
                    )
                    return
                document = safe_filename(raw_document)
                saved_rule = {
                    "document": document,
                    "expected": bool(expected_var.get()),
                    "match_mode": mode_var.get().lower(),
                    "keywords": entered_keywords,
                    "sample_filename": sample_path.name if sample_path else existing.get(
                        "sample_filename",
                        "",
                    ),
                }
                rules = self.rules.setdefault("custom_rules", [])
                if rule is None:
                    rules.append(saved_rule)
                    selected = len(rules) - 1
                else:
                    selected = rules.index(rule)
                    old_document = str(rule.get("document", ""))
                    rules[selected] = saved_rule
                    if (
                        old_document != document
                        and old_document in self.rules["expected_document_types"]
                    ):
                        self.rules["expected_document_types"].remove(
                            old_document
                        )
                if document not in self.rules["document_types"]:
                    self.rules["document_types"].append(document)
                expected_documents = self.rules["expected_document_types"]
                if saved_rule["expected"] and document not in expected_documents:
                    expected_documents.append(document)
                if not saved_rule["expected"] and document in expected_documents:
                    expected_documents.remove(document)
                if self.save_rules():
                    refresh_rules(selected)
                    editor.destroy()

            editor_buttons = ctk.CTkFrame(editor, fg_color="transparent")
            editor_buttons.pack(fill="x", padx=20, pady=(0, 16))
            ctk.CTkButton(
                editor_buttons,
                text="Cancel",
                command=editor.destroy,
                fg_color="#FFFFFF",
                hover_color="#F8FAFC",
                border_width=1,
                border_color="#CBD5E1",
                text_color=TEXT,
                width=100,
            ).pack(side="right")
            ctk.CTkButton(
                editor_buttons,
                text="Save Rule",
                command=save_rule,
                fg_color=PRODUCT_BLUE,
                hover_color=SUCCESS_GREEN,
                width=120,
            ).pack(side="right", padx=(0, 8))

        def add_from_pdf():
            selected = filedialog.askopenfilename(
                title="Choose a sample form PDF",
                filetypes=[("PDF files", "*.pdf")],
                parent=window,
            )
            if selected:
                open_rule_editor(sample_path=Path(selected))

        def edit_selected():
            index = selected_rule_index()
            if index is None:
                messagebox.showwarning(
                    APP_TITLE,
                    "Select a custom rule to edit.",
                    parent=window,
                )
                return
            open_rule_editor(self.rules["custom_rules"][index])

        def delete_selected():
            index = selected_rule_index()
            if index is None:
                return
            rule = self.rules["custom_rules"][index]
            if not messagebox.askyesno(
                APP_TITLE,
                f"Delete the custom rule for {rule.get('document', '')}?",
                parent=window,
            ):
                return
            document = rule.get("document", "")
            del self.rules["custom_rules"][index]
            if not any(
                item.get("document") == document
                for item in self.rules["custom_rules"]
            ):
                if document in self.rules["expected_document_types"]:
                    self.rules["expected_document_types"].remove(document)
            if self.save_rules():
                refresh_rules(index)

        def export_profile():
            destination = filedialog.asksaveasfilename(
                title=f"Export {self.active_profile_name} profile",
                defaultextension=".json",
                filetypes=[("JSON profile", "*.json")],
                parent=window,
            )
            if destination:
                try:
                    exported_by = os.environ.get("USERNAME") or os.environ.get("USER") or ""
                except Exception:
                    exported_by = ""
                Path(destination).write_text(
                    json.dumps(
                        {
                            "schema_version": 3,
                            "profile_name": self.active_profile_name,
                            # Provenance fields — help teams track which version of
                            # a profile is installed on which workstation.
                            "exported_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                            "exported_by": exported_by,
                            "profile": self.rules,
                        },
                        indent=2,
                    ),
                    encoding="utf-8",
                )

        def import_profile():
            source = filedialog.askopenfilename(
                title="Import PacketFlow rule profile",
                filetypes=[("JSON profile", "*.json")],
                parent=window,
            )
            if not source:
                return
            try:
                imported = json.loads(Path(source).read_text(encoding="utf-8"))
                if not isinstance(imported, dict):
                    raise ValueError("The profile must contain a JSON object.")
                if isinstance(imported.get("profile"), dict):
                    suggested_name = str(
                        imported.get("profile_name", Path(source).stem)
                    ).strip()
                    imported_profile = imported["profile"]
                else:
                    suggested_name = Path(source).stem
                    imported_profile = imported
                for key in (
                    "document_types",
                    "expected_document_types",
                    "custom_rules",
                ):
                    if not isinstance(imported_profile.get(key), list):
                        raise ValueError(f"The profile is missing {key}.")
            except Exception as exc:
                messagebox.showerror(
                    APP_TITLE,
                    "The rule profile is not valid.\n\n" + str(exc),
                    parent=window,
                )
                return
            profile_name = simpledialog.askstring(
                APP_TITLE,
                "Save imported profile as:",
                initialvalue=suggested_name,
                parent=window,
            )
            if not profile_name:
                return
            profile_name = re.sub(r"\s+", " ", profile_name.strip())
            if not profile_change_allowed():
                return
            existing = next(
                (
                    name
                    for name in self.rule_profiles
                    if name.casefold() == profile_name.casefold()
                ),
                None,
            )
            if existing and not messagebox.askyesno(
                APP_TITLE,
                f"Replace the existing {existing} profile?",
                parent=window,
            ):
                return
            if existing:
                profile_name = existing
            self.rule_profiles[self.active_profile_name] = self.rules
            self.rule_profiles[profile_name] = self.normalize_rule_profile(
                imported_profile
            )
            if profile_name == self.active_profile_name:
                self.rules = self.rule_profiles[profile_name]
                self.analyzer.rules = self.rules
                self.custom_document_types.clear()
                saved = self.save_rules()
            else:
                saved = self.switch_rule_profile(profile_name)
            if saved:
                refresh_profiles()
                refresh_rules()

        controls = ctk.CTkFrame(window, fg_color="transparent")
        controls.pack(fill="x", padx=20, pady=(0, 16))
        ctk.CTkButton(
            controls,
            text="Add Sample PDF",
            command=add_from_pdf,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
        ).pack(side="left")
        ctk.CTkButton(
            controls,
            text="Add Manually",
            command=open_rule_editor,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color=PRODUCT_BLUE,
            text_color=PRODUCT_BLUE,
        ).pack(side="left", padx=6)
        ctk.CTkButton(
            controls,
            text="Edit",
            command=edit_selected,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
            width=70,
        ).pack(side="left")
        ctk.CTkButton(
            controls,
            text="Delete",
            command=delete_selected,
            fg_color="#FFFFFF",
            hover_color="#FBEAEA",
            border_width=1,
            border_color=WARNING,
            text_color=WARNING,
            width=75,
        ).pack(side="left", padx=6)
        ctk.CTkButton(
            controls,
            text="Workflow Checklists",
            command=self.show_workflow_template_editor,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color=PRODUCT_BLUE,
            text_color=PRODUCT_BLUE,
        ).pack(side="left", padx=(0, 6))
        ctk.CTkButton(
            controls,
            text="Close",
            command=window.destroy,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
            width=80,
        ).pack(side="right")
        ctk.CTkButton(
            controls,
            text="Export Profile",
            command=export_profile,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color=PRODUCT_BLUE,
            text_color=PRODUCT_BLUE,
        ).pack(side="right", padx=6)
        ctk.CTkButton(
            controls,
            text="Import Profile",
            command=import_profile,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color=PRODUCT_BLUE,
            text_color=PRODUCT_BLUE,
        ).pack(side="right")

        rule_list.bind("<Double-Button-1>", lambda _event: edit_selected())
        refresh_rules()

    def bind_file_drop(self):
        if windnd is None:
            return
        try:
            windnd.hook_dropfiles(
                self.root,
                func=lambda paths: self.root.after(
                    0,
                    lambda: self.handle_dropped_files(paths),
                ),
            )
        except Exception:
            pass

    def handle_dropped_files(self, paths):
        selected_paths = []
        for raw_path in paths:
            if isinstance(raw_path, bytes):
                path = Path(raw_path.decode("utf-8", errors="replace"))
            else:
                path = Path(str(raw_path))
            if (
                path.is_file()
                and path.suffix.lower() in SUPPORTED_INPUT_EXTENSIONS
            ):
                selected_paths.append(path)
        if not selected_paths:
            messagebox.showwarning(
                APP_TITLE,
                "Drop a supported PDF, image, text, or Office file onto "
                "the application window.",
            )
            return
        if (
            not self.reader
            and len(selected_paths) == 1
            and selected_paths[0].suffix.lower() == ".pdf"
        ):
            self.load_packet(selected_paths[0])
        else:
            self.add_file_paths(selected_paths)

    def initialize_watch_folder(self):
        if not self.watch_enabled or not self.watch_folder:
            self.update_watch_button()
            return
        try:
            self.watch_known_files = {
                path.resolve()
                for path in self.watch_folder.glob("*.pdf")
                if path.is_file()
            }
        except Exception:
            self.watch_enabled = False
        self.update_watch_button()

    def update_watch_button(self):
        if not hasattr(self, "watch_button"):
            return
        if self.watch_enabled and self.watch_folder:
            self.watch_button.configure(
                text="Scanner Folder",
                border_color=SUCCESS_GREEN,
                text_color="#287A55",
            )
            self.watch_folder_label.configure(
                text=f"Watching: {self.watch_folder}",
                text_color="#287A55",
            )
        else:
            self.watch_button.configure(
                text="Scanner Folder",
                border_color="#CBD5E1",
                text_color=TEXT,
            )
            self.watch_folder_label.configure(
                text="Scanner folder is paused or not selected",
                text_color=MUTED,
            )

    def choose_scanner_folder(self):
        proceed = messagebox.askyesno(
            APP_TITLE,
            "Choose the scanner folder for new PDFs?\n\n"
            "The processor must remain open. Existing PDFs will be ignored. "
            "A new PDF will be analyzed only after the scanner finishes writing "
            "it, and it will wait if another packet still needs review.\n\n"
            "Pause or resume watching from Settings.\n\n"
            "Continue?",
        )
        if not proceed:
            return
        selected = filedialog.askdirectory(
            title="Choose the scanner's PDF destination folder",
            initialdir=str(
                self.watch_folder
                or (self.pdf_path.parent if self.pdf_path else Path.home())
            ),
            mustexist=True,
        )
        if not selected:
            return
        self.watch_folder = Path(selected)
        self.watch_enabled = True
        self.watch_candidates.clear()
        self.watch_queue.clear()
        self.watch_known_files = {
            path.resolve()
            for path in self.watch_folder.glob("*.pdf")
            if path.is_file()
        }
        self.save_settings()
        self.update_watch_button()
        self.status_var.set(f"Watching scanner folder: {self.watch_folder}")

    def poll_watch_folder(self):
        try:
            if self.watch_enabled and self.watch_folder and self.watch_folder.is_dir():
                now = time.time()
                try:
                    pdf_candidates = list(self.watch_folder.glob("*.pdf"))
                except OSError as exc:
                    # The scanner folder became unavailable (e.g. mapped network
                    # drive went offline).  Show a one-time status message and
                    # reschedule — do NOT disable watching so recovery is automatic
                    # when the drive reconnects.
                    self.status_var.set(
                        f"Scanner folder temporarily unavailable: {exc}"
                    )
                    return
                for path in pdf_candidates:
                    if not path.is_file():
                        continue
                    resolved = path.resolve()
                    if resolved in self.watch_known_files or resolved in self.watch_queue:
                        continue
                    try:
                        stat = path.stat()
                    except OSError:
                        continue
                    previous = self.watch_candidates.get(resolved)
                    if previous and previous[:2] == (stat.st_size, stat.st_mtime):
                        stable_checks = previous[2] + 1
                    else:
                        stable_checks = 0
                    self.watch_candidates[resolved] = (
                        stat.st_size,
                        stat.st_mtime,
                        stable_checks,
                    )
                    if (
                        stat.st_size > 0
                        and stable_checks >= 2
                        and now - stat.st_mtime >= 2
                    ):
                        try:
                            with path.open("rb") as handle:
                                PdfReader(handle)
                        except Exception:
                            continue
                        self.watch_known_files.add(resolved)
                        self.watch_candidates.pop(resolved, None)
                        self.watch_queue.append(resolved)
                self.process_watch_queue()
        finally:
            self.root.after(1500, self.poll_watch_folder)

    def process_watch_queue(self):
        if not self.watch_queue or self.analyzing:
            return
        next_packet = self.watch_queue.pop(0)
        if self.setting_enabled("open_window_when_scanner_file_detected"):
            self.show_window()
        self.load_packet(next_packet, from_watch=True)

    def bind_shortcuts(self):
        self.root.bind("<Control-o>", lambda _event: self.open_packet())
        self.root.bind("<Control-Shift-O>", lambda _event: self.add_files())
        self.root.bind("<Control-e>", lambda _event: self.export_pdfs())
        self.root.bind("<Control-Return>", lambda _event: self.assign_to_document())
        self.root.bind("<Control-z>", lambda _event: self.undo_last_change())

    def build_ui(self):
        """Windows-style utility layout.

        Left: compact page list. Center: large preview. Right: controls/output/status.
        This keeps the PDF preview as the main working area instead of pushing it
        down with assignment/output panels.
        """
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(1, weight=1)

        # Light product header, closer to a professional Windows installer/wizard.
        # The status and progress area is grouped directly above the action buttons
        # on the right so the entire toolbar reads as one clean, organized block.
        self.header = ctk.CTkFrame(self.root, fg_color=HEADER_BG, corner_radius=0, height=112)
        self.header.grid(row=0, column=0, sticky="ew")
        self.header.grid_propagate(False)
        self.header.grid_columnconfigure(1, weight=1)

        self.logo_frame = ctk.CTkFrame(self.header, fg_color="transparent", corner_radius=0, width=230, height=72)
        self.logo_frame.grid(row=0, column=0, padx=(14, 14), pady=6, sticky="w")
        self.logo_frame.grid_propagate(False)
        self.logo_label = ctk.CTkLabel(
            self.logo_frame,
            text="PacketFlow",
            text_color=CARD_NAVY,
            font=("Segoe UI", 15, "bold"),
        )
        logo_path = APP_DIR / self.settings.get(
            "branding_logo",
            "packetflow-logo.png",
        )
        if logo_path.exists():
            try:
                img = Image.open(logo_path)
                target_w = min(215, img.width)
                target_h = max(1, int(target_w * img.height / img.width))
                if target_h > 56:
                    target_h = 56
                    target_w = max(1, int(target_h * img.width / img.height))
                self.logo_img = ctk.CTkImage(light_image=img, dark_image=img, size=(target_w, target_h))
                self.logo_label.configure(text="", image=self.logo_img)
            except Exception:
                pass
        self.logo_label.pack(expand=True, fill="both")

        # Right-side command block: status/progress above, buttons below.
        # The progress bar is the final element in the top row so it remains at
        # the far-right edge of the progress information.
        header_actions = ctk.CTkFrame(self.header, fg_color="transparent")
        header_actions.grid(row=0, column=1, padx=(12, 18), pady=(9, 9), sticky="e")

        header_progress = ctk.CTkFrame(header_actions, fg_color="transparent")
        header_progress.pack(fill="x", pady=(0, 7))
        header_progress.grid_columnconfigure(0, weight=1)

        header_status_text = ctk.CTkFrame(header_progress, fg_color="transparent")
        header_status_text.grid(row=0, column=0, sticky="ew", padx=(0, 10))
        header_status_text.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            header_status_text,
            textvariable=self.status_var,
            text_color="#1D4E89",
            font=("Segoe UI", 11),
            wraplength=520,
            anchor="e",
            justify="right",
        ).grid(row=0, column=0, sticky="e")
        ctk.CTkLabel(
            header_status_text,
            textvariable=self.packet_stats_var,
            text_color="#1D4E89",
            font=("Segoe UI", 10),
            wraplength=520,
            anchor="e",
            justify="right",
        ).grid(row=1, column=0, sticky="e", pady=(1, 0))

        ctk.CTkLabel(
            header_progress,
            textvariable=self.progress_label_var,
            text_color=CARD_NAVY,
            font=("Segoe UI", 11, "bold"),
            width=42,
        ).grid(row=0, column=1, padx=(0, 8), sticky="e")
        self.progress = ctk.CTkProgressBar(
            header_progress,
            width=225,
            height=8,
            fg_color="#DDEBF5",
            progress_color=PRODUCT_BLUE,
            corner_radius=5,
        )
        self.progress.grid(row=0, column=2, sticky="e")
        self.progress.set(0)

        toolbar = ctk.CTkFrame(header_actions, fg_color="transparent")
        toolbar.pack(anchor="e")
        self.open_button = ctk.CTkButton(
            toolbar,
            text="Open Packet",
            command=self.open_packet,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
            text_color="white",
            corner_radius=5,
            height=36,
            width=118,
            font=("Segoe UI", 12, "bold"),
        )
        self.open_button.pack(side="left", padx=(0, 8))
        self.export_button = ctk.CTkButton(
            toolbar,
            text="Export PDFs",
            command=self.export_pdfs,
            state="disabled",
            fg_color="#F8FAFC",
            hover_color=SUCCESS_GREEN,
            text_color=MUTED,
            border_width=1,
            border_color="#B8C7D8",
            corner_radius=5,
            height=36,
            width=112,
            font=("Segoe UI", 12, "bold"),
        )
        self.export_button.pack(side="left", padx=(0, 8))
        self.add_files_button = ctk.CTkButton(
            toolbar,
            text="Add Files",
            command=self.add_files,
            fg_color="#F8FAFC",
            hover_color=SUCCESS_GREEN,
            text_color=TEXT,
            border_width=1,
            border_color="#B8C7D8",
            corner_radius=5,
            height=36,
            width=96,
            font=("Segoe UI", 12, "bold"),
        )
        self.add_files_button.pack(side="left", padx=(0, 8))
        self.audit_center_button = ctk.CTkButton(
            toolbar,
            text="Audit",
            command=self.show_audit_center,
            fg_color="#F8FAFC",
            hover_color=SUCCESS_GREEN,
            text_color=TEXT,
            border_width=1,
            border_color="#B8C7D8",
            corner_radius=5,
            height=36,
            width=104,
            font=("Segoe UI", 12, "bold"),
        )
        self.audit_center_button.pack(side="left", padx=(0, 8))
        # Backward-compatible alias used by the audit worker state logic.
        self.audit_folder_button = self.audit_center_button
        self.review_button = ctk.CTkButton(
            toolbar,
            text="Review Packet",
            command=self.show_packet_review,
            state="disabled",
            fg_color="#F8FAFC",
            hover_color=SUCCESS_GREEN,
            text_color=MUTED,
            border_width=1,
            border_color="#B8C7D8",
            corner_radius=5,
            height=36,
            width=112,
            font=("Segoe UI", 12, "bold"),
        )
        self.review_button.pack(side="left", padx=(8, 0))

        # ── Modern Settings button — clearer than a lone gear icon ─────────────
        self.settings_button = ctk.CTkButton(
            toolbar,
            text="⚙  Settings",
            command=self.show_preferences,
            fg_color="#F8FAFC",
            hover_color="#EEF6FF",
            text_color="#174A8B",
            border_width=1,
            border_color="#B8C7D8",
            corner_radius=7,
            height=36,
            width=120,
            font=("Segoe UI", 12, "bold"),
        )
        self.settings_button.pack(side="left", padx=(8, 0))

        # Main three-column layout. The center preview gets the extra space.
        main = ctk.CTkFrame(self.root, fg_color=APP_BG, corner_radius=0)
        main.grid(row=1, column=0, sticky="nsew", padx=14, pady=12)
        main.grid_columnconfigure(0, weight=0, minsize=252)
        main.grid_columnconfigure(1, weight=1)
        main.grid_columnconfigure(2, weight=0, minsize=340)
        main.grid_rowconfigure(0, weight=1)

        # Compact page list panel
        self.left_card = self.card(main)
        self.left_card.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.left_card.configure(width=252)
        self.left_card.grid_propagate(False)
        self.left_card.grid_rowconfigure(1, weight=1)
        self.left_card.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            self.left_card,
            text="Packet Pages",
            text_color=TEXT,
            font=("Segoe UI", 15, "bold"),
        ).grid(row=0, column=0, sticky="w", padx=10, pady=(9, 5))
        self.pages_scroll = ctk.CTkScrollableFrame(
            self.left_card,
            fg_color=CARD_BG,
            scrollbar_button_color="#CBD5E1",
            scrollbar_button_hover_color="#94A3B8",
        )
        self.pages_scroll.grid(row=1, column=0, sticky="nsew", padx=6, pady=(0, 6))

        # Large center preview. No assignment/output panels below it.
        self.preview_card = self.card(main)
        self.preview_card.grid(row=0, column=1, sticky="nsew", padx=(0, 10))
        self.preview_card.grid_columnconfigure(0, weight=1)
        self.preview_card.grid_columnconfigure(1, weight=0)
        self.preview_card.grid_rowconfigure(1, weight=1)
        top_preview = ctk.CTkFrame(self.preview_card, fg_color="transparent")
        top_preview.grid(row=0, column=0, sticky="ew", padx=12, pady=(9, 7))
        top_preview.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            top_preview,
            text="Page Preview",
            text_color=TEXT,
            font=("Segoe UI", 15, "bold"),
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(
            top_preview,
            textvariable=self.summary_var,
            text_color=MUTED,
            font=("Segoe UI", 11),
        ).grid(row=0, column=1, sticky="e", padx=(0, 10))
        preview_nav = ctk.CTkFrame(top_preview, fg_color="transparent")
        preview_nav.grid(row=0, column=2, sticky="e")
        self.preview_prev_button = ctk.CTkButton(
            preview_nav,
            text="‹",
            width=32,
            height=24,
            command=self.preview_previous_page,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color="#CBD5E1",
            text_color=CARD_NAVY,
            corner_radius=4,
            font=("Segoe UI", 14, "bold"),
        )
        self.preview_prev_button.pack(side="left", padx=(0, 4))
        ctk.CTkLabel(
            preview_nav,
            textvariable=self.preview_nav_var,
            text_color=MUTED,
            font=("Segoe UI", 10),
            width=92,
        ).pack(side="left")
        self.preview_next_button = ctk.CTkButton(
            preview_nav,
            text="›",
            width=32,
            height=24,
            command=self.preview_next_page,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color="#CBD5E1",
            text_color=CARD_NAVY,
            corner_radius=4,
            font=("Segoe UI", 14, "bold"),
        )
        self.preview_next_button.pack(side="left", padx=(4, 0))
        preview_rotation = ctk.CTkFrame(
            top_preview,
            fg_color="transparent",
        )
        preview_rotation.grid(
            row=1,
            column=0,
            columnspan=3,
            pady=(5, 1),
        )
        ctk.CTkButton(
            preview_rotation,
            text="↶",
            command=lambda: self.rotate_selected_pages(-90),
            width=34,
            height=27,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_color="#CBD5E1",
            border_width=1,
            text_color=TEXT,
            corner_radius=5,
            font=("Segoe UI Symbol", 16, "bold"),
        ).pack(side="left", padx=(0, 3))
        ctk.CTkButton(
            preview_rotation,
            text="↷",
            command=lambda: self.rotate_selected_pages(90),
            width=34,
            height=27,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_color="#CBD5E1",
            border_width=1,
            text_color=TEXT,
            corner_radius=5,
            font=("Segoe UI Symbol", 16, "bold"),
        ).pack(side="left", padx=(3, 0))
        ctk.CTkLabel(
            top_preview,
            textvariable=self.packet_filename_var,
            text_color=CARD_NAVY,
            font=("Segoe UI", 11, "bold"),
            anchor="w",
            justify="left",
            wraplength=780,
        ).grid(row=2, column=0, columnspan=3, sticky="ew", pady=(4, 0))
        self.preview_canvas = tk.Canvas(
            self.preview_card,
            background="#EAF2F8",
            highlightthickness=0,
            bd=0,
        )
        self.preview_canvas.grid(row=1, column=0, sticky="nsew", padx=(12, 0), pady=(0, 12))
        preview_scroll_style = ttk.Style()
        preview_scroll_style.configure(
            "Preview.Vertical.TScrollbar",
            background="#CBD5E1",
            troughcolor="#EAF2F8",
            bordercolor="#EAF2F8",
            arrowcolor=CARD_NAVY,
        )
        self.preview_scrollbar = ttk.Scrollbar(
            self.preview_card,
            orient="vertical",
            command=self.preview_canvas.yview,
            style="Preview.Vertical.TScrollbar",
        )
        self.preview_scrollbar.grid(row=1, column=1, sticky="ns", padx=(6, 12), pady=(0, 12))
        self.preview_canvas.configure(yscrollcommand=self.preview_scrollbar.set)
        self.preview_canvas.bind("<Configure>", self.on_preview_resize)
        self.preview_canvas.bind("<MouseWheel>", self.on_preview_mousewheel)
        self.preview_canvas.bind("<Button-4>", self.on_preview_mousewheel)
        self.preview_canvas.bind("<Button-5>", self.on_preview_mousewheel)
        self.root.bind("<Prior>", lambda _event: self.preview_canvas.yview_scroll(-1, "pages"))
        self.root.bind("<Next>", lambda _event: self.preview_canvas.yview_scroll(1, "pages"))
        self.root.bind("<Left>", lambda _event: self.preview_previous_page())
        self.root.bind("<Right>", lambda _event: self.preview_next_page())

        # Right-side task pane, like a Windows setup/utility sidebar.
        right_panel = ctk.CTkFrame(main, fg_color=APP_BG, corner_radius=0)
        right_panel.grid(row=0, column=2, sticky="nsew")
        right_panel.grid_columnconfigure(0, weight=1)
        right_panel.grid_rowconfigure(1, weight=1)

        self.action_card = self.card(right_panel)
        self.action_card.grid(row=0, column=0, sticky="ew")
        self.action_card.grid_columnconfigure(0, weight=1)
        self.action_card.grid_columnconfigure(1, weight=0)
        ctk.CTkLabel(
            self.action_card,
            textvariable=self.action_title_var,
            text_color=TEXT,
            font=("Segoe UI", 15, "bold"),
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(10, 6))
        ctk.CTkLabel(
            self.action_card,
            text="Document filename",
            text_color=MUTED,
            font=("Segoe UI", 11, "bold"),
        ).grid(row=1, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 4))
        self.document_combo = ctk.CTkComboBox(
            self.action_card,
            variable=self.document_var,
            values=self.rules["document_types"],
            height=34,
            fg_color="white",
            border_color="#CFE0EA",
            button_color=PRODUCT_BLUE,
            button_hover_color="#176FCC",
            dropdown_fg_color="white",
            corner_radius=5,
        )
        self.document_combo.grid(row=2, column=0, columnspan=2, sticky="ew", padx=12, pady=(0, 8))

        button_grid = ctk.CTkFrame(self.action_card, fg_color="transparent")
        button_grid.grid(row=3, column=0, columnspan=2, sticky="ew", padx=12, pady=(0, 12))
        button_grid.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkButton(button_grid, text="Assign to Document", command=self.assign_to_document, fg_color=PRODUCT_BLUE, hover_color="#176FCC", corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        ctk.CTkButton(button_grid, text="Mark Unsorted", command=self.remove_assignments, fg_color="#FFFFFF", hover_color="#FBEAEA", border_color="#8A2020", border_width=1, text_color=WARNING, corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=1, column=0, sticky="ew", padx=(0, 5))
        ctk.CTkButton(button_grid, text="Rename Output", command=self.rename_document, fg_color="#FFFFFF", hover_color="#F8FAFC", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=1, column=1, sticky="ew", padx=(5, 0))
        ctk.CTkButton(button_grid, text="Save Adjustments", command=self.remember_correction, fg_color="#FFFFFF", hover_color="#EEF6FF", border_color=PRODUCT_BLUE, border_width=1, text_color=PRODUCT_BLUE, corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=2, column=0, sticky="ew", padx=(0, 5), pady=(6, 0))
        ctk.CTkButton(button_grid, text="Assignment Details", command=self.show_assignment_reason, fg_color="#FFFFFF", hover_color="#EEF6FF", border_color=PRODUCT_BLUE, border_width=1, text_color=PRODUCT_BLUE, corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=2, column=1, sticky="ew", padx=(5, 0), pady=(6, 0))
        ctk.CTkButton(button_grid, text="Undo Last Change", command=self.undo_last_change, fg_color="#FFFFFF", hover_color="#F8FAFC", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5, height=32, font=("Segoe UI", 11, "bold")).grid(row=3, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        self.watch_button = ctk.CTkButton(button_grid, text="Scanner Folder", command=self.choose_scanner_folder, fg_color="#FFFFFF", hover_color="#EAF7F0", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5, height=32, font=("Segoe UI", 11, "bold"))
        self.watch_button.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(6, 0))
        self.watch_folder_label = ctk.CTkLabel(
            button_grid,
            text="Scanner folder watch is off",
            text_color=MUTED,
            font=("Segoe UI", 9),
            anchor="w",
            justify="left",
            wraplength=300,
        )
        self.watch_folder_label.grid(row=5, column=0, columnspan=2, sticky="ew", pady=(3, 0))

        self.output_card = self.card(right_panel)
        self.output_card.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        self.output_card.grid_columnconfigure(0, weight=1)
        self.output_card.grid_rowconfigure(1, weight=1)
        out_header = ctk.CTkFrame(self.output_card, fg_color="transparent")
        out_header.grid(row=0, column=0, sticky="ew", padx=12, pady=(10, 6))
        out_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(out_header, text="Output PDFs", text_color=TEXT, font=("Segoe UI", 15, "bold")).grid(row=0, column=0, sticky="w")
        order_buttons = ctk.CTkFrame(out_header, fg_color="transparent")
        order_buttons.grid(row=0, column=1, sticky="e")
        ctk.CTkButton(order_buttons, text="Up", command=lambda: self.move_document(-1), width=48, height=28, fg_color="#FFFFFF", hover_color="#F8FAFC", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5).pack(side="left", padx=(0, 5))
        ctk.CTkButton(order_buttons, text="Down", command=lambda: self.move_document(1), width=64, height=28, fg_color="#FFFFFF", hover_color="#F8FAFC", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5).pack(side="left")
        self.output_scroll = ctk.CTkScrollableFrame(
            self.output_card,
            fg_color=CARD_BG,
            scrollbar_button_color="#CBD5E1",
            scrollbar_button_hover_color="#94A3B8",
        )
        self.output_scroll.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 8))


    def update_header_progress(self, percent: float, text: str):
        """Update the shared header progress/status area immediately.

        Open Packet already used this bar during OCR. Add Files and Audit Center
        also do real work before/around OCR, so they should report progress in
        the same place instead of appearing idle.
        """
        percent = max(0, min(100, float(percent)))
        try:
            self.progress_var.set(percent)
            self.progress.set(percent / 100)
            self.progress_label_var.set(f"{int(percent)}%")
        except Exception:
            pass
        self.status_var.set(text)
        try:
            self.root.update_idletasks()
        except Exception:
            pass


    def card(self, parent):
        return ctk.CTkFrame(parent, fg_color=CARD_BG, corner_radius=10, border_width=1, border_color=BORDER)

    def open_packet(self):
        selected = filedialog.askopenfilename(
            title="Choose a packet",
            filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")],
        )
        if not selected:
            return
        self.load_packet(Path(selected))

    def add_files(self):
        if self.analyzing:
            messagebox.showinfo(
                APP_TITLE,
                "Wait for the current analysis to finish before adding files.",
            )
            return
        selected = filedialog.askopenfilenames(
            title=(
                "Add files to the current packet"
                if self.reader
                else "Choose files for an ad hoc packet"
            ),
            filetypes=[
                (
                    "Supported documents and images",
                    " ".join(f"*{extension}" for extension in sorted(
                        SUPPORTED_INPUT_EXTENSIONS
                    )),
                ),
                ("PDF files", "*.pdf"),
                (
                    "Image files",
                    "*.png *.jpg *.jpeg *.jfif *.bmp *.tif *.tiff *.gif *.webp",
                ),
                (
                    "Office documents",
                    "*.doc *.docx *.rtf *.odt *.html *.htm "
                    "*.xls *.xlsx *.xlsm *.ods *.ppt *.pptx *.odp",
                ),
                ("Text files", "*.txt *.log *.csv *.md"),
                ("All files", "*.*"),
            ],
        )
        if selected:
            self.add_file_paths([Path(path) for path in selected])

    def add_file_paths(self, selected_paths: list[Path]):
        if self.analyzing:
            messagebox.showinfo(
                APP_TITLE,
                "Wait for the current analysis to finish before adding files.",
            )
            return
        new_paths = [
            Path(path)
            for path in selected_paths
            if (
                Path(path).is_file()
                and Path(path).suffix.lower() in SUPPORTED_INPUT_EXTENSIONS
            )
        ]
        if not new_paths:
            messagebox.showwarning(
                APP_TITLE,
                "Choose at least one supported PDF, image, text, or Office file.",
            )
            return

        self.set_busy(True)
        self.update_header_progress(2, "Preparing selected files...")

        existing_page_count = len(self.reader.pages) if self.reader else 0

        source_paths = list(self.packet_source_paths) if self.reader else []
        source_paths.extend(new_paths)
        if not source_paths:
            source_paths = new_paths

        manual_dir = Path(tempfile.mkdtemp(prefix="packetflow_manual_"))
        conversion_dir = manual_dir / "converted"
        conversion_dir.mkdir()
        if self.reader:
            base_stem = self.packet_base_stem or self.current_packet_stem()
            added_count = max(len(source_paths) - 1, len(new_paths))
            display_name = (
                f"{base_stem} + {added_count} added file"
                + ("" if added_count == 1 else "s")
            )
        elif len(new_paths) == 1:
            base_stem = new_paths[0].stem
            display_name = new_paths[0].name
        else:
            base_stem = new_paths[0].stem
            display_name = (
                f"{new_paths[0].stem} + {len(new_paths) - 1} more files"
            )
        combined_path = manual_dir / safe_filename(display_name)
        added_pages_path = manual_dir / "newly-added-pages.pdf"
        source_page_ranges: list[tuple[int, int]] = []

        try:
            writer = PdfWriter()
            added_writer = PdfWriter()
            if self.reader:
                for page in self.reader.pages:
                    writer.add_page(copy.deepcopy(page))
            total_to_convert = max(len(new_paths), 1)
            for sequence, path in enumerate(new_paths, start=1):
                self.update_header_progress(
                    5 + int(((sequence - 1) / total_to_convert) * 25),
                    f"Preparing {path.name}...",
                )
                converted_path = self.convert_input_to_pdf(
                    path,
                    conversion_dir,
                    sequence,
                )
                reader = PdfReader(str(converted_path))
                range_start = len(added_writer.pages)
                for page in reader.pages:
                    copied_page = copy.deepcopy(page)
                    writer.add_page(copied_page)
                    added_writer.add_page(copy.deepcopy(page))
                source_page_ranges.append(
                    (range_start, len(added_writer.pages))
                )
            self.update_header_progress(32, "Combining selected files into a packet...")
            if not writer.pages:
                raise ValueError("The selected files do not contain any pages.")
            if not added_writer.pages:
                raise ValueError(
                    "The newly selected files do not contain any pages."
                )
            with combined_path.open("wb") as handle:
                writer.write(handle)
            with added_pages_path.open("wb") as handle:
                added_writer.write(handle)
        except OfficeConverterUnavailable as exc:
            shutil.rmtree(manual_dir, ignore_errors=True)
            self.set_busy(False)
            self.update_header_progress(0, "Add files cancelled.")
            messagebox.showwarning(APP_TITLE, str(exc))
            self.offer_office_converter_install()
            return
        except Exception as exc:
            shutil.rmtree(manual_dir, ignore_errors=True)
            self.set_busy(False)
            self.update_header_progress(0, "The selected files could not be added.")
            messagebox.showerror(
                APP_TITLE,
                "The selected files could not be added.\n\n" + str(exc),
            )
            return

        self.update_header_progress(38, "Starting analysis for added files...")

        if self.reader and existing_page_count:
            self.start_incremental_analysis(
                added_pages_path=added_pages_path,
                combined_path=combined_path,
                manual_dir=manual_dir,
                source_paths=source_paths,
                display_name=display_name,
                base_stem=base_stem,
                source_page_ranges=source_page_ranges,
            )
        else:
            self.load_packet(
                combined_path,
                source_paths=source_paths,
                display_name=display_name,
                base_stem=base_stem,
                manual_packet_dir=manual_dir,
            )

    @staticmethod
    def inherit_added_file_assignments(
        assignments: list[Assignment],
        blank_pages: set[int],
        source_page_ranges: list[tuple[int, int]],
        rotations: list[int],
    ) -> list[Assignment]:
        updated = list(assignments)
        for range_start, range_end in source_page_ranges:
            pages = [
                page
                for page in range(range_start, range_end)
                if page not in blank_pages
            ]
            assigned_documents = {
                item.document
                for item in updated
                if range_start <= item.page_index < range_end
            }
            allowed_documents: set[str] | None = None
            if len(assigned_documents) == 1:
                allowed_documents = assigned_documents
            elif assigned_documents == {
                "Banking.pdf",
                "Viventium Direct Deposit.pdf",
            }:
                allowed_documents = assigned_documents
            if not allowed_documents:
                continue
            assigned_pages = {
                item.page_index
                for item in updated
                if range_start <= item.page_index < range_end
            }
            for page in pages:
                if page in assigned_pages:
                    continue
                for document in allowed_documents:
                    updated.append(
                        Assignment(
                            page,
                            document,
                            rotations[page],
                            None,
                        )
                    )
        return updated

    def start_incremental_analysis(
        self,
        added_pages_path: Path,
        combined_path: Path,
        manual_dir: Path,
        source_paths: list[Path],
        display_name: str,
        base_stem: str,
        source_page_ranges: list[tuple[int, int]],
    ):
        if self.analyzing or not self.reader:
            return
        old_page_count = len(self.reader.pages)
        old_manual_dir = self.manual_packet_dir
        append_work_dir = Path(
            tempfile.mkdtemp(prefix="packetflow_added_pages_")
        )
        self.analyzing = True
        self.set_busy(True)
        self.progress_var.set(0)
        self.progress.set(0)
        self.progress_label_var.set("0%")
        self.status_var.set("Analyzing newly added pages only...")

        def worker():
            try:
                def progress(value, text, page_index=None):
                    global_index = (
                        old_page_count + page_index
                        if page_index is not None
                        else None
                    )
                    self.worker_queue.put(
                        (
                            "progress",
                            value,
                            text.replace(
                                "packet pages",
                                "newly added pages",
                            ),
                            global_index,
                        )
                    )

                (
                    page_images,
                    ocr_texts,
                    assignments,
                    rotations,
                    blank_pages,
                    fingerprints,
                ) = self.analyzer.analyze(
                    added_pages_path,
                    append_work_dir,
                    progress,
                )
                quality_warnings = (
                    self.analyzer.scan_quality_warnings_for_images(
                        page_images,
                        blank_pages,
                        str(self.settings.get("scan_quality_sensitivity", "standard")),
                    )
                    if self.setting_enabled("scan_quality_checks_enabled")
                    else {}
                )
                assignments = self.inherit_added_file_assignments(
                    assignments,
                    blank_pages,
                    source_page_ranges,
                    rotations,
                )
                if self.setting_enabled("apply_remembered_corrections"):
                    assignments, memory_pages = self.apply_correction_memory(
                        ocr_texts,
                        assignments,
                        rotations,
                        blank_pages,
                    )
                else:
                    memory_pages = set()
                combined_reader = PdfReader(str(combined_path))
                self.worker_queue.put(
                    (
                        "append_complete",
                        {
                            "old_page_count": old_page_count,
                            "combined_path": combined_path,
                            "combined_reader": combined_reader,
                            "manual_dir": manual_dir,
                            "old_manual_dir": old_manual_dir,
                            "source_paths": source_paths,
                            "display_name": display_name,
                            "base_stem": base_stem,
                            "append_work_dir": append_work_dir,
                            "page_images": page_images,
                            "ocr_texts": ocr_texts,
                            "assignments": assignments,
                            "rotations": rotations,
                            "blank_pages": blank_pages,
                            "fingerprints": fingerprints,
                            "quality_warnings": quality_warnings,
                            "memory_pages": memory_pages,
                        },
                    )
                )
            except Exception:
                self.worker_queue.put(
                    (
                        "append_error",
                        traceback.format_exc(),
                        manual_dir,
                        append_work_dir,
                    )
                )

        threading.Thread(target=worker, daemon=True).start()

    def load_packet(
        self,
        selected: Path,
        from_watch: bool = False,
        source_paths: list[Path] | None = None,
        display_name: str | None = None,
        base_stem: str | None = None,
        manual_packet_dir: Path | None = None,
        preserved_state: dict | None = None,
    ):
        selected = Path(selected)
        if not selected.is_file() or selected.suffix.lower() != ".pdf":
            messagebox.showwarning(APP_TITLE, "Choose a valid PDF packet.")
            return
        try:
            reader = PdfReader(str(selected))
        except Exception as exc:
            if manual_packet_dir:
                shutil.rmtree(manual_packet_dir, ignore_errors=True)
            messagebox.showerror(APP_TITLE, f"Could not open that PDF:\n\n{exc}")
            return
        if self.pdf_path or self.reader or self.page_images or self.assignments:
            self.clear_loaded_packet("Loading the new packet...")
        self.pdf_path = selected
        self.reader = reader
        self.packet_source_paths = list(source_paths or [selected])
        self.packet_display_name = display_name or selected.name
        self.packet_base_stem = base_stem or selected.stem
        self.manual_packet_dir = manual_packet_dir
        self.pending_append_state = preserved_state
        self.export_packet_name = None
        self.packet_exported = False
        self.current_packet_from_watch = from_watch
        source_label = (
            ", ".join(path.name for path in self.packet_source_paths)
            if len(self.packet_source_paths) > 1
            else self.packet_display_name
        )
        self.packet_filename_var.set(f"Packet file(s): {source_label}")
        self.root.title(f"{self.packet_display_name} - {APP_TITLE}")
        self.status_var.set(
            f"Loaded {self.packet_display_name} ({len(self.reader.pages)} pages)."
        )
        self.start_analysis()

    def start_analysis(self):
        if not self.pdf_path or self.analyzing:
            return
        self.analyzing = True
        self.set_busy(True)
        self.progress_var.set(0)
        self.progress.set(0)
        self.progress_label_var.set("0%")
        self.assignments.clear(); self.page_images.clear(); self.ocr_texts.clear(); self.page_rotations.clear(); self.page_manual_rotations.clear(); self.blank_pages.clear(); self.page_fingerprints.clear()
        self.duplicate_pairs.clear(); self.low_confidence_pages.clear(); self.page_quality_warnings.clear(); self.memory_applied_pages.clear()
        self.undo_stack.clear()
        self.selected_pages.clear(); self.selected_document = None; self.preview_page_position = 0
        self.clear_preview_cache()
        self.summary_var.set("Analyzing packet...")
        self.show_analyzing_placeholders()
        self.refresh_output_cards()
        self.refresh_preview()
        if self.work_dir and self.work_dir.exists():
            shutil.rmtree(self.work_dir, ignore_errors=True)
        for directory in self.additional_work_dirs:
            if directory.exists():
                shutil.rmtree(directory, ignore_errors=True)
        self.additional_work_dirs.clear()
        self.work_dir = Path(tempfile.mkdtemp(prefix="onboarding_packet_"))

        def worker():
            try:
                def progress(value, text, page_index=None):
                    self.worker_queue.put(("progress", value, text, page_index))
                result = self.analyzer.analyze(self.pdf_path, self.work_dir, progress)
                (
                    page_images,
                    ocr_texts,
                    assignments,
                    rotations,
                    blank_pages,
                    fingerprints,
                ) = result
                if self.setting_enabled("apply_remembered_corrections"):
                    assignments, memory_pages = self.apply_correction_memory(
                        ocr_texts,
                        assignments,
                        rotations,
                        blank_pages,
                    )
                else:
                    memory_pages = set()
                duplicates = (
                    self.find_duplicate_pairs(
                        ocr_texts,
                        fingerprints,
                        blank_pages,
                    )
                    if self.setting_enabled("show_duplicate_warnings")
                    else []
                )
                assignments, duplicate_unsorted_pages = (
                    self.auto_unsort_duplicate_assignments(assignments, duplicates)
                )
                low_confidence = (
                    self.calculate_low_confidence_pages(
                        ocr_texts,
                        assignments,
                    )
                    if self.setting_enabled("show_low_confidence_warnings")
                    else set()
                )
                quality_warnings = (
                    self.analyzer.scan_quality_warnings_for_images(
                        page_images,
                        blank_pages,
                        str(self.settings.get("scan_quality_sensitivity", "standard")),
                    )
                    if self.setting_enabled("scan_quality_checks_enabled")
                    else {}
                )
                self.worker_queue.put(
                    (
                        "complete",
                        (
                            page_images,
                            ocr_texts,
                            assignments,
                            rotations,
                            blank_pages,
                            fingerprints,
                            duplicates,
                            low_confidence,
                            quality_warnings,
                            memory_pages,
                            duplicate_unsorted_pages,
                        ),
                    )
                )
            except Exception:
                self.worker_queue.put(("error", traceback.format_exc()))
        threading.Thread(target=worker, daemon=True).start()

    def show_analyzing_placeholders(self):
        self.clear_frame(self.pages_scroll)
        self.page_status_widgets.clear()
        if not self.reader:
            return
        for index in range(len(self.reader.pages)):
            self.add_page_card(index, "Analyzing...", "reading")

    def poll_worker_queue(self):
        poll_delay = 50 if self.analyzing else 120
        try:
            while True:
                message = self.worker_queue.get_nowait()
                kind = message[0]
                if kind == "progress":
                    value = message[1]
                    self.progress_var.set(value)
                    self.progress.set(max(0, min(1, value / 100)))
                    self.progress_label_var.set(f"{int(value)}%")
                    self.status_var.set(message[2])
                    # Match the original app behavior: each page changes from
                    # "Analyzing..." to "Read" as soon as that individual OCR
                    # worker finishes. Do not rebuild the full page list here;
                    # only update the one card that completed so the UI stays responsive.
                    if len(message) > 3 and message[3] is not None:
                        self.set_page_card_status(int(message[3]), "Read", "read")
                elif kind == "complete":
                    (
                        self.page_images,
                        self.ocr_texts,
                        self.assignments,
                        self.page_rotations,
                        self.blank_pages,
                        self.page_fingerprints,
                        self.duplicate_pairs,
                        self.low_confidence_pages,
                        self.page_quality_warnings,
                        self.memory_applied_pages,
                        duplicate_unsorted_pages,
                    ) = message[1]
                    self.page_manual_rotations = [0] * len(self.page_rotations)
                    if self.pending_append_state:
                        preserved = self.pending_append_state
                        old_count = int(preserved.get("page_count", 0))
                        old_assignments = preserved.get("assignments", [])
                        self.assignments = [
                            item
                            for item in self.assignments
                            if item.page_index >= old_count
                        ] + old_assignments
                        self.blank_pages = {
                            page for page in self.blank_pages if page >= old_count
                        } | set(preserved.get("blank_pages", set()))
                        old_manual_rotations = list(
                            preserved.get("manual_rotations", [])
                        )
                        for index, rotation in enumerate(old_manual_rotations):
                            if index < len(self.page_manual_rotations):
                                self.page_manual_rotations[index] = rotation
                        self.document_order = list(
                            preserved.get("document_order", [])
                        )
                        self.custom_document_types = set(
                            preserved.get("custom_document_types", set())
                        )
                        self.pending_append_state = None
                    else:
                        self.document_order = []
                    self.sync_document_order()
                    self.analyzing = False
                    self.set_busy(False)
                    self.progress_var.set(100); self.progress.set(1); self.progress_label_var.set("100%")
                    grouped_count = len(self.grouped_assignments())
                    merged_file_count = len(
                        {
                            assignment.page_index
                            for assignment in self.assignments
                            if assignment.page_index not in self.blank_pages
                        }
                    )
                    self.status_var.set(
                        f"Merged {merged_file_count} files into "
                        f"{grouped_count} Output PDFs."
                    )
                    self.notify_user(
                        "Packet Ready for Review",
                        (
                            f"{self.packet_display_name or (self.pdf_path.name if self.pdf_path else 'A packet')} "
                            f"was merged into {grouped_count} Output PDFs."
                        ),
                    )
                    self.update_summary()
                    self.refresh_all_views()
                    if self.page_images:
                        self.selected_pages = {0}
                        self.refresh_page_cards()
                        self.on_page_selected()
                    if (
                        self.current_packet_from_watch
                        and self.setting_enabled(
                            "automatically_export_scanner_packets"
                        )
                    ):
                        self.root.after(
                            150,
                            lambda: self.export_pdfs(automatic=True),
                        )
                elif kind == "append_complete":
                    result = message[1]
                    old_page_count = result["old_page_count"]
                    shifted_assignments = [
                        Assignment(
                            item.page_index + old_page_count,
                            item.document,
                            item.rotation,
                            item.sequence,
                        )
                        for item in result["assignments"]
                    ]
                    shifted_blank_pages = {
                        page + old_page_count
                        for page in result["blank_pages"]
                    }
                    shifted_memory_pages = {
                        page + old_page_count
                        for page in result["memory_pages"]
                    }
                    shifted_quality_warnings = {
                        page + old_page_count: list(issues)
                        for page, issues in result.get("quality_warnings", {}).items()
                    }
                    self.pdf_path = result["combined_path"]
                    self.reader = result["combined_reader"]
                    self.packet_source_paths = list(result["source_paths"])
                    self.packet_display_name = result["display_name"]
                    self.packet_base_stem = result["base_stem"]
                    self.manual_packet_dir = result["manual_dir"]
                    self.packet_exported = False
                    self.current_packet_from_watch = False
                    self.page_images.extend(result["page_images"])
                    self.ocr_texts.extend(result["ocr_texts"])
                    self.page_rotations.extend(result["rotations"])
                    self.page_manual_rotations.extend(
                        [0] * len(result["rotations"])
                    )
                    self.page_fingerprints.extend(result["fingerprints"])
                    self.assignments.extend(shifted_assignments)
                    self.blank_pages.update(shifted_blank_pages)
                    self.memory_applied_pages.update(shifted_memory_pages)
                    self.page_quality_warnings.update(shifted_quality_warnings)
                    self.additional_work_dirs.append(
                        result["append_work_dir"]
                    )
                    old_manual_dir = result.get("old_manual_dir")
                    if (
                        old_manual_dir
                        and old_manual_dir != self.manual_packet_dir
                        and old_manual_dir.exists()
                    ):
                        shutil.rmtree(old_manual_dir, ignore_errors=True)
                        if old_manual_dir.exists():
                            self.retired_manual_dirs.append(old_manual_dir)

                    self.duplicate_pairs = (
                        self.find_duplicate_pairs(
                            self.ocr_texts,
                            self.page_fingerprints,
                            self.blank_pages,
                        )
                        if self.setting_enabled("show_duplicate_warnings")
                        else []
                    )
                    self.assignments, duplicate_unsorted_pages = (
                        self.auto_unsort_duplicate_assignments(
                            self.assignments,
                            self.duplicate_pairs,
                        )
                    )
                    self.low_confidence_pages = (
                        self.calculate_low_confidence_pages(
                            self.ocr_texts,
                            self.assignments,
                        )
                        if self.setting_enabled(
                            "show_low_confidence_warnings"
                        )
                        else set()
                    )
                    self.sync_document_order()
                    self.undo_stack.clear()
                    self.analyzing = False
                    self.set_busy(False)
                    self.progress_var.set(100)
                    self.progress.set(1)
                    self.progress_label_var.set("100%")
                    added_count = len(result["ocr_texts"])
                    self.packet_filename_var.set(
                        "Packet file(s): "
                        + ", ".join(
                            path.name
                            for path in self.packet_source_paths
                        )
                    )
                    self.root.title(
                        f"{self.packet_display_name} - {APP_TITLE}"
                    )
                    self.status_var.set(
                        f"Added and analyzed {added_count} new page"
                        + ("" if added_count == 1 else "s")
                        + "; existing pages were not re-analyzed."
                    )
                    self.update_summary()
                    self.clear_preview_cache()
                    self.refresh_all_views()
                    if added_count:
                        self.selected_document = None
                        self.selected_pages = {old_page_count}
                        self.preview_page_position = 0
                        self.refresh_page_cards()
                        self.on_page_selected()
                elif kind == "append_error":
                    self.analyzing = False
                    self.set_busy(False)
                    self.progress_var.set(0)
                    self.progress.set(0)
                    self.progress_label_var.set("0%")
                    shutil.rmtree(message[2], ignore_errors=True)
                    shutil.rmtree(message[3], ignore_errors=True)
                    self.status_var.set(
                        "The added files could not be analyzed."
                    )
                    messagebox.showerror(
                        APP_TITLE,
                        "The added files could not be analyzed.\n\n"
                        + message[1],
                    )
                elif kind == "directory_audit_complete":
                    self.directory_audit_running = False
                    self.set_busy(False)
                    self.update_header_progress(100, "Directory audit complete.")
                    if hasattr(self, "audit_folder_button"):
                        self.audit_folder_button.configure(state="normal")
                    report_text = message[1]
                    report_path = message[2]
                    self.status_var.set(f"Directory audit complete: {report_path.name}")
                    self.update_review_queue_badge()
                    # Refresh any Audit Center windows that are already open so
                    # newly discovered issues appear immediately without a
                    # manual Refresh click or closing and reopening the window.
                    self.refresh_open_audit_centers()
                    self.show_directory_audit_report(report_text, report_path)
                elif kind == "directory_audit_error":
                    self.directory_audit_running = False
                    self.set_busy(False)
                    if hasattr(self, "audit_folder_button"):
                        self.audit_folder_button.configure(state="normal")
                    self.update_header_progress(0, "Directory audit failed.")
                    messagebox.showerror(
                        APP_TITLE,
                        "The directory audit could not be completed.\n\n"
                        + message[1],
                    )
                elif kind == "error":
                    self.analyzing = False
                    self.set_busy(False)
                    self.progress_var.set(0); self.progress.set(0); self.progress_label_var.set("0%")
                    self.status_var.set("Analysis failed.")
                    self.summary_var.set("Analysis failed")
                    messagebox.showerror(APP_TITLE, "The packet could not be analyzed.\n\n" + message[1])
        except queue.Empty:
            pass
        self.root.after(poll_delay, self.poll_worker_queue)

    def set_busy(self, busy: bool):
        self.open_button.configure(state="disabled" if busy else "normal")
        if hasattr(self, "add_files_button"):
            self.add_files_button.configure(state="disabled" if busy else "normal")
        if hasattr(self, "audit_folder_button"):
            self.audit_folder_button.configure(
                state=(
                    "disabled"
                    if busy or self.directory_audit_running
                    else "normal"
                )
            )
        can_export = (not busy and bool(self.assignments))
        self.export_button.configure(
            state="normal" if can_export else "disabled",
            fg_color="#F8FAFC" if can_export else "#E9EEF5",
            text_color=TEXT if can_export else MUTED,
        )
        self.review_button.configure(
            state="normal" if can_export else "disabled",
            text_color=TEXT if can_export else MUTED,
        )

    def update_packet_stats(self):
        if not self.page_images:
            self.packet_stats_var.set("Open a packet to begin")
            return
        page_count = len(self.page_images)
        assigned_pages = {a.page_index for a in self.assignments if a.page_index not in self.blank_pages}
        unsorted = page_count - len(self.blank_pages) - len(assigned_pages)
        grouped = self.grouped_assignments()
        pdf_count = len(grouped)
        failed_outputs = sum(
            1
            for values in grouped.values()
            if not self.output_completeness_details(values)["complete"]
        )
        lower_conf = sum(
            1
            for values in grouped.values()
            if self.output_completeness_details(values)["complete"]
            and self.output_confidence_score(values) < 85
        )
        self.packet_stats_var.set(
            f"{page_count} pages · {pdf_count} PDFs · {unsorted} unsorted · "
            f"{len(self.blank_pages)} blank removed · {failed_outputs} failed · "
            f"{lower_conf} needs review · "
            f"{len(self.duplicate_pairs)} duplicate pairs"
        )

    def show_assignment_reason(self):
        if not self.selected_pages:
            messagebox.showinfo("Assignment Details", "Select a page first.")
            return
        page = min(self.selected_pages)
        page_assignments = [a for a in self.assignments if a.page_index == page]
        docs = [a.document for a in page_assignments]
        if page in self.blank_pages:
            messagebox.showinfo(
                "Assignment Details",
                f"Page {page + 1} is marked as a blank scanner page and is removed from export.",
            )
            return
        if not docs:
            messagebox.showinfo(
                "Assignment Details",
                f"Page {page + 1} is currently unsorted. Assign it, then use Save Adjustments if you want future packets to remember the correction.",
            )
            return

        lines: list[str] = [
            f"Page {page + 1}",
            "",
            "Assigned To:",
            ", ".join(dict.fromkeys(docs)),
            "",
        ]
        for assignment_index, assignment in enumerate(page_assignments):
            if assignment_index:
                lines.append("")
            details = self.assignment_confidence_details(assignment)
            output_assignments = self.grouped_assignments().get(
                assignment.document,
                [assignment],
            )
            completeness = self.output_completeness_details(output_assignments)
            score = details["score"]
            if completeness["checked"] and not completeness["complete"]:
                lines.append("Output Status: FAIL")
                lines.extend(f"- {issue}" for issue in completeness["issues"])
                lines.append("")
            else:
                output_score = self.output_confidence_score(output_assignments)
                if output_score != score and len(output_assignments) > 1:
                    if output_score >= 95:
                        output_band = "Very High"
                    elif output_score >= 85:
                        output_band = "High"
                    elif output_score >= 70:
                        output_band = "Medium"
                    else:
                        output_band = "Review Recommended"
                    lines.append(f"Output Confidence: {output_score}% ({output_band})")

                if score >= 95:
                    band = "Very High"
                elif score >= 85:
                    band = "High"
                elif score >= 70:
                    band = "Medium"
                else:
                    band = "Review Recommended"
                label = "Selected Page Confidence" if len(output_assignments) > 1 else "Confidence"
                lines.append(f"{label}: {score}% ({band})")
                lines.append("")

            matched = details.get("matched", [])
            lines.append("Detected Indicators:")
            for item in matched[:12]:
                lines.append(f"✓ {item}")
            if not matched:
                lines.append("- No strong evidence isolated")
            lines.append("")

            missing = details.get("missing", [])
            if missing:
                deduction_by_item = {}
                for reason, points in details.get("reductions", []):
                    prefix = "Missing expected indicator: "
                    if str(reason).startswith(prefix):
                        deduction_by_item[str(reason)[len(prefix):]] = points
                lines.append("Missing Checklist:")
                for item in missing[:12]:
                    points = deduction_by_item.get(item, 4)
                    lines.append(f"⚠ {item} (-{points}%)")
                lines.append("")

        messagebox.showinfo("Assignment Details", "\n".join(lines).strip())

    def update_summary(self):
        if not self.page_images:
            self.summary_var.set("No packet loaded")
            self.update_packet_stats()
            return
        page_count = len(self.page_images)
        assigned_pages = {a.page_index for a in self.assignments if a.page_index not in self.blank_pages}
        unsorted_count = page_count - len(self.blank_pages) - len(assigned_pages)
        pdf_count = len(self.grouped_assignments())
        self.summary_var.set(f"{pdf_count} PDFs · {len(assigned_pages)} sorted · {unsorted_count} unsorted · {len(self.blank_pages)} blank")
        self.update_packet_stats()

    def clear_preview_cache(self):
        self.preview_cache.clear(); self.preview_cache_size = (0, 0); self.preview_photo = None; self.preview_image_refs = []; self.preview_page_offsets = []

    def refresh_all_views(self):
        self.refresh_page_cards(); self.refresh_output_cards(); self.refresh_preview(); self.update_summary(); self.set_busy(False)

    def clear_frame(self, frame):
        for child in frame.winfo_children():
            child.destroy()

    def page_label_for(self, index):
        docs = [a.document for a in self.assignments if a.page_index == index]
        if index in self.blank_pages:
            return "BLANK PAGE", "blank"
        if docs:
            display_docs = [
                self.page_display_document_name(index, document)
                for document in dict.fromkeys(docs)
            ]
            if (
                "Identification.pdf" in display_docs
                and "Birth and Marriage Certificates.pdf" in display_docs
            ):
                display_docs = ["Identification.pdf"]
            return "; ".join(dict.fromkeys(display_docs)), "sorted"
        return "UNSORTED", "unsorted"

    def page_display_document_name(self, index: int, document: str) -> str:
        if (
            safe_filename(document).lower()
            != "form i-9 employment eligibility verification.pdf"
            or index >= len(self.ocr_texts)
        ):
            return document

        normalized = re.sub(r"\s+", " ", self.ocr_texts[index].lower())
        if (
            "form i-9" in normalized
            or "employment eligibility verification" in normalized
            or (
                "department of homeland security" in normalized
                and any(
                    phrase in normalized
                    for phrase in (
                        "employee attestation",
                        "employer review",
                        "authorized representative",
                    )
                )
            )
        ):
            return document

        indicators = self.i9_confidence_indicators_for_text(normalized)
        if indicators and not any(
            display == "Form I-9 heading" for display, _phrases in indicators
        ):
            return "Identification.pdf"
        return document

    def refresh_page_cards(self):
        self.clear_frame(self.pages_scroll)
        self.page_status_widgets.clear()
        for index in range(len(self.page_images)):
            label, state = self.page_label_for(index)
            self.add_page_card(index, label, state)

    def page_state_style(self, state):
        color_map = {
            "sorted": SUCCESS_GREEN,
            "unsorted": "#8A2020",
            "blank": "#CBD5E1",
            "reading": BRIGHT_BLUE,
            "read": PRODUCT_BLUE,
        }
        text_map = {"sorted": "✓", "unsorted": "!", "blank": "–", "reading": "…", "read": "✓"}
        text_color = NAVY if state == "sorted" else "white"
        label_color = WARNING if state == "unsorted" else MUTED
        return color_map.get(state, BRIGHT_BLUE), text_map.get(state, ""), text_color, label_color

    def compact_page_parts(self, index, label, state):
        # Windows setup/file-list style: dense, readable, no decorative graphics.
        status_map = {
            "sorted": "READ",
            "unsorted": "UNSORTED",
            "blank": "BLANK",
            "reading": "READING",
            "read": "READ",
        }
        status = status_map.get(state, "")
        short_label = label.replace(".pdf", "")
        if len(short_label) > 24:
            short_label = short_label[:21] + "..."
        return status, f"Page {index + 1:<3} {short_label}"

    def add_page_card(self, index, label, state):
        selected = index in self.selected_pages
        _badge_color, _badge_text, _badge_text_color, label_color = self.page_state_style(state)

        bg = "#EAF2FF" if selected else "#FFFFFF"
        row = ctk.CTkFrame(
            self.pages_scroll,
            fg_color=bg,
            corner_radius=0,
            border_width=0,
            height=21,
        )
        row.pack(fill="x", padx=0, pady=0)
        row.pack_propagate(False)

        status_text, detail_text = self.compact_page_parts(index, label, state)
        status_line = ctk.CTkLabel(
            row,
            text=status_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
            font=("Segoe UI", 10, "bold"),
            width=68,
            anchor="w",
        )
        status_line.pack(side="left", padx=(4, 0), pady=0)
        detail_line = ctk.CTkLabel(
            row,
            text=detail_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
            font=("Segoe UI", 10),
            anchor="w",
        )
        detail_line.pack(side="left", fill="x", expand=True, pady=0)

        self.page_status_widgets[index] = {
            "card": row,
            "status": status_line,
            "detail": detail_line,
        }
        status_line.bind("<Button-1>", lambda e, i=index: self.toggle_page_selection(i, e))
        detail_line.bind("<Button-1>", lambda e, i=index: self.toggle_page_selection(i, e))
        row.bind("<Button-1>", lambda e, i=index: self.toggle_page_selection(i, e))

    def set_page_card_status(self, index, label, state):
        widgets = self.page_status_widgets.get(index)
        if not widgets:
            return
        _badge_color, _badge_text, _badge_text_color, label_color = self.page_state_style(state)
        status_text, detail_text = self.compact_page_parts(index, label, state)
        widgets["status"].configure(
            text=status_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
        )
        widgets["detail"].configure(
            text=detail_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
        )
        try:
            self.pages_scroll.update_idletasks()
        except Exception:
            pass

    def toggle_page_selection(self, index, event=None):
        ctrl = bool(event and (event.state & 0x0004))
        shift = bool(event and (event.state & 0x0001))
        if shift and self.selected_pages:
            start = min(self.selected_pages)
            self.selected_pages = set(range(min(start,index), max(start,index)+1))
        elif ctrl:
            if index in self.selected_pages:
                self.selected_pages.remove(index)
            else:
                self.selected_pages.add(index)
        else:
            self.selected_pages = {index}
        self.preview_page_position = 0
        self.on_page_selected()
        self.refresh_page_cards()

    def grouped_assignments(self) -> dict[str, list[Assignment]]:
        grouped: dict[str, list[Assignment]] = {}
        for assignment in self.assignments:
            if assignment.page_index in self.blank_pages:
                continue
            grouped.setdefault(assignment.document, []).append(assignment)
        for values in grouped.values():
            values.sort(key=lambda item: (item.sequence is None, item.sequence if item.sequence is not None else item.page_index, item.page_index))
        self.sync_document_order(grouped)
        return {document: grouped[document] for document in self.document_order if document in grouped}

    def sync_document_order(self, grouped: dict[str, list[Assignment]] | None = None):
        if grouped is None:
            grouped = {}
            for assignment in self.assignments:
                grouped.setdefault(assignment.document, []).append(assignment)
        current_documents = set(grouped)
        self.document_order = [document for document in self.document_order if document in current_documents]
        remembered = (
            [
                document
                for document in self.preferred_document_order
                if document in current_documents
            ]
            if self.setting_enabled("apply_remembered_pdf_order")
            else []
        )
        defaults = [
            document
            for document in self.rules["document_types"]
            if document in current_documents
        ]
        extras = sorted(
            current_documents
            .difference(remembered)
            .difference(defaults)
            .difference(self.document_order),
            key=str.lower,
        )
        for document in remembered + defaults + extras:
            if document not in self.document_order:
                self.document_order.append(document)

    def refresh_output_cards(self):
        self.clear_frame(self.output_scroll)
        self.output_row_widgets = {}
        grouped = self.grouped_assignments()
        if not grouped:
            ctk.CTkLabel(
                self.output_scroll,
                text="No output PDFs yet.",
                text_color=MUTED,
                font=("Segoe UI", 11),
            ).pack(anchor="w", padx=8, pady=6)
            return

        for number, (document, assignments) in enumerate(grouped.items(), start=1):
            selected = document == self.selected_document
            bg = "#EAF2FF" if selected else "#FFFFFF"
            border = PRODUCT_BLUE if selected else BORDER
            frame = ctk.CTkFrame(
                self.output_scroll,
                fg_color=bg,
                corner_radius=5,
                border_width=1,
                border_color=border,
            )
            # Keep the bordered/padded look, but make each row much tighter than
            # the earlier large card version.
            frame.pack(fill="x", padx=3, pady=1)
            frame.grid_columnconfigure(0, weight=1)

            # Compact bordered output row. Use explicit short label heights
            # because CTkLabel defaults to a taller control that creates a
            # large visual gap between the PDF name and page list.
            ctk.CTkLabel(
                frame,
                text=f"{number}.  {document}",
                text_color=PRODUCT_BLUE,
                font=("Segoe UI", 10, "bold" if selected else "normal"),
                anchor="w",
                height=16,
            ).grid(row=0, column=0, sticky="ew", padx=(8, 6), pady=(2, 0))

            pages = ", ".join(str(a.page_number) for a in assignments)
            page_word = "Page" if len(assignments) == 1 else "Pages"
            ctk.CTkLabel(
                frame,
                text=f"{len(assignments)} {page_word}: {pages}",
                text_color=MUTED,
                font=("Segoe UI", 9),
                anchor="w",
                height=15,
            ).grid(row=1, column=0, sticky="ew", padx=(8, 6), pady=(0, 0))

            confidence_text, confidence_color = self.confidence_label_for_assignments(assignments)
            learned_pages = sorted(
                a.page_number for a in assignments if a.page_index in self.memory_applied_pages
            )
            learned_text = (
                f"  ·  ✓ Learned: {', '.join(map(str, learned_pages))}"
                if learned_pages
                else ""
            )
            ctk.CTkLabel(
                frame,
                text=confidence_text + learned_text,
                text_color=(
                    DANGER
                    if confidence_text.startswith("FAIL")
                    else confidence_color if not learned_pages else SUCCESS_GREEN
                ),
                font=("Segoe UI", 9, "bold"),
                anchor="w",
                height=15,
            ).grid(row=2, column=0, sticky="ew", padx=(8, 6), pady=(0, 2))

            self.output_row_widgets[document] = frame
            self.bind_output_row(frame, document)
            for child in frame.winfo_children():
                self.bind_output_row(child, document)

    def bind_output_row(self, widget, document: str):
        # Click to select. Reordering is handled by the Move Up / Move Down
        # buttons because drag reordering was unreliable in this scroll frame.
        widget.bind("<Button-1>", lambda e, d=document: self.on_output_selected(d))

    def on_output_drag_start(self, event, document: str):
        self.dragging_document = document
        self.on_output_selected(document)

    def on_output_drag_motion(self, event, document: str):
        # Keep the selected row visible while dragging. Reordering happens on release.
        self.dragging_document = document

    def on_output_drag_release(self, event, document: str):
        dragging = self.dragging_document or document
        self.dragging_document = None
        if dragging not in self.document_order:
            return

        target = self.output_document_at_pointer()
        if not target or target == dragging or target not in self.document_order:
            return

        old_index = self.document_order.index(dragging)
        new_index = self.document_order.index(target)
        self.document_order.pop(old_index)
        if old_index < new_index:
            new_index -= 1
        self.document_order.insert(new_index, dragging)
        self.selected_document = dragging
        self.refresh_output_cards()

    def output_document_at_pointer(self) -> str | None:
        pointer_y = self.root.winfo_pointery()
        closest_doc = None
        closest_distance = 10**9
        for document, frame in self.output_row_widgets.items():
            try:
                top = frame.winfo_rooty()
                bottom = top + frame.winfo_height()
                mid = (top + bottom) / 2
            except Exception:
                continue
            if top <= pointer_y <= bottom:
                return document
            distance = abs(pointer_y - mid)
            if distance < closest_distance:
                closest_distance = distance
                closest_doc = document
        return closest_doc

    def selected_page_indices(self) -> list[int]:
        return sorted(self.selected_pages)

    def selected_nonblank_page_indices(self) -> list[int]:
        selected = self.selected_page_indices()
        nonblank = [index for index in selected if index not in self.blank_pages]
        if selected and not nonblank:
            messagebox.showinfo(APP_TITLE, "Blank pages are always removed and cannot be assigned to a PDF.")
        return nonblank

    def on_page_selected(self, _event=None):
        selected = self.selected_page_indices()
        if not selected:
            return
        self.selected_document = None
        first = selected[0]
        matches = [a for a in self.assignments if a.page_index == first]
        if matches:
            self.document_var.set(matches[0].document)
        elif first in self.blank_pages:
            self.document_var.set("BLANK PAGE")
        else:
            self.document_var.set("UNSORTED")
        self.refresh_output_cards()
        self.refresh_preview(reset_scroll=True)

    def on_output_selected(self, document):
        self.selected_document = document
        self.document_var.set(document)
        self.selected_pages = {a.page_index for a in self.assignments if a.document == document}
        self.preview_page_position = 0
        self.refresh_output_cards(); self.refresh_page_cards(); self.refresh_preview(reset_scroll=True)

    def move_document(self, direction: int):
        document = self.selected_document
        if not document:
            messagebox.showwarning(APP_TITLE, "Select an output PDF to move.")
            return
        self.sync_document_order()
        if document not in self.document_order:
            return
        old_index = self.document_order.index(document)
        new_index = old_index + direction
        if new_index < 0 or new_index >= len(self.document_order):
            return
        self.push_undo("move output PDF")
        self.document_order[old_index], self.document_order[new_index] = self.document_order[new_index], self.document_order[old_index]
        self.refresh_output_cards()

    def on_preview_resize(self, _event=None):
        canvas_width = max(self.preview_canvas.winfo_width() - 24, 200)
        canvas_height = max(self.preview_canvas.winfo_height() - 24, 200)
        if (canvas_width, canvas_height) != self.preview_cache_size:
            self.clear_preview_cache(); self.preview_cache_size = (canvas_width, canvas_height)
        self.refresh_preview()

    def on_preview_mousewheel(self, event):
        if not self.preview_pages():
            return
        if getattr(event, "num", None) == 4:
            self.preview_canvas.yview_scroll(-3, "units")
        elif getattr(event, "num", None) == 5:
            self.preview_canvas.yview_scroll(3, "units")
        else:
            delta = getattr(event, "delta", 0)
            self.preview_canvas.yview_scroll(int(-1 * (delta / 120)), "units")

    def preview_pages(self) -> list[int]:
        """Pages currently available in the preview.

        When an Output PDF is selected, this returns every source page that belongs
        to that output document in the same order it will export. That lets the
        preview step through all pages in a multi-page output PDF instead of only
        showing the first selected page.
        """
        if self.selected_document:
            grouped = self.grouped_assignments()
            if self.selected_document in grouped:
                return [assignment.page_index for assignment in grouped[self.selected_document]]
        return self.selected_page_indices()

    def update_preview_nav(self, pages: list[int]):
        if not pages:
            self.preview_nav_var.set("")
            try:
                self.preview_prev_button.configure(state="disabled")
                self.preview_next_button.configure(state="disabled")
            except Exception:
                pass
            return
        self.preview_page_position = max(0, min(self.preview_page_position, len(pages) - 1))
        if len(pages) == 1:
            self.preview_nav_var.set(f"Page {pages[0] + 1}")
        else:
            self.preview_nav_var.set(
                f"{self.preview_page_position + 1} of {len(pages)}  ·  Page {pages[self.preview_page_position] + 1}"
            )
        try:
            self.preview_prev_button.configure(state="normal" if self.preview_page_position > 0 else "disabled")
            self.preview_next_button.configure(state="normal" if self.preview_page_position < len(pages) - 1 else "disabled")
        except Exception:
            pass

    def preview_previous_page(self):
        pages = self.preview_pages()
        if not pages:
            return
        self.preview_page_position = max(0, self.preview_page_position - 1)
        self.refresh_preview(reset_scroll=True)

    def preview_next_page(self):
        pages = self.preview_pages()
        if not pages:
            return
        self.preview_page_position = min(len(pages) - 1, self.preview_page_position + 1)
        self.refresh_preview(reset_scroll=True)

    def refresh_preview(self, reset_scroll: bool = False):
        pages = self.preview_pages()
        self.preview_canvas.delete("all")
        self.preview_image_refs = []
        self.preview_page_offsets = []
        if not pages or not self.page_images:
            self.preview_nav_var.set("")
            try:
                self.preview_prev_button.configure(state="disabled")
                self.preview_next_button.configure(state="disabled")
            except Exception:
                pass
            self.preview_canvas.configure(scrollregion=(0, 0, self.preview_canvas.winfo_width(), self.preview_canvas.winfo_height()))
            self.preview_canvas.create_text(max(self.preview_canvas.winfo_width() // 2, 120), max(self.preview_canvas.winfo_height() // 2, 120), text="Select a page to preview it.", fill=MUTED, font=("Segoe UI", 14))
            return

        # Show every page in the selected Output PDF stacked vertically, like a
        # PDF viewer. The left/right buttons still jump between pages, but the
        # mouse wheel can now scroll naturally from page 1 through the last page.
        self.update_preview_nav(pages)
        canvas_width = max(self.preview_canvas.winfo_width() - 34, 200)
        canvas_height = max(self.preview_canvas.winfo_height() - 24, 200)
        y = 12
        gap = 18
        max_image_width = 0

        for position, page_index in enumerate(pages):
            manual_rotation = (
                self.page_manual_rotations[page_index]
                if page_index < len(self.page_manual_rotations)
                else 0
            )
            cache_key = (page_index, canvas_width, manual_rotation)
            if cache_key not in self.preview_cache:
                image = Image.open(self.page_images[page_index]).convert("RGB")
                if manual_rotation:
                    image = image.rotate(-manual_rotation, expand=True)
                scale = canvas_width / max(image.width, 1)
                new_width = max(1, int(image.width * scale))
                new_height = max(1, int(image.height * scale))
                image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
                self.preview_cache[cache_key] = ImageTk.PhotoImage(image)
                # Evict the least-recently-used entry when the cache is full.
                if len(self.preview_cache) > self._preview_cache_max:
                    self.preview_cache.popitem(last=False)
            else:
                # Move the hit entry to the most-recently-used end.
                self.preview_cache.move_to_end(cache_key)

            photo = self.preview_cache[cache_key]
            self.preview_image_refs.append(photo)
            self.preview_page_offsets.append(y)

            image_width = photo.width()
            image_height = photo.height()
            max_image_width = max(max_image_width, image_width)
            x = max(self.preview_canvas.winfo_width() // 2, image_width // 2 + 10)

            if len(pages) > 1:
                self.preview_canvas.create_text(
                    14,
                    y,
                    text=f"Page {position + 1} of {len(pages)}  ·  Source page {page_index + 1}",
                    anchor="nw",
                    fill=MUTED,
                    font=("Segoe UI", 10, "bold"),
                )
                y += 22

            self.preview_canvas.create_image(x, y, image=photo, anchor="n")
            y += image_height + gap

        scroll_height = max(y, self.preview_canvas.winfo_height())
        self.preview_canvas.configure(
            scrollregion=(0, 0, max(self.preview_canvas.winfo_width(), max_image_width + 20), scroll_height)
        )

        if reset_scroll and self.preview_page_offsets:
            target_y = self.preview_page_offsets[self.preview_page_position]
            max_scroll = max(scroll_height - canvas_height, 1)
            self.preview_canvas.yview_moveto(max(0, min(target_y / max_scroll, 1)))

    def normalized_document_name(self) -> str | None:
        name = self.document_var.get().strip()
        if not name:
            messagebox.showwarning(APP_TITLE, "Choose or enter a document name first.")
            return None
        alias = re.sub(r"\s+", " ", name.casefold()).removesuffix(".pdf").strip()
        if alias in {
            "direct deposit",
            "direct deposit authorization",
            "direct deposit authorization form",
            "direct deposit form",
        }:
            return "Viventium Direct Deposit.pdf"
        return safe_filename(name)

    def effective_page_rotation(self, page_index: int) -> int:
        automatic = (
            self.page_rotations[page_index]
            if page_index < len(self.page_rotations)
            else 0
        )
        manual = (
            self.page_manual_rotations[page_index]
            if page_index < len(self.page_manual_rotations)
            else 0
        )
        return (automatic + manual) % 360

    def push_undo(self, description: str):
        # deque(maxlen=20) automatically drops the oldest entry when full —
        # no manual pop(0) needed (and pop(0) on a list was O(n) anyway).
        self.undo_stack.append(
            {
                "description": description,
                "assignments": [
                    Assignment(
                        item.page_index,
                        item.document,
                        item.rotation,
                        item.sequence,
                    )
                    for item in self.assignments
                ],
                "document_order": list(self.document_order),
                "manual_rotations": list(self.page_manual_rotations),
                "selected_pages": set(self.selected_pages),
                "selected_document": self.selected_document,
                "custom_document_types": set(self.custom_document_types),
            }
        )

    def undo_last_change(self):
        if not self.undo_stack:
            messagebox.showinfo(APP_TITLE, "There is no change to undo.")
            return
        state = self.undo_stack.pop()
        self.assignments = state["assignments"]
        self.document_order = state["document_order"]
        self.page_manual_rotations = state["manual_rotations"]
        self.selected_pages = state["selected_pages"]
        self.selected_document = state["selected_document"]
        self.custom_document_types = state["custom_document_types"]
        self.refresh_document_choices()
        self.clear_preview_cache()
        self.refresh_all_views()
        self.status_var.set(f"Undid: {state['description']}.")

    def rotate_selected_pages(self, degrees: int):
        pages = self.selected_nonblank_page_indices()
        if not pages:
            return
        self.push_undo(
            "rotate selected pages right" if degrees > 0 else "rotate selected pages left"
        )
        if len(self.page_manual_rotations) < len(self.page_rotations):
            self.page_manual_rotations.extend(
                [0] * (len(self.page_rotations) - len(self.page_manual_rotations))
            )
        for page in pages:
            self.page_manual_rotations[page] = (
                self.page_manual_rotations[page] + degrees
            ) % 360
            effective_rotation = self.effective_page_rotation(page)
            for assignment in self.assignments:
                if assignment.page_index == page:
                    assignment.rotation = effective_rotation
        self.clear_preview_cache()
        self.refresh_all_views()
        direction = "right" if degrees > 0 else "left"
        self.status_var.set(
            f"Rotated {len(pages)} selected page"
            + ("" if len(pages) == 1 else "s")
            + f" {direction}."
        )

    def refresh_document_choices(self):
        choices = list(self.rules["document_types"])
        for document in sorted(self.custom_document_types, key=str.lower):
            if document not in choices:
                choices.append(document)
        self.document_combo.configure(values=choices)

    def assign_to_document(self):
        pages = self.selected_nonblank_page_indices()
        document = self.normalized_document_name()
        if not pages or not document:
            return
        self.push_undo("assign selected pages")
        self.assignments = [item for item in self.assignments if item.page_index not in pages]
        for page in pages:
            self.assignments.append(
                Assignment(
                    page,
                    document,
                    self.effective_page_rotation(page),
                    None,
                )
            )
            if document == "Banking.pdf":
                self.assignments.append(
                    Assignment(
                        page,
                        "Viventium Direct Deposit.pdf",
                        self.effective_page_rotation(page),
                        None,
                    )
                )
        self.refresh_all_views()
        if document == "Banking.pdf":
            self.status_var.set(
                "Assigned to Banking and automatically included with Direct Deposit."
            )
        else:
            self.status_var.set("Assigned to document.")

    def remove_assignments(self):
        pages = self.selected_page_indices()
        if not pages:
            return
        self.push_undo("mark selected pages unsorted")
        self.assignments = [item for item in self.assignments if item.page_index not in pages]
        self.selected_document = None
        self.document_var.set("UNSORTED")
        self.refresh_all_views(); self.status_var.set("Selected pages marked as unsorted.")

    def rename_document(self):
        old_name = self.selected_document
        if not old_name:
            messagebox.showwarning(APP_TITLE, "Select an output PDF to rename.")
            return
        new_name = simpledialog.askstring(APP_TITLE, "New PDF filename:", initialvalue=old_name)
        if not new_name:
            return
        new_name = safe_filename(new_name)
        self.push_undo("rename output")
        for assignment in self.assignments:
            if assignment.document == old_name:
                assignment.document = new_name
        if old_name in self.custom_document_types:
            self.custom_document_types.remove(old_name)
            self.custom_document_types.add(new_name)
            self.refresh_document_choices()
        if old_name in self.document_order:
            self.document_order[self.document_order.index(old_name)] = new_name
        self.selected_document = new_name
        self.refresh_all_views(); self.document_var.set(new_name)

    def remember_correction(self):
        pages = self.selected_nonblank_page_indices()
        document = self.normalized_document_name() if pages else None
        remembered = 0
        learned_rules = 0
        learned_phrases: list[str] = []
        document_added = False
        if document:
            for page in pages:
                signature = self.correction_signature(self.ocr_texts[page])
                if len(signature) < 12:
                    continue
                self.correction_memory = [
                    entry
                    for entry in self.correction_memory
                    if entry.get("signature") != signature
                ]
                self.correction_memory.append(
                    {"document": document, "signature": signature}
                )
                remembered += 1
            if (
                remembered
                and document not in self.rules["document_types"]
            ):
                self.rules["document_types"].append(document)
                self.custom_document_types.discard(document)
                document_added = True
            learned_rules, learned_phrases = self.learn_document_rules(
                document,
                pages,
            )

        self.sync_document_order()
        order_saved = bool(self.document_order)
        if order_saved:
            self.preferred_document_order = list(self.document_order)

        if not remembered and not learned_rules and not order_saved:
            messagebox.showwarning(
                APP_TITLE,
                "There is not enough readable, stable text to learn this page, "
                "and there is no output order to remember.",
            )
            return
        rules_saved = (
            self.save_rules()
            if document_added or learned_rules
            else True
        )
        if rules_saved and self.save_correction_memory():
            saved_parts = []
            if remembered:
                saved_parts.append(
                    f"{remembered} page correction"
                    + ("" if remembered == 1 else "s")
                )
            if document_added:
                saved_parts.append(f"{document} in this profile")
            if learned_rules:
                saved_parts.append(
                    f"{learned_rules} recognition rule"
                    + ("" if learned_rules == 1 else "s")
                )
            if order_saved:
                saved_parts.append("the current PDF output order")
            self.status_var.set(
                "Remembered "
                + " and ".join(saved_parts)
                + " for future packets."
            )
            if learned_rules:
                phrase_preview = "\n".join(
                    f"  - {phrase}" for phrase in learned_phrases[:5]
                )
                messagebox.showinfo(
                    APP_TITLE,
                    "PacketFlow learned how to recognize this document in "
                    f"the {self.active_profile_name} profile.\n\n"
                    "Identifying phrases saved:\n"
                    + phrase_preview
                    + "\n\nYou can edit or remove this rule in "
                    "Settings > Manage Document Rules.",
                )
            if pages and not remembered and not learned_rules:
                messagebox.showinfo(
                    APP_TITLE,
                    "The selected page did not contain enough readable text for "
                    "template matching. The PDF output order was still saved.",
                )

    def show_memory_manager(self):
        proceed = messagebox.askyesno(
            APP_TITLE,
            "Open remembered settings?\n\n"
            "Deleting remembered page corrections or the saved PDF order affects "
            "future packets. The current packet will not be changed.\n\n"
            "Continue?",
        )
        if not proceed:
            return
        window = ctk.CTkToplevel(self.root)
        window.title("Remembered Settings")
        window.geometry("470x310")
        window.resizable(False, False)
        window.transient(self.root)
        window.grab_set()

        ctk.CTkLabel(
            window,
            text="Remembered Settings",
            text_color=CARD_NAVY,
            font=("Segoe UI", 18, "bold"),
        ).pack(anchor="w", padx=20, pady=(18, 5))
        summary_var = tk.StringVar()

        def update_summary():
            summary_var.set(
                f"Saved page corrections: {len(self.correction_memory)}\n"
                f"Saved PDF order entries: {len(self.preferred_document_order)}"
            )

        def clear_page_corrections():
            if not messagebox.askyesno(
                APP_TITLE,
                "Delete all remembered page assignments?\n\n"
                "This cannot be undone.",
                parent=window,
            ):
                return
            self.correction_memory = []
            self.save_correction_memory()
            update_summary()

        def clear_output_order():
            if not messagebox.askyesno(
                APP_TITLE,
                "Delete the remembered Output PDFs order?\n\n"
                "Future packets will return to the default order.",
                parent=window,
            ):
                return
            self.preferred_document_order = []
            self.save_correction_memory()
            update_summary()

        def clear_everything():
            if not messagebox.askyesno(
                APP_TITLE,
                "Delete every remembered correction and the saved PDF order?\n\n"
                "This cannot be undone.",
                parent=window,
            ):
                return
            self.correction_memory = []
            self.preferred_document_order = []
            self.save_correction_memory()
            update_summary()

        ctk.CTkLabel(
            window,
            textvariable=summary_var,
            text_color=TEXT,
            font=("Segoe UI", 12),
            justify="left",
        ).pack(anchor="w", padx=20, pady=(5, 14))
        update_summary()

        ctk.CTkButton(
            window,
            text="Clear Page Corrections",
            command=clear_page_corrections,
            fg_color="#FFFFFF",
            hover_color="#FFF8E8",
            border_width=1,
            border_color="#C78B22",
            text_color="#7A5418",
            height=34,
        ).pack(fill="x", padx=20, pady=4)
        ctk.CTkButton(
            window,
            text="Clear Saved PDF Order",
            command=clear_output_order,
            fg_color="#FFFFFF",
            hover_color="#FFF8E8",
            border_width=1,
            border_color="#C78B22",
            text_color="#7A5418",
            height=34,
        ).pack(fill="x", padx=20, pady=4)
        ctk.CTkButton(
            window,
            text="Clear All Remembered Settings",
            command=clear_everything,
            fg_color="#FFFFFF",
            hover_color="#FBEAEA",
            border_width=1,
            border_color=WARNING,
            text_color=WARNING,
            height=34,
        ).pack(fill="x", padx=20, pady=4)
        ctk.CTkButton(
            window,
            text="Close",
            command=window.destroy,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
            height=34,
        ).pack(fill="x", padx=20, pady=(12, 16))

    @staticmethod
    def format_page_list(pages, limit: int = 18) -> str:
        values = [str(page) for page in pages]
        if len(values) <= limit:
            return ", ".join(values) if values else "None"
        return ", ".join(values[:limit]) + f", and {len(values) - limit} more"

    def review_details(self) -> dict:
        grouped = self.grouped_assignments()
        found = set(grouped)
        expected = self.rules.get("expected_document_types", [])
        found_expected = [document for document in expected if document in found]
        missing = [document for document in expected if document not in found]
        assigned_by_page: dict[int, list[str]] = {}
        for assignment in self.assignments:
            if assignment.page_index in self.blank_pages:
                continue
            assigned_by_page.setdefault(assignment.page_index, []).append(
                assignment.document
            )
        unsorted = [
            index + 1
            for index in range(len(self.reader.pages) if self.reader else 0)
            if index not in self.blank_pages and index not in assigned_by_page
        ]
        multiple = {
            index + 1: list(dict.fromkeys(documents))
            for index, documents in assigned_by_page.items()
            if len(set(documents)) > 1
        }
        output_failures = {
            document: result["issues"]
            for document, assignments in grouped.items()
            if not (
                result := self.output_completeness_details(assignments)
            )["complete"]
        }
        return {
            "grouped": grouped,
            "found_expected": found_expected,
            "missing": missing,
            "output_failures": output_failures,
            "unsorted": unsorted,
            "multiple": multiple,
            "duplicates": [
                (left + 1, right + 1) for left, right in self.duplicate_pairs
            ],
            "low_confidence": sorted(
                page + 1 for page in self.low_confidence_pages
            ),
            "scan_quality": {
                page + 1: list(issues)
                for page, issues in sorted(self.page_quality_warnings.items())
            },
            "blank": sorted(page + 1 for page in self.blank_pages),
            "rotated": [
                index + 1
                for index in range(len(self.page_rotations))
                if self.effective_page_rotation(index)
            ],
            "memory": sorted(page + 1 for page in self.memory_applied_pages),
        }

    def build_review_summary(self) -> str:
        details = self.review_details()
        found_names = list(details["grouped"])
        lines = [
            "EXPECTED DOCUMENT CHECKLIST",
            f"Profile: {self.active_profile_name}",
            f"Found: {len(found_names)} output PDFs",
        ]
        if details["found_expected"]:
            lines.append("Found expected:")
            lines.extend(
                f"  - {name}" for name in details["found_expected"]
            )
        else:
            lines.append("Found expected: None")
        if details["missing"]:
            lines.append("Missing expected:")
            lines.extend(f"  - {name}" for name in details["missing"])
        else:
            lines.append("Missing expected: None")

        lines.extend(["", "OUTPUT COMPLETENESS"])
        if details["output_failures"]:
            for document, issues in details["output_failures"].items():
                lines.append(f"FAIL - {document}")
                lines.extend(f"  - {issue}" for issue in issues)
        else:
            lines.append("All checked output PDFs are complete")

        lines.extend(
            [
                "",
                "PAGE REVIEW",
                "Unsorted pages: "
                + self.format_page_list(details["unsorted"]),
                "Blank pages removed: "
                + self.format_page_list(details["blank"]),
                "Pages rotated for orientation: "
                + self.format_page_list(details["rotated"]),
                "Remembered corrections applied: "
                + self.format_page_list(details["memory"]),
            ]
        )
        if self.setting_enabled("show_low_confidence_warnings"):
            lines.append(
                "Low-confidence pages: "
                + self.format_page_list(details["low_confidence"])
            )
        if self.setting_enabled("scan_quality_checks_enabled"):
            lines.extend(["", "SCAN QUALITY PRE-FLIGHT"])
            if details["scan_quality"]:
                for page, issues in details["scan_quality"].items():
                    lines.append(f"Page {page}: " + "; ".join(issues))
                lines.append("Review flagged pages before export. Continue only after confirming the scan is acceptable.")
            else:
                lines.append("No obvious scan-quality issues detected")
        if self.setting_enabled("show_duplicate_warnings"):
            if details["duplicates"]:
                duplicate_text = ", ".join(
                    f"{left}/{right}" for left, right in details["duplicates"]
                )
                lines.append(
                    "Suspected duplicate page pairs: " + duplicate_text
                )
            else:
                lines.append("Suspected duplicate page pairs: None")
        if details["multiple"]:
            multiple_text = "; ".join(
                f"{page}: {', '.join(documents)}"
                for page, documents in details["multiple"].items()
            )
            lines.append("Pages used in multiple PDFs: " + multiple_text)
        else:
            lines.append("Pages used in multiple PDFs: None")
        return "\n".join(lines)

    def show_packet_review(self):
        if not self.reader:
            return
        self.show_review_dialog(confirm=False)

    def show_review_dialog(self, confirm: bool) -> bool:
        summary = self.build_review_summary()
        lines = summary.splitlines()
        body_font = tkfont.Font(family="Segoe UI", size=11)
        longest_line = max(
            (body_font.measure(line) for line in lines),
            default=520,
        )
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        window_width = min(
            max(620, longest_line + 90),
            max(620, screen_width - 120),
        )
        window_height = min(
            max(460, len(lines) * 22 + (150 if confirm else 120)),
            max(460, screen_height - 140),
        )

        result = {"accepted": False}
        window = ctk.CTkToplevel(self.root)
        window.title("Review Packet")
        window.geometry(f"{window_width}x{window_height}")
        window.minsize(620, 460)
        window.transient(self.root)
        window.grab_set()

        ctk.CTkLabel(
            window,
            text="Packet Review",
            text_color=CARD_NAVY,
            font=("Segoe UI", 19, "bold"),
        ).pack(anchor="w", padx=20, pady=(16, 8))

        review_text = ctk.CTkTextbox(
            window,
            wrap="none",
            fg_color="#FFFFFF",
            text_color=TEXT,
            border_width=1,
            border_color=BORDER,
            font=("Segoe UI", 11),
        )
        review_text.pack(fill="both", expand=True, padx=20, pady=(0, 12))
        review_text.insert("1.0", summary)
        review_text.configure(state="disabled")

        def finish(accepted: bool):
            result["accepted"] = accepted
            window.destroy()

        button_row = ctk.CTkFrame(window, fg_color="transparent")
        button_row.pack(fill="x", padx=20, pady=(0, 16))
        if self.duplicate_pairs:
            ctk.CTkButton(
                button_row,
                text="Review Duplicates",
                command=self.show_duplicate_review,
                fg_color="#FFFFFF",
                hover_color="#FFF8E8",
                border_width=1,
                border_color="#C78B22",
                text_color="#7A5418",
                width=145,
            ).pack(side="left")
        if confirm:
            ctk.CTkButton(
                button_row,
                text="Cancel",
                command=lambda: finish(False),
                fg_color="#FFFFFF",
                hover_color="#F8FAFC",
                border_width=1,
                border_color="#CBD5E1",
                text_color=TEXT,
                width=110,
            ).pack(side="right")
            ctk.CTkButton(
                button_row,
                text="Continue with Export",
                command=lambda: finish(True),
                fg_color=PRODUCT_BLUE,
                hover_color=SUCCESS_GREEN,
                width=165,
            ).pack(side="right", padx=(0, 8))
            window.protocol("WM_DELETE_WINDOW", lambda: finish(False))
        else:
            ctk.CTkButton(
                button_row,
                text="Close",
                command=lambda: finish(True),
                fg_color=PRODUCT_BLUE,
                hover_color=SUCCESS_GREEN,
                width=110,
            ).pack(side="right")
            window.protocol("WM_DELETE_WINDOW", lambda: finish(True))

        window.update_idletasks()
        x = max(0, (screen_width - window.winfo_width()) // 2)
        y = max(0, (screen_height - window.winfo_height()) // 2)
        window.geometry(f"+{x}+{y}")
        self.root.wait_window(window)
        return result["accepted"]

    @staticmethod
    def suggest_packet_name(stem: str) -> str:
        raw = re.sub(r"\s+", " ", stem.strip()).strip(" _-")

        # Remove scanner / packet counters first.
        raw = re.sub(
            r"(?i)[ _-]+(?:scan|packet)?[ _-]*\d+$",
            "",
            raw,
        ).strip(" _-")

        # The first source file is often a document, for example
        # Ford_Laurie_Application.pdf.  That document label should not become
        # part of the employee packet name or export folder.
        document_suffixes = (
            "careco job application",
            "job application",
            "application",
            "orientation agenda",
            "auto enrollment opt out",
            "child protective services authorization",
            "employee choice acknowledgement waiver",
            "federal w 4 withholding",
            "federal w4 withholding",
            "form i 9 employment eligibility verification",
            "job description",
            "payroll",
            "viventium direct deposit",
            "banking",
            "baking",
            "birth marriage certs",
            "birth marriage certificates",
            "birth and marriage certificates",
            "cherkr auth",
            "cherkr authorization",
            "interview statement",
            "mbc auth",
            "mbc authorization",
            "mbc clearance",
            "mbc payment",
            "time recording",
            "confirmation child abuse registry background check request",
        )

        def normalized(value: str) -> str:
            return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()

        norm_raw = normalized(raw)
        for suffix in sorted(document_suffixes, key=len, reverse=True):
            norm_suffix = normalized(suffix)
            if norm_raw == norm_suffix:
                break
            if norm_raw.endswith(" " + norm_suffix):
                # Remove the suffix from the original string using a tolerant
                # regex so underscores, hyphens, and spaces all work.
                suffix_pattern = r"[ _-]+".join(re.escape(part) for part in norm_suffix.split())
                raw = re.sub(
                    rf"(?i)[ _-]+{suffix_pattern}$",
                    "",
                    raw,
                ).strip(" _-")
                break

        underscore_parts = [part for part in raw.split("_") if part]
        if "_" in raw and len(underscore_parts) == 2:
            # Employee folders/files commonly use Last_First.  Export folders
            # should be First Last.
            raw = f"{underscore_parts[1]} {underscore_parts[0]}"
        else:
            raw = re.sub(r"[_-]+", " ", raw)

        return " ".join(
            word if word.isupper() and len(word) <= 4 else word.title()
            for word in raw.split()
        )

    def current_packet_stem(self) -> str:
        if self.packet_base_stem:
            return self.packet_base_stem
        if self.packet_display_name:
            display_name = self.packet_display_name.strip()
            if display_name.lower().endswith(".pdf"):
                return Path(display_name).stem
            return display_name
        if self.pdf_path:
            return self.pdf_path.stem
        return "Ad Hoc Packet"

    def confirm_packet_name(self) -> str | None:
        if not self.pdf_path:
            return None
        packet_stem = self.current_packet_stem()
        original = safe_folder_name(packet_stem)
        suggested = safe_folder_name(self.suggest_packet_name(packet_stem))
        if self.export_packet_name:
            return self.export_packet_name
        if suggested == original:
            self.export_packet_name = original
            return original
        answer = messagebox.askyesnocancel(
            APP_TITLE,
            "Use this cleaned packet name for the output folder and PDF prefix?\n\n"
            f"{suggested}\n\n"
            f"Yes: use {suggested}\n"
            f"No: keep {original}",
        )
        if answer is None:
            return None
        self.export_packet_name = suggested if answer else original
        return self.export_packet_name

    def cleanup_work_files(self):
        self.clear_preview_cache()
        if self.work_dir and self.work_dir.exists():
            shutil.rmtree(self.work_dir, ignore_errors=True)
        self.work_dir = None
        for directory in self.additional_work_dirs:
            if directory.exists():
                shutil.rmtree(directory, ignore_errors=True)
        self.additional_work_dirs.clear()
        if self.manual_packet_dir and self.manual_packet_dir.exists():
            shutil.rmtree(self.manual_packet_dir, ignore_errors=True)
        self.manual_packet_dir = None
        for directory in self.retired_manual_dirs:
            if directory.exists():
                shutil.rmtree(directory, ignore_errors=True)
        self.retired_manual_dirs.clear()
        self.page_images = []

    def clear_loaded_packet(self, status: str = "Open a PDF packet to begin."):
        self.cleanup_work_files()
        self.pdf_path = None
        self.reader = None
        self.packet_source_paths = []
        self.packet_display_name = None
        self.packet_base_stem = None
        self.pending_append_state = None
        self.export_packet_name = None
        self.packet_exported = True
        self.current_packet_from_watch = False
        self.assignments.clear()
        self.ocr_texts.clear()
        self.page_rotations.clear()
        self.page_manual_rotations.clear()
        self.blank_pages.clear()
        self.page_fingerprints.clear()
        self.duplicate_pairs.clear()
        self.low_confidence_pages.clear()
        self.page_quality_warnings.clear()
        self.memory_applied_pages.clear()
        self.document_order.clear()
        self.custom_document_types.clear()
        self.undo_stack.clear()
        self.selected_pages.clear()
        self.selected_document = None
        self.preview_page_position = 0
        self.document_var.set("")
        self.packet_filename_var.set("Original PDF: No packet selected")
        self.root.title(APP_TITLE)
        self.progress_var.set(0)
        self.progress.set(0)
        self.progress_label_var.set("0%")
        self.refresh_document_choices()
        self.refresh_all_views()
        self.status_var.set(status)

    def choose_output_folder(self, packet_name: str) -> Path | None:
        if not self.pdf_path:
            return None
        source_parent = (
            self.packet_source_paths[0].parent
            if self.packet_source_paths
            else self.pdf_path.parent
        )
        initial_folder = self.export_parent_folder or source_parent
        selected = filedialog.askdirectory(
            title=f"Choose where to save the {packet_name} folder",
            initialdir=str(initial_folder),
            mustexist=True,
        )
        if not selected:
            return None
        chosen_folder = Path(selected)
        if chosen_folder.name.casefold() == packet_name.casefold():
            self.export_parent_folder = chosen_folder.parent
            destination = chosen_folder
        else:
            self.export_parent_folder = chosen_folder
            destination = chosen_folder / packet_name
        if self.setting_enabled("remember_last_export_location"):
            self.settings["last_export_location"] = str(self.export_parent_folder)
            self.save_settings()
        return destination

    def export_to_last_location(self):
        if not self.export_parent_folder or not self.export_parent_folder.is_dir():
            messagebox.showinfo(APP_TITLE, "No previous export folder is saved yet.")
            return
        if not self.reader or not self.pdf_path or not self.assignments:
            return
        packet_name = self.confirm_packet_name()
        if not packet_name:
            return
        destination = self.export_parent_folder / packet_name
        self.export_pdfs(automatic=False, destination_override=destination)

    def show_duplicate_review(self):
        if not self.duplicate_pairs:
            messagebox.showinfo(APP_TITLE, "No suspected duplicate pages were found.")
            return
        window = ctk.CTkToplevel(self.root)
        window.title("Duplicate Page Review")
        window.geometry("980x680")
        window.minsize(860, 560)
        window.transient(self.root)
        window.grab_set()
        ctk.CTkLabel(window, text="Suspected Duplicate Pages", text_color=CARD_NAVY, font=("Segoe UI", 19, "bold")).pack(anchor="w", padx=18, pady=(16, 4))
        ctk.CTkLabel(window, text="Compare the page images. If one is truly a duplicate, select it in the main page list and mark it unsorted before export.", text_color=MUTED, font=("Segoe UI", 11), wraplength=900, justify="left").pack(anchor="w", padx=18, pady=(0, 10))
        scroll = ctk.CTkScrollableFrame(window, fg_color="#FFFFFF", border_width=1, border_color=BORDER)
        scroll.pack(fill="both", expand=True, padx=18, pady=(0, 12))
        self._duplicate_review_images = []
        for left, right in self.duplicate_pairs:
            row = ctk.CTkFrame(scroll, fg_color="#F8FAFC", corner_radius=6, border_width=1, border_color=BORDER)
            row.pack(fill="x", padx=8, pady=8)
            ctk.CTkLabel(row, text=f"Pages {left + 1} and {right + 1}", text_color=TEXT, font=("Segoe UI", 13, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", padx=10, pady=(8, 5))
            for col, page_index in enumerate((left, right)):
                try:
                    img = Image.open(self.page_images[page_index]).convert("RGB")
                    img.thumbnail((360, 460))
                    photo = ImageTk.PhotoImage(img)
                    self._duplicate_review_images.append(photo)
                    label = ctk.CTkLabel(row, image=photo, text="")
                    label.grid(row=1, column=col, padx=10, pady=(0, 6))
                    ctk.CTkLabel(row, text=f"Page {page_index + 1}", text_color=MUTED, font=("Segoe UI", 11, "bold")).grid(row=2, column=col, pady=(0, 8))
                except Exception:
                    ctk.CTkLabel(row, text=f"Page {page_index + 1} preview unavailable", text_color=WARNING).grid(row=1, column=col, padx=10, pady=10)
        ctk.CTkButton(window, text="Close", command=window.destroy, fg_color=PRODUCT_BLUE, hover_color=SUCCESS_GREEN, width=110).pack(anchor="e", padx=18, pady=(0, 16))

    def export_pdfs(self, automatic: bool = False, destination_override: Path | None = None):
        if not self.reader or not self.pdf_path or not self.assignments:
            return
        if automatic and self.setting_enabled("scan_quality_checks_enabled") and self.page_quality_warnings:
            self.status_var.set("Automatic export paused: review scan-quality warnings before export.")
            self.notify_user(
                "Packet Needs Scan Review",
                f"{len(self.page_quality_warnings)} page(s) have scan-quality warnings. Review the packet before exporting.",
            )
            self.root.after(150, lambda: self.show_review_dialog(confirm=False))
            return
        if automatic:
            packet_name = safe_folder_name(
                self.suggest_packet_name(self.current_packet_stem())
            ) or safe_folder_name(self.current_packet_stem())
            self.export_packet_name = packet_name
        else:
            packet_name = self.confirm_packet_name()
        if not packet_name:
            return
        destination = destination_override or self.choose_output_folder(packet_name)
        if not destination:
            return
        ordered_groups = list(self.grouped_assignments().items())
        target_names = [
            safe_filename(document)
            for document, _assignments in ordered_groups
        ]
        target_names.append("Export Audit Log.txt")
        if not automatic:
            if not self.show_review_dialog(confirm=True):
                return
        if destination.exists():
            existing_files = [
                path.name for path in destination.iterdir() if path.is_file()
            ]
            replacements = [
                name for name in target_names if name in existing_files
            ]
            preserved = [
                name
                for name in existing_files
                if name not in replacements
            ]
            message = (
                "The output folder already exists:\n\n"
                + str(destination)
                + "\n\nFiles that will be replaced:\n"
                + ("\n".join(f"  - {name}" for name in replacements) or "  None")
                + "\n\nOther existing files that will remain untouched:\n"
                + (
                    "\n".join(f"  - {name}" for name in preserved[:12])
                    or "  None"
                )
            )
            if len(preserved) > 12:
                message += f"\n  - and {len(preserved) - 12} more"
            message += "\n\nContinue?"
            proceed = messagebox.askyesno(APP_TITLE, message)
            if not proceed:
                return
        try:
            destination.mkdir(parents=True, exist_ok=True)
            written = []
            newest_time = time.time()
            for order_index, (document, assignments) in enumerate(ordered_groups):
                writer = PdfWriter()
                for assignment in assignments:
                    page = copy.deepcopy(self.reader.pages[assignment.page_index])
                    if assignment.rotation:
                        page.rotate(assignment.rotation)
                    writer.add_page(page)
                output_path = destination / safe_filename(document)
                with output_path.open("wb") as handle:
                    writer.write(handle)
                modified_time = newest_time - (order_index * 60)
                os.utime(output_path, (modified_time, modified_time))
                written.append(output_path.name)
            self.write_packet_metadata(destination)
            # lightweight audit trail
            audit_path = destination / "Export Audit Log.txt"
            with audit_path.open("w", encoding="utf-8") as audit:
                audit.write(
                    f"Packet: {self.packet_display_name or self.pdf_path.name}\n"
                    f"Profile: {self.active_profile_name}\n"
                    f"Exported: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                )
                if self.packet_source_paths:
                    audit.write("Source PDFs:\n")
                    for source_path in self.packet_source_paths:
                        audit.write(f"  - {source_path.name}\n")
                    audit.write("\n")
                for document, assignments in ordered_groups:
                    audit.write(f"{document}: pages {', '.join(str(a.page_number) for a in assignments)}\n")
                audit.write("\n" + self.build_review_summary() + "\n")
            audit_time = newest_time - (len(ordered_groups) * 60)
            os.utime(audit_path, (audit_time, audit_time))
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Export failed:\n\n{exc}")
            return
        export_status = (
            f"Exported {len(written)} PDFs + Export Audit Log.txt to {destination}."
        )
        self.ledger_call(
            "record_packet_export",
            employee=destination.name,
            profile=self.active_profile_name,
            source_paths=self.packet_source_paths or ([self.pdf_path] if self.pdf_path else []),
            destination_path=destination,
            written_files=written,
            review_summary=self.build_review_summary(),
        )
        self.update_review_queue_badge()
        self.clear_loaded_packet(export_status)
        report = (
            f"Finished. Exported {len(written)} PDFs to:\n\n{destination}\n\n"
            + "\n".join(f"  - {name}" for name in written)
            + "\n  - Export Audit Log.txt\n\n"
            + "Temporary OCR images have been deleted.\n\n"
            + "Open the output folder now?"
        )
        if automatic:
            self.notify_user(
                "Packet Exported",
                f"Exported {len(written)} PDFs to {destination}.",
            )
        elif messagebox.askyesno(APP_TITLE, report):
            try:
                os.startfile(destination)
            except Exception as exc:
                messagebox.showerror(
                    APP_TITLE,
                    "The folder could not be opened.\n\n" + str(exc),
                )
        self.root.after(250, self.process_watch_queue)

    def close(self):
        if not self.exiting:
            self.minimize_to_tray()
            self.status_var.set("Still running. Use the tray menu to exit.")
            self.notify_user(
                "Still Running",
                "PacketFlow is running in the system tray.",
            )
            return
        self.exit_application()


def main():
    configure_windows_app_identity()
    if not acquire_single_instance():
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showinfo(
                APP_TITLE,
                "PacketFlow is already running.",
            )
            root.destroy()
        except Exception:
            pass
        return
    root = ctk.CTk()
    app = PacketSorterApp(root)
    if not (app.setting_enabled("start_minimized_to_tray") and app.watch_enabled):
        root.after(100, lambda: root.state("zoomed"))
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        report_fatal_error(exc)
        raise
