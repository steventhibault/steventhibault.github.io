@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_installer.ps1"
if errorlevel 1 (
  echo.
  echo The single-file Windows EXE was not built. Press any key to close.
  pause >nul
)
exit /b %errorlevel%
