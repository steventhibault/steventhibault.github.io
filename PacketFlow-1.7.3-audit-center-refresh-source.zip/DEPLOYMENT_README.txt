PACKETFLOW 1.7.3 DEPLOYMENT OPTIONS
===================================

EDITABLE SOURCE
---------------
Keep PacketFlow-1.7.3-source.zip as the editable master. Future revisions should
be applied to that source package, tested, then repackaged.

IMMEDIATE OFFICE INSTALLATION
-----------------------------
Extract PacketFlow-1.7.3-office-installer.zip on a Windows computer and double-
click:

  PacketFlow Setup.cmd

This installs or updates PacketFlow under the current Windows user's LocalAppData
Programs folder, creates Desktop and Start Menu shortcuts, registers an uninstall
entry under Windows Apps, preserves AppData rules/settings/history, and launches
the normal dependency checker.

OPTIONAL SINGLE-FILE WINDOWS SETUP.EXE
--------------------------------------
The source package includes an Inno Setup project. On a Windows development
computer with Inno Setup 6 installed, double-click:

  Build PacketFlow Setup.cmd

The resulting file is created under:

  Output\PacketFlow-Setup-1.7.3.exe

If runtime\python and runtime\tools are staged before building, the Setup EXE
includes those isolated runtime files. Without staged runtime files, the Setup EXE
acts as a bootstrap installer and PacketFlow's launcher offers to install missing
components.

UPGRADE SAFETY
--------------
Program code is installed under LocalAppData\Programs\PacketFlow.
Mutable state remains under AppData\PacketFlow, including editable rules,
settings, learned corrections, Review Queue, and Packet History. Installing an
update replaces program files without overwriting mutable AppData state.
