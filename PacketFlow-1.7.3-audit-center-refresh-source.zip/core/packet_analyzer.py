from __future__ import annotations

import glob
import os
import re
import shutil
import subprocess
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageFilter, ImageOps, ImageStat
from pypdf import PdfReader

OCR_WORKERS = min(8, max(2, os.cpu_count() or 4))
TESSERACT_BASE_ARGS = ["--oem", "1", "-c", "preserve_interword_spaces=1"]

@dataclass
class Assignment:
    page_index: int
    document: str
    rotation: int = 0
    sequence: float | None = None

    @property
    def page_number(self) -> int:
        return self.page_index + 1


def find_program(name: str, common_paths: list[str]) -> str | None:
    located = shutil.which(name)
    if located:
        return located
    for raw_path in common_paths:
        expanded = os.path.expandvars(raw_path)
        matches = sorted(glob.glob(expanded), reverse=True)
        if matches:
            return matches[0]
    return None


class PacketAnalyzer:
    def __init__(self, rules: dict):
        self.rules = rules
        self.pdftoppm = find_program(
            "pdftoppm",
            [
                r"C:\Program Files\poppler-*\Library\bin\pdftoppm.exe",
                r"C:\Program Files\poppler\Library\bin\pdftoppm.exe",
                r"C:\Program Files (x86)\poppler-*\Library\bin\pdftoppm.exe",
            ],
        )
        self.tesseract = find_program(
            "tesseract",
            [
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            ],
        )

    def check_dependencies(self) -> None:
        missing = []
        if not self.pdftoppm:
            missing.append("Poppler (pdftoppm)")
        if not self.tesseract:
            missing.append("Tesseract OCR")
        if missing:
            raise RuntimeError(
                "Missing required software: "
                + ", ".join(missing)
                + ". Close the app and run 'Start PacketFlow.cmd' "
                + "to receive installation help."
            )

    def analyze(
        self,
        pdf_path: Path,
        work_dir: Path,
        progress_callback,
    ) -> tuple[
        list[Path],
        list[str],
        list[Assignment],
        list[int],
        set[int],
        list[int],
    ]:
        self.check_dependencies()
        reader = PdfReader(str(pdf_path))
        page_count = len(reader.pages)
        image_prefix = work_dir / "page"

        progress_callback(2, "Rendering packet pages...")
        subprocess.run(
            [
                self.pdftoppm,
                "-jpeg",
                "-r",
                "110",
                "-jpegopt",
                "quality=78",
                str(pdf_path),
                str(image_prefix),
            ],
            check=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )

        images = sorted(work_dir.glob("page-*.jpg"))
        if len(images) != page_count:
            raise RuntimeError(
                f"Rendered {len(images)} page images, but the PDF has {page_count} pages."
            )

        ocr_texts: list[str] = [""] * page_count
        rotations: list[int] = [0] * page_count
        blank_pages: set[int] = set()
        fingerprints: list[int] = [0] * page_count
        worker_count = min(OCR_WORKERS, page_count)
        completed = 0
        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            future_pages = {
                executor.submit(
                    self.analyze_page,
                    index,
                    image_path,
                    work_dir,
                    pdf_path,
                ): index
                for index, image_path in enumerate(images)
            }
            for future in as_completed(future_pages):
                index, text, rotation, is_blank, fingerprint = future.result()
                ocr_texts[index] = text
                rotations[index] = rotation
                fingerprints[index] = fingerprint
                if is_blank:
                    blank_pages.add(index)
                completed += 1
                percent = 8 + int((completed / max(page_count, 1)) * 82)
                progress_callback(
                    percent,
                    f"Reading pages: {completed} of {page_count} complete...",
                    index,
                )

        progress_callback(94, "Building document groups...")
        assignments = self.classify_pages(ocr_texts, rotations, blank_pages)
        progress_callback(100, "Analysis complete")
        return (
            images,
            ocr_texts,
            assignments,
            rotations,
            blank_pages,
            fingerprints,
        )

    def analyze_page(
        self,
        index: int,
        image_path: Path,
        work_dir: Path,
        pdf_path: Path,
    ) -> tuple[int, str, int, bool, int]:
        with Image.open(image_path) as source_image:
            image = source_image.convert("RGB")
        grayscale = image.convert("L")
        statistics = ImageStat.Stat(grayscale)
        histogram = grayscale.histogram()
        ink_ratio = sum(histogram[:235]) / max(image.width * image.height, 1)
        fingerprint = self.page_fingerprint(grayscale)

        if statistics.stddev[0] < 3 and ink_ratio < 0.002:
            return index, "", 0, True, fingerprint

        with tempfile.NamedTemporaryFile(
            suffix=".jpg", dir=work_dir, delete=False
        ) as rotated_handle:
            rotated_path = Path(rotated_handle.name)
            image.rotate(180).save(rotated_path, quality=85)

        with ThreadPoolExecutor(max_workers=2) as orientation_pool:
            original_future = orientation_pool.submit(self.ocr_image, image_path)
            rotated_future = orientation_pool.submit(self.ocr_image, rotated_path)
            original_text = original_future.result()
            rotated_text = rotated_future.result()

        original_score = self.orientation_score(original_text)
        rotated_score = self.orientation_score(rotated_text)
        if rotated_score > original_score * 1.12 + 15:
            image.rotate(180).save(image_path, quality=85)
            selected_text = rotated_text
            rotation = 180
        else:
            selected_text = original_text
            rotation = 0
        rotated_path.unlink(missing_ok=True)

        if len(re.findall(r"[A-Za-z]{3,}", selected_text)) < 60:
            selected_text += "\n__SPARSE_SCAN__\n"
            detail_text = self.high_resolution_ocr(
                pdf_path, index, work_dir, rotation
            )
            if detail_text:
                selected_text += "\n" + detail_text

        return index, selected_text, rotation, False, fingerprint

    @staticmethod
    def scan_quality_issues(
        image_path: Path,
        sensitivity: str = "standard",
    ) -> list[str]:
        """Return conservative record-quality warnings for one rendered page.

        These checks are intentionally local and lightweight. They do not inspect
        signatures, dates, parent/guardian fields, or document contents.
        """
        sensitivity = str(sensitivity or "standard").strip().lower()
        if sensitivity not in {"standard", "strict"}:
            return []
        with Image.open(image_path) as source:
            image = source.convert("L")
        width, height = image.size
        pixel_count = max(width * height, 1)
        histogram = image.histogram()
        mean = ImageStat.Stat(image).mean[0]
        ink_ratio = sum(histogram[:235]) / pixel_count
        issues: list[str] = []

        # Rendered OCR pages are normally around 935x1210 at 110 DPI. Warn only
        # when the available image is materially below record-quality resolution.
        min_short = 700 if sensitivity == "standard" else 850
        if min(width, height) < min_short:
            issues.append(f"Low resolution ({width} x {height} pixels)")

        dark_limit = 115 if sensitivity == "standard" else 135
        bright_limit = 252 if sensitivity == "standard" else 248
        if mean < dark_limit:
            issues.append("Page may be too dark")
        elif mean > bright_limit and ink_ratio < (0.006 if sensitivity == "standard" else 0.012):
            issues.append("Page may be washed out or nearly blank")

        # A small edge-energy metric detects obvious blur without requiring
        # OpenCV or a second OCR pass. Downsample first to keep processing fast.
        sample = image.copy()
        sample.thumbnail((900, 1200))
        edges = sample.filter(ImageFilter.FIND_EDGES)
        edge_mean = ImageStat.Stat(edges).mean[0]
        if ink_ratio > 0.008:
            blur_limit = 8.0 if sensitivity == "standard" else 11.0
            if edge_mean < blur_limit:
                issues.append("Page may be blurry")

        # Detect likely clipping only when dark content touches an edge much
        # more heavily than the page interior. This avoids flagging normal forms
        # with a few border marks.
        border = max(6, min(width, height) // 90)
        edge_bands = [
            image.crop((0, 0, width, border)),
            image.crop((0, max(0, height - border), width, height)),
            image.crop((0, 0, border, height)),
            image.crop((max(0, width - border), 0, width, height)),
        ]
        edge_ratios = []
        for band in edge_bands:
            band_hist = band.histogram()
            edge_ratios.append(sum(band_hist[:215]) / max(band.width * band.height, 1))
        clipping_limit = 0.22 if sensitivity == "standard" else 0.14
        if max(edge_ratios, default=0.0) > clipping_limit:
            issues.append("Content may be clipped near a page edge")

        # A lightweight projection check flags only severe tilt. It is designed
        # for obvious scanner-feed problems, not minor deskewing imperfections.
        reduced = image.copy()
        reduced.thumbnail((420, 540))
        best_angle = 0
        best_score = -1.0
        for angle in (-12, -8, -4, 0, 4, 8, 12):
            rotated = reduced.rotate(angle, expand=True, fillcolor=255)
            hist = rotated.point(lambda px: 0 if px > 205 else 255).histogram()
            # The binary histogram itself is not useful for direction; use
            # row-density variance, which peaks when text lines are horizontal.
            row_sums = []
            pixels = rotated.load()
            for y in range(rotated.height):
                row_sums.append(sum(1 for x in range(rotated.width) if pixels[x, y] < 128))
            if row_sums:
                avg = sum(row_sums) / len(row_sums)
                score = sum((value - avg) ** 2 for value in row_sums) / len(row_sums)
                if score > best_score:
                    best_score = score
                    best_angle = angle
        skew_limit = 8 if sensitivity == "standard" else 4
        if abs(best_angle) >= skew_limit and ink_ratio > 0.01:
            issues.append(f"Page may be severely skewed (about {abs(best_angle)} degrees)")

        return issues

    def scan_quality_warnings_for_images(
        self,
        images: list[Path],
        blank_pages: set[int],
        sensitivity: str = "standard",
    ) -> dict[int, list[str]]:
        warnings: dict[int, list[str]] = {}
        for index, image_path in enumerate(images):
            if index in blank_pages:
                continue
            issues = self.scan_quality_issues(image_path, sensitivity)
            if issues:
                warnings[index] = issues
        return warnings

    @staticmethod
    def page_fingerprint(grayscale: Image.Image) -> int:
        """Return a tiny difference hash using the image already in memory."""
        sample = grayscale.resize((17, 16), Image.Resampling.BILINEAR)
        pixels = list(sample.getdata())
        fingerprint = 0
        for row in range(16):
            offset = row * 17
            for column in range(16):
                fingerprint <<= 1
                if pixels[offset + column] > pixels[offset + column + 1]:
                    fingerprint |= 1
        return fingerprint

    def high_resolution_ocr(
        self,
        pdf_path: Path,
        page_index: int,
        work_dir: Path,
        rotation: int,
    ) -> str:
        prefix = work_dir / f"detail-{page_index + 1:03}"
        detail_path = prefix.with_suffix(".jpg")
        subprocess.run(
            [
                self.pdftoppm,
                "-f",
                str(page_index + 1),
                "-l",
                str(page_index + 1),
                "-singlefile",
                "-jpeg",
                "-r",
                "300",
                str(pdf_path),
                str(prefix),
            ],
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if not detail_path.exists():
            return ""
        try:
            if rotation:
                with Image.open(detail_path) as source_image:
                    source_image.rotate(rotation).save(detail_path, quality=88)
            result = subprocess.run(
                [
                    self.tesseract,
                    str(detail_path),
                    "stdout",
                    *TESSERACT_BASE_ARGS,
                    "--psm",
                    "6",
                    "-c",
                    "user_defined_dpi=300",
                ],
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
            )
            return result.stdout.decode("utf-8", errors="ignore")
        finally:
            detail_path.unlink(missing_ok=True)

    def ocr_image(self, image_path: Path) -> str:
        result = subprocess.run(
            [
                self.tesseract,
                str(image_path),
                "stdout",
                *TESSERACT_BASE_ARGS,
                "--psm",
                "11",
                "-c",
                "user_defined_dpi=110",
            ],
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
        return result.stdout.decode("utf-8", errors="ignore")

    @staticmethod
    def orientation_score(text: str) -> int:
        normalized = re.sub(r"\s+", " ", text.lower())
        words = re.findall(r"[a-z]{3,}", normalized)
        keywords = (
            "employee",
            "employer",
            "signature",
            "application",
            "authorization",
            "background",
            "withholding",
            "orientation",
            "employment",
            "instructions",
            "maine",
            "payroll",
            "coverage",
            "waiver",
            "deposit",
            "handbook",
        )
        return len(words) + (20 * sum(word in normalized for word in keywords))

    def classify_pages(
        self,
        texts: list[str],
        rotations: list[int] | None = None,
        blank_pages: set[int] | None = None,
    ) -> list[Assignment]:
        normalized = [re.sub(r"\s+", " ", text.lower()) for text in texts]
        rotations = rotations or [0] * len(texts)
        blank_pages = blank_pages or set()
        assignments: list[Assignment] = []
        last_i9_page: int | None = None

        def add(
            page_index: int,
            document: str,
            sequence: float | None = None,
        ):
            if sequence is None:
                sequence = self.document_sequence(document, normalized[page_index])
            candidate = Assignment(
                page_index,
                document,
                rotations[page_index],
                sequence,
            )
            if candidate not in assignments:
                assignments.append(candidate)

        for index, text in enumerate(normalized):
            if index in blank_pages:
                continue

            custom_document = self.match_custom_rule(text)
            if custom_document:
                add(index, custom_document)
                if custom_document == "Banking.pdf":
                    add(index, "Viventium Direct Deposit.pdf")
                continue

            if (
                "non-disclosure agreement" in text
                or "nondisclosure agreement" in text
            ):
                add(index, "Non-Disclosure Agreement.pdf")
                continue

            has_i9 = "form i-9" in text or (
                "employment eligibility verification" in text
                and (
                    "department of homeland security" in text
                    or "citizenship and immigration services" in text
                    or "anti-discrimination notice" in text
                )
            ) or (
                "lists of acceptable documents" in text
                and "documents that establish identity" in text
                and "employment authorization" in text
            )
            has_orientation = (
                "orientation agenda" in text
                or (
                    "congratulations" in text
                    and "welcome to our team" in text
                )
            )
            has_social_security_card = (
                (
                    ("security" in text or "ocial secur" in text)
                    and "established" in text
                    and "signature" in text
                )
                or "social security administration" in text
                or (
                    "security administration" in text
                    and ("social" in text or "soc security" in text)
                )
            )
            social_security_is_restricted = any(
                restriction in text
                for restriction in (
                    "not valid for employment",
                    "valid for work only with ins authorization",
                    "valid for work only with dhs authorization",
                )
            )
            has_social_security_card = (
                has_social_security_card and not social_security_is_restricted
            )
            license_detail_markers = sum(
                marker in text
                for marker in (
                    "dl. no",
                    "class",
                    "expires",
                    "issued",
                    "endorsements",
                    "restrictions",
                )
            )
            has_driver_license = (
                any(
                    marker in text
                    for marker in (
                        "driver's license",
                        "driver'slicense",
                        "driver'siicense",
                        "drivers license",
                    )
                )
                and license_detail_markers >= 1
            )
            passport_detail_markers = sum(
                marker in text
                for marker in (
                    "nationality",
                    "passport no",
                    "passport number",
                    "date of expiry",
                    "date of expiration",
                    "expiration date",
                    "issuing country",
                    "place of birth",
                )
            )
            has_passport = (
                (
                    "passport card" in text
                    and passport_detail_markers >= 1
                )
                or (
                    "passport" in text
                    and passport_detail_markers >= 2
                    and (
                        "united states of america" in text
                        or "issuing country" in text
                        or "nationality" in text
                    )
                )
            )
            has_permanent_resident_card = (
                "permanent resident card" in text
                or "alien registration receipt card" in text
                or (
                    re.search(r"\b(?:i|1)[ -]?551\b", text) is not None
                    and any(
                        marker in text
                        for marker in (
                            "resident since",
                            "card expires",
                            "alien registration",
                            "uscis#",
                            "uscis #",
                        )
                    )
                )
            )
            has_temporary_i551 = (
                "temporary i-551" in text
                or "temporary 1-551" in text
                or "upon endorsement serves as temporary i-551" in text
                or (
                    "machine readable immigrant visa" in text
                    and "passport" in text
                )
            )
            has_employment_authorization_card = (
                "employment authorization card" in text
                or (
                    "employment authorization document" in text
                    and re.search(r"\b(?:i|1)[ -]?766\b", text) is not None
                )
                or (
                    re.search(r"\b(?:i|1)[ -]?766\b", text) is not None
                    and "uscis" in text
                    and ("category" in text or "card expires" in text)
                )
            )
            has_i94 = (
                re.search(r"\b(?:i|1)[ -]?94a?\b", text) is not None
                or "arrival/departure record" in text
                or "arrival-departure record" in text
            ) and any(
                marker in text
                for marker in (
                    "class of admission",
                    "admit until",
                    "departure number",
                    "admission number",
                    "refugee",
                    "asylee",
                )
            )
            has_foreign_passport_work_authorization = (
                "passport" in text
                and (
                    has_temporary_i551
                    or (
                        has_i94
                        and any(
                            marker in text
                            for marker in (
                                "employment authorized",
                                "authorized to work",
                                "nonimmigrant status",
                                "h-1b",
                                "h1b",
                                "refugee",
                                "asylee",
                                "federated states of micronesia",
                                "marshall islands",
                                "compact of free association",
                            )
                        )
                    )
                )
            )
            identity_detail_markers = sum(
                marker in text
                for marker in (
                    "date of birth",
                    "dob",
                    "sex",
                    "height",
                    "eye color",
                    "eyes",
                    "address",
                    "photograph",
                    "photo",
                )
            )
            has_government_id = (
                any(
                    marker in text
                    for marker in (
                        "government identification card",
                        "government id card",
                        "personal identity verification",
                        "piv card",
                        "common access card",
                        "cac card",
                        "state identification card",
                        "state id card",
                    )
                )
                and identity_detail_markers >= 1
            )
            has_school_id = (
                any(
                    marker in text
                    for marker in (
                        "school identification card",
                        "school id card",
                        "student identification card",
                        "student id card",
                    )
                )
                and ("student" in text or "school" in text)
            )
            has_voter_registration = (
                "voter registration card" in text
                or "voter's registration card" in text
                or "voters registration card" in text
            )
            has_military_id = any(
                marker in text
                for marker in (
                    "uniformed services identification",
                    "united states uniformed services",
                    "military identification card",
                    "military id card",
                    "military dependent",
                    "dependent identification card",
                    "department of defense identification",
                    "dod identification card",
                    "common access card",
                    "draft record",
                )
            )
            has_merchant_mariner_card = (
                "merchant mariner card" in text
                or "merchant mariner credential" in text
                or (
                    "united states coast guard" in text
                    and "merchant mariner" in text
                )
            )
            has_tribal_document = any(
                marker in text
                for marker in (
                    "native american tribal document",
                    "tribal identification card",
                    "tribal enrollment card",
                    "certificate of degree of indian blood",
                )
            )
            has_canadian_driver_license = (
                ("canada" in text or "canadian" in text)
                and any(
                    marker in text
                    for marker in (
                        "driver's licence",
                        "driver licence",
                        "permis de conduire",
                    )
                )
                and license_detail_markers >= 1
            )
            has_us_citizen_id = (
                re.search(r"\b(?:i|1)[ -]?197\b", text) is not None
                and "citizen" in text
                and "identification" in text
            )
            has_resident_citizen_id = (
                re.search(r"\b(?:i|1)[ -]?179\b", text) is not None
                and "resident citizen" in text
                and "identification" in text
            )
            has_dhs_employment_document = any(
                marker in text
                for marker in (
                    "refugee travel document",
                    "reentry permit",
                    "re-entry permit",
                    "certificate of citizenship",
                    "certificate of naturalization",
                    "replacement certificate of citizenship",
                    "replacement certificate of naturalization",
                )
            ) or any(
                re.search(pattern, text) is not None
                for pattern in (
                    r"\b(?:i|1)[ -]?571\b",
                    r"\b(?:i|1)[ -]?327\b",
                    r"\bn[ -]?560\b",
                    r"\bn[ -]?561\b",
                    r"\bn[ -]?550\b",
                    r"\bn[ -]?570\b",
                )
            )
            has_birth_certificate = (
                "certificate of live birth" in text
                or "certified abstract of a certificate of live birth" in text
                or "consular report of birth abroad" in text
                or "certification of report of birth" in text
                or "certification of birth abroad" in text
                or any(
                    form_number in text
                    for form_number in ("ds-1350", "fs-545", "fs-240")
                )
                or (
                    ("vital records" in text or "certification of vital record" in text)
                    and "birth place" in text
                    and "date of birth" in text
                )
            )
            has_marriage_certificate = (
                "certificate of marriage" in text
                or (
                    "vital records" in text
                    and "marriage" in text
                    and ("party a" in text or "party b" in text)
                )
            )
            has_interview_statement = (
                "interview statement" in text
                or (
                    "interviewed by" in text
                    and "what are your strengths" in text
                    and (
                        "what are your weaknesses" in text
                        or "why do you want this job" in text
                        or "why do youwantthisjob" in text
                    )
                )
            )
            is_i9_adjacent = (
                last_i9_page is not None
                and 0 < index - last_i9_page <= 3
            )
            has_minor_identity_record = (
                is_i9_adjacent
                and any(
                    marker in text
                    for marker in (
                        "school record",
                        "school report card",
                        "student report card",
                        "clinic record",
                        "doctor record",
                        "hospital record",
                        "day care record",
                        "day-care record",
                        "nursery school record",
                    )
                )
            )
            has_acceptable_replacement_receipt = (
                is_i9_adjacent
                and "receipt" in text
                and any(
                    marker in text
                    for marker in (
                        "replacement",
                        "lost",
                        "stolen",
                        "damaged",
                        "form i-797c",
                        "notice of action",
                        "adit stamp",
                        "refugee stamp",
                    )
                )
            )

            if has_i9 and has_orientation:
                # Mixed documents on one scan require rescanning. The app does
                # not divide a source page.
                continue
            if has_i9:
                add(index, "Form I-9 Employment Eligibility Verification.pdf")
                last_i9_page = index
                continue
            if has_orientation:
                add(index, "Orientation Agenda.pdf")
                continue
            if has_birth_certificate:
                add(index, "Birth and Marriage Certificates.pdf")
                add(index, "Form I-9 Employment Eligibility Verification.pdf")
                continue
            if has_marriage_certificate:
                add(index, "Birth and Marriage Certificates.pdf")
                continue
            if has_interview_statement:
                add(index, "Interview Statement.pdf")
                continue
            if any(
                (
                    has_social_security_card,
                    has_driver_license,
                    has_passport,
                    has_permanent_resident_card,
                    has_temporary_i551,
                    has_employment_authorization_card,
                    has_foreign_passport_work_authorization,
                    has_government_id,
                    has_school_id,
                    has_voter_registration,
                    has_military_id,
                    has_merchant_mariner_card,
                    has_tribal_document,
                    has_canadian_driver_license,
                    has_us_citizen_id,
                    has_resident_citizen_id,
                    has_dhs_employment_document,
                    has_minor_identity_record,
                    has_acceptable_replacement_receipt,
                )
            ):
                add(index, "Form I-9 Employment Eligibility Verification.pdf")
                continue
            if (
                is_i9_adjacent
                and "__sparse_scan__" in text
            ):
                # ID cards are often small, photographed, or faint enough that
                # OCR returns mostly noise. Immediately following I-9 pages are
                # treated as supporting identification unless a recognizable
                # certificate or other document matched above.
                add(index, "Form I-9 Employment Eligibility Verification.pdf")
                continue

            if "recording of time worked" in text:
                add(index, "Time Recording.pdf")
                continue

            # CHERKR / consumer-report authorization pages can contain broad
            # employment language (and sometimes the words "job application") that
            # also appears in the Job Application packet.  Classify CHERKR before
            # the general Job Application catch-all so these pages export as their
            # own required output instead of being swallowed into Job Application.pdf.
            has_cherkr_authorization = (
                "cherkr" in text
                or ("consumer report" in text and "candidate disclosure" in text)
                or (
                    "procurement of consumer reports" in text
                    and "investigative consumer report" in text
                )
                or (
                    "fcra candidate disclosure" in text
                    and "consumer reports" in text
                )
            )
            if has_cherkr_authorization:
                add(index, "CHERKR Authorization.pdf")
                continue

            job_application_markers = (
                "job application",
                "employee availability sheet",
                "non-exempt compensation agreement",
                "companion checklist",
                "comprehensive hiring form",
                "handbook acknowledgement form",
                "personal support specialist",
                "essential functions pss",
                "job requirements",
                "assist clients with personal care",
                "adl assistance",
                "iadl assistance",
                "tadl assistance",
                "performs homemaking activities",
                "reasons for immediate termination",
                "requests that all employees follow the following rules",
                "nothing in this employee handbook shall form a contract",
                "employee handbook shall form a contract",
                "by signing this agreement",
                "acknowledges receipt of, and agreement to",
                "compensation agreement",
                "medical examination and drug test",
                "work reference",
                "personal references",
                "at-will employment",
                "must have a reliable enclosed vehicle",
                "the job description provides a framework for the job",
                "duties and responsibilities listed above for my position",
            )
            is_resume_page = (
                (
                    "experience" in text
                    and re.search(
                        r"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}",
                        text,
                    )
                    is not None
                )
                or ("page 2 of 2" in text and "education" in text)
            )
            if is_resume_page or any(
                marker in text for marker in job_application_markers
            ):
                add(index, "Job Application.pdf")
                continue

            if (
                "maine background check center" in text
                or "background check report correcting inaccurate information"
                in text
                or (
                    "authorization and release by the applicant" in text
                    and "background check center" in text
                )
            ):
                add(index, "MBC Authorization.pdf")
                continue

            if "application fee paid for maine criminal background check" in text:
                add(index, "MBC Payment.pdf")
                continue

            if "child abuse background check confirmation" in text:
                add(
                    index,
                    "Confirmation - Child Abuse Registry Background Check Request.pdf",
                )
                continue

            if (
                "child abuse and neglect records information" in text
                or "child protective services case" in text
                or (
                    "child and family services" in text
                    and "authorization release" in text
                )
            ):
                add(index, "Child Protective Services Authorization.pdf")
                continue

            if "w-4me" in text or (
                "maine" in text and "withholding allowance certificate" in text
            ):
                add(index, "Payroll.pdf")
                continue

            if "form 8850" in text or "work opportunity credit" in text:
                add(index, "Payroll.pdf")
                continue

            if (
                "form w-4" in text
                or "employee’s withholding certificate" in text
                or "employee's withholding certificate" in text
                or "multiple jobs worksheet" in text
            ) and (
                "internal revenue" in text
                or "treasury" in text
                or "multiple jobs worksheet" in text
                or "general instructions" in text
            ):
                add(index, "Federal W-4 Withholding.pdf")
                continue

            is_legacy_payroll = (
                "paypro payroll" in text
                or "skylight payoptions" in text
                or (
                    "card mailing address" in text
                    and "net pay" in text
                    and "employee signature" in text
                )
            )
            if is_legacy_payroll:
                continue

            is_direct_deposit_form = (
                "viventium payroll" in text
                or "employee direct deposit authorization" in text
                or "direct deposit authorization form" in text
                or "direct deposit enrollment form" in text
                or (
                    "direct deposit" in text
                    and (
                        "authorization agreement" in text
                        or "payroll compensation" in text
                        or "sign this direct deposit form" in text
                    )
                )
            )
            if is_direct_deposit_form:
                add(index, "Viventium Direct Deposit.pdf")
                continue

            if self.looks_like_banking_page(
                text, index, normalized, blank_pages
            ):
                add(index, "Banking.pdf")
                add(index, "Viventium Direct Deposit.pdf")
                continue

            if "auto enrol" in text and "opt out" in text:
                add(index, "Auto Enrollment Opt Out.pdf")
                continue

            if (
                "waiver form" in text
                or "decline all coverage" in text
                or ("employee" in text and "choice" in text and "waiver" in text)
            ):
                add(index, "Employee Choice Acknowledgement Waiver.pdf")
                continue

        return sorted(assignments, key=lambda item: (item.document.lower(), item.page_index))

    def match_custom_rule(self, text: str) -> str | None:
        text = re.sub(r"\s+", " ", text.lower())
        for rule in self.rules.get("custom_rules", []):
            document = str(rule.get("document", "")).strip()
            keywords = [
                re.sub(r"\s+", " ", str(keyword).strip().lower())
                for keyword in rule.get("keywords", [])
                if str(keyword).strip()
            ]
            if not document or not keywords:
                continue
            matches = [keyword in text for keyword in keywords]
            mode = str(rule.get("match_mode", "all")).lower()
            if (mode == "any" and any(matches)) or (
                mode != "any" and all(matches)
            ):
                return document
        return None

    @staticmethod
    def document_sequence(document: str, text: str) -> float | None:
        if document == "Form I-9 Employment Eligibility Verification.pdf":
            if "form i-9" in text or "department of homeland security" in text:
                return 1
            return 2

        if document == "Job Application.pdf":
            markers = (
                ("job application", 1),
                ("work reference", 2),
                ("medical examination and drug test", 3),
                ("page 1 of 2", 13),
                ("page 2 of 2", 14),
                ("employee availability sheet", 4),
                ("nothing in this employee handbook shall form a contract", 5),
                ("employee handbook shall form a contract", 5),
                ("by signing this agreement", 5),
                ("acknowledges receipt of, and agreement to", 5),
                ("comprehensive hiring form", 6),
                ("companion checklist", 7),
                ("non-exempt compensation agreement", 8),
                ("compensation agreement", 8),
                ("requests that all employees follow the following rules", 9),
                ("reasons for immediate termination", 9.5),
                ("must have a reliable enclosed vehicle", 11),
                ("at least 18 years of age", 11),
                ("personal support specialist", 10),
                ("handbook acknowledgement form", 12),
                ("the job description provides a framework for the job", 12.5),
                ("duties and responsibilities listed above for my position", 12.5),
            )
            for marker, sequence in markers:
                if marker in text:
                    return sequence
            if (
                "experience" in text
                and re.search(
                    r"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}",
                    text,
                )
                is not None
            ):
                return 13

        if document == "MBC Authorization.pdf":
            if "notification and authorization and release" in text:
                return 1
            if "authorization and release" in text and "applicant" in text:
                return 2
            if "signature of applicant" in text and "title 18" in text:
                return 2
            if "voluntary consent for disclosure" in text:
                return 3
            return 4

        if document == "Federal W-4 Withholding.pdf":
            heading = text[:500]
            if "multiple jobs worksheet" in heading:
                return 3
            if "general instructions" in heading or "page 2" in heading:
                return 2
            return 1

        if document == "Viventium Direct Deposit.pdf":
            if "direct deposit" in text or "viventium" in text:
                return 1
            return 2

        return None

    @staticmethod
    def looks_like_banking_page(
        text: str,
        index: int,
        all_texts: list[str],
        blank_pages: set[int] | None = None,
    ) -> bool:
        blank_pages = blank_pages or set()
        strong_banking_words = (
            "routing number",
            "voided check",
            "checking account",
            "savings account",
            "this check",
            "pay to the",
            "new balance",
        )
        if any(word in text for word in strong_banking_words):
            return True
        if (
            len(text.strip()) < 350 or "__sparse_scan__" in text
        ) and index > 0 and index not in blank_pages:
            previous = all_texts[index - 1]
            return (
                "direct deposit" in previous
                or "attach a voided check" in previous
                or "viventium" in previous
            )
        return False

