from __future__ import annotations

import re
from .packet_analyzer import Assignment
from .utils import safe_filename

SUCCESS_GREEN = "#63C393"
MUTED = "#64748B"
WARNING = "#8A2020"
DANGER = "#DC2626"

class ConfidenceMixin:
    def expected_indicators_for_document(self, document: str) -> list[tuple[str, list[str]]]:
        """Return user-facing expected indicators for confidence explanations.

        Each tuple is (display name, OCR phrases). The display name is what staff
        see in Assignment Details; phrases are the words PacketFlow looks
        for in OCR text. These are intentionally business-document indicators,
        not scan-quality warnings, so the user sees what was missing.
        """
        doc = safe_filename(document).lower()
        mapping: dict[str, list[tuple[str, list[str]]]] = {
            "job application.pdf": [
                ("Job application heading", ["job application"]),
                ("Employee availability sheet", ["employee availability sheet"]),
                ("Work reference section", ["work reference", "personal references"]),
                ("Employment/handbook acknowledgement", ["handbook acknowledgement", "acknowledges receipt", "employee handbook"]),
                ("Compensation agreement", ["compensation agreement", "non-exempt compensation agreement"]),
                ("Job description / duties acknowledgement", [
                    "job description",
                    "duties and responsibilities",
                    "personal support specialist",
                    "essential functions pss",
                    "job requirements",
                    "assist clients with personal care",
                ]),
            ],
            "form i-9 employment eligibility verification.pdf": [
                ("Form I-9 heading", ["form i-9", "employment eligibility verification"]),
                ("Department of Homeland Security / USCIS wording", ["department of homeland security", "citizenship and immigration services", "uscis"]),
                ("Employee information / attestation area", ["employee information", "employee attestation", "citizenship or immigration status"]),
                ("Employer review / verification area", ["employer review", "authorized representative", "document title"]),
                ("Supporting identity/work document", ["driver's license", "drivers license", "social security", "passport", "permanent resident", "employment authorization"]),
            ],
            "mbc authorization.pdf": [
                ("Maine Background Check Center wording", ["maine background check center", "background check center"]),
                ("Authorization and release wording", ["notification and authorization and release", "authorization and release by the applicant", "background check center authorization"]),
                ("Applicant signature area", ["signature of applicant", "applicant signature"]),
            ],
            "child protective services authorization.pdf": [
                ("Child protective services wording", ["child protective services", "child abuse and neglect"]),
                ("Authorization/release wording", ["child protective services authorization", "child and family services authorization release", "child abuse and neglect records information"]),
                ("Child and family services wording", ["child and family services"]),
            ],
            "confirmation - child abuse registry background check request.pdf": [
                ("Child abuse background check confirmation", ["child abuse background check confirmation"]),
                ("Registry/background check request wording", ["registry", "background check request"]),
            ],
            "orientation agenda.pdf": [
                ("Orientation agenda heading", ["orientation agenda"]),
                ("Welcome/congratulations wording", ["welcome to our team", "congratulations"]),
            ],
            "time recording.pdf": [
                ("Recording of time worked heading", ["recording of time worked"]),
                ("Time worked / timesheet wording", ["time worked", "timesheet", "time recording"]),
            ],
            "interview statement.pdf": [
                ("Interview statement heading", ["interview statement"]),
                ("Interviewed by field", ["interviewed by"]),
                ("Strengths/weaknesses questions", ["what are your strengths", "what are your weaknesses"]),
            ],
            "federal w-4 withholding.pdf": [
                ("Form W-4 heading", ["form w-4", "employee's withholding certificate", "employee’s withholding certificate"]),
                ("IRS/Treasury wording", ["internal revenue", "treasury"]),
                ("Multiple jobs / worksheet area", ["multiple jobs worksheet", "step 2"]),
            ],
            "payroll.pdf": [
                ("Maine W-4ME / payroll form", ["w-4me", "withholding allowance certificate", "payroll"]),
                ("Employee/tax withholding wording", ["employee", "withholding"]),
            ],
            "viventium direct deposit.pdf": [
                ("Direct deposit wording", ["direct deposit"]),
                ("Viventium payroll wording", ["viventium"]),
                ("Authorization/agreement wording", ["authorization agreement", "direct deposit authorization"]),
            ],
            "banking.pdf": [
                ("Banking/check evidence", ["routing number", "voided check", "checking account", "savings account", "pay to the", "linked banking/check page"]),
            ],
            "cherkr authorization.pdf": [
                ("CHERKR / consumer report wording", ["cherkr", "consumer report"]),
                ("Candidate disclosure wording", ["candidate disclosure"]),
            ],
            "auto enrollment opt out.pdf": [
                ("Auto enrollment wording", ["auto enrol", "auto enrollment"]),
                ("Opt-out wording", ["opt out", "opt-out"]),
            ],
            "employee choice acknowledgement waiver.pdf": [
                ("Waiver / employee choice wording", ["waiver", "employee choice"]),
                ("Decline coverage wording", ["decline all coverage", "decline coverage"]),
            ],
            "birth and marriage certificates.pdf": [
                ("Birth or marriage certificate wording", ["certificate of live birth", "certified abstract of a certificate of live birth", "certificate of marriage"]),
            ],
        }
        return mapping.get(doc, [])

    def i9_confidence_indicators_for_text(self, normalized_text: str) -> list[tuple[str, list[str]]]:
        """Use the right confidence checklist for either I-9 forms or I-9 IDs.

        I-9 exports often contain pages that are not the I-9 form itself:
        driver's licenses, Social Security cards, passports, and other accepted
        identity/work-authorization documents. Those supporting pages should not
        lose confidence just because they do not contain I-9 form wording.
        """
        form_indicators = [
            ("Form I-9 heading", ["form i-9", "employment eligibility verification"]),
            ("Department of Homeland Security / USCIS wording", ["department of homeland security", "citizenship and immigration services", "uscis"]),
            ("Employee information / attestation area", ["employee information", "employee attestation", "citizenship or immigration status"]),
            ("Employer review / verification area", ["employer review", "authorized representative", "document title"]),
        ]

        def has_any(phrases: tuple[str, ...]) -> bool:
            return any(phrase in normalized_text for phrase in phrases)

        has_i9_form_evidence = (
            "form i-9" in normalized_text
            or "employment eligibility verification" in normalized_text
            or (
                "lists of acceptable documents" in normalized_text
                and "documents that establish identity" in normalized_text
            )
            or (
                "department of homeland security" in normalized_text
                and has_any((
                    "employee attestation",
                    "employer review",
                    "authorized representative",
                ))
            )
        )
        if has_i9_form_evidence:
            return form_indicators

        support_indicators: list[tuple[str, list[str]]] = []

        license_details = (
            "dl. no",
            "class",
            "expires",
            "issued",
            "endorsements",
            "restrictions",
        )
        license_detail_count = sum(
            detail in normalized_text for detail in license_details
        )
        has_license_heading = has_any((
            "driver's license",
            "driver'slicense",
            "driver'siicense",
            "drivers license",
            "driver licence",
            "driver's licence",
            "permis de conduire",
        ))
        has_ocr_tolerant_license_evidence = (
            license_detail_count >= 3
            and has_any((
                "not intended for federal",
                "motor vehicles",
                "class:",
                "gender",
                "height",
                "eyes",
            ))
        )
        if (
            (has_license_heading and license_detail_count >= 1)
            or has_ocr_tolerant_license_evidence
        ):
            license_identity_phrases = [
                "driver's license",
                "drivers license",
                "driver licence",
                "driver's licence",
                "permis de conduire",
            ]
            if has_ocr_tolerant_license_evidence:
                license_identity_phrases.extend(
                    [
                        "not intended for federal",
                        "motor vehicles",
                        "class:",
                        "gender",
                    ]
                )
            support_indicators.extend(
                [
                    ("Driver's license / state ID", license_identity_phrases),
                    ("License details", list(license_details)),
                ]
            )

        if (
            "social security administration" in normalized_text
            or (
                ("social security" in normalized_text or "ocial secur" in normalized_text)
                and ("signature" in normalized_text or "established" in normalized_text)
            )
        ) and not has_any((
            "not valid for employment",
            "valid for work only with ins authorization",
            "valid for work only with dhs authorization",
        )):
            support_indicators.extend(
                [
                    ("Social Security card", ["social security", "social security administration", "ocial secur"]),
                    ("Social Security card detail", ["signature", "established", "administration"]),
                ]
            )

        passport_details = (
            "nationality",
            "passport no",
            "passport number",
            "date of expiry",
            "date of expiration",
            "expiration date",
            "issuing country",
            "place of birth",
        )
        if "passport" in normalized_text and has_any(passport_details):
            support_indicators.extend(
                [
                    ("Passport", ["passport", "passport card"]),
                    ("Passport detail", list(passport_details)),
                ]
            )

        if has_any(("permanent resident card", "alien registration receipt card", "i-551", "1-551")):
            support_indicators.append(
                ("Permanent resident / I-551 evidence", ["permanent resident card", "alien registration", "i-551", "1-551", "resident since", "card expires"])
            )

        if has_any(("employment authorization card", "employment authorization document", "i-766", "1-766")):
            support_indicators.append(
                ("Employment authorization document", ["employment authorization card", "employment authorization document", "i-766", "1-766", "uscis", "category", "card expires"])
            )

        if (
            "passport" in normalized_text
            and has_any(("i-94", "1-94", "arrival/departure record", "arrival-departure record"))
            and has_any(("employment authorized", "authorized to work", "class of admission", "admit until", "refugee", "asylee"))
        ):
            support_indicators.append(
                ("Passport with I-94/work authorization", ["passport", "i-94", "1-94", "arrival/departure record", "employment authorized", "authorized to work", "class of admission"])
            )

        if has_any((
            "government identification card",
            "government id card",
            "personal identity verification",
            "piv card",
            "common access card",
            "cac card",
            "state identification card",
            "state id card",
        )):
            support_indicators.append(
                ("Government or state identification", ["government identification card", "government id card", "state identification card", "state id card", "piv card", "common access card"])
            )

        other_id_groups = [
            ("School ID", ("school identification card", "school id card", "student identification card", "student id card")),
            ("Voter registration card", ("voter registration card", "voter's registration card", "voters registration card")),
            ("Military ID / draft record", ("uniformed services identification", "military identification card", "military id card", "draft record", "department of defense identification", "dod identification card")),
            ("Native American tribal document", ("native american tribal document", "tribal identification card", "tribal enrollment card", "certificate of degree of indian blood")),
            ("Citizen/resident ID card", ("i-197", "1-197", "i-179", "1-179", "citizen identification", "resident citizen")),
            ("DHS citizenship/travel document", ("refugee travel document", "reentry permit", "re-entry permit", "certificate of citizenship", "certificate of naturalization", "n-560", "n-561", "n-550", "n-570")),
            ("Minor identity record", ("school record", "school report card", "student report card", "clinic record", "doctor record", "hospital record", "day care record", "nursery school record")),
        ]
        for display, phrases in other_id_groups:
            if has_any(phrases):
                support_indicators.append((display, list(phrases)))

        if has_any(("merchant mariner card", "merchant mariner credential")):
            support_indicators.append(
                ("Merchant mariner credential", ["merchant mariner card", "merchant mariner credential"])
            )

        has_birth_wording = has_any((
            "certificate of live birth",
            "certified abstract of a certificate of live birth",
            "consular report of birth abroad",
            "certification of report of birth",
            "certification of birth abroad",
        )) or (
            has_any(("certification of vital record", "vital records", "vital record"))
            and has_any(("date of birth", "birth place", "full name of child", "certificate of live birth"))
        )
        if has_birth_wording:
            support_indicators.append(
                ("Birth certificate / vital record", ["certificate of live birth", "certified abstract of a certificate of live birth", "consular report of birth abroad", "certification of report of birth", "certification of birth abroad", "date of birth", "birth place", "full name of child"])
            )

        if (
            "receipt" in normalized_text
            and has_any(("replacement", "lost", "stolen", "damaged", "form i-797c", "notice of action", "adit stamp", "refugee stamp"))
        ):
            support_indicators.append(
                ("Replacement document receipt", ["receipt", "replacement", "form i-797c", "notice of action", "adit stamp", "refugee stamp"])
            )

        return support_indicators or form_indicators

    def direct_deposit_confidence_indicators_for_text(self, normalized_text: str) -> list[tuple[str, list[str]]]:
        """Use a generic direct-deposit checklist unless Viventium text exists.

        Some packets contain a Viventium form, while others contain a bank's
        direct-deposit authorization plus a voided check/account screenshot.
        The generic bank form is still a complete direct-deposit document even
        when it does not contain the Viventium name.
        """
        indicators = [
            ("Direct deposit wording", ["direct deposit"]),
            ("Authorization/agreement wording", ["authorization agreement", "direct deposit authorization", "direct deposit authorization form"]),
        ]
        if "linked banking/check page" in normalized_text:
            indicators.append(
                ("Linked banking/check page", ["linked banking/check page"])
            )
        if "viventium" in normalized_text:
            indicators.append(
                ("Viventium payroll wording", ["viventium"])
            )
        return indicators

    def custom_rule_indicators_for_document(self, document: str) -> list[tuple[str, list[str]]]:
        indicators: list[tuple[str, list[str]]] = []
        for rule in self.rules.get("custom_rules", []):
            if safe_filename(str(rule.get("document", ""))) == safe_filename(document):
                for keyword in rule.get("keywords", []):
                    keyword = str(keyword).strip()
                    if keyword:
                        indicators.append((keyword, [keyword.lower()]))
        return indicators

    @staticmethod
    def indicator_present(normalized_text: str, phrases: list[str]) -> bool:
        return any(str(phrase).lower() in normalized_text for phrase in phrases if str(phrase).strip())

    def confidence_context_text(self, assignment: Assignment, page_text: str) -> tuple[str, bool]:
        """Return the text used for confidence scoring.

        Some outputs are intentionally multi-page packets. A continuation page
        in a Job Application should not lose confidence just because the
        compensation agreement, references, or handbook acknowledgement appear
        on other pages in the same exported PDF.
        """
        normalized_document = safe_filename(assignment.document).lower()
        if normalized_document in {
            "banking.pdf",
            "viventium direct deposit.pdf",
        }:
            all_assignments = getattr(self, "assignments", [])
            page_documents = {
                safe_filename(item.document).lower()
                for item in all_assignments
                if item.page_index == assignment.page_index
            }
            linked_documents = {
                "banking.pdf",
                "viventium direct deposit.pdf",
            }
            if linked_documents.issubset(page_documents):
                direct_deposit_pages = sorted(
                    {
                        item.page_index
                        for item in all_assignments
                        if safe_filename(item.document).lower()
                        == "viventium direct deposit.pdf"
                        and item.page_index != assignment.page_index
                        and item.page_index
                        not in getattr(self, "blank_pages", set())
                        and item.page_index
                        < len(getattr(self, "ocr_texts", []))
                        and "direct deposit"
                        in self.ocr_texts[item.page_index].lower()
                    }
                )
                nearby_pages = [
                    page
                    for page in direct_deposit_pages
                    if abs(page - assignment.page_index) <= 2
                ]
                if nearby_pages:
                    combined_text = "\n".join(
                        [page_text]
                        + [self.ocr_texts[page] for page in nearby_pages]
                        + ["linked banking/check page"]
                    )
                    return combined_text, True
            return page_text, False

        if normalized_document not in {"job application.pdf"}:
            return page_text, False

        normalized_page = re.sub(r"\s+", " ", page_text.lower())
        indicators = self.expected_indicators_for_document(assignment.document)
        page_hits = sum(
            1
            for _display, phrases in indicators
            if self.indicator_present(normalized_page, phrases)
        )
        readable_words = re.findall(r"[a-z]{3,}", normalized_page)
        if (
            "__sparse_scan__" in normalized_page
            or (len(readable_words) < 6 and page_hits == 0)
        ):
            return page_text, False

        assignments = [
            item
            for item in getattr(self, "assignments", [])
            if safe_filename(item.document).lower() == normalized_document
            and item.page_index not in getattr(self, "blank_pages", set())
            and item.page_index < len(getattr(self, "ocr_texts", []))
        ]
        page_indexes = sorted({item.page_index for item in assignments})
        if len(page_indexes) < 2:
            return page_text, False

        combined_text = "\n".join(self.ocr_texts[index] for index in page_indexes)
        normalized_combined = re.sub(r"\s+", " ", combined_text.lower())
        combined_hits = sum(
            1
            for _display, phrases in indicators
            if self.indicator_present(normalized_combined, phrases)
        )
        if combined_hits >= 2 and combined_hits > page_hits:
            return combined_text, True
        return page_text, False

    def assignment_confidence_details(self, assignment: Assignment) -> dict:
        page_text = self.ocr_texts[assignment.page_index] if assignment.page_index < len(self.ocr_texts) else ""
        text, used_group_context = self.confidence_context_text(assignment, page_text)
        normalized = re.sub(r"\s+", " ", text.lower())
        normalized_document = safe_filename(assignment.document).lower()
        restricted_social_security_card = (
            normalized_document == "form i-9 employment eligibility verification.pdf"
            and "social security" in normalized
            and any(
                restriction in normalized
                for restriction in (
                    "not valid for employment",
                    "valid for work only with ins authorization",
                    "valid for work only with dhs authorization",
                )
            )
        )
        indicators = self.custom_rule_indicators_for_document(assignment.document)
        if normalized_document == "form i-9 employment eligibility verification.pdf":
            indicators.extend(self.i9_confidence_indicators_for_text(normalized))
        elif normalized_document == "viventium direct deposit.pdf":
            indicators.extend(self.direct_deposit_confidence_indicators_for_text(normalized))
        else:
            indicators.extend(self.expected_indicators_for_document(assignment.document))

        matched: list[str] = []
        missing: list[str] = []
        for display, phrases in indicators:
            if self.indicator_present(normalized, phrases):
                if display not in matched:
                    matched.append(display)
            else:
                if display not in missing:
                    missing.append(display)

        remembered = assignment.page_index in self.memory_applied_pages
        if used_group_context and "Multi-page document evidence found" not in matched:
            matched.insert(0, "Multi-page document evidence found")
        if remembered and "Remembered correction" not in matched:
            matched.insert(0, "Remembered correction")

        if indicators:
            total = len(indicators)
            found = sum(1 for display, phrases in indicators if self.indicator_present(normalized, phrases))
            # A complete match is 100%. Points are removed only when expected
            # evidence is missing or a specific warning condition is present.
            score = 100
            missing_count = max(0, total - found)
            score -= missing_count * 4
            if found == 0 and not remembered:
                score = 62
            elif found == 1 and total >= 4 and not remembered:
                score = min(score, 78)
            score = max(55, min(100, score))
        else:
            # Unknown/custom document without configured expected indicators.
            raw = self.analyzer.orientation_score(text) if text else 0
            if remembered:
                score = 97
            elif raw >= 120:
                score = 92
            elif raw >= 75:
                score = 84
            elif raw >= 45:
                score = 72
            else:
                score = 62
        if restricted_social_security_card and not remembered:
            score = min(score, 62)

        reductions: list[tuple[str, int]] = []
        for item in missing:
            reductions.append((f"Missing expected indicator: {item}", 4))
        if restricted_social_security_card:
            reductions.append(
                ("Social Security card contains an employment restriction", 16)
            )
        if not matched and not remembered:
            reductions.append(("No strong document-specific indicator was isolated", 12))

        return {
            "score": score,
            "matched": matched,
            "missing": missing,
            "reductions": reductions,
            "remembered": remembered,
            "indicator_count": len(indicators),
            "matched_indicator_count": found if indicators else 0,
        }

    def assignment_confidence_score(self, assignment: Assignment) -> int:
        return int(self.assignment_confidence_details(assignment)["score"])

    def output_completeness_details(
        self,
        assignments: list[Assignment],
    ) -> dict:
        """Validate whether a finished output PDF contains its required pieces."""
        if not assignments:
            return {"checked": False, "complete": True, "issues": []}

        document = safe_filename(assignments[0].document).lower()
        page_indexes = list(dict.fromkeys(
            assignment.page_index for assignment in assignments
        ))
        page_texts = [
            re.sub(r"\s+", " ", self.ocr_texts[index].lower())
            for index in page_indexes
            if index < len(self.ocr_texts)
        ]
        combined = " ".join(page_texts)

        def has_any(*phrases: str) -> bool:
            return any(phrase in combined for phrase in phrases)

        issues: list[str] = []

        if document == "form i-9 employment eligibility verification.pdf":
            has_form = any(
                "form i-9" in text
                or (
                    "employment eligibility verification" in text
                    and (
                        "department of homeland security" in text
                        or "citizenship and immigration services" in text
                        or "anti-discrimination notice" in text
                    )
                )
                for text in page_texts
            )
            id_type_by_indicator = {
                "Driver's license / state ID": "Driver's license / state ID",
                "Social Security card": "Social Security card",
                "Passport": "Passport",
                "Permanent resident / I-551 evidence": "Permanent resident card",
                "Employment authorization document": "Employment authorization document",
                "Passport with I-94/work authorization": "Passport",
                "Government or state identification": "Government or state ID",
                "School ID": "School ID",
                "Voter registration card": "Voter registration card",
                "Military ID / draft record": "Military ID / draft record",
                "Native American tribal document": "Tribal document",
                "Citizen/resident ID card": "Citizen/resident ID card",
                "DHS citizenship/travel document": "DHS citizenship/travel document",
                "Minor identity record": "Minor identity record",
                "Merchant mariner credential": "Merchant mariner credential",
                "Birth certificate / vital record": "Birth certificate / vital record",
                "Replacement document receipt": "Replacement document receipt",
            }
            detected_ids: set[str] = set()
            for text in page_texts:
                for display, _phrases in self.i9_confidence_indicators_for_text(text):
                    id_type = id_type_by_indicator.get(display)
                    if id_type:
                        detected_ids.add(id_type)
            if not has_form:
                issues.append("I-9 form is missing")
            missing_ids = max(0, 2 - len(detected_ids))
            if missing_ids:
                noun = "form" if missing_ids == 1 else "forms"
                issues.append(f"Missing {missing_ids} {noun} of identification")

        elif document == "job application.pdf":
            required_sections = self.expected_indicators_for_document(
                "Job Application.pdf"
            )
            missing_sections = [
                display
                for display, phrases in required_sections
                if not self.indicator_present(combined, phrases)
            ]
            if missing_sections:
                section_word = (
                    "section" if len(missing_sections) == 1 else "sections"
                )
                issues.append(
                    f"Missing {len(missing_sections)} required application "
                    f"{section_word}: " + ", ".join(missing_sections)
                )

        elif document == "mbc authorization.pdf":
            signed_pages = (
                (
                    "Notification and authorization page",
                    "notification and authorization and release" in combined,
                ),
                (
                    "Applicant authorization and release page",
                    "authorization and release by the applicant" in combined
                    or (
                        "authorization and release" in combined
                        and "signature of applicant" in combined
                    ),
                ),
                (
                    "Voluntary consent page",
                    "voluntary consent for disclosure" in combined,
                ),
            )
            missing_pages = [name for name, present in signed_pages if not present]
            if missing_pages:
                page_word = "page: " if len(missing_pages) == 1 else "pages: "
                issues.append(
                    "Missing required signed "
                    + page_word
                    + ", ".join(missing_pages)
                )

        elif document == "federal w-4 withholding.pdf":
            if not has_any(
                "employee's withholding certificate",
                "employee’s withholding certificate",
            ):
                issues.append("Employee W-4 form page is missing")

        elif document == "viventium direct deposit.pdf":
            has_direct_deposit_form = has_any(
                "viventium payroll",
                "employee direct deposit authorization",
                "direct deposit authorization form",
                "direct deposit enrollment form",
                "authorization agreement",
            )
            banking_page_indexes = {
                item.page_index
                for item in getattr(self, "assignments", [])
                if safe_filename(item.document).lower() == "banking.pdf"
            }
            has_banking_evidence = (
                any(index in banking_page_indexes for index in page_indexes)
                or has_any(
                    "routing number",
                    "voided check",
                    "checking account",
                    "savings account",
                    "pay to the",
                )
            )
            if not has_direct_deposit_form:
                issues.append("Direct deposit authorization form is missing")
            if not has_banking_evidence:
                issues.append("Banking or checking-account evidence is missing")

        else:
            light_requirements = {
                "orientation agenda.pdf": (
                    "Orientation Agenda page is missing",
                    ("orientation agenda",),
                ),
                "interview statement.pdf": (
                    "Interview Statement page is missing",
                    ("interview statement",),
                ),
                "time recording.pdf": (
                    "Time Recording page is missing",
                    ("recording of time worked", "time recording"),
                ),
                "cherkr authorization.pdf": (
                    "CHERKR authorization page is missing",
                    ("cherkr", "candidate disclosure"),
                ),
                "child protective services authorization.pdf": (
                    "CPS authorization page is missing",
                    (
                        "child abuse and neglect records information",
                        "child protective services case",
                        "child and family services",
                    ),
                ),
                "confirmation - child abuse registry background check request.pdf": (
                    "Child abuse background-check confirmation is missing",
                    ("child abuse background check confirmation",),
                ),
                "payroll.pdf": (
                    "Payroll withholding form is missing",
                    ("w-4me", "withholding allowance certificate", "form 8850"),
                ),
                "auto enrollment opt out.pdf": (
                    "Auto Enrollment Opt Out form is missing",
                    ("auto enrollment", "auto enrol"),
                ),
                "employee choice acknowledgement waiver.pdf": (
                    "Employee Choice waiver is missing",
                    ("employee choice", "decline all coverage", "waiver form"),
                ),
            }
            requirement = light_requirements.get(document)
            if requirement:
                # These are standalone checklist documents. If PacketFlow already
                # assigned pages to this output document, do not fail the packet
                # just because OCR missed the title words on a scanned/low-text
                # page. False failures were occurring for valid files such as
                # INTERVIEW STATEMENT.pdf when the document was visibly present
                # and assigned, but OCR did not include the exact phrase.
                # Low-confidence/review flags still handle scan-quality concerns.
                pass
            else:
                return {"checked": False, "complete": True, "issues": []}

        return {
            "checked": True,
            "complete": not issues,
            "issues": issues,
        }

    def output_confidence_score(self, assignments: list[Assignment]) -> int:
        """Return a packet/output-level confidence score.

        Assignment Details shows the confidence for the selected page. Output
        rows need a document-level score, so one weak continuation/supporting
        page should not make a complete multi-page PDF look like the entire
        document is low confidence.
        """
        if not assignments:
            return 0
        scores = [self.assignment_confidence_score(item) for item in assignments]
        return int(round(sum(scores) / max(len(scores), 1)))

    def confidence_label_for_assignments(self, assignments: list[Assignment]) -> tuple[str, str]:
        if not assignments:
            return "No confidence", MUTED
        completeness = self.output_completeness_details(assignments)
        if completeness["checked"] and not completeness["complete"]:
            return f"FAIL - {completeness['issues'][0]}", DANGER
        score = self.output_confidence_score(assignments)
        if score >= 95:
            return f"✓ Very High Confidence ({score}%)", SUCCESS_GREEN
        if score >= 85:
            return f"✓ High Confidence ({score}%)", SUCCESS_GREEN
        if score >= 70:
            return f"⚠ Medium Confidence ({score}%)", "#C78B22"
        return f"⚠ Review Recommended ({score}%)", WARNING


