from __future__ import annotations

import collections
import difflib
import json
import os
import re
from pathlib import Path
from tkinter import messagebox

from .packet_analyzer import Assignment
from .utils import safe_filename

APP_TITLE = "PacketFlow"
_APPDATA_ROOT = os.environ.get("APPDATA", "")
CORRECTION_MEMORY_PATH = (Path(_APPDATA_ROOT) / "PacketFlow" / "correction_memory.json") if _APPDATA_ROOT else (Path(__file__).resolve().parents[1] / "correction_memory.json")

class CorrectionMemoryMixin:
    # Maximum correction-memory entries kept per profile.  Older entries are
    # trimmed on load so the file stays small after months of use.
    _CORRECTION_MEMORY_MAX = 500

    @staticmethod
    def _deduplicate_corrections(entries: list[dict]) -> list[dict]:
        """Remove exact-duplicate correction entries, keeping the last occurrence."""
        seen: dict[str, int] = {}
        for position, entry in enumerate(entries):
            key = json.dumps(entry, sort_keys=True)
            seen[key] = position
        kept = {position for position in seen.values()}
        return [entry for position, entry in enumerate(entries) if position in kept]

    def load_correction_memory(self) -> list[dict]:
        self.correction_memory_profiles: dict[str, dict] = {}
        if not CORRECTION_MEMORY_PATH.exists():
            return []
        try:
            data = json.loads(CORRECTION_MEMORY_PATH.read_text(encoding="utf-8"))
            if isinstance(data, list):
                cleaned = self._deduplicate_corrections(data)[-self._CORRECTION_MEMORY_MAX:]
                self.correction_memory_profiles[self.active_profile_name] = {
                    "corrections": cleaned,
                    "output_order": [],
                }
                return cleaned
            if isinstance(data, dict):
                if isinstance(data.get("profiles"), dict):
                    self.correction_memory_profiles = {
                        str(name): {
                            "corrections": self._deduplicate_corrections(
                                list(profile.get("corrections", []))
                            )[-self._CORRECTION_MEMORY_MAX:],
                            "output_order": list(
                                profile.get("output_order", [])
                            ),
                        }
                        for name, profile in data["profiles"].items()
                        if isinstance(profile, dict)
                    }
                    active_memory = self.correction_memory_profiles.get(
                        self.active_profile_name,
                        {},
                    )
                    self.preferred_document_order = [
                        safe_filename(str(document))
                        for document in active_memory.get("output_order", [])
                        if str(document).strip()
                    ]
                    return list(active_memory.get("corrections", []))
                saved_order = data.get("output_order", [])
                if isinstance(saved_order, list):
                    self.preferred_document_order = [
                        safe_filename(str(document))
                        for document in saved_order
                        if str(document).strip()
                    ]
                corrections = data.get("corrections", [])
                corrections = corrections if isinstance(corrections, list) else []
                corrections = self._deduplicate_corrections(corrections)[-self._CORRECTION_MEMORY_MAX:]
                self.correction_memory_profiles[self.active_profile_name] = {
                    "corrections": corrections,
                    "output_order": self.preferred_document_order,
                }
                return corrections
            return []
        except Exception:
            return []

    def save_correction_memory(self) -> bool:
        try:
            self.correction_memory_profiles[self.active_profile_name] = {
                "corrections": self.correction_memory,
                "output_order": self.preferred_document_order,
            }
            CORRECTION_MEMORY_PATH.write_text(
                json.dumps(
                    {
                        "schema_version": 2,
                        "profiles": self.correction_memory_profiles,
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
            return True
        except Exception as exc:
            messagebox.showerror(
                APP_TITLE,
                "The correction could not be saved for future packets.\n\n"
                + str(exc),
            )
            return False

    @staticmethod
    def correction_signature(text: str) -> list[str]:
        cleaned = text.lower().replace("__sparse_scan__", " ")
        tokens = re.findall(r"[a-z]{4,}", cleaned)
        shingles = {
            f"{tokens[index]} {tokens[index + 1]}"
            for index in range(len(tokens) - 1)
        }
        return sorted(shingles)

    def apply_correction_memory(
        self,
        texts: list[str],
        assignments: list[Assignment],
        rotations: list[int],
        blank_pages: set[int],
    ) -> tuple[list[Assignment], set[int]]:
        if not self.correction_memory:
            return assignments, set()

        updated = list(assignments)
        applied: set[int] = set()
        for index, text in enumerate(texts):
            if index in blank_pages:
                continue
            current = set(self.correction_signature(text))
            if len(current) < 12:
                continue
            best_entry = None
            best_score = 0.0
            for entry in self.correction_memory:
                remembered = set(entry.get("signature", []))
                overlap = len(current & remembered)
                if overlap < 12:
                    continue
                score = overlap / max(len(current | remembered), 1)
                if score > best_score:
                    best_score = score
                    best_entry = entry
            if best_entry is None or best_score < 0.82:
                continue
            document = safe_filename(str(best_entry.get("document", "")))
            updated = [item for item in updated if item.page_index != index]
            updated.append(Assignment(index, document, rotations[index], None))
            if document == "Banking.pdf":
                updated.append(
                    Assignment(
                        index,
                        "Viventium Direct Deposit.pdf",
                        rotations[index],
                        None,
                    )
                )
            applied.add(index)
        return updated, applied

    @staticmethod
    def find_duplicate_pairs(
        texts: list[str],
        fingerprints: list[int],
        blank_pages: set[int],
    ) -> list[tuple[int, int]]:
        normalized = [
            re.sub(r"\s+", " ", text.replace("__SPARSE_SCAN__", "").strip().lower())
            for text in texts
        ]
        duplicates: list[tuple[int, int]] = []
        for left in range(len(texts)):
            if left in blank_pages or len(normalized[left]) < 40:
                continue
            for right in range(left + 1, len(texts)):
                if right in blank_pages:
                    continue
                distance = (fingerprints[left] ^ fingerprints[right]).bit_count()
                if distance > 40:
                    continue
                if normalized[left] == normalized[right]:
                    duplicates.append((left, right))
                    continue
                similarity = difflib.SequenceMatcher(
                    None,
                    normalized[left],
                    normalized[right],
                    autojunk=False,
                ).ratio()
                if similarity >= 0.92:
                    duplicates.append((left, right))
        return duplicates

    @staticmethod
    def auto_unsort_duplicate_assignments(
        assignments: list[Assignment],
        duplicate_pairs: list[tuple[int, int]],
    ) -> tuple[list[Assignment], set[int]]:
        """Remove export assignments from duplicate pages so duplicates do not export.

        Duplicate detection is page-based. When two or more pages are detected as
        the same scan/content, PacketFlow keeps one representative page assigned
        and removes assignments from the duplicate pages. Legitimate multi-use of
        the same page, such as Birth Certificate also supporting I-9 or Banking
        also supporting Direct Deposit, is not affected because that is multiple
        assignments on one page rather than duplicate pages.
        """
        if not duplicate_pairs or not assignments:
            return assignments, set()

        assigned_counts: dict[int, int] = collections.Counter(
            item.page_index for item in assignments
        )
        graph: dict[int, set[int]] = collections.defaultdict(set)
        for left, right in duplicate_pairs:
            graph[left].add(right)
            graph[right].add(left)

        pages_to_unsort: set[int] = set()
        visited: set[int] = set()
        for start in sorted(graph):
            if start in visited:
                continue
            stack = [start]
            component: set[int] = set()
            while stack:
                page = stack.pop()
                if page in component:
                    continue
                component.add(page)
                stack.extend(graph.get(page, set()) - component)
            visited.update(component)
            if len(component) < 2:
                continue

            keep_page = max(
                component,
                key=lambda page: (assigned_counts.get(page, 0), -page),
            )
            for page in component:
                if page != keep_page:
                    pages_to_unsort.add(page)

        if not pages_to_unsort:
            return assignments, set()
        filtered = [
            item for item in assignments if item.page_index not in pages_to_unsort
        ]
        removed_pages = {
            page for page in pages_to_unsort if assigned_counts.get(page, 0) > 0
        }
        return filtered, removed_pages

    def calculate_low_confidence_pages(
        self,
        texts: list[str],
        assignments: list[Assignment],
    ) -> set[int]:
        assigned = {item.page_index for item in assignments}
        return {
            index
            for index, text in enumerate(texts)
            if index in assigned
            and (
                "__SPARSE_SCAN__" in text
                or self.analyzer.orientation_score(text) < 45
            )
        }


