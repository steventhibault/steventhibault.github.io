from __future__ import annotations
import re

def safe_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "_", name.strip())
    name = name.rstrip(". ")
    name = re.sub(r"\.pdf$", "", name, flags=re.IGNORECASE)
    name = name.rstrip(". ")
    return (name + ".pdf") if name else "Unsorted.pdf"

def safe_folder_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "_", name.strip())
    name = name.rstrip(". ")
    return name or "Sorted Packet"
