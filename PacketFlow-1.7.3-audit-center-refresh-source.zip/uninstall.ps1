$ErrorActionPreference = "Stop"
Add-Type -AssemblyName PresentationFramework
function Show-Info([string]$Message, [string]$Title = "PacketFlow Uninstaller") { [System.Windows.MessageBox]::Show($Message, $Title, [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Information) | Out-Null }
function Show-ErrorMessage([string]$Message) { [System.Windows.MessageBox]::Show($Message, "PacketFlow Uninstaller", [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Error) | Out-Null }
function Ask-YesNo([string]$Message) { return [System.Windows.MessageBox]::Show($Message, "PacketFlow Uninstaller", [System.Windows.MessageBoxButton]::YesNo, [System.Windows.MessageBoxImage]::Warning) -eq [System.Windows.MessageBoxResult]::Yes }

$InstallDirectory = Join-Path $env:LOCALAPPDATA "Programs\PacketFlow"
$AppDataDirectory = Join-Path $env:APPDATA "PacketFlow"
$DesktopShortcut = Join-Path ([Environment]::GetFolderPath("Desktop")) "PacketFlow.lnk"
$StartMenuDirectory = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\PacketFlow"
$StartupKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run"
$UninstallKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\PacketFlow"

if (-not (Test-Path -LiteralPath $InstallDirectory)) { Show-Info "PacketFlow does not appear to be installed. Nothing was removed."; exit 0 }
$keepData = Ask-YesNo ("Remove PacketFlow program files?`n`nClick Yes to KEEP your AppData rules, settings, correction memory, Review Queue, and Packet History.`nClick No to delete the app and all PacketFlow AppData.")
$confirmed = Ask-YesNo "Continue uninstalling PacketFlow?"
if (-not $confirmed) { Show-Info "Uninstall cancelled."; exit 0 }
try { Remove-ItemProperty -Path $StartupKey -Name "PacketFlow" -Force -ErrorAction SilentlyContinue } catch {}
foreach ($path in @($DesktopShortcut, $StartMenuDirectory)) { if (Test-Path -LiteralPath $path) { try { Remove-Item -LiteralPath $path -Recurse -Force } catch {} } }
try { Remove-Item -LiteralPath $UninstallKey -Recurse -Force -ErrorAction SilentlyContinue } catch {}
try { Remove-Item -LiteralPath $InstallDirectory -Recurse -Force } catch { Show-ErrorMessage "Could not fully remove the install folder.`n`n$($_.Exception.Message)"; exit 1 }
if (-not $keepData -and (Test-Path -LiteralPath $AppDataDirectory)) { try { Remove-Item -LiteralPath $AppDataDirectory -Recurse -Force } catch {} }
$dataNote = if ($keepData) { "`n`nYour AppData was kept at:`n$AppDataDirectory" } else { "" }
Show-Info "PacketFlow has been uninstalled.$dataNote"
