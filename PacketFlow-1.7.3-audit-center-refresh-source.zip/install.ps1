param([switch]$SkipLaunch)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName PresentationFramework

$ProductName = "PacketFlow"
$ProductVersion = "1.7.3"
$Publisher = "PacketFlow"
$SourceDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDirectory = Join-Path $env:LOCALAPPDATA "Programs\PacketFlow"
$AppDataDirectory = Join-Path $env:APPDATA "PacketFlow"
$Desktop = [Environment]::GetFolderPath("Desktop")
$StartMenuDirectory = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\PacketFlow"
$DesktopShortcut = Join-Path $Desktop "PacketFlow.lnk"
$StartMenuShortcut = Join-Path $StartMenuDirectory "PacketFlow.lnk"
$UninstallShortcut = Join-Path $StartMenuDirectory "Uninstall PacketFlow.lnk"
$UninstallKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\PacketFlow"

function Show-Info([string]$Message, [string]$Title = "PacketFlow Setup") {
    [System.Windows.MessageBox]::Show($Message, $Title, [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Information) | Out-Null
}
function Show-ErrorMessage([string]$Message) {
    [System.Windows.MessageBox]::Show($Message, "PacketFlow Setup", [System.Windows.MessageBoxButton]::OK, [System.Windows.MessageBoxImage]::Error) | Out-Null
}
function New-Shortcut([string]$Path, [string]$TargetPath, [string]$WorkingDirectory, [string]$Description, [string]$IconLocation) {
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($Path)
    $shortcut.TargetPath = $TargetPath
    $shortcut.WorkingDirectory = $WorkingDirectory
    $shortcut.Description = $Description
    if ($IconLocation) { $shortcut.IconLocation = $IconLocation }
    $shortcut.Save()
}
function Copy-LegacyMutableFile([string]$Name) {
    $destination = Join-Path $AppDataDirectory $Name
    if (Test-Path -LiteralPath $destination) { return }
    foreach ($candidate in @((Join-Path $InstallDirectory $Name), (Join-Path $SourceDirectory $Name))) {
        if (Test-Path -LiteralPath $candidate) {
            Copy-Item -LiteralPath $candidate -Destination $destination -Force
            return
        }
    }
}

try {
    New-Item -ItemType Directory -Path $InstallDirectory -Force | Out-Null
    New-Item -ItemType Directory -Path $AppDataDirectory -Force | Out-Null
    New-Item -ItemType Directory -Path $StartMenuDirectory -Force | Out-Null

    # Migrate mutable state before replacing program files. This preserves rules,
    # workflow templates, correction memory, settings, history, and queue data.
    foreach ($fileName in @("rules.json", "settings.json", "correction_memory.json")) {
        Copy-LegacyMutableFile $fileName
    }

    $sourceResolved = [System.IO.Path]::GetFullPath($SourceDirectory)
    $installResolved = [System.IO.Path]::GetFullPath($InstallDirectory)
    if ($sourceResolved -ne $installResolved) {
        Get-ChildItem -LiteralPath $SourceDirectory -Force |
            Where-Object { $_.Name -notin @("__pycache__", ".git", ".pytest_cache") } |
            Copy-Item -Destination $InstallDirectory -Recurse -Force
    }

    # The packaged rules.json remains a factory default. The editable active copy
    # lives in AppData and is never overwritten during upgrades.
    if (-not (Test-Path -LiteralPath (Join-Path $AppDataDirectory "rules.json"))) {
        Copy-Item -LiteralPath (Join-Path $InstallDirectory "rules.json") -Destination (Join-Path $AppDataDirectory "rules.json") -Force
    }

    $launcher = Join-Path $InstallDirectory "Start PacketFlow.cmd"
    $uninstaller = Join-Path $InstallDirectory "Uninstall_PacketFlow.cmd"
    $icon = Join-Path $InstallDirectory "packetflow.ico"
    New-Shortcut $DesktopShortcut $launcher $InstallDirectory "PacketFlow Intake Processor" $icon
    New-Shortcut $StartMenuShortcut $launcher $InstallDirectory "PacketFlow Intake Processor" $icon
    New-Shortcut $UninstallShortcut $uninstaller $InstallDirectory "Remove PacketFlow" $icon

    New-Item -Path $UninstallKey -Force | Out-Null
    Set-ItemProperty -Path $UninstallKey -Name "DisplayName" -Value "PacketFlow"
    Set-ItemProperty -Path $UninstallKey -Name "DisplayVersion" -Value $ProductVersion
    Set-ItemProperty -Path $UninstallKey -Name "Publisher" -Value $Publisher
    Set-ItemProperty -Path $UninstallKey -Name "InstallLocation" -Value $InstallDirectory
    Set-ItemProperty -Path $UninstallKey -Name "DisplayIcon" -Value $icon
    Set-ItemProperty -Path $UninstallKey -Name "UninstallString" -Value ('"{0}"' -f $uninstaller)
    Set-ItemProperty -Path $UninstallKey -Name "NoModify" -Value 1 -Type DWord
    Set-ItemProperty -Path $UninstallKey -Name "NoRepair" -Value 1 -Type DWord

    Show-Info ("PacketFlow $ProductVersion was installed or updated successfully.`n`n" +
        "Desktop and Start Menu shortcuts were created.`n" +
        "Your editable rules, settings, learned corrections, Review Queue, and Packet History remain in:`n`n$AppDataDirectory")

    if (-not $SkipLaunch) {
        Start-Process -FilePath $launcher -WorkingDirectory $InstallDirectory
    }
}
catch {
    Show-ErrorMessage "PacketFlow could not be installed or updated.`n`n$($_.Exception.Message)"
    exit 1
}
