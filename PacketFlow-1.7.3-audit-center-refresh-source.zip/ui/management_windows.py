from __future__ import annotations

import copy
import csv
import json
import os
import platform
import re
import sys
import tempfile
import time
import webbrowser
import zipfile
from datetime import datetime, timedelta
from importlib import metadata as importlib_metadata
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

try:
    import customtkinter as ctk
except ImportError as exc:
    raise SystemExit("Missing required package: customtkinter. Run Start PacketFlow.cmd so it can install dependencies.") from exc

APP_TITLE = "PacketFlow"
APP_VERSION = "1.7.3-audit-center-refresh"
APP_DIR = Path(__file__).resolve().parents[1]
_APPDATA_ROOT = os.environ.get("APPDATA", "")
APP_DATA_DIR = (Path(_APPDATA_ROOT) / "PacketFlow") if _APPDATA_ROOT else APP_DIR
ACTIVE_RULES_PATH = APP_DATA_DIR / "rules.json"
SETTINGS_PATH = APP_DATA_DIR / "settings.json"
ERROR_LOG_PATH = APP_DATA_DIR / "PacketFlow Error Log.txt"
EMAIL_FILING_AUDIT_PATH = APP_DATA_DIR / "Email Filing Audit Log.txt"
PACKET_LEDGER_PATH = APP_DATA_DIR / "PacketFlow Ledger.sqlite3"

CARD_NAVY = "#112C6B"
PRODUCT_BLUE = "#1E88E5"
SUCCESS_GREEN = "#63C393"
TEXT = "#0F172A"
MUTED = "#64748B"
WARNING = "#8A2020"
BORDER = "#DDE5EE"

class ManagementWindowsMixin:
    def refresh_open_audit_centers(self):
        """Refresh every Audit Center window that is still open.

        Directory audits run in a background worker. When one completes, the
        main app calls this method on the Tk thread so newly created findings
        appear immediately in any already-open Audit Center window.
        """
        callbacks = list(getattr(self, "_audit_center_refresh_callbacks", []))
        active_callbacks = []
        for window, callback in callbacks:
            try:
                if window.winfo_exists():
                    callback()
                    active_callbacks.append((window, callback))
            except Exception:
                # A window may have been closed between the audit completing
                # and this refresh pass. Stale callbacks are discarded.
                continue
        self._audit_center_refresh_callbacks = active_callbacks

    def show_workflow_template_editor(self):
        window = ctk.CTkToplevel(self.root)
        window.title("PacketFlow Workflow Checklists")
        window.geometry("1120x700")
        window.minsize(920, 560)
        window.transient(self.root)
        window.grab_set()

        ctk.CTkLabel(window, text="Workflow Checklists", text_color=CARD_NAVY, font=("Segoe UI", 20, "bold")).pack(anchor="w", padx=20, pady=(16, 2))
        ctk.CTkLabel(
            window,
            text=("Define which PDFs are required for each packet type. Existing folders keep using the default checklist unless "
                  "a .packetflow.json sidecar assigns a different template. Missing optional documents never create audit errors."),
            text_color=MUTED,
            font=("Segoe UI", 11),
            wraplength=1060,
            justify="left",
        ).pack(anchor="w", padx=20, pady=(0, 10))

        body = ctk.CTkFrame(window, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=20, pady=(0, 10))
        body.grid_columnconfigure(1, weight=1)
        body.grid_rowconfigure(0, weight=1)

        left = ctk.CTkFrame(body, fg_color="#F8FAFC", corner_radius=6)
        left.grid(row=0, column=0, sticky="nsw", padx=(0, 10))
        ctk.CTkLabel(left, text="Templates", text_color=TEXT, font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=10, pady=(10, 5))
        template_list = tk.Listbox(left, width=28, font=("Segoe UI", 10), exportselection=False, activestyle="none")
        template_list.pack(fill="both", expand=True, padx=10, pady=(0, 8))

        right = ctk.CTkFrame(body, fg_color="#FFFFFF", border_width=1, border_color=BORDER)
        right.grid(row=0, column=1, sticky="nsew")
        right.grid_columnconfigure(0, weight=1)
        right.grid_rowconfigure(1, weight=1)
        header_var = tk.StringVar(value="Select a checklist template")
        ctk.CTkLabel(right, textvariable=header_var, text_color=TEXT, font=("Segoe UI", 12, "bold")).grid(row=0, column=0, sticky="w", padx=10, pady=(10, 6))
        columns = ("document", "status", "note")
        tree = ttk.Treeview(right, columns=columns, show="headings", selectmode="browse")
        for column, heading, width in (("document", "Output PDF", 360), ("status", "Requirement", 125), ("note", "Condition / Note", 330)):
            tree.heading(column, text=heading)
            tree.column(column, width=width, minwidth=90, stretch=(column != "status"))
        tree.grid(row=1, column=0, sticky="nsew", padx=(10, 0), pady=(0, 8))
        scroll = ttk.Scrollbar(right, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        scroll.grid(row=1, column=1, sticky="ns", padx=(0, 10), pady=(0, 8))

        editor = ctk.CTkFrame(right, fg_color="#F8FAFC", corner_radius=6)
        editor.grid(row=2, column=0, columnspan=2, sticky="ew", padx=10, pady=(0, 10))
        editor.grid_columnconfigure(3, weight=1)
        ctk.CTkLabel(editor, text="Requirement", text_color=TEXT, font=("Segoe UI", 10, "bold")).grid(row=0, column=0, padx=(10, 6), pady=9)
        status_var = tk.StringVar(value="optional")
        status_combo = ctk.CTkComboBox(editor, variable=status_var, values=["required", "optional", "conditional", "expected_later"], state="readonly", width=140)
        status_combo.grid(row=0, column=1, padx=(0, 12), pady=8)
        ctk.CTkLabel(editor, text="Note", text_color=TEXT, font=("Segoe UI", 10, "bold")).grid(row=0, column=2, padx=(0, 6), pady=9)
        note_var = tk.StringVar(value="")
        ctk.CTkEntry(editor, textvariable=note_var).grid(row=0, column=3, sticky="ew", padx=(0, 8), pady=8)

        templates = self.rules.setdefault("workflow_templates", {})
        current_template = tk.StringVar(value=self.active_workflow_template_name())

        def template_names():
            return list(templates)

        def selected_template_name() -> str:
            selection = template_list.curselection()
            return str(template_list.get(selection[0])) if selection else current_template.get()

        def refresh_templates(select_name: str = ""):
            selected = select_name or current_template.get() or self.active_workflow_template_name()
            template_list.delete(0, tk.END)
            names = template_names()
            for name in names:
                suffix = "  [default]" if name == self.rules.get("default_workflow_template") else ""
                template_list.insert(tk.END, name + suffix)
            if not names:
                return
            actual = selected if selected in names else names[0]
            index = names.index(actual)
            template_list.selection_set(index)
            template_list.see(index)
            current_template.set(actual)
            refresh_documents()

        def selected_document() -> str:
            selection = tree.selection()
            return str(tree.item(selection[0], "values")[0]) if selection else ""

        def refresh_documents():
            tree.delete(*tree.get_children())
            name = current_template.get()
            template = templates.get(name, {})
            header_var.set(f"{name}" + ("  ·  Default" if name == self.rules.get("default_workflow_template") else ""))
            docs = template.get("documents", {}) if isinstance(template, dict) else {}
            for document in self.rules.get("document_types", []):
                entry = docs.get(document, {}) if isinstance(docs, dict) else {}
                tree.insert("", "end", values=(document, entry.get("status", "optional"), entry.get("note", "")))

        def list_select(_event=None):
            names = template_names()
            selection = template_list.curselection()
            if not selection or not names:
                return
            current_template.set(names[int(selection[0])])
            refresh_documents()

        def document_select(_event=None):
            document = selected_document()
            if not document:
                return
            entry = templates[current_template.get()]["documents"].get(document, {})
            status_var.set(str(entry.get("status", "optional")))
            note_var.set(str(entry.get("note", "")))

        def save_document_setting():
            document = selected_document()
            if not document:
                messagebox.showinfo(APP_TITLE, "Select an output PDF first.", parent=window)
                return
            templates[current_template.get()]["documents"][document] = {"status": status_var.get(), "note": note_var.get().strip()[:500]}
            if self.save_rules():
                refresh_documents()

        def prompt_name(prompt: str, initial: str = "") -> str:
            entered = simpledialog.askstring(APP_TITLE, prompt, initialvalue=initial, parent=window)
            return re.sub(r"\s+", " ", entered.strip()) if entered else ""

        def add_template(copy_current: bool = False):
            name = prompt_name("New checklist template name:", "New Checklist")
            if not name:
                return
            if any(existing.casefold() == name.casefold() for existing in templates):
                messagebox.showwarning(APP_TITLE, "A checklist template with that name already exists.", parent=window)
                return
            if copy_current and current_template.get() in templates:
                templates[name] = copy.deepcopy(templates[current_template.get()])
            else:
                templates[name] = {"description": "", "documents": {document: {"status": "optional", "note": ""} for document in self.rules.get("document_types", [])}}
            self.save_rules()
            refresh_templates(name)

        def rename_template():
            old = current_template.get()
            name = prompt_name("Rename checklist template:", old)
            if not name or name == old:
                return
            if any(existing.casefold() == name.casefold() for existing in templates):
                messagebox.showwarning(APP_TITLE, "A checklist template with that name already exists.", parent=window)
                return
            templates[name] = templates.pop(old)
            if self.rules.get("default_workflow_template") == old:
                self.rules["default_workflow_template"] = name
            self.save_rules()
            refresh_templates(name)

        def delete_template():
            name = current_template.get()
            if len(templates) <= 1:
                messagebox.showwarning(APP_TITLE, "Keep at least one checklist template.", parent=window)
                return
            if not messagebox.askyesno(APP_TITLE, f"Delete the {name} checklist template?", parent=window):
                return
            del templates[name]
            if self.rules.get("default_workflow_template") == name:
                self.rules["default_workflow_template"] = next(iter(templates))
            self.save_rules()
            refresh_templates()

        def make_default():
            self.rules["default_workflow_template"] = current_template.get()
            self.save_rules()
            refresh_templates(current_template.get())

        def assign_existing_folder():
            selected = filedialog.askdirectory(title="Choose an existing employee folder", parent=window)
            if not selected:
                return
            folder = Path(selected)
            sidecar = folder / ".packetflow.json"
            existing: dict = {}
            if sidecar.is_file():
                try:
                    loaded = json.loads(sidecar.read_text(encoding="utf-8"))
                    existing = loaded if isinstance(loaded, dict) else {}
                except Exception:
                    existing = {}
            folder_window = ctk.CTkToplevel(window)
            folder_window.title("PacketFlow Employee Folder Checklist")
            folder_window.geometry("920x610")
            folder_window.minsize(760, 500)
            folder_window.transient(window)
            folder_window.grab_set()
            ctk.CTkLabel(folder_window, text="Employee Folder Checklist", text_color=CARD_NAVY, font=("Segoe UI", 18, "bold")).pack(anchor="w", padx=18, pady=(15, 2))
            ctk.CTkLabel(folder_window, text=str(folder), text_color=MUTED, font=("Segoe UI", 10), wraplength=860, justify="left").pack(anchor="w", padx=18, pady=(0, 8))
            top = ctk.CTkFrame(folder_window, fg_color="#F8FAFC", corner_radius=6)
            top.pack(fill="x", padx=18, pady=(0, 8))
            ctk.CTkLabel(top, text="Workflow template", text_color=TEXT, font=("Segoe UI", 10, "bold")).pack(side="left", padx=(10, 7), pady=9)
            assigned_var = tk.StringVar(value=str(existing.get("workflow_template", "")).strip() or current_template.get())
            assigned_combo = ctk.CTkComboBox(top, variable=assigned_var, values=template_names(), state="readonly", width=220)
            assigned_combo.pack(side="left", pady=8)
            ctk.CTkLabel(top, text="Waive only after supervisor review. Reasons are stored as metadata only.", text_color=MUTED, font=("Segoe UI", 10)).pack(side="left", padx=(12, 0))
            folder_tree = ttk.Treeview(folder_window, columns=("document", "requirement", "waiver"), show="headings", selectmode="browse")
            for column, heading, width in (("document", "Output PDF", 340), ("requirement", "Requirement", 120), ("waiver", "Manual Waiver Reason", 370)):
                folder_tree.heading(column, text=heading)
                folder_tree.column(column, width=width, minwidth=90, stretch=(column != "requirement"))
            folder_tree.pack(fill="both", expand=True, padx=18, pady=(0, 8))
            waivers = {str(key): str(value) for key, value in existing.get("waived_documents", {}).items()} if isinstance(existing.get("waived_documents"), dict) else {}

            def refresh_folder_documents(*_args):
                folder_tree.delete(*folder_tree.get_children())
                template = templates.get(assigned_var.get(), {})
                docs = template.get("documents", {}) if isinstance(template, dict) else {}
                for document in self.rules.get("document_types", []):
                    entry = docs.get(document, {}) if isinstance(docs, dict) else {}
                    folder_tree.insert("", "end", values=(document, entry.get("status", "optional"), waivers.get(document, "")))

            def folder_selected_document() -> str:
                selection = folder_tree.selection()
                return str(folder_tree.item(selection[0], "values")[0]) if selection else ""

            def waive_document():
                document = folder_selected_document()
                if not document:
                    messagebox.showinfo(APP_TITLE, "Select a document first.", parent=folder_window)
                    return
                reason = simpledialog.askstring(APP_TITLE, f"Reason for waiving {document}:", initialvalue=waivers.get(document, ""), parent=folder_window)
                if reason and reason.strip():
                    waivers[document] = reason.strip()[:500]
                    refresh_folder_documents()

            def clear_waiver():
                document = folder_selected_document()
                if document in waivers:
                    waivers.pop(document, None)
                    refresh_folder_documents()

            def save_folder_metadata():
                try:
                    self.write_packet_metadata(folder, assigned_var.get(), waivers)
                except Exception as exc:
                    messagebox.showerror(APP_TITLE, "The employee-folder metadata could not be written.\n\n" + str(exc), parent=folder_window)
                    return
                messagebox.showinfo(APP_TITLE, f"Saved {assigned_var.get()} for:\n\n{folder}", parent=folder_window)
                folder_window.destroy()

            assigned_combo.configure(command=refresh_folder_documents)
            actions = ctk.CTkFrame(folder_window, fg_color="transparent")
            actions.pack(fill="x", padx=18, pady=(0, 14))
            ctk.CTkButton(actions, text="Waive Selected", command=waive_document, width=118, height=30, fg_color="#FFFFFF", hover_color="#EEF6FF", text_color=PRODUCT_BLUE, border_width=1, border_color=PRODUCT_BLUE).pack(side="left")
            ctk.CTkButton(actions, text="Clear Waiver", command=clear_waiver, width=102, height=30, fg_color="#FFFFFF", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="left", padx=(6, 0))
            ctk.CTkButton(actions, text="Cancel", command=folder_window.destroy, width=80, height=30, fg_color="#FFFFFF", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="right")
            ctk.CTkButton(actions, text="Save Folder Checklist", command=save_folder_metadata, width=145, height=30, fg_color=PRODUCT_BLUE, hover_color=SUCCESS_GREEN).pack(side="right", padx=(0, 7))
            refresh_folder_documents()

        template_list.bind("<<ListboxSelect>>", list_select)
        tree.bind("<<TreeviewSelect>>", document_select)
        ctk.CTkButton(editor, text="Save Document Setting", command=save_document_setting, width=158, height=28, fg_color=PRODUCT_BLUE, hover_color=SUCCESS_GREEN).grid(row=0, column=4, padx=(0, 10), pady=8)

        buttons = ctk.CTkFrame(window, fg_color="transparent")
        buttons.pack(fill="x", padx=20, pady=(0, 14))
        ctk.CTkButton(buttons, text="New", command=lambda: add_template(False), width=70, height=30, fg_color="#FFFFFF", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="left")
        ctk.CTkButton(buttons, text="Duplicate", command=lambda: add_template(True), width=88, height=30, fg_color="#FFFFFF", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="left", padx=(6, 0))
        ctk.CTkButton(buttons, text="Rename", command=rename_template, width=82, height=30, fg_color="#FFFFFF", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="left", padx=(6, 0))
        ctk.CTkButton(buttons, text="Delete", command=delete_template, width=75, height=30, fg_color="#FFFFFF", hover_color="#FBEAEA", text_color=WARNING, border_width=1, border_color=WARNING).pack(side="left", padx=(6, 0))
        ctk.CTkButton(buttons, text="Set as Default", command=make_default, width=112, height=30, fg_color="#FFFFFF", hover_color="#EEF6FF", text_color=PRODUCT_BLUE, border_width=1, border_color=PRODUCT_BLUE).pack(side="left", padx=(12, 0))
        ctk.CTkButton(buttons, text="Assign to Existing Folder", command=assign_existing_folder, width=166, height=30, fg_color="#FFFFFF", hover_color="#EEF6FF", text_color=PRODUCT_BLUE, border_width=1, border_color=PRODUCT_BLUE).pack(side="left", padx=(6, 0))
        ctk.CTkButton(buttons, text="Close", command=window.destroy, width=80, height=30, fg_color="#FFFFFF", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="right")
        refresh_templates()

    def show_audit_center(self):
        """Open the combined audit launcher and unresolved-item queue."""
        return self.show_review_queue()

    def show_review_queue(self):
        window = ctk.CTkToplevel(self.root)
        window.title("PacketFlow Audit Center")
        window.geometry("1260x720")
        window.minsize(980, 560)
        window.transient(self.root)

        ctk.CTkLabel(
            window,
            text="Audit Center",
            text_color=CARD_NAVY,
            font=("Segoe UI", 21, "bold"),
        ).pack(anchor="w", padx=20, pady=(16, 2))
        ctk.CTkLabel(
            window,
            text=(
                "Run an employee-folder audit or manage unresolved directory-audit "
                "findings and Outlook items that could not be filed automatically. "
                "Check several rows to clear them together. PacketFlow stores metadata only."
            ),
            text_color=MUTED,
            font=("Segoe UI", 11),
            wraplength=1160,
            justify="left",
        ).pack(anchor="w", padx=20, pady=(0, 8))

        audit_actions = ctk.CTkFrame(window, fg_color="#F8FAFC", corner_radius=6)
        audit_actions.pack(fill="x", padx=20, pady=(0, 10))
        ctk.CTkLabel(
            audit_actions,
            text="Run a new audit:",
            text_color=TEXT,
            font=("Segoe UI", 11, "bold"),
        ).pack(side="left", padx=(12, 8), pady=10)
        ctk.CTkButton(
            audit_actions,
            text="Open Folder",
            command=self.choose_employee_folder_to_audit,
            width=104,
            height=28,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
        ).pack(side="left", padx=(0, 6), pady=8)
        ctk.CTkButton(
            audit_actions,
            text="Open Directory",
            command=self.choose_directory_to_audit,
            width=118,
            height=28,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            text_color=TEXT,
            border_width=1,
            border_color="#B8C7D8",
        ).pack(side="left", pady=8)
        ctk.CTkLabel(
            audit_actions,
            text="Open Folder audits one employee folder. Open Directory gives you all, selected, recent, and custom-date options.",
            text_color=MUTED,
            font=("Segoe UI", 10),
        ).pack(side="left", padx=(12, 8), pady=10)

        options = ctk.CTkFrame(window, fg_color="transparent")
        options.pack(fill="x", padx=20, pady=(0, 6))
        show_resolved_var = tk.BooleanVar(value=False)
        selected_count_var = tk.StringVar(value="0 items checked")

        table_frame = ctk.CTkFrame(window, fg_color="#FFFFFF", border_width=1, border_color=BORDER)
        table_frame.pack(fill="both", expand=True, padx=20, pady=(0, 10))
        columns = ("mark", "updated", "status", "category", "employee", "issue", "location")
        tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        widths = {"mark": 44, "updated": 135, "status": 72, "category": 125, "employee": 145, "issue": 400, "location": 250}
        headings = {"mark": "✓", "updated": "Updated", "status": "Status", "category": "Type", "employee": "Employee / Folder", "issue": "Issue", "location": "Location"}
        for column in columns:
            tree.heading(column, text=headings[column])
            tree.column(column, width=widths[column], minwidth=42 if column == "mark" else 70, stretch=(column in {"issue", "location"}), anchor="center" if column in {"mark", "status"} else "w")
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=8)
        scrollbar.pack(side="right", fill="y", padx=(0, 8), pady=8)

        detail_var = tk.StringVar(value="Select an item to see details.")
        ctk.CTkLabel(
            window,
            textvariable=detail_var,
            text_color=MUTED,
            font=("Segoe UI", 10),
            wraplength=1200,
            justify="left",
        ).pack(anchor="w", padx=20, pady=(0, 8))

        current_items: dict[str, object] = {}
        checked_ids: set[int] = set()

        def update_checked_count():
            selected_count_var.set(f"{len(checked_ids)} item(s) checked")

        def selected_item():
            selection = tree.selection()
            return current_items.get(selection[0]) if selection else None

        def item_path(item) -> Path | None:
            for raw in (getattr(item, "destination_path", ""), getattr(item, "source_path", "")):
                if not raw:
                    continue
                candidate = Path(raw)
                if candidate.exists():
                    return candidate if candidate.is_dir() else candidate.parent
            return None

        def refresh():
            tree.delete(*tree.get_children())
            current_items.clear()
            status = "all" if show_resolved_var.get() else "open"
            rows = self.ledger_call("list_review_items", status, 1500) or []
            visible_ids = {int(item.id) for item in rows}
            checked_ids.intersection_update(visible_ids)
            for item in rows:
                iid = str(item.id)
                location = item.destination_path or item.source_path
                current_items[iid] = item
                tree.insert(
                    "",
                    "end",
                    iid=iid,
                    values=("☑" if item.id in checked_ids else "☐", item.updated_at, item.status.title(), item.category, item.employee, item.title, location),
                )
            detail_var.set(
                f"{len(rows)} review item(s) shown. Check rows to apply a bulk action."
                if rows else "No review items match the current view. The queue is clear."
            )
            update_checked_count()
            self.update_review_queue_badge()

        # Keep this queue synchronized while the Audit Center remains open.
        # The directory-audit completion handler calls refresh_open_audit_centers.
        callbacks = list(getattr(self, "_audit_center_refresh_callbacks", []))
        callbacks.append((window, refresh))
        self._audit_center_refresh_callbacks = callbacks

        def close_window():
            callbacks = list(getattr(self, "_audit_center_refresh_callbacks", []))
            self._audit_center_refresh_callbacks = [
                (open_window, callback)
                for open_window, callback in callbacks
                if open_window is not window
            ]
            window.destroy()

        window.protocol("WM_DELETE_WINDOW", close_window)

        def show_detail(_event=None):
            item = selected_item()
            if not item:
                return
            detail_var.set(
                f"{item.title} | {item.detail or 'No additional detail'}"
                + (f" | Source: {item.source_path}" if item.source_path else "")
            )

        def open_location():
            item = selected_item()
            location = item_path(item) if item else None
            if not location:
                messagebox.showinfo("Audit Center", "Select a row whose stored folder is available on this computer.", parent=window)
                return
            try:
                os.startfile(location)
            except Exception as exc:
                messagebox.showerror("Audit Center", "The folder could not be opened.\n\n" + str(exc), parent=window)

        def toggle_checked(iid: str):
            item = current_items.get(iid)
            if not item:
                return
            if item.id in checked_ids:
                checked_ids.remove(item.id)
            else:
                checked_ids.add(item.id)
            values = list(tree.item(iid, "values"))
            values[0] = "☑" if item.id in checked_ids else "☐"
            tree.item(iid, values=values)
            update_checked_count()

        def tree_click(event):
            iid = tree.identify_row(event.y)
            if iid and tree.identify_column(event.x) == "#1":
                toggle_checked(iid)
                return "break"
            return None

        def select_all_visible():
            visible = [int(iid) for iid in tree.get_children()]
            if visible and all(item_id in checked_ids for item_id in visible):
                checked_ids.difference_update(visible)
            else:
                checked_ids.update(visible)
            refresh()

        def bulk_action(action: str):
            if not checked_ids:
                messagebox.showinfo("Audit Center", "Check one or more items first.", parent=window)
                return
            if action == "clear":
                prompt = f"Clear {len(checked_ids)} checked item(s) from the Review Queue?\n\nCleared items are removed permanently."
                method = "clear_review_items"
                args = (sorted(checked_ids),)
            else:
                prompt = f"Reopen {len(checked_ids)} checked item(s)?"
                method = "reopen_review_items"
                args = (sorted(checked_ids),)
            if not messagebox.askyesno("Audit Center", prompt, parent=window):
                return
            changed = int(self.ledger_call(method, *args) or 0)
            checked_ids.clear()
            refresh()
            messagebox.showinfo("Audit Center", f"{changed} item(s) updated.", parent=window)

        ctk.CTkButton(options, text="Select All Visible", command=select_all_visible, width=126, height=28, fg_color="#F8FAFC", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="left")
        ctk.CTkLabel(options, textvariable=selected_count_var, text_color=MUTED, font=("Segoe UI", 10)).pack(side="left", padx=(10, 0))
        ctk.CTkCheckBox(options, text="Show resolved items", variable=show_resolved_var, command=refresh, text_color=TEXT, font=("Segoe UI", 10)).pack(side="right")

        tree.bind("<<TreeviewSelect>>", show_detail)
        tree.bind("<Double-1>", lambda _event: open_location())
        tree.bind("<Button-1>", tree_click, add="+")

        actions = ctk.CTkFrame(window, fg_color="transparent")
        actions.pack(fill="x", padx=20, pady=(0, 14))
        ctk.CTkButton(actions, text="Open Selected Folder", command=open_location, width=150, height=32, fg_color=PRODUCT_BLUE, hover_color=SUCCESS_GREEN).pack(side="left")
        ctk.CTkButton(actions, text="Clear Checked", command=lambda: bulk_action("clear"), width=125, height=32, fg_color="#F8FAFC", hover_color=SUCCESS_GREEN, text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="left", padx=(8, 0))
        ctk.CTkButton(actions, text="Reopen Checked", command=lambda: bulk_action("reopen"), width=125, height=32, fg_color="#F8FAFC", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="left", padx=(8, 0))
        ctk.CTkButton(actions, text="Refresh", command=refresh, width=90, height=32, fg_color="#F8FAFC", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="left", padx=(8, 0))
        ctk.CTkButton(actions, text="Close", command=close_window, width=90, height=32, fg_color="#F8FAFC", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="right")
        refresh()

    def show_packet_history(self):
        """Read-only metadata history view available from Settings > Advanced."""
        window = ctk.CTkToplevel(self.root)
        window.title("PacketFlow Packet History")
        window.geometry("1320x760")
        window.minsize(1000, 580)
        window.transient(self.root)

        ctk.CTkLabel(
            window,
            text="Packet History",
            text_color=CARD_NAVY,
            font=("Segoe UI", 21, "bold"),
        ).pack(anchor="w", padx=20, pady=(16, 2))
        ctk.CTkLabel(
            window,
            text=(
                "Read-only metadata history for packet exports, Outlook filings, and directory audits. "
                "PacketFlow does not store OCR text, email bodies, Social Security numbers, banking details, or document contents here."
            ),
            text_color=MUTED,
            font=("Segoe UI", 11),
            wraplength=1220,
            justify="left",
        ).pack(anchor="w", padx=20, pady=(0, 10))

        filters = ctk.CTkFrame(window, fg_color="#FFFFFF", border_width=1, border_color=BORDER)
        filters.pack(fill="x", padx=20, pady=(0, 10))
        search_var = tk.StringVar()
        category_var = tk.StringVar(value="All activity types")
        source_var = tk.StringVar(value="All sources")
        from_var = tk.StringVar()
        to_var = tk.StringVar()
        result_var = tk.StringVar(value="")

        def filter_label(parent, text, column):
            ctk.CTkLabel(parent, text=text, text_color=MUTED, font=("Segoe UI", 10)).grid(row=0, column=column, sticky="w", padx=(10, 4), pady=(8, 2))

        filter_label(filters, "Employee or keyword", 0)
        filter_label(filters, "Activity type", 1)
        filter_label(filters, "Source", 2)
        filter_label(filters, "From date", 3)
        filter_label(filters, "To date", 4)
        ctk.CTkEntry(filters, textvariable=search_var, width=230, placeholder_text="Search history").grid(row=1, column=0, sticky="ew", padx=(10, 4), pady=(0, 10))
        category_menu = ctk.CTkOptionMenu(filters, variable=category_var, values=["All activity types"], width=180)
        category_menu.grid(row=1, column=1, sticky="ew", padx=4, pady=(0, 10))
        source_menu = ctk.CTkOptionMenu(filters, variable=source_var, values=["All sources", "Manual scan", "Scanner folder", "Outlook", "Directory audit"], width=150)
        source_menu.grid(row=1, column=2, sticky="ew", padx=4, pady=(0, 10))
        ctk.CTkEntry(filters, textvariable=from_var, width=110, placeholder_text="YYYY-MM-DD").grid(row=1, column=3, sticky="ew", padx=4, pady=(0, 10))
        ctk.CTkEntry(filters, textvariable=to_var, width=110, placeholder_text="YYYY-MM-DD").grid(row=1, column=4, sticky="ew", padx=4, pady=(0, 10))
        for column in range(5):
            filters.grid_columnconfigure(column, weight=1 if column == 0 else 0)

        table_frame = ctk.CTkFrame(window, fg_color="#FFFFFF", border_width=1, border_color=BORDER)
        table_frame.pack(fill="both", expand=True, padx=20, pady=(0, 8))
        columns = ("date", "employee", "activity", "status", "source", "destination", "detail")
        tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        headings = {"date": "Date", "employee": "Employee", "activity": "Activity", "status": "Status", "source": "Source", "destination": "Destination", "detail": "Details"}
        widths = {"date": 145, "employee": 150, "activity": 145, "status": 85, "source": 125, "destination": 245, "detail": 380}
        for column in columns:
            tree.heading(column, text=headings[column])
            tree.column(column, width=widths[column], minwidth=70, stretch=(column in {"destination", "detail"}), anchor="w")
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        tree.pack(side="left", fill="both", expand=True, padx=(8, 0), pady=8)
        scrollbar.pack(side="right", fill="y", padx=(0, 8), pady=8)

        history_rows = []
        visible_rows = {}

        def classify_source(item):
            text = f"{getattr(item, 'category', '')} {getattr(item, 'source_path', '')} {getattr(item, 'detail', '')}".casefold()
            if "outlook" in text or "email" in text or "clearance" in text:
                return "Outlook"
            if "scanner" in text or "watch folder" in text:
                return "Scanner folder"
            if "directory audit" in text or str(getattr(item, "category", "")).casefold() == "directory audit":
                return "Directory audit"
            return "Manual scan"

        def parse_date(value, end=False):
            value = str(value or "").strip()
            if not value:
                return None
            try:
                parsed = datetime.strptime(value, "%Y-%m-%d")
                return parsed + (timedelta(days=1) if end else timedelta())
            except ValueError:
                raise ValueError("Dates must use YYYY-MM-DD format.")

        def selected_row():
            selection = tree.selection()
            return visible_rows.get(selection[0]) if selection else None

        def refresh():
            nonlocal history_rows
            try:
                start = parse_date(from_var.get())
                end = parse_date(to_var.get(), end=True)
            except ValueError as exc:
                messagebox.showerror("Packet History", str(exc), parent=window)
                return
            history_rows = self.ledger_call("list_history_events", 5000) or []
            categories = sorted({str(item.category) for item in history_rows if str(item.category).strip()})
            menu_values = ["All activity types"] + categories
            category_menu.configure(values=menu_values)
            if category_var.get() not in menu_values:
                category_var.set("All activity types")
            tree.delete(*tree.get_children())
            visible_rows.clear()
            query = search_var.get().strip().casefold()
            wanted_category = category_var.get()
            wanted_source = source_var.get()
            shown = 0
            for item in history_rows:
                try:
                    created = datetime.strptime(str(item.created_at), "%Y-%m-%d %H:%M:%S")
                except ValueError:
                    created = None
                if start and (not created or created < start):
                    continue
                if end and (not created or created >= end):
                    continue
                source = classify_source(item)
                if wanted_category != "All activity types" and item.category != wanted_category:
                    continue
                if wanted_source != "All sources" and source != wanted_source:
                    continue
                haystack = " ".join(str(value or "") for value in (item.employee, item.category, item.status, item.source_path, item.destination_path, item.detail)).casefold()
                if query and query not in haystack:
                    continue
                iid = str(item.id)
                visible_rows[iid] = item
                tree.insert("", "end", iid=iid, values=(item.created_at, item.employee, item.category, item.status, source, item.destination_path, item.detail))
                shown += 1
            result_var.set(f"{shown} history item(s) shown")

        def open_location():
            item = selected_row()
            if not item:
                messagebox.showinfo("Packet History", "Select a history row first.", parent=window)
                return
            for raw in (item.destination_path, item.source_path):
                if not raw:
                    continue
                candidate = Path(raw)
                if candidate.exists():
                    target = candidate if candidate.is_dir() else candidate.parent
                    try:
                        if os.name == "nt":
                            os.startfile(str(target))
                        else:
                            webbrowser.open(target.as_uri())
                    except Exception as exc:
                        messagebox.showerror("Packet History", f"The folder could not be opened.\n\n{exc}", parent=window)
                    return
            messagebox.showinfo("Packet History", "The stored folder is not available on this computer.", parent=window)

        def export_csv():
            rows = [visible_rows[str(iid)] for iid in tree.get_children()]
            if not rows:
                messagebox.showinfo("Packet History", "There are no visible rows to export.", parent=window)
                return
            path = filedialog.asksaveasfilename(parent=window, title="Export Packet History", defaultextension=".csv", filetypes=[("CSV files", "*.csv")], initialfile=f"PacketFlow History {time.strftime('%Y-%m-%d')}.csv")
            if not path:
                return
            try:
                with open(path, "w", newline="", encoding="utf-8-sig") as handle:
                    writer = csv.writer(handle)
                    writer.writerow(["Date", "Employee", "Activity", "Status", "Source", "Source Path", "Destination Path", "Details"])
                    for item in rows:
                        writer.writerow([item.created_at, item.employee, item.category, item.status, classify_source(item), item.source_path, item.destination_path, item.detail])
                messagebox.showinfo("Packet History", f"Exported {len(rows)} visible history item(s).", parent=window)
            except Exception as exc:
                messagebox.showerror("Packet History", f"Could not export CSV.\n\n{exc}", parent=window)

        buttons = ctk.CTkFrame(window, fg_color="transparent")
        buttons.pack(fill="x", padx=20, pady=(0, 14))
        ctk.CTkButton(buttons, text="Apply Filters", command=refresh, width=105, height=32, fg_color=PRODUCT_BLUE, hover_color=SUCCESS_GREEN).pack(side="left")
        ctk.CTkButton(buttons, text="Open Folder", command=open_location, width=105, height=32, fg_color="#F8FAFC", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="left", padx=(8, 0))
        ctk.CTkButton(buttons, text="Export Visible CSV", command=export_csv, width=135, height=32, fg_color="#F8FAFC", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="left", padx=(8, 0))
        ctk.CTkLabel(buttons, textvariable=result_var, text_color=MUTED, font=("Segoe UI", 10)).pack(side="left", padx=(12, 0))
        ctk.CTkButton(buttons, text="Close", command=window.destroy, width=90, height=32, fg_color="#F8FAFC", hover_color="#EEF6FF", text_color=TEXT, border_width=1, border_color="#B8C7D8").pack(side="right")
        tree.bind("<Double-1>", lambda _event: open_location())
        refresh()

    def export_diagnostics_zip(self):
        """Create a redacted support ZIP without employee records or secrets."""
        save_path = filedialog.asksaveasfilename(
            parent=self.root,
            title="Export PacketFlow Diagnostics",
            defaultextension=".zip",
            filetypes=[("ZIP archives", "*.zip")],
            initialfile=f"PacketFlow Diagnostics {time.strftime('%Y-%m-%d')}.zip",
        )
        if not save_path:
            return

        secret_fragments = (
            "token", "secret", "password", "credential", "client_secret",
            "refresh", "authorization", "cookie",
        )
        path_fragments = ("employee", "folder", "directory", "location", "path")

        def redact_settings(value, key=""):
            key_lower = str(key).casefold()
            if any(fragment in key_lower for fragment in secret_fragments):
                return "[REDACTED]"
            if any(fragment in key_lower for fragment in path_fragments):
                return "[REDACTED PATH]" if str(value or "").strip() else ""
            if isinstance(value, dict):
                return {str(k): redact_settings(v, str(k)) for k, v in value.items()}
            if isinstance(value, list):
                return [redact_settings(item, key) for item in value]
            return value

        def safe_read(path: Path, maximum=200000):
            try:
                if not path.exists():
                    return "[Not present]\n"
                text = path.read_text(encoding="utf-8", errors="replace")[-maximum:]
                # Logs should already avoid sensitive content. Still redact common
                # Windows user-folder paths before exporting a support package.
                text = re.sub(r"(?i)[A-Z]:\\Users\\[^\\\r\n]+", "[REDACTED USER PATH]", text)
                return text
            except Exception as exc:
                return f"[Could not read: {exc}]\n"

        dependency_names = [
            "Pillow", "pypdf", "customtkinter", "windnd", "pystray",
            "msal", "msal-extensions", "requests", "pywin32",
        ]
        dependency_versions = {}
        for name in dependency_names:
            try:
                dependency_versions[name] = importlib_metadata.version(name)
            except Exception:
                dependency_versions[name] = "not detected"

        analyzer = getattr(self, "analyzer", None)
        system_summary = {
            "packetflow_version": APP_VERSION,
            "python_version": sys.version.split()[0],
            "platform": platform.platform(),
            "python_executable": "[REDACTED PATH]",
            "app_data_directory": "[REDACTED PATH]",
            "rules_storage": "AppData",
            "tesseract_detected": bool(getattr(analyzer, "tesseract", None)),
            "poppler_detected": bool(getattr(analyzer, "pdftoppm", None)),
            "ledger_present": PACKET_LEDGER_PATH.exists(),
            "settings_present": SETTINGS_PATH.exists(),
            "rules_present": ACTIVE_RULES_PATH.exists(),
            "dependencies": dependency_versions,
        }
        settings_summary = redact_settings(dict(getattr(self, "settings", {}) or {}))
        rules_summary = {
            "active_profile": getattr(self, "active_profile_name", ""),
            "profile_names": sorted(str(name) for name in getattr(self, "rule_profiles", {}).keys()),
            "active_document_type_count": len(getattr(self, "rules", {}).get("document_types", [])),
            "workflow_template_names": sorted(str(name) for name in getattr(self, "rules", {}).get("workflow_templates", {}).keys()),
        }

        try:
            with tempfile.TemporaryDirectory(prefix="packetflow-diagnostics-") as temp_dir:
                root = Path(temp_dir)
                (root / "system_summary.json").write_text(json.dumps(system_summary, indent=2), encoding="utf-8")
                (root / "settings_summary_redacted.json").write_text(json.dumps(settings_summary, indent=2), encoding="utf-8")
                (root / "rules_summary.json").write_text(json.dumps(rules_summary, indent=2), encoding="utf-8")
                (root / "PacketFlow Error Log.txt").write_text(safe_read(ERROR_LOG_PATH), encoding="utf-8")
                (root / "Email Filing Audit Log.txt").write_text(safe_read(EMAIL_FILING_AUDIT_PATH), encoding="utf-8")
                with zipfile.ZipFile(save_path, "w", zipfile.ZIP_DEFLATED) as archive:
                    for item in sorted(root.iterdir()):
                        archive.write(item, arcname=item.name)
            messagebox.showinfo(
                "PacketFlow Diagnostics",
                "A redacted diagnostics ZIP was created. It does not include PDFs, OCR text, email bodies, employee names, login tokens, or banking details.",
                parent=self.root,
            )
        except Exception as exc:
            messagebox.showerror("PacketFlow Diagnostics", f"Could not export diagnostics.\n\n{exc}", parent=self.root)


