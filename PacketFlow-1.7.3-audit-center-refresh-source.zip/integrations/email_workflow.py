from __future__ import annotations

import os
import re
import shutil
import threading
import time
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox

from pypdf import PdfReader

try:
    import customtkinter as ctk
except ImportError as exc:
    raise SystemExit("Missing required package: customtkinter. Run Start PacketFlow.cmd so it can install dependencies.") from exc

APP_DIR = Path(__file__).resolve().parents[1]
_APPDATA_ROOT = os.environ.get("APPDATA", "")
APP_DATA_DIR = (Path(_APPDATA_ROOT) / "PacketFlow") if _APPDATA_ROOT else APP_DIR
EMAIL_FILING_AUDIT_PATH = APP_DATA_DIR / "Email Filing Audit Log.txt"

CARD_NAVY = "#112C6B"
PRODUCT_BLUE = "#1E88E5"
SUCCESS_GREEN = "#63C393"
TEXT = "#0F172A"
MUTED = "#64748B"
BORDER = "#DDE5EE"

class EmailWorkflowMixin:
    @staticmethod
    def email_setting_items(value: str) -> list[str]:
        return [
            item.strip().lower()
            for item in re.split(r"[,;\n]+", str(value))
            if item.strip()
        ]

    @staticmethod
    def normalized_name_text(value: str) -> str:
        return re.sub(
            r"\s+",
            " ",
            re.sub(r"[^a-z0-9]+", " ", str(value).lower()),
        ).strip()

    @classmethod
    def employee_name_variants(cls, folder_name: str) -> set[str]:
        """Return likely full-name phrases represented by an employee folder."""
        raw = str(folder_name).strip()
        if not raw:
            return set()

        stop_words = {
            "active",
            "applicant",
            "archive",
            "employee",
            "employees",
            "folder",
            "inactive",
            "needs",
            "new",
            "onboarding",
            "pca",
            "personnel",
            "review",
            "terminated",
        }
        if "," in raw:
            last_part, first_part = raw.split(",", 1)
            last_tokens = cls.normalized_name_text(last_part).split()
            first_tokens = cls.normalized_name_text(first_part).split()
            if last_tokens and first_tokens:
                first = next(
                    (token for token in first_tokens if token not in stop_words),
                    "",
                )
                last = next(
                    (token for token in last_tokens if token not in stop_words),
                    "",
                )
                if first and last:
                    return {f"{first} {last}", f"{last} {first}"}

        tokens = [
            token
            for token in cls.normalized_name_text(raw).split()
            if token not in stop_words
            and not token.isdigit()
            and len(token) > 1
        ]
        if len(tokens) < 2:
            return set()

        variants = {f"{tokens[0]} {tokens[1]}"}
        if len(tokens) >= 3:
            variants.add(" ".join(tokens[:3]))
            variants.add(f"{tokens[0]} {tokens[-1]}")
        return variants

    def employee_folder_index(self, root: Path | None = None) -> list[dict]:
        configured = str(
            self.settings.get("outlook_employee_folder_root", "")
        ).strip()
        employee_root = root or (Path(configured) if configured else None)
        if not employee_root or not employee_root.is_dir():
            return []

        results: list[dict] = []
        try:
            directories = [
                path for path in employee_root.iterdir() if path.is_dir()
            ]
        except OSError:
            return []
        for directory in directories:
            variants = self.employee_name_variants(directory.name)
            if variants:
                results.append({
                    "path": directory,
                    "name": directory.name,
                    "variants": variants,
                })
        return results

    def match_employee_folder(
        self,
        email_body: str,
        root: Path | None = None,
    ) -> dict:
        normalized_body = f" {self.normalized_name_text(email_body)} "
        matches: list[dict] = []
        for candidate in self.employee_folder_index(root):
            matching_variants = sorted(
                variant
                for variant in candidate["variants"]
                if f" {variant} " in normalized_body
            )
            if matching_variants:
                matches.append({
                    **candidate,
                    "matched_name": matching_variants[0],
                })

        unique_by_path = {
            str(match["path"]).casefold(): match for match in matches
        }
        unique_matches = list(unique_by_path.values())
        if len(unique_matches) == 1:
            return {
                "status": "matched",
                "folder": unique_matches[0]["path"],
                "matched_name": unique_matches[0]["matched_name"],
                "matches": unique_matches,
            }
        if not unique_matches:
            return {
                "status": "not_found",
                "folder": None,
                "matched_name": "",
                "matches": [],
            }
        return {
            "status": "ambiguous",
            "folder": None,
            "matched_name": "",
            "matches": unique_matches,
        }

    def email_sender_is_approved(self, sender: str, _subject: str = "", _body: str = "") -> bool:
        """Allow linked report downloads only from configured senders/domains."""
        approved_senders = self.email_setting_items(
            self.settings.get("outlook_approved_senders", "")
        )
        sender_address = str(sender).strip().lower()
        sender_domain = sender_address.rsplit("@", 1)[1] if "@" in sender_address else ""
        return not approved_senders or any(
            item == sender_address if "@" in item else item.lstrip("@") == sender_domain
            for item in approved_senders
        )

    def email_matches_filing_filters(
        self,
        sender: str,
        subject: str,
        body: str,
    ) -> bool:
        if not self.email_sender_is_approved(sender):
            return False

        keywords = self.email_setting_items(
            self.settings.get("outlook_required_keywords", "")
        )
        searchable = f"{subject}\n{body}".lower()
        return not keywords or any(keyword in searchable for keyword in keywords)

    @staticmethod
    def email_keyword_filename_label(keyword: str) -> str:
        acronym_words = {
            "aps": "APS",
            "cps": "CPS",
            "mbc": "MBC",
            "pca": "PCA",
            "pss": "PSS",
            "pps": "PPS",
            "i9": "I-9",
            "i-9": "I-9",
            "w4": "W-4",
            "w-4": "W-4",
        }
        words = re.split(r"(\s+)", str(keyword).strip())
        label = "".join(
            acronym_words.get(word.lower(), word.capitalize())
            if word.strip()
            else word
            for word in words
        ).strip()
        return label or "Outlook Email"

    def matched_email_keyword_label(self, subject: str, body: str) -> str:
        searchable = f"{subject}\n{body}".lower()
        # Stable output names for the Maine clearance sources PacketFlow is
        # intended to monitor. Generic configured keywords remain supported.
        if "adult protective services" in searchable or "not listed in the adult protective services" in searchable:
            return "APS Clearance"
        if "application fee paid" in searchable and ("maine criminal background" in searchable or "mbcc" in searchable):
            return "MCBC Receipt"
        if "child abuse background check report" in searchable:
            return "CPS Clearance"
        if "child abuse" in searchable and ("final_report" in searchable or "cps" in searchable or "carb" in searchable):
            return "CPS Clearance"
        keywords = self.email_setting_items(
            self.settings.get("outlook_required_keywords", "")
        )
        for keyword in keywords:
            if keyword in searchable:
                return self.email_keyword_filename_label(keyword)
        return "Outlook Email"

    def email_filing_pdf_name(
        self,
        folder_name: str,
        subject: str,
        body: str,
    ) -> str:
        keyword_label = self.matched_email_keyword_label(subject, body)
        prefix = str(folder_name).strip() or "Needs Review"
        return f"{prefix} - {keyword_label}.pdf"

    @staticmethod
    def unique_email_destination(folder: Path, filename: str) -> Path:
        clean_name = re.sub(r'[<>:"/\\|?*]', "_", Path(filename).name).strip()
        clean_name = clean_name or "Outlook Attachment.pdf"
        destination = folder / clean_name
        counter = 2
        while destination.exists():
            destination = (
                folder
                / f"{Path(clean_name).stem} ({counter}){Path(clean_name).suffix}"
            )
            counter += 1
        return destination

    def write_email_filing_audit(
        self,
        status: str,
        sender: str,
        subject: str,
        destination: str = "",
        detail: str = "",
    ):
        try:
            with EMAIL_FILING_AUDIT_PATH.open("a", encoding="utf-8") as audit:
                audit.write(
                    f"{time.strftime('%Y-%m-%d %H:%M:%S')} | {status} | "
                    f"{sender} | {subject} | {destination} | {detail}\n"
                )
        except OSError:
            pass

    def email_needs_review_folder(
        self,
        employee_root: Path | None = None,
    ) -> Path | None:
        configured_review = str(
            self.settings.get("outlook_needs_review_folder", "")
        ).strip()
        configured_root = str(
            self.settings.get("outlook_employee_folder_root", "")
        ).strip()
        review_folder = (
            Path(configured_review)
            if configured_review
            else (
                (employee_root or (Path(configured_root) if configured_root else None))
                / "Needs Review"
                if employee_root or configured_root
                else None
            )
        )
        if not review_folder:
            return None
        try:
            review_folder.mkdir(parents=True, exist_ok=True)
            return review_folder
        except OSError:
            return None


    @staticmethod
    def pdf_attachment_search_text(path: Path, max_pages: int = 3) -> str:
        """Extract lightweight text from downloaded/attached PDFs for email filing.

        Forwarded CPS/CARB emails often hide the employee name inside the linked
        report PDF, not in the visible email body.  This lets PacketFlow match
        the employee folder after the linked PDF is downloaded.
        """
        try:
            reader = PdfReader(str(path))
            parts: list[str] = []
            for page in reader.pages[:max_pages]:
                try:
                    parts.append(page.extract_text() or "")
                except Exception:
                    continue
            return "\n".join(part for part in parts if part).strip()
        except Exception:
            return ""

    def email_body_with_attachment_text(
        self,
        body: str,
        attachments: list[Path],
    ) -> str:
        parts = [str(body or "")]
        for attachment in attachments:
            path = Path(attachment)
            if path.suffix.lower() != ".pdf" or not path.is_file():
                continue
            extracted = self.pdf_attachment_search_text(path)
            if extracted:
                parts.append(extracted)
        return "\n\n".join(part for part in parts if part).strip()

    def file_outlook_pdf_attachments(
        self,
        sender: str,
        subject: str,
        body: str,
        attachments: list[Path],
        employee_root: Path | None = None,
    ) -> dict:
        """File PDF attachments after Outlook supplies a message to PacketFlow."""
        pdf_attachments = [
            Path(path)
            for path in attachments
            if Path(path).suffix.lower() == ".pdf" and Path(path).is_file()
        ]
        searchable_body = self.email_body_with_attachment_text(body, pdf_attachments)

        if not self.email_matches_filing_filters(sender, subject, searchable_body):
            return {"status": "ignored", "saved": [], "folder": None}

        match = self.match_employee_folder(searchable_body, employee_root)
        if match["status"] != "matched" or not pdf_attachments:
            reason = (
                "No matching employee folder"
                if match["status"] == "not_found"
                else "Multiple employee folders matched"
                if match["status"] == "ambiguous"
                else "No PDF attachment"
            )
            self.write_email_filing_audit(
                "NEEDS REVIEW",
                sender,
                subject,
                detail=reason,
            )
            review_folder = self.email_needs_review_folder(employee_root)
            review_copies: list[Path] = []
            if review_folder:
                review_name = self.email_filing_pdf_name(
                    "Needs Review",
                    subject,
                    searchable_body,
                )
                for attachment in pdf_attachments:
                    destination = self.unique_email_destination(
                        review_folder,
                        review_name,
                    )
                    shutil.copy2(attachment, destination)
                    review_copies.append(destination)
            review_destination = str(review_copies[0] if review_copies else (review_folder or ""))
            self.ledger_call(
                "add_review_item",
                category="Outlook Email",
                title=reason,
                employee=", ".join(match.get("matches", [])[:3]),
                source_path=subject,
                destination_path=review_destination,
                detail=f"Sender: {sender}",
                context_key="Outlook Email Filing",
            )
            return {
                "status": "needs_review",
                "saved": review_copies,
                "folder": review_folder,
                "reason": reason,
                "matches": match.get("matches", []),
            }

        destination_folder = Path(match["folder"])
        destination_name = self.email_filing_pdf_name(
            destination_folder.name,
            subject,
            searchable_body,
        )
        saved: list[Path] = []
        for attachment in pdf_attachments:
            destination = self.unique_email_destination(
                destination_folder,
                destination_name,
            )
            shutil.copy2(attachment, destination)
            saved.append(destination)
            self.write_email_filing_audit(
                "FILED",
                sender,
                subject,
                destination=str(destination),
                detail=f"Matched {match['matched_name']}",
            )
        self.ledger_call(
            "record_event",
            "Outlook Email",
            "FILED",
            employee=match["matched_name"],
            source_path=subject,
            destination_path=str(destination_folder),
            detail=f"{len(saved)} PDF attachment(s) filed from {sender}",
        )
        return {
            "status": "filed",
            "saved": saved,
            "folder": destination_folder,
            "matched_name": match["matched_name"],
        }

    def show_email_filing_manager(self):
        window = ctk.CTkToplevel(self.root)
        window.title("Outlook Email Filing")
        window.geometry("650x610")
        window.minsize(600, 560)
        window.transient(self.root)
        window.grab_set()

        ctk.CTkLabel(
            window,
            text="Outlook Email Filing",
            text_color=CARD_NAVY,
            font=("Segoe UI", 20, "bold"),
        ).pack(anchor="w", padx=22, pady=(18, 4))
        ctk.CTkLabel(
            window,
            text=(
                "PacketFlow can use the employee folders you already create as "
                "the name list. Choose one Outlook connection method below. "
                "You do not need to configure both."
            ),
            text_color=MUTED,
            font=("Segoe UI", 11),
            wraplength=590,
            justify="left",
        ).pack(anchor="w", padx=22, pady=(0, 12))

        content = ctk.CTkScrollableFrame(
            window,
            fg_color="#FFFFFF",
            border_width=1,
            border_color=BORDER,
        )
        content.pack(fill="both", expand=True, padx=20, pady=(0, 12))

        enabled_var = tk.BooleanVar(
            value=self.setting_enabled("outlook_email_filing_enabled")
        )
        ctk.CTkSwitch(
            content,
            text="Enable Outlook email filing",
            variable=enabled_var,
            text_color=TEXT,
            font=("Segoe UI", 12, "bold"),
            progress_color=SUCCESS_GREEN,
            button_color=PRODUCT_BLUE,
        ).pack(anchor="w", padx=10, pady=(12, 4))
        ctk.CTkLabel(
            content,
            text=(
                "Automatic checks scan the newest 10 messages every 2 minutes. "
                "Check Outlook Now scans the newest 100."
            ),
            text_color=MUTED,
            font=("Segoe UI", 10),
            wraplength=540,
            justify="left",
        ).pack(anchor="w", padx=38, pady=(0, 5))

        saved_connection_method = self.settings.get(
            "outlook_connection_method",
            "auto",
        )
        connection_method_var = tk.StringVar(
            value=(
                "Microsoft Entra / New Outlook"
                if saved_connection_method == "entra"
                else "Local Outlook Profile"
                if saved_connection_method == "local"
                else "Auto Detect"
            )
        )
        connection_frame = ctk.CTkFrame(
            content,
            fg_color="#F8FAFC",
            corner_radius=6,
        )
        connection_frame.pack(fill="x", padx=10, pady=7)
        ctk.CTkLabel(
            connection_frame,
            text="Outlook connection method",
            text_color=TEXT,
            font=("Segoe UI", 12, "bold"),
        ).pack(anchor="w", padx=10, pady=(8, 3))
        connection_selector = ctk.CTkSegmentedButton(
            connection_frame,
            values=[
                "Auto Detect",
                "Local Outlook Profile",
                "Microsoft Entra / New Outlook",
            ],
            variable=connection_method_var,
            selected_color=PRODUCT_BLUE,
            selected_hover_color=PRODUCT_BLUE,
            unselected_color="#FFFFFF",
            unselected_hover_color="#EEF6FF",
            text_color=TEXT,
        )
        connection_selector.pack(fill="x", padx=10, pady=(0, 4))
        connection_help_var = tk.StringVar()
        ctk.CTkLabel(
            connection_frame,
            textvariable=connection_help_var,
            text_color=MUTED,
            font=("Segoe UI", 10),
            wraplength=560,
            justify="left",
        ).pack(anchor="w", padx=10, pady=(0, 8))

        root_var = tk.StringVar(
            value=self.settings.get("outlook_employee_folder_root", "")
            or "No folder selected"
        )
        review_var = tk.StringVar(
            value=self.settings.get("outlook_needs_review_folder", "")
            or "Use employee root folder"
        )

        def folder_row(title: str, variable: tk.StringVar, setting_name: str):
            row = ctk.CTkFrame(content, fg_color="#F8FAFC", corner_radius=6)
            row.pack(fill="x", padx=10, pady=7)
            row.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(
                row,
                text=title,
                text_color=TEXT,
                font=("Segoe UI", 12, "bold"),
            ).grid(row=0, column=0, sticky="w", padx=10, pady=(8, 1))
            ctk.CTkLabel(
                row,
                textvariable=variable,
                text_color=MUTED,
                font=("Segoe UI", 10),
                wraplength=450,
                justify="left",
                anchor="w",
            ).grid(row=1, column=0, sticky="w", padx=10, pady=(0, 8))

            def browse():
                selected = filedialog.askdirectory(
                    title=title,
                    initialdir=str(Path.home()),
                    mustexist=True,
                    parent=window,
                )
                if not selected:
                    return
                self.settings[setting_name] = selected
                variable.set(selected)

            ctk.CTkButton(
                row,
                text="Browse",
                command=browse,
                width=82,
                height=28,
                fg_color="#FFFFFF",
                hover_color="#EEF6FF",
                border_width=1,
                border_color="#CBD5E1",
                text_color=TEXT,
            ).grid(row=0, column=1, rowspan=2, padx=10, pady=8)

        folder_row(
            "Employee folder directory",
            root_var,
            "outlook_employee_folder_root",
        )
        folder_row(
            "Needs Review folder",
            review_var,
            "outlook_needs_review_folder",
        )

        ctk.CTkLabel(
            content,
            text="Approved senders",
            text_color=TEXT,
            font=("Segoe UI", 12, "bold"),
        ).pack(anchor="w", padx=10, pady=(10, 2))
        sender_box = ctk.CTkTextbox(content, height=58)
        sender_box.pack(fill="x", padx=10, pady=(0, 5))
        sender_box.insert(
            "1.0",
            self.settings.get("outlook_approved_senders", ""),
        )
        ctk.CTkLabel(
            content,
            text="Separate senders or domains with commas or new lines. Leave blank to allow any sender.",
            text_color=MUTED,
            font=("Segoe UI", 10),
            wraplength=560,
            justify="left",
        ).pack(anchor="w", padx=10, pady=(0, 7))

        ctk.CTkLabel(
            content,
            text="Required email keywords",
            text_color=TEXT,
            font=("Segoe UI", 12, "bold"),
        ).pack(anchor="w", padx=10, pady=(4, 2))
        keyword_box = ctk.CTkTextbox(content, height=58)
        keyword_box.pack(fill="x", padx=10, pady=(0, 5))
        keyword_box.insert(
            "1.0",
            self.settings.get("outlook_required_keywords", ""),
        )

        local_profile_var = tk.StringVar(
            value=self.settings.get("outlook_local_profile_name", "")
        )
        client_id_var = tk.StringVar(
            value=self.settings.get("outlook_graph_client_id", "")
        )
        tenant_id_var = tk.StringVar(
            value=self.settings.get("outlook_tenant_id", "organizations")
        )
        mail_folder_var = tk.StringVar(
            value=self.settings.get("outlook_mail_folder", "Inbox")
        )
        processed_folder_var = tk.StringVar(
            value=self.settings.get(
                "outlook_processed_folder",
                "PacketFlow Processed",
            )
        )
        connection_specific_frame = ctk.CTkFrame(
            content,
            fg_color="transparent",
        )
        connection_specific_frame.pack(fill="x")

        def labeled_entry(parent, label: str, variable: tk.StringVar):
            ctk.CTkLabel(
                parent,
                text=label,
                text_color=TEXT,
                font=("Segoe UI", 12, "bold"),
            ).pack(anchor="w", padx=10, pady=(9, 2))
            ctk.CTkEntry(parent, textvariable=variable).pack(
                fill="x",
                padx=10,
                pady=(0, 3),
            )

        common_folder_frame = ctk.CTkFrame(content, fg_color="transparent")
        common_folder_frame.pack(fill="x")
        labeled_entry(
            common_folder_frame,
            "Outlook folder to monitor",
            mail_folder_var,
        )
        labeled_entry(
            common_folder_frame,
            "Move completed emails to",
            processed_folder_var,
        )

        def refresh_connection_fields(_value=None):
            for child in connection_specific_frame.winfo_children():
                child.destroy()
            method = connection_method_var.get()
            if method in {"auto", "Auto Detect"}:
                connection_method_var.set("Auto Detect")
                connection_help_var.set(
                    "Recommended. PacketFlow uses Microsoft Entra/New Outlook "
                    "first when it is configured, then falls back to the local "
                    "Classic Outlook profile. Users do not need to know which "
                    "Outlook version they have."
                )
                labeled_entry(
                    connection_specific_frame,
                    "Local Outlook profile name (optional fallback)",
                    local_profile_var,
                )
                labeled_entry(
                    connection_specific_frame,
                    "Microsoft application ID (optional New Outlook)",
                    client_id_var,
                )
                labeled_entry(
                    connection_specific_frame,
                    "Microsoft directory/tenant ID (optional New Outlook)",
                    tenant_id_var,
                )
            elif method in {"local", "Local Outlook Profile"}:
                connection_method_var.set("Local Outlook Profile")
                connection_help_var.set(
                    "Recommended for most office computers. Uses the default "
                    "Classic Outlook profile already signed into Windows. No "
                    "Microsoft application or tenant credentials are required."
                )
                labeled_entry(
                    connection_specific_frame,
                    "Local Outlook profile name (optional)",
                    local_profile_var,
                )
                ctk.CTkLabel(
                    connection_specific_frame,
                    text=(
                        "Leave blank to use the default local Outlook profile. "
                        "This method requires Classic Outlook to be installed."
                    ),
                    text_color=MUTED,
                    font=("Segoe UI", 10),
                    wraplength=560,
                    justify="left",
                ).pack(anchor="w", padx=10, pady=(0, 5))
            else:
                connection_method_var.set("Microsoft Entra / New Outlook")
                connection_help_var.set(
                    "Use this for New Outlook or computers without a local "
                    "Classic Outlook profile. This method requires Microsoft "
                    "application and tenant IDs plus account authorization."
                )
                labeled_entry(
                    connection_specific_frame,
                    "Microsoft application ID",
                    client_id_var,
                )
                labeled_entry(
                    connection_specific_frame,
                    "Microsoft directory (tenant) ID",
                    tenant_id_var,
                )

        connection_selector.configure(command=refresh_connection_fields)
        refresh_connection_fields()

        folder_count = len(self.employee_folder_index())
        ctk.CTkLabel(
            content,
            text=(
                f"Current employee folders recognized: {folder_count}\n"
                "If an email matches no folder or more than one folder, it will "
                "be held for review instead of filed automatically."
            ),
            text_color="#7A5418",
            fg_color="#FFF8E8",
            corner_radius=6,
            font=("Segoe UI", 10),
            wraplength=560,
            justify="left",
        ).pack(fill="x", padx=10, pady=(12, 10), ipady=7)

        def store_email_preferences() -> bool:
            requested_enabled = bool(enabled_var.get())
            employee_root = str(
                self.settings.get("outlook_employee_folder_root", "")
            ).strip()
            client_id = client_id_var.get().strip()
            if requested_enabled and not employee_root:
                messagebox.showwarning(
                    "Outlook Email Filing",
                    "Choose the employee folder directory before enabling email filing.",
                    parent=window,
                )
                return False
            self.settings["outlook_email_filing_enabled"] = bool(
                requested_enabled
            )
            selected_method = connection_method_var.get()
            self.settings["outlook_connection_method"] = (
                "entra"
                if selected_method == "Microsoft Entra / New Outlook"
                else "local"
                if selected_method == "Local Outlook Profile"
                else "auto"
            )
            self.settings["outlook_local_profile_name"] = (
                local_profile_var.get().strip()
            )
            self.settings["outlook_approved_senders"] = sender_box.get(
                "1.0",
                "end",
            ).strip()
            self.settings["outlook_required_keywords"] = keyword_box.get(
                "1.0",
                "end",
            ).strip()
            self.settings["outlook_graph_client_id"] = client_id
            self.settings["outlook_tenant_id"] = (
                tenant_id_var.get().strip() or "organizations"
            )
            self.settings["outlook_mail_folder"] = (
                mail_folder_var.get().strip() or "Inbox"
            )
            self.settings["outlook_processed_folder"] = (
                processed_folder_var.get().strip() or "PacketFlow Processed"
            )
            return self.save_settings()

        def save_email_preferences():
            requested_enabled = bool(enabled_var.get())
            client_id = client_id_var.get().strip()
            if store_email_preferences():
                window.destroy()
                if (
                    requested_enabled
                    and self.settings.get("outlook_connection_method") == "entra"
                    and not client_id
                ):
                    messagebox.showinfo(
                        "Outlook Email Filing",
                        "Employee-folder matching is ready.\n\n"
                        "New Outlook is not connected yet. A Microsoft application "
                        "ID and account authorization are required before emails "
                        "can be downloaded automatically.",
                        parent=self.root,
                    )
                self.status_var.set("Outlook email filing preferences saved.")

        def check_outlook_from_window():
            if not store_email_preferences():
                return
            self.check_outlook_now(parent=window)

        button_row = ctk.CTkFrame(window, fg_color="transparent")
        button_row.pack(fill="x", padx=20, pady=(0, 16))
        ctk.CTkButton(
            button_row,
            text="Cancel",
            command=window.destroy,
            fg_color="#FFFFFF",
            hover_color="#F8FAFC",
            border_width=1,
            border_color="#CBD5E1",
            text_color=TEXT,
            width=120,
        ).pack(side="right")
        self.outlook_check_button = ctk.CTkButton(
            button_row,
            text="Check Outlook Now",
            command=check_outlook_from_window,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
            width=170,
        ).pack(side="left")
        ctk.CTkButton(
            button_row,
            text="Save Settings",
            command=save_email_preferences,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
            width=150,
        ).pack(side="right", padx=(0, 8))

    def schedule_outlook_auto_check(self, initial: bool = False):
        if self.outlook_auto_check_after_id is not None:
            try:
                self.root.after_cancel(self.outlook_auto_check_after_id)
            except Exception:
                pass
            self.outlook_auto_check_after_id = None
        if (
            self.exiting
            or not self.setting_enabled("outlook_email_filing_enabled")
            or not self.setting_enabled("outlook_automatic_check_enabled")
        ):
            return
        try:
            interval_minutes = int(
                self.settings.get("outlook_check_interval_minutes", 2) or 2
            )
        except (TypeError, ValueError):
            interval_minutes = 2
        delay_ms = 10_000 if initial else max(2, interval_minutes) * 60_000
        self.outlook_auto_check_after_id = self.root.after(
            delay_ms,
            self.run_outlook_auto_check,
        )
        self.outlook_next_check_text = time.strftime(
            "%I:%M %p",
            time.localtime(time.time() + (delay_ms / 1000)),
        ).lstrip("0")

    def run_outlook_auto_check(self):
        self.outlook_auto_check_after_id = None
        try:
            if not self.outlook_check_running:
                self.check_outlook_now(automatic=True)
        finally:
            self.schedule_outlook_auto_check()

    def check_outlook_now(self, parent=None, automatic: bool = False):
        """Start Outlook email filing without freezing the PacketFlow UI."""
        if self.outlook_check_running:
            if not automatic:
                self.status_var.set("Outlook is already being checked in the background...")
            return

        self.outlook_check_running = True
        self.status_var.set("Checking Outlook in background...")
        if hasattr(self, "outlook_check_button"):
            try:
                self.outlook_check_button.configure(state="disabled", text="Checking...")
            except Exception:
                pass

        def _run():
            try:
                self._check_outlook_now_blocking(parent=parent, automatic=automatic)
            finally:
                def _finish_ui():
                    self.outlook_check_running = False
                    if hasattr(self, "outlook_check_button"):
                        try:
                            self.outlook_check_button.configure(state="normal", text="Check Outlook Now")
                        except Exception:
                            pass
                try:
                    self.root.after(0, _finish_ui)
                except Exception:
                    self.outlook_check_running = False

        threading.Thread(target=_run, daemon=True).start()

    def _check_outlook_now_blocking(self, parent=None, automatic: bool = False):
        if not self.setting_enabled("outlook_email_filing_enabled"):
            if not automatic:
                messagebox.showinfo(
                    "Outlook Email Filing",
                    "Turn on Enable Outlook email filing, then save the settings "
                    "before checking Outlook.",
                    parent=parent or self.root,
                )
            return
        try:
            from email_intake import (
                EmailIntakeConfigurationError,
                EmailIntakeDependencyError,
                EmailIntakeError,
                GraphOutlookIntake,
                LocalOutlookIntake,
            )
        except ImportError as exc:
            if not automatic:
                messagebox.showerror(
                    "Outlook Email Filing",
                    "The email intake module is missing.\n\n" + str(exc),
                    parent=parent or self.root,
                )
            return

        employee_root_text = str(
            self.settings.get("outlook_employee_folder_root", "")
        ).strip()
        if not employee_root_text or not Path(employee_root_text).is_dir():
            if not automatic:
                messagebox.showwarning(
                    "Outlook Email Filing",
                    "Choose a valid employee folder directory first.",
                    parent=parent or self.root,
                )
            return

        def auth_prompt(flow: dict):
            verification_uri = flow.get(
                "verification_uri",
                "https://microsoft.com/devicelogin",
            )
            try:
                webbrowser.open(verification_uri)
            except Exception:
                pass
            messagebox.showinfo(
                "Connect Microsoft Outlook",
                "A Microsoft sign-in page has been opened.\n\n"
                f"Enter this code:\n\n{flow.get('user_code', '')}\n\n"
                "Sign in with the Outlook account PacketFlow should check, "
                "then return here. The first connection may require approval "
                "from your Microsoft 365 administrator.",
                parent=parent or self.root,
            )

        self.root.after(0, lambda: self.status_var.set("Checking Outlook in background..."))
        try:
            message_limit = 10 if automatic else 100
            connection_method = self.settings.get(
                "outlook_connection_method",
                "auto",
            )
            intake_errors: list[str] = []

            def run_graph():
                return GraphOutlookIntake(
                    self.settings,
                    APP_DATA_DIR,
                    auth_prompt=auth_prompt,
                    allow_interactive_auth=not automatic,
                ).process_now(
                    lambda sender, subject, body, attachments: (
                        self.file_outlook_pdf_attachments(
                            sender,
                            subject,
                            body,
                            attachments,
                            Path(employee_root_text),
                        )
                    ),
                    limit=message_limit,
                    allow_link_downloads=self.email_sender_is_approved,
                )

            def run_local():
                return LocalOutlookIntake(
                    self.settings,
                    APP_DATA_DIR,
                ).process_now(
                    lambda sender, subject, body, attachments: (
                        self.file_outlook_pdf_attachments(
                            sender,
                            subject,
                            body,
                            attachments,
                            Path(employee_root_text),
                        )
                    ),
                    limit=message_limit,
                    allow_link_downloads=self.email_sender_is_approved,
                )

            if connection_method == "entra":
                summary = run_graph()
            elif connection_method == "local":
                summary = run_local()
            else:
                if str(self.settings.get("outlook_graph_client_id", "")).strip():
                    try:
                        summary = run_graph()
                    except (
                        EmailIntakeConfigurationError,
                        EmailIntakeDependencyError,
                        EmailIntakeError,
                    ) as exc:
                        intake_errors.append(
                            "New Outlook/Entra was not available: " + str(exc)
                        )
                        summary = run_local()
                else:
                    summary = run_local()
            if intake_errors:
                summary.errors.extend(intake_errors)
        except (
            EmailIntakeConfigurationError,
            EmailIntakeDependencyError,
            EmailIntakeError,
        ) as exc:
            self.status_var.set("Outlook check could not be completed.")
            if not automatic:
                messagebox.showerror(
                    "Outlook Email Filing",
                    str(exc),
                    parent=parent or self.root,
                )
            return
        except Exception as exc:
            self.status_var.set("Outlook check could not be completed.")
            if not automatic:
                messagebox.showerror(
                    "Outlook Email Filing",
                    "Outlook could not be checked.\n\n" + str(exc),
                    parent=parent or self.root,
                )
            return
        finally:
            self.outlook_check_running = False

        result_text = (
            f"Emails scanned: {summary.scanned}\n"
            f"PDFs filed: {summary.filed}\n"
            f"Sent to Needs Review: {summary.needs_review}\n"
            f"Ignored by filters: {summary.ignored}\n"
            f"Already processed/skipped: {summary.skipped}"
        )
        if summary.errors:
            result_text += (
                f"\n\nWarnings: {len(summary.errors)}\n"
                + "\n".join(summary.errors[:5])
            )
        self.root.after(0, lambda: self.status_var.set(
            f"Outlook check complete: {summary.filed} filed, "
            f"{summary.needs_review} needs review."
        ))
        self.root.after(0, self.update_review_queue_badge)
        self.outlook_last_check_text = (
            time.strftime("%I:%M %p").lstrip("0")
            + f" - {summary.filed} filed, "
            + f"{summary.needs_review} needs review"
        )
        if not automatic:
            messagebox.showinfo(
                "Outlook Check Complete",
                result_text,
                parent=parent or self.root,
            )


