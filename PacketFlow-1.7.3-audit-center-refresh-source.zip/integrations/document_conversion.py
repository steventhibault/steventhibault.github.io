from __future__ import annotations

import glob
import os
import shutil
import subprocess
import textwrap
import webbrowser
from pathlib import Path
from tkinter import messagebox

from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageSequence
from pypdf import PdfReader

APP_TITLE = "PacketFlow"
IMAGE_INPUT_EXTENSIONS = {".png", ".jpg", ".jpeg", ".jfif", ".bmp", ".tif", ".tiff", ".gif", ".webp"}
TEXT_INPUT_EXTENSIONS = {".txt", ".log", ".csv", ".md"}
WORD_INPUT_EXTENSIONS = {".doc", ".docx", ".rtf", ".odt", ".html", ".htm"}
SPREADSHEET_INPUT_EXTENSIONS = {".xls", ".xlsx", ".xlsm", ".ods"}
PRESENTATION_INPUT_EXTENSIONS = {".ppt", ".pptx", ".odp"}

class OfficeConverterUnavailable(RuntimeError):
    pass

def find_program(name: str, common_paths: list[str]) -> str | None:
    located = shutil.which(name)
    if located:
        return located
    for raw_path in common_paths:
        expanded = os.path.expandvars(raw_path)
        matches = sorted(glob.glob(expanded), reverse=True)
        if matches:
            return matches[0]
    return None

class DocumentConversionMixin:
    @staticmethod
    def image_frame_to_rgb(frame: Image.Image) -> Image.Image:
        frame = ImageOps.exif_transpose(frame)
        if frame.mode in ("RGBA", "LA") or (
            frame.mode == "P" and "transparency" in frame.info
        ):
            rgba = frame.convert("RGBA")
            background = Image.new("RGB", rgba.size, "white")
            background.paste(rgba, mask=rgba.getchannel("A"))
            return background
        return frame.convert("RGB")

    def convert_image_to_pdf(self, source: Path, destination: Path):
        with Image.open(source) as image:
            frames = [
                self.image_frame_to_rgb(frame.copy())
                for frame in ImageSequence.Iterator(image)
            ]
        if not frames:
            raise ValueError(f"{source.name} does not contain a readable image.")
        frames[0].save(
            destination,
            "PDF",
            resolution=150,
            save_all=True,
            append_images=frames[1:],
        )

    @staticmethod
    def load_text_font(size: int = 24):
        for font_path in (
            Path(os.environ.get("WINDIR", r"C:\Windows"))
            / "Fonts"
            / "segoeui.ttf",
            Path(os.environ.get("WINDIR", r"C:\Windows"))
            / "Fonts"
            / "arial.ttf",
        ):
            if font_path.exists():
                try:
                    return ImageFont.truetype(str(font_path), size)
                except Exception:
                    pass
        return ImageFont.load_default()

    def convert_text_to_pdf(self, source: Path, destination: Path):
        raw = source.read_bytes()
        try:
            text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            text = raw.decode("cp1252", errors="replace")
        font = self.load_text_font()
        page_size = (1275, 1650)
        margin = 90
        line_height = 34
        lines_per_page = max(1, (page_size[1] - margin * 2) // line_height)
        wrapped_lines: list[str] = []
        for original_line in text.expandtabs(4).splitlines() or [""]:
            wrapped = textwrap.wrap(
                original_line,
                width=95,
                replace_whitespace=False,
                drop_whitespace=False,
            )
            wrapped_lines.extend(wrapped or [""])
        pages = []
        for offset in range(0, max(len(wrapped_lines), 1), lines_per_page):
            page = Image.new("RGB", page_size, "white")
            draw = ImageDraw.Draw(page)
            for row, line in enumerate(
                wrapped_lines[offset : offset + lines_per_page]
            ):
                draw.text(
                    (margin, margin + row * line_height),
                    line,
                    fill="black",
                    font=font,
                )
            pages.append(page)
        pages[0].save(
            destination,
            "PDF",
            resolution=150,
            save_all=True,
            append_images=pages[1:],
        )

    @staticmethod
    def libreoffice_path() -> str | None:
        return find_program(
            "soffice.exe",
            [
                r"C:\Program Files\LibreOffice\program\soffice.exe",
                r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
            ],
        )

    def convert_office_with_microsoft(
        self,
        source: Path,
        destination: Path,
    ) -> bool:
        script_path = destination.parent / "convert-with-office.ps1"
        script_path.write_text(
            r'''param(
    [Parameter(Mandatory=$true)][string]$Source,
    [Parameter(Mandatory=$true)][string]$Destination,
    [Parameter(Mandatory=$true)][string]$Kind
)
$ErrorActionPreference = "Stop"
if ($Kind -eq "word") {
    $app = New-Object -ComObject Word.Application
    $app.Visible = $false
    $app.DisplayAlerts = 0
    try {
        $document = $app.Documents.Open($Source, $false, $true)
        try { $document.ExportAsFixedFormat($Destination, 17) }
        finally { $document.Close($false) }
    } finally { $app.Quit() }
}
elseif ($Kind -eq "spreadsheet") {
    $app = New-Object -ComObject Excel.Application
    $app.Visible = $false
    $app.DisplayAlerts = $false
    try {
        $workbook = $app.Workbooks.Open($Source, 0, $true)
        try { $workbook.ExportAsFixedFormat(0, $Destination) }
        finally { $workbook.Close($false) }
    } finally { $app.Quit() }
}
elseif ($Kind -eq "presentation") {
    $app = New-Object -ComObject PowerPoint.Application
    try {
        $presentation = $app.Presentations.Open($Source, $true, $true, $false)
        try { $presentation.SaveAs($Destination, 32) }
        finally { $presentation.Close() }
    } finally { $app.Quit() }
}
else { throw "Unsupported Microsoft Office conversion type." }
''',
            encoding="utf-8",
        )
        extension = source.suffix.lower()
        if extension in WORD_INPUT_EXTENSIONS:
            kind = "word"
        elif extension in SPREADSHEET_INPUT_EXTENSIONS:
            kind = "spreadsheet"
        else:
            kind = "presentation"
        result = subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-NonInteractive",
                "-ExecutionPolicy",
                "Bypass",
                "-File",
                str(script_path),
                "-Source",
                str(source.resolve()),
                "-Destination",
                str(destination.resolve()),
                "-Kind",
                kind,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            timeout=120,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        return (
            result.returncode == 0
            and destination.exists()
            and destination.stat().st_size > 0
        )

    def convert_office_to_pdf(self, source: Path, destination: Path):
        try:
            if self.convert_office_with_microsoft(source, destination):
                return
        except Exception:
            pass
        libreoffice = self.libreoffice_path()
        if libreoffice:
            result = subprocess.run(
                [
                    libreoffice,
                    "--headless",
                    "--convert-to",
                    "pdf",
                    "--outdir",
                    str(destination.parent),
                    str(source.resolve()),
                ],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=120,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            generated = destination.parent / f"{source.stem}.pdf"
            if result.returncode == 0 and generated.exists():
                if generated != destination:
                    generated.replace(destination)
                return
        raise OfficeConverterUnavailable(
            f"{source.name} requires Microsoft Office or LibreOffice "
            "to convert it into a PDF."
        )

    def convert_input_to_pdf(
        self,
        source: Path,
        conversion_dir: Path,
        sequence: int,
    ) -> Path:
        extension = source.suffix.lower()
        if extension == ".pdf":
            PdfReader(str(source))
            return source
        destination = conversion_dir / f"{sequence:03d}-{source.stem}.pdf"
        if extension in IMAGE_INPUT_EXTENSIONS:
            self.convert_image_to_pdf(source, destination)
        elif extension in TEXT_INPUT_EXTENSIONS:
            self.convert_text_to_pdf(source, destination)
        elif extension in (
            WORD_INPUT_EXTENSIONS
            | SPREADSHEET_INPUT_EXTENSIONS
            | PRESENTATION_INPUT_EXTENSIONS
        ):
            self.convert_office_to_pdf(source, destination)
        else:
            raise ValueError(f"{source.name} is not a supported file type.")
        return destination

    def offer_office_converter_install(self):
        install = messagebox.askyesno(
            APP_TITLE,
            "Microsoft Office or LibreOffice is required to add this file type.\n\n"
            "Would you like to install LibreOffice now?\n\n"
            "After installation finishes, use Add Files again.",
        )
        if not install:
            return
        winget = shutil.which("winget.exe") or shutil.which("winget")
        if winget:
            try:
                subprocess.Popen(
                    [
                        winget,
                        "install",
                        "--id",
                        "TheDocumentFoundation.LibreOffice",
                        "--exact",
                        "--accept-package-agreements",
                        "--accept-source-agreements",
                    ],
                    creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0),
                )
                return
            except Exception:
                pass
        webbrowser.open("https://www.libreoffice.org/download/download-libreoffice/")


