OPTIONAL BUNDLED RUNTIME STAGING FOLDER
=======================================

PacketFlow's launcher prefers isolated files staged here before falling back to
system-installed tools or guided installation.

Expected optional layout:

  runtime\python\python.exe
  runtime\tools\tesseract\tesseract.exe
  runtime\tools\poppler\Library\bin\pdftoppm.exe

The editable source package intentionally does not include third-party runtime
binaries. Stage reviewed Windows runtime files here before running
Build PacketFlow Setup.cmd when producing a fully bundled offline Setup EXE.
