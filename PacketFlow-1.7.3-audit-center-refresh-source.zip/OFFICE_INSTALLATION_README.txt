PACKETFLOW 1.7.3 OFFICE INSTALLATION
====================================

1. Extract this ZIP to a normal folder on the Windows office computer.
2. Double-click: PacketFlow Setup.cmd
3. PacketFlow installs or updates under the current user's LocalAppData Programs folder.
4. Desktop and Start Menu shortcuts are created.
5. The launcher checks for required components and offers guided installation when needed.

UPGRADES
--------
Run PacketFlow Setup.cmd from a newer release ZIP. Editable rules, settings,
learned corrections, Review Queue, and Packet History remain under AppData and
are not overwritten.

UNINSTALL
---------
Use Windows Settings > Apps > Installed apps > PacketFlow, or use the Start Menu
PacketFlow uninstall shortcut.

EDITING SOURCE
--------------
Do not edit the installed office copy. Keep the separate PacketFlow source ZIP
as the editable master for future revisions.
