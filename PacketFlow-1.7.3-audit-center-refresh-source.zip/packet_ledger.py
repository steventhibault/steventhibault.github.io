from __future__ import annotations

import hashlib
import json
import sqlite3
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


@dataclass(frozen=True)
class ReviewItem:
    id: int
    created_at: str
    updated_at: str
    status: str
    category: str
    employee: str
    title: str
    source_path: str
    destination_path: str
    detail: str
    context_key: str


@dataclass(frozen=True)
class HistoryEvent:
    id: int
    created_at: str
    category: str
    status: str
    employee: str
    source_path: str
    destination_path: str
    detail: str


class PacketLedger:
    """Small local activity ledger and unified manual-review queue.

    The database is intentionally metadata-only. It never stores OCR text,
    document contents, bank information, Social Security numbers, or email
    bodies. PDFs continue to live in the normal employee folders.
    """

    def __init__(self, database_path: Path):
        self.database_path = Path(database_path)
        self.database_path.parent.mkdir(parents=True, exist_ok=True)
        self._schema_lock = threading.Lock()
        self._initialize()

    @staticmethod
    def _now() -> str:
        return time.strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def _clean(value: Any, maximum: int = 1000) -> str:
        text = " ".join(str(value or "").replace("\x00", " ").split())
        return text[:maximum]

    @staticmethod
    def _fingerprint(*parts: Any) -> str:
        normalized = "\n".join(str(part or "").strip().casefold() for part in parts)
        return hashlib.sha256(normalized.encode("utf-8", errors="replace")).hexdigest()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(str(self.database_path), timeout=15)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 15000")
        return connection

    def _initialize(self):
        with self._schema_lock, self._connect() as connection:
            connection.executescript(
                """
                PRAGMA journal_mode = WAL;

                CREATE TABLE IF NOT EXISTS activity_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    category TEXT NOT NULL,
                    status TEXT NOT NULL,
                    employee TEXT NOT NULL DEFAULT '',
                    source_path TEXT NOT NULL DEFAULT '',
                    destination_path TEXT NOT NULL DEFAULT '',
                    detail TEXT NOT NULL DEFAULT ''
                );

                CREATE TABLE IF NOT EXISTS processed_packets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    exported_at TEXT NOT NULL,
                    employee TEXT NOT NULL DEFAULT '',
                    profile TEXT NOT NULL DEFAULT '',
                    source_summary TEXT NOT NULL DEFAULT '',
                    destination_path TEXT NOT NULL DEFAULT '',
                    written_files TEXT NOT NULL DEFAULT '[]',
                    review_summary TEXT NOT NULL DEFAULT ''
                );

                CREATE TABLE IF NOT EXISTS review_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'open',
                    category TEXT NOT NULL,
                    employee TEXT NOT NULL DEFAULT '',
                    title TEXT NOT NULL,
                    source_path TEXT NOT NULL DEFAULT '',
                    destination_path TEXT NOT NULL DEFAULT '',
                    detail TEXT NOT NULL DEFAULT '',
                    context_key TEXT NOT NULL DEFAULT '',
                    fingerprint TEXT NOT NULL UNIQUE,
                    resolution_note TEXT NOT NULL DEFAULT ''
                );

                CREATE TABLE IF NOT EXISTS employee_packets (
                    folder_path TEXT PRIMARY KEY,
                    employee TEXT NOT NULL DEFAULT '',
                    profile TEXT NOT NULL DEFAULT '',
                    workflow_template TEXT NOT NULL DEFAULT '',
                    updated_at TEXT NOT NULL,
                    note TEXT NOT NULL DEFAULT ''
                );

                CREATE INDEX IF NOT EXISTS idx_activity_events_created
                    ON activity_events(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_review_items_status_updated
                    ON review_items(status, updated_at DESC);
                CREATE INDEX IF NOT EXISTS idx_review_items_context
                    ON review_items(category, context_key, status);
                """
            )

    def record_event(
        self,
        category: str,
        status: str,
        *,
        employee: str = "",
        source_path: str | Path = "",
        destination_path: str | Path = "",
        detail: str = "",
    ) -> int:
        with self._connect() as connection:
            cursor = connection.execute(
                """
                INSERT INTO activity_events
                    (created_at, category, status, employee, source_path, destination_path, detail)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    self._now(),
                    self._clean(category, 80),
                    self._clean(status, 80),
                    self._clean(employee, 160),
                    self._clean(source_path, 1000),
                    self._clean(destination_path, 1000),
                    self._clean(detail, 2000),
                ),
            )
            return int(cursor.lastrowid)

    def record_packet_export(
        self,
        *,
        employee: str,
        profile: str,
        source_paths: Iterable[str | Path],
        destination_path: str | Path,
        written_files: Iterable[str],
        review_summary: str = "",
    ) -> int:
        source_summary = " | ".join(self._clean(path, 500) for path in source_paths)
        written = [self._clean(filename, 260) for filename in written_files]
        with self._connect() as connection:
            cursor = connection.execute(
                """
                INSERT INTO processed_packets
                    (exported_at, employee, profile, source_summary, destination_path, written_files, review_summary)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    self._now(),
                    self._clean(employee, 160),
                    self._clean(profile, 120),
                    source_summary[:4000],
                    self._clean(destination_path, 1000),
                    json.dumps(written),
                    self._clean(review_summary, 4000),
                ),
            )
            packet_id = int(cursor.lastrowid)
        self.record_event(
            "Packet Export",
            "EXPORTED",
            employee=employee,
            source_path=source_summary,
            destination_path=destination_path,
            detail=f"{len(written)} PDFs exported; ledger packet #{packet_id}",
        )
        return packet_id

    def add_review_item(
        self,
        *,
        category: str,
        title: str,
        employee: str = "",
        source_path: str | Path = "",
        destination_path: str | Path = "",
        detail: str = "",
        context_key: str = "",
        fingerprint: str = "",
    ) -> int:
        clean_category = self._clean(category, 80)
        clean_title = self._clean(title, 300)
        clean_employee = self._clean(employee, 160)
        clean_source = self._clean(source_path, 1000)
        clean_destination = self._clean(destination_path, 1000)
        clean_detail = self._clean(detail, 2000)
        clean_context = self._clean(context_key, 1000)
        stable_fingerprint = fingerprint or self._fingerprint(
            clean_category,
            clean_employee,
            clean_title,
            clean_source,
            clean_destination,
            clean_context,
        )
        now = self._now()
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO review_items
                    (created_at, updated_at, status, category, employee, title,
                     source_path, destination_path, detail, context_key, fingerprint)
                VALUES (?, ?, 'open', ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(fingerprint) DO UPDATE SET
                    updated_at = excluded.updated_at,
                    status = 'open',
                    category = excluded.category,
                    employee = excluded.employee,
                    title = excluded.title,
                    source_path = excluded.source_path,
                    destination_path = excluded.destination_path,
                    detail = excluded.detail,
                    context_key = excluded.context_key,
                    resolution_note = ''
                """,
                (
                    now,
                    now,
                    clean_category,
                    clean_employee,
                    clean_title,
                    clean_source,
                    clean_destination,
                    clean_detail,
                    clean_context,
                    stable_fingerprint,
                ),
            )
            row = connection.execute(
                "SELECT id FROM review_items WHERE fingerprint = ?",
                (stable_fingerprint,),
            ).fetchone()
            return int(row["id"])

    def resolve_review_item(self, item_id: int, note: str = "") -> bool:
        return bool(self.resolve_review_items([item_id], note))

    def resolve_review_items(self, item_ids: Iterable[int], note: str = "") -> int:
        ids = sorted({int(item_id) for item_id in item_ids})
        if not ids:
            return 0
        placeholders = ",".join("?" for _ in ids)
        with self._connect() as connection:
            cursor = connection.execute(
                f"""
                UPDATE review_items
                SET status = 'resolved', updated_at = ?, resolution_note = ?
                WHERE id IN ({placeholders}) AND status != 'resolved'
                """,
                (self._now(), self._clean(note, 1000), *ids),
            )
            return int(cursor.rowcount)

    def clear_review_item(self, item_id: int) -> bool:
        return bool(self.clear_review_items([item_id]))

    def clear_review_items(self, item_ids: Iterable[int]) -> int:
        """Permanently remove selected queue rows without creating history entries.

        This is intentionally different from resolving a real issue. It is for
        accidental audits, irrelevant folders, and other queue noise that staff
        simply want removed. No activity-event record is written.
        """
        ids = sorted({int(item_id) for item_id in item_ids})
        if not ids:
            return 0
        placeholders = ",".join("?" for _ in ids)
        with self._connect() as connection:
            cursor = connection.execute(
                f"DELETE FROM review_items WHERE id IN ({placeholders})",
                ids,
            )
            return int(cursor.rowcount)

    def reopen_review_item(self, item_id: int, note: str = "") -> bool:
        return bool(self.reopen_review_items([item_id], note))

    def reopen_review_items(self, item_ids: Iterable[int], note: str = "") -> int:
        ids = sorted({int(item_id) for item_id in item_ids})
        if not ids:
            return 0
        placeholders = ",".join("?" for _ in ids)
        with self._connect() as connection:
            cursor = connection.execute(
                f"""
                UPDATE review_items
                SET status = 'open', updated_at = ?, resolution_note = ?
                WHERE id IN ({placeholders}) AND status != 'open'
                """,
                (self._now(), self._clean(note, 1000), *ids),
            )
            return int(cursor.rowcount)

    def list_review_items(self, status: str = "open", limit: int = 500) -> list[ReviewItem]:
        normalized = str(status or "open").strip().lower()
        where = "" if normalized == "all" else "WHERE status = ?"
        parameters: tuple[Any, ...]
        if normalized == "all":
            parameters = (max(1, min(int(limit), 5000)),)
        else:
            parameters = (normalized, max(1, min(int(limit), 5000)))
        with self._connect() as connection:
            rows = connection.execute(
                f"""
                SELECT id, created_at, updated_at, status, category, employee,
                       title, source_path, destination_path, detail, context_key
                FROM review_items
                {where}
                ORDER BY updated_at DESC, id DESC
                LIMIT ?
                """,
                parameters,
            ).fetchall()
        return [ReviewItem(**dict(row)) for row in rows]

    def list_open_review_items(self, limit: int = 500) -> list[ReviewItem]:
        return self.list_review_items("open", limit)

    def set_employee_packet_template(
        self,
        folder_path: str | Path,
        *,
        employee: str = "",
        profile: str = "",
        workflow_template: str = "",
        note: str = "",
    ) -> None:
        folder = str(Path(folder_path))
        with self._connect() as connection:
            connection.execute(
                """
                INSERT INTO employee_packets
                    (folder_path, employee, profile, workflow_template, updated_at, note)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(folder_path) DO UPDATE SET
                    employee = excluded.employee,
                    profile = excluded.profile,
                    workflow_template = excluded.workflow_template,
                    updated_at = excluded.updated_at,
                    note = excluded.note
                """,
                (
                    self._clean(folder, 1000),
                    self._clean(employee, 160),
                    self._clean(profile, 120),
                    self._clean(workflow_template, 160),
                    self._now(),
                    self._clean(note, 1000),
                ),
            )

    def get_employee_packet_template(self, folder_path: str | Path) -> str:
        folder = str(Path(folder_path))
        with self._connect() as connection:
            row = connection.execute(
                "SELECT workflow_template FROM employee_packets WHERE folder_path = ?",
                (self._clean(folder, 1000),),
            ).fetchone()
        return str(row["workflow_template"]) if row else ""

    def count_open_review_items(self) -> int:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT COUNT(*) AS count FROM review_items WHERE status = 'open'"
            ).fetchone()
            return int(row["count"])

    def list_history_events(self, limit: int = 3000) -> list[HistoryEvent]:
        """Return metadata-only activity history for the Advanced settings view."""
        safe_limit = max(1, min(int(limit), 10000))
        with self._connect() as connection:
            rows = connection.execute(
                """
                SELECT id, created_at, category, status, employee,
                       source_path, destination_path, detail
                FROM activity_events
                ORDER BY created_at DESC, id DESC
                LIMIT ?
                """,
                (safe_limit,),
            ).fetchall()
        return [HistoryEvent(**dict(row)) for row in rows]

    def replace_context_review_items(
        self,
        *,
        category: str,
        context_key: str,
        items: Iterable[dict[str, Any]],
    ) -> int:
        """Sync review findings for a repeatable operation such as a directory audit.

        Findings no longer present in the newest audit are marked resolved. New
        or recurring findings are opened. Returns the number of current items.
        """
        clean_category = self._clean(category, 80)
        clean_context = self._clean(context_key, 1000)
        current_fingerprints: set[str] = set()
        prepared: list[dict[str, Any]] = []
        for item in items:
            prepared_item = dict(item)
            fingerprint = str(prepared_item.get("fingerprint", "")).strip() or self._fingerprint(
                clean_category,
                prepared_item.get("employee", ""),
                prepared_item.get("title", ""),
                prepared_item.get("source_path", ""),
                prepared_item.get("destination_path", ""),
                clean_context,
            )
            prepared_item["fingerprint"] = fingerprint
            current_fingerprints.add(fingerprint)
            prepared.append(prepared_item)

        with self._connect() as connection:
            if current_fingerprints:
                placeholders = ",".join("?" for _ in current_fingerprints)
                connection.execute(
                    f"""
                    UPDATE review_items
                    SET status = 'resolved', updated_at = ?,
                        resolution_note = 'No longer present in the latest audit'
                    WHERE category = ? AND context_key = ? AND status = 'open'
                      AND fingerprint NOT IN ({placeholders})
                    """,
                    (self._now(), clean_category, clean_context, *sorted(current_fingerprints)),
                )
            else:
                connection.execute(
                    """
                    UPDATE review_items
                    SET status = 'resolved', updated_at = ?,
                        resolution_note = 'No longer present in the latest audit'
                    WHERE category = ? AND context_key = ? AND status = 'open'
                    """,
                    (self._now(), clean_category, clean_context),
                )

        for item in prepared:
            self.add_review_item(
                category=clean_category,
                context_key=clean_context,
                fingerprint=item["fingerprint"],
                title=str(item.get("title", "Review required")),
                employee=str(item.get("employee", "")),
                source_path=item.get("source_path", ""),
                destination_path=item.get("destination_path", ""),
                detail=str(item.get("detail", "")),
            )
        return len(prepared)

    def record_directory_audit(self, root: Path, result: Any, report_path: Path | str = "") -> int:
        """Record an audit without resolving findings from folders that were skipped.

        Older PacketFlow builds synchronized every directory audit against one
        root-level context. That was safe only when every employee folder was
        scanned. Audit Scope can intentionally scan a subset, so findings are
        now synchronized per employee folder. A partial audit refreshes only
        the folders that were actually checked.
        """
        root = Path(root)
        findings = list(getattr(result, "findings", []) or [])
        raw_scanned_folders = list(getattr(result, "scanned_folders", []) or [])

        # Backward-compatible behavior for synthetic callers and older result
        # objects that predate scoped audits.
        if not raw_scanned_folders:
            items: list[dict[str, Any]] = []
            for finding in findings:
                folder = Path(getattr(finding, "folder", root))
                file_path = getattr(finding, "file", None)
                location = Path(file_path) if file_path else folder
                level = self._clean(getattr(finding, "level", "WARNING"), 20)
                message = self._clean(getattr(finding, "message", "Review required"), 1000)
                items.append(
                    {
                        "employee": folder.name,
                        "title": f"{level}: {message}",
                        "source_path": str(location),
                        "destination_path": str(report_path or ""),
                        "detail": f"Directory audit finding in {folder}",
                    }
                )
            count = self.replace_context_review_items(
                category="Directory Audit",
                context_key=str(root.resolve()),
                items=items,
            )
        else:
            scanned_folders = [Path(folder) for folder in raw_scanned_folders]
            scanned_keys = {str(folder.resolve()): folder for folder in scanned_folders}
            grouped: dict[str, list[dict[str, Any]]] = {key: [] for key in scanned_keys}
            global_items: list[dict[str, Any]] = []

            for finding in findings:
                folder = Path(getattr(finding, "folder", root))
                file_path = getattr(finding, "file", None)
                location = Path(file_path) if file_path else folder
                level = self._clean(getattr(finding, "level", "WARNING"), 20)
                message = self._clean(getattr(finding, "message", "Review required"), 1000)
                item = {
                    "employee": folder.name,
                    "title": f"{level}: {message}",
                    "source_path": str(location),
                    "destination_path": str(report_path or ""),
                    "detail": f"Directory audit finding in {folder}",
                }
                try:
                    folder_key = str(folder.resolve())
                except OSError:
                    folder_key = str(folder)
                if folder_key in grouped:
                    grouped[folder_key].append(item)
                else:
                    global_items.append(item)

            count = 0
            for folder_key, folder_items in grouped.items():
                count += self.replace_context_review_items(
                    category="Directory Audit",
                    context_key=folder_key,
                    items=folder_items,
                )

            # Root-level findings, such as duplicate content spanning folders,
            # are refreshed only during a complete audit. Partial audits must
            # not clear unrelated root-level warnings.
            if bool(getattr(result, "scope_is_complete", False)):
                count += self.replace_context_review_items(
                    category="Directory Audit",
                    context_key=str(root.resolve()) + "::global",
                    items=global_items,
                )
                # Resolve legacy root-context findings after the first complete
                # post-upgrade audit so stale 1.2/1.3 queue items do not linger.
                self.replace_context_review_items(
                    category="Directory Audit",
                    context_key=str(root.resolve()),
                    items=[],
                )
            else:
                for item in global_items:
                    self.add_review_item(
                        category="Directory Audit",
                        context_key=str(root.resolve()) + "::partial",
                        title=str(item.get("title", "Review required")),
                        employee=str(item.get("employee", "")),
                        source_path=item.get("source_path", ""),
                        destination_path=item.get("destination_path", ""),
                        detail=str(item.get("detail", "")),
                    )
                    count += 1

        self.record_event(
            "Directory Audit",
            "COMPLETE",
            source_path=root,
            destination_path=report_path,
            detail=(
                f"{getattr(result, 'folders_scanned', 0)} folders, "
                f"{getattr(result, 'folders_skipped', 0)} skipped, "
                f"{getattr(result, 'pdfs_scanned', 0)} PDFs, "
                f"{len(getattr(result, 'errors', []) or [])} errors, "
                f"{len(getattr(result, 'warnings', []) or [])} warnings; "
                f"scope={getattr(result, 'scope_description', 'All folders')}"
            ),
        )
        return count
