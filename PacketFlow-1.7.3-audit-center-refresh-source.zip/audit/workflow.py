from __future__ import annotations

import os
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox
import tkinter as tk

try:
    import customtkinter as ctk
except ImportError as exc:
    raise SystemExit("Missing required package: customtkinter. Run Start PacketFlow.cmd so it can install dependencies.") from exc

APP_TITLE = "PacketFlow"
_APPDATA_ROOT = os.environ.get("APPDATA", "")
APP_DATA_DIR = (Path(_APPDATA_ROOT) / "PacketFlow") if _APPDATA_ROOT else Path(__file__).resolve().parents[1]
CARD_NAVY = "#112C6B"
PRODUCT_BLUE = "#1E88E5"
SUCCESS_GREEN = "#63C393"
TEXT = "#0F172A"
MUTED = "#64748B"
BORDER = "#DDE5EE"

class AuditWorkflowMixin:
    @staticmethod
    def compact_directory_audit_report(report_text: str) -> str:
        """Return a clean content-completeness audit report.

        Directory Audit is for finding incomplete employee folders, missing
        documents, duplicate documents, unreadable PDFs, and corrupt PDFs. It is
        not a filename-style audit, so old PacketFlow naming warnings are removed
        here as a safety net even if an older directory_audit module is loaded.
        """
        naming_warning = "Filename does not follow the current PacketFlow naming format"
        summary: dict[str, str] = {
            "Audit scope:": "Audit scope: All folders",
            "Folders containing PDFs:": "Folders containing PDFs: 0",
            "Folders skipped by scope:": "Folders skipped by scope: 0",
            "PDFs scanned:": "PDFs scanned: 0",
        }
        issues: dict[str, list[str]] = {"ERRORS": [], "WARNINGS": []}
        current_section: str | None = None

        for raw_line in str(report_text).splitlines():
            line = raw_line.rstrip()
            stripped = line.strip()
            if not stripped:
                continue

            # Drop legacy filename-format noise completely. The audit must be
            # content-based only and should not care about underscores, casing,
            # spaces, hyphens, or old employee-file names.
            if naming_warning in stripped:
                continue

            if stripped.upper() == "PACKETFLOW DIRECTORY AUDIT":
                continue
            if stripped.startswith("Directory:") or stripped.startswith("Report saved to:"):
                continue
            if stripped.startswith("Mode:"):
                continue
            if stripped.startswith("Audit mode:"):
                summary["Audit mode:"] = stripped
                continue

            if stripped.startswith("Audit scope:"):
                summary["Audit scope:"] = stripped
                continue
            if stripped.startswith("Folders containing PDFs:"):
                summary["Folders containing PDFs:"] = stripped
                continue
            if stripped.startswith("Folders skipped by scope:"):
                summary["Folders skipped by scope:"] = stripped
                continue
            if stripped.startswith("PDFs scanned:"):
                summary["PDFs scanned:"] = stripped
                continue
            if stripped.startswith("Errors:") or stripped.startswith("Warnings:"):
                # Recomputed after filename-format warnings are filtered.
                continue

            if stripped in {"ERRORS", "WARNINGS"}:
                current_section = stripped
                continue

            if stripped.startswith("- ") and ":" in stripped and current_section:
                item, detail = stripped[2:].split(":", 1)
                item = item.strip()
                detail = detail.strip()
                item_path = Path(item)
                display_name = item_path.name or item_path.parent.name or item
                issues[current_section].append(f"- {display_name}: {detail}")
                continue

            if current_section:
                issues[current_section].append(stripped)

        output: list[str] = [
            summary.get("Audit mode:", "Audit mode: Content-based OCR using PacketFlow imported-packet classifier"),
            summary["Audit scope:"],
            summary["Folders containing PDFs:"],
            summary["Folders skipped by scope:"],
            summary["PDFs scanned:"],
            f"Errors: {len(issues['ERRORS'])}",
            f"Warnings: {len(issues['WARNINGS'])}",
            "",
        ]

        for section in ("ERRORS", "WARNINGS"):
            if not issues[section]:
                continue
            output.append(section)
            output.extend(issues[section])
            output.append("")

        if not issues["ERRORS"] and not issues["WARNINGS"]:
            output.append("No missing, incomplete, duplicate, unreadable, or corrupt PDF issues were found.")

        return "\n".join(output).strip() + "\n"

    @staticmethod
    def _audit_candidate_folders(audit_root: Path) -> list[tuple[Path, float]]:
        """Return folders containing PDFs and their latest meaningful activity."""
        grouped: dict[Path, list[Path]] = {}
        try:
            for pdf in Path(audit_root).rglob("*.pdf"):
                if pdf.is_file():
                    grouped.setdefault(pdf.parent, []).append(pdf)
        except OSError:
            return []

        candidates: list[tuple[Path, float]] = []
        for folder, pdfs in grouped.items():
            timestamps: list[float] = []
            try:
                timestamps.append(folder.stat().st_mtime)
            except OSError:
                pass
            for pdf in pdfs:
                try:
                    timestamps.append(pdf.stat().st_mtime)
                except OSError:
                    pass
            candidates.append((folder, max(timestamps) if timestamps else 0.0))
        return sorted(candidates, key=lambda item: (-item[1], item[0].name.casefold()))

    @staticmethod
    def _parse_audit_date(value: str, *, end_of_day: bool = False) -> float | None:
        value = str(value or "").strip()
        if not value:
            return None
        parsed = datetime.strptime(value, "%Y-%m-%d")
        if end_of_day:
            parsed += timedelta(days=1)
        return parsed.timestamp()

    def choose_employee_folder_to_audit(self):
        """Audit one explicitly chosen employee folder without a scope dialog."""
        if self.directory_audit_running:
            return
        initial_directory = (
            Path(self.settings.get("last_audit_directory", ""))
            if self.settings.get("last_audit_directory", "")
            and Path(self.settings.get("last_audit_directory", "")).is_dir()
            else (self.export_parent_folder or (self.pdf_path.parent if self.pdf_path else Path.home()))
        )
        selected = filedialog.askdirectory(
            title="Choose one employee folder for PacketFlow to audit",
            initialdir=str(initial_directory),
            mustexist=True,
            parent=self.root,
        )
        if not selected:
            return

        employee_folder = Path(selected)
        self.settings["last_audit_directory"] = str(employee_folder.parent)
        self.save_settings()
        self.start_directory_audit(
            employee_folder,
            folders_to_scan=[employee_folder],
            scope_label=f"Single employee folder: {employee_folder.name}",
        )

    def choose_directory_to_audit(self):
        if self.directory_audit_running:
            return
        selected = filedialog.askdirectory(
            title="Choose a directory for PacketFlow to audit",
            initialdir=str(
                Path(self.settings.get("last_audit_directory", ""))
                if self.settings.get("last_audit_directory", "")
                and Path(self.settings.get("last_audit_directory", "")).is_dir()
                else (self.export_parent_folder or (self.pdf_path.parent if self.pdf_path else Path.home()))
            ),
            mustexist=True,
            parent=self.root,
        )
        if not selected:
            return

        audit_root = Path(selected)
        self.settings["last_audit_directory"] = str(audit_root)
        self.save_settings()
        self.show_audit_scope_dialog(audit_root)

    def show_audit_scope_dialog(self, audit_root: Path):
        candidates = self._audit_candidate_folders(audit_root)
        window = ctk.CTkToplevel(self.root)
        window.title("Directory Audit Scope")
        window.geometry("900x720")
        window.minsize(760, 600)
        window.transient(self.root)
        try:
            window.grab_set()
        except Exception:
            pass

        remember_saved = bool(self.settings.get("audit_remember_scope", False))
        saved_mode = str(self.settings.get("audit_scope_mode", "all")) if remember_saved else "all"
        if saved_mode not in {"all", "selected", "recent", "custom"}:
            saved_mode = "all"
        mode_var = tk.StringVar(value=saved_mode)
        recent_days_var = tk.StringVar(value=str(self.settings.get("audit_recent_days", 90) or 90))
        start_var = tk.StringVar(value=str(self.settings.get("audit_custom_start_date", "")))
        end_var = tk.StringVar(value=str(self.settings.get("audit_custom_end_date", "")))
        remember_var = tk.BooleanVar(value=remember_saved)
        search_var = tk.StringVar(value="")
        selected_count_var = tk.StringVar(value="0 folders checked")
        folder_vars: dict[Path, tk.BooleanVar] = {folder: tk.BooleanVar(value=False) for folder, _ in candidates}
        visible_folders: list[Path] = []

        ctk.CTkLabel(
            window,
            text="Directory Audit Scope",
            text_color=CARD_NAVY,
            font=("Segoe UI", 20, "bold"),
        ).pack(anchor="w", padx=20, pady=(16, 2))
        ctk.CTkLabel(
            window,
            text=(
                f"Directory: {audit_root}\n"
                "Standard Onboarding remains the normal default. Use a narrower scope only when useful."
            ),
            text_color=MUTED,
            font=("Segoe UI", 10),
            justify="left",
            wraplength=850,
        ).pack(anchor="w", padx=20, pady=(0, 10))

        scope_card = ctk.CTkFrame(window, fg_color="#FFFFFF", border_width=1, border_color=BORDER)
        scope_card.pack(fill="x", padx=20, pady=(0, 10))
        ctk.CTkLabel(scope_card, text="Choose what to audit", text_color=TEXT, font=("Segoe UI", 12, "bold")).grid(row=0, column=0, columnspan=4, sticky="w", padx=14, pady=(12, 4))
        ctk.CTkRadioButton(scope_card, text="All folders in directory", variable=mode_var, value="all", text_color=TEXT).grid(row=1, column=0, sticky="w", padx=14, pady=5)
        ctk.CTkRadioButton(scope_card, text="Selected folders only", variable=mode_var, value="selected", text_color=TEXT).grid(row=1, column=1, sticky="w", padx=14, pady=5)
        ctk.CTkRadioButton(scope_card, text="Most recent folders", variable=mode_var, value="recent", text_color=TEXT).grid(row=2, column=0, sticky="w", padx=14, pady=5)
        recent_combo = ctk.CTkComboBox(scope_card, variable=recent_days_var, values=["7", "30", "90", "180", "365"], width=90)
        recent_combo.grid(row=2, column=1, sticky="w", padx=(14, 4), pady=5)
        ctk.CTkLabel(scope_card, text="days", text_color=MUTED).grid(row=2, column=2, sticky="w", padx=(0, 10), pady=5)
        ctk.CTkRadioButton(scope_card, text="Custom date range", variable=mode_var, value="custom", text_color=TEXT).grid(row=3, column=0, sticky="w", padx=14, pady=5)
        custom_frame = ctk.CTkFrame(scope_card, fg_color="transparent")
        custom_frame.grid(row=3, column=1, columnspan=3, sticky="w", padx=14, pady=5)
        ctk.CTkEntry(custom_frame, textvariable=start_var, width=110, placeholder_text="YYYY-MM-DD").pack(side="left")
        ctk.CTkLabel(custom_frame, text=" through ", text_color=MUTED).pack(side="left")
        ctk.CTkEntry(custom_frame, textvariable=end_var, width=110, placeholder_text="YYYY-MM-DD").pack(side="left")
        ctk.CTkCheckBox(scope_card, text="Remember this scope next time", variable=remember_var, text_color=TEXT).grid(row=4, column=0, columnspan=3, sticky="w", padx=14, pady=(6, 12))

        folder_card = ctk.CTkFrame(window, fg_color="#FFFFFF", border_width=1, border_color=BORDER)
        folder_card.pack(fill="both", expand=True, padx=20, pady=(0, 10))
        folder_toolbar = ctk.CTkFrame(folder_card, fg_color="transparent")
        folder_toolbar.pack(fill="x", padx=12, pady=(10, 6))
        ctk.CTkLabel(folder_toolbar, text="Employee folders", text_color=TEXT, font=("Segoe UI", 12, "bold")).pack(side="left")
        ctk.CTkLabel(folder_toolbar, textvariable=selected_count_var, text_color=MUTED, font=("Segoe UI", 10)).pack(side="left", padx=(10, 0))
        search_entry = ctk.CTkEntry(folder_toolbar, textvariable=search_var, width=230, placeholder_text="Search employee folders")
        search_entry.pack(side="right")

        button_row = ctk.CTkFrame(folder_card, fg_color="transparent")
        button_row.pack(fill="x", padx=12, pady=(0, 6))
        list_frame = ctk.CTkScrollableFrame(folder_card, fg_color="#FFFFFF")
        list_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        def update_selected_count():
            count = sum(1 for var in folder_vars.values() if var.get())
            selected_count_var.set(f"{count} folder{'s' if count != 1 else ''} checked")

        def refresh_folder_list(*_args):
            for child in list_frame.winfo_children():
                child.destroy()
            visible_folders.clear()
            query = search_var.get().strip().casefold()
            for folder, modified in candidates:
                relative = str(folder.relative_to(audit_root)) if folder != audit_root else folder.name
                if query and query not in relative.casefold():
                    continue
                visible_folders.append(folder)
                row = ctk.CTkFrame(list_frame, fg_color="transparent")
                row.pack(fill="x", padx=2, pady=2)
                ctk.CTkCheckBox(
                    row,
                    text=relative,
                    variable=folder_vars[folder],
                    command=update_selected_count,
                    text_color=TEXT,
                    font=("Segoe UI", 11),
                ).pack(side="left", fill="x", expand=True)
                date_text = time.strftime("%Y-%m-%d", time.localtime(modified)) if modified else "Unknown date"
                ctk.CTkLabel(row, text=date_text, text_color=MUTED, font=("Segoe UI", 10)).pack(side="right", padx=6)
            if not visible_folders:
                ctk.CTkLabel(list_frame, text="No folders containing PDFs matched the search.", text_color=MUTED).pack(anchor="w", padx=6, pady=6)

        def set_visible(value: bool):
            for folder in visible_folders:
                folder_vars[folder].set(value)
            update_selected_count()
            refresh_folder_list()

        ctk.CTkButton(button_row, text="Select All Visible", command=lambda: set_visible(True), width=125, height=28).pack(side="left", padx=(0, 6))
        ctk.CTkButton(button_row, text="Clear Visible", command=lambda: set_visible(False), width=100, height=28, fg_color="#64748B").pack(side="left")
        ctk.CTkLabel(button_row, text=f"{len(candidates)} folders contain PDFs", text_color=MUTED, font=("Segoe UI", 10)).pack(side="right")
        search_var.trace_add("write", refresh_folder_list)
        refresh_folder_list()

        footer = ctk.CTkFrame(window, fg_color="transparent")
        footer.pack(fill="x", padx=20, pady=(0, 16))

        def run_selected_scope():
            mode = mode_var.get()
            folders_to_scan: list[Path] | None = None
            modified_after: float | None = None
            modified_before: float | None = None
            scope_label = "All folders"

            if mode == "selected":
                folders_to_scan = [folder for folder, var in folder_vars.items() if var.get()]
                if not folders_to_scan:
                    messagebox.showwarning(APP_TITLE, "Select at least one employee folder to audit.", parent=window)
                    return
                scope_label = f"Selected folders only ({len(folders_to_scan)})"
            elif mode == "recent":
                try:
                    days = int(recent_days_var.get())
                    if days <= 0:
                        raise ValueError
                except ValueError:
                    messagebox.showwarning(APP_TITLE, "Choose a valid recent-folder period.", parent=window)
                    return
                modified_after = time.time() - (days * 86400)
                scope_label = f"Folders modified within the last {days} days"
            elif mode == "custom":
                try:
                    modified_after = self._parse_audit_date(start_var.get())
                    modified_before = self._parse_audit_date(end_var.get(), end_of_day=True)
                except ValueError:
                    messagebox.showwarning(APP_TITLE, "Enter custom dates as YYYY-MM-DD.", parent=window)
                    return
                if modified_after is None and modified_before is None:
                    messagebox.showwarning(APP_TITLE, "Enter a start date, an end date, or both.", parent=window)
                    return
                if modified_after is not None and modified_before is not None and modified_after >= modified_before:
                    messagebox.showwarning(APP_TITLE, "The start date must be before the end date.", parent=window)
                    return
                start_text = start_var.get().strip() or "beginning"
                end_text = end_var.get().strip() or "today"
                scope_label = f"Folders modified from {start_text} through {end_text}"

            self.settings["audit_remember_scope"] = bool(remember_var.get())
            self.settings["audit_scope_mode"] = mode if remember_var.get() else "all"
            self.settings["audit_recent_days"] = recent_days_var.get().strip() or "90"
            self.settings["audit_custom_start_date"] = start_var.get().strip()
            self.settings["audit_custom_end_date"] = end_var.get().strip()
            self.save_settings()
            try:
                window.grab_release()
            except Exception:
                pass
            window.destroy()
            self.start_directory_audit(
                audit_root,
                folders_to_scan=folders_to_scan,
                modified_after=modified_after,
                modified_before=modified_before,
                scope_label=scope_label,
            )

        ctk.CTkButton(footer, text="Cancel", command=window.destroy, width=90, fg_color="#64748B").pack(side="right")
        ctk.CTkButton(footer, text="Run Audit", command=run_selected_scope, width=120).pack(side="right", padx=(0, 8))

    def start_directory_audit(
        self,
        audit_root: Path,
        *,
        folders_to_scan: list[Path] | None = None,
        modified_after: float | None = None,
        modified_before: float | None = None,
        scope_label: str = "All folders",
    ):
        if self.directory_audit_running:
            return
        self.directory_audit_running = True
        self.set_busy(True)
        self.audit_folder_button.configure(state="disabled")
        self.update_header_progress(0, f"Auditing directory: {audit_root.name}")

        def run_audit():
            try:
                from directory_audit import audit_directory, format_audit_report

                selected_set = None if folders_to_scan is None else {Path(folder) for folder in folders_to_scan}
                audit_pdf_total = 0
                for folder, modified in self._audit_candidate_folders(audit_root):
                    if selected_set is not None and folder not in selected_set:
                        continue
                    if modified_after is not None and modified < modified_after:
                        continue
                    if modified_before is not None and modified >= modified_before:
                        continue
                    try:
                        audit_pdf_total += sum(1 for item in folder.glob("*.pdf") if item.is_file())
                    except OSError:
                        pass
                audit_completed = 0

                def audit_progress(text: str):
                    nonlocal audit_completed
                    audit_completed += 1
                    if audit_pdf_total:
                        percent = min(95, int((audit_completed / audit_pdf_total) * 95))
                    else:
                        percent = 10
                    self.worker_queue.put(("progress", percent, text, None))

                result = audit_directory(
                    audit_root,
                    list(self.rules.get("document_types", [])),
                    list(self.rules.get("expected_document_types", [])),
                    analyzer=self.analyzer,
                    rules=self.rules,
                    workflow_templates=self.rules.get("workflow_templates", {}),
                    default_workflow_template=self.active_workflow_template_name(),
                    progress_callback=audit_progress,
                    folders_to_scan=folders_to_scan,
                    modified_after=modified_after,
                    modified_before=modified_before,
                    scope_description=scope_label,
                )
                report_text = self.compact_directory_audit_report(format_audit_report(result))
                report_path = (
                    APP_DATA_DIR
                    / f"Directory Audit {time.strftime('%Y-%m-%d %H%M%S')}.txt"
                )
                report_path.write_text(report_text, encoding="utf-8")
                self.ledger_call("record_directory_audit", audit_root, result, report_path)
                self.worker_queue.put(("directory_audit_complete", report_text, report_path))
            except Exception as exc:
                self.worker_queue.put(("directory_audit_error", str(exc)))

        threading.Thread(target=run_audit, daemon=True).start()

    def show_directory_audit_report(
        self,
        report_text: str,
        report_path: Path,
    ):
        window = ctk.CTkToplevel(self.root)
        window.title("Directory Audit Results")
        window.geometry("900x680")
        window.minsize(720, 520)
        window.transient(self.root)

        ctk.CTkLabel(
            window,
            text="Directory Audit Results",
            text_color=CARD_NAVY,
            font=("Segoe UI", 20, "bold"),
        ).pack(anchor="w", padx=20, pady=(16, 2))
        ctk.CTkLabel(
            window,
            text=f"Report saved to: {report_path.name}",
            text_color=MUTED,
            font=("Segoe UI", 10),
            wraplength=850,
            justify="left",
        ).pack(anchor="w", padx=20, pady=(0, 10))

        report_box = ctk.CTkTextbox(
            window,
            font=("Consolas", 11),
            wrap="word",
        )
        report_box.pack(fill="both", expand=True, padx=20, pady=(0, 12))
        report_box.insert("1.0", report_text)
        report_box.configure(state="disabled")

        def save_copy():
            selected = filedialog.asksaveasfilename(
                title="Save Directory Audit Report",
                initialdir=str(report_path.parent),
                initialfile=report_path.name,
                defaultextension=".txt",
                filetypes=[("Text report", "*.txt")],
                parent=window,
            )
            if selected:
                Path(selected).write_text(report_text, encoding="utf-8")

        button_row = ctk.CTkFrame(window, fg_color="transparent")
        button_row.pack(fill="x", padx=20, pady=(0, 16))
        ctk.CTkButton(
            button_row,
            text="Save Copy",
            command=save_copy,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color=PRODUCT_BLUE,
            text_color=PRODUCT_BLUE,
            width=120,
        ).pack(side="left")
        ctk.CTkButton(
            button_row,
            text="Close",
            command=window.destroy,
            fg_color=PRODUCT_BLUE,
            hover_color=SUCCESS_GREEN,
            width=110,
        ).pack(side="right")


