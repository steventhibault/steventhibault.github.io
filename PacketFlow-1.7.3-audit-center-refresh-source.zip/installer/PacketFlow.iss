#define MyAppName "PacketFlow"
#define MyAppVersion "1.7.3"
#define MyAppPublisher "PacketFlow"
#define MyAppExeName "Start PacketFlow.cmd"

[Setup]
AppId={{B52B44B3-7422-4F1A-A538-CE23C8F3D4A8}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\PacketFlow
DefaultGroupName=PacketFlow
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=..\Output
OutputBaseFilename=PacketFlow-Setup-{#MyAppVersion}
SetupIconFile=..\packetflow.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\packetflow.ico
VersionInfoVersion=1.7.3.0
VersionInfoProductName=PacketFlow
VersionInfoDescription=PacketFlow Intake Processor Setup

[Files]
Source: "..\app.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\directory_audit.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\email_intake.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\packet_ledger.py"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\core\*"; DestDir: "{app}\core"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\audit\*"; DestDir: "{app}\audit"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\ui\*"; DestDir: "{app}\ui"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\integrations\*"; DestDir: "{app}\integrations"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\rules.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\requirements.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\launcher.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Start PacketFlow.cmd"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\uninstall.ps1"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Uninstall_PacketFlow.cmd"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\packetflow.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\packetflow-icon.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\packetflow-logo.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\customer-logo.png"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\version.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\README.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\CHANGELOG.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\TEST_RESULTS.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\IMPROVEMENT_ROADMAP.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\ARCHITECTURE.txt"; DestDir: "{app}"; Flags: ignoreversion
; Optional isolated runtime. When staged, office computers avoid separate Python/Poppler setup.
Source: "..\runtime\*"; DestDir: "{app}\runtime"; Flags: ignoreversion recursesubdirs createallsubdirs skipifsourcedoesntexist

[Icons]
Name: "{autodesktop}\PacketFlow"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\packetflow.ico"
Name: "{group}\PacketFlow"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\packetflow.ico"
Name: "{group}\Uninstall PacketFlow"; Filename: "{uninstallexe}"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch PacketFlow"; Flags: nowait postinstall skipifsilent

[Code]
procedure CopyLegacyMutableFile(const FileName: string);
var
  ExistingFile, AppDataDir, Destination: string;
begin
  AppDataDir := ExpandConstant('{userappdata}\PacketFlow');
  Destination := AddBackslash(AppDataDir) + FileName;
  if FileExists(Destination) then
    exit;
  ExistingFile := ExpandConstant('{localappdata}\Programs\PacketFlow\') + FileName;
  if FileExists(ExistingFile) then
  begin
    ForceDirectories(AppDataDir);
    FileCopy(ExistingFile, Destination, False);
  end;
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
begin
  CopyLegacyMutableFile('rules.json');
  CopyLegacyMutableFile('settings.json');
  CopyLegacyMutableFile('correction_memory.json');
  Result := '';
end;
