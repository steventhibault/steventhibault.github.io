from __future__ import annotations

import hashlib
import json
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from pypdf import PdfReader


@dataclass
class AuditFinding:
    level: str
    folder: Path
    message: str
    file: Path | None = None


@dataclass
class DirectoryAuditResult:
    root: Path
    folders_scanned: int = 0
    pdfs_scanned: int = 0
    folders_skipped: int = 0
    scope_description: str = "All folders"
    scope_is_complete: bool = True
    scanned_folders: list[Path] = field(default_factory=list)
    findings: list[AuditFinding] = field(default_factory=list)

    @property
    def errors(self) -> list[AuditFinding]:
        return [item for item in self.findings if item.level == "ERROR"]

    @property
    def warnings(self) -> list[AuditFinding]:
        return [item for item in self.findings if item.level == "WARNING"]


def _slug(value: str) -> str:
    """Normalize a filename or document label without deleting real names."""
    value = Path(str(value)).stem
    value = re.sub(r"\.pdf$", "", value, flags=re.I)
    value = value.lower()
    value = value.replace("i-9", "i9").replace("w-4", "w4")
    value = re.sub(r"[^a-z0-9]+", " ", value)
    return " ".join(token for token in value.split() if token != "pdf")


def _doc_aliases(document: str) -> set[str]:
    doc = _slug(document)
    aliases = {doc, doc.replace(" ", "")}
    manual = {
        "orientation agenda": {"orientation", "orientation agenda"},
        "form i9 employment eligibility verification": {"form i9", "i9", "employment eligibility verification"},
        "job application": {"application", "job application", "careco job application"},
        "interview statement": {"interview", "interview statement"},
        "time recording": {"time recording", "recording of time worked"},
        "cherkr authorization": {"cherkr", "cherkr auth", "cherkr authorization", "consumer report"},
        "mbc authorization": {"mbc auth", "mbc authorization", "maine background check center authorization"},
        "mbc clearance": {"mbc clearance", "background check clearance"},
        "mbc payment": {"mbc payment", "background check payment"},
        "child protective services authorization": {"cps auth", "cps authorization", "child protective services authorization"},
        "confirmation child abuse registry background check request": {
            "confirmation child abuse registry background check request",
            "child abuse registry background check request",
            "child abuse background check confirmation",
        },
        "payroll": {"payroll"},
        "federal w4 withholding": {"federal w4", "federal withholding", "w4 withholding"},
        "viventium direct deposit": {"viventium direct deposit", "direct deposit"},
        "banking": {"banking", "baking", "bank", "voided check"},
        "auto enrollment opt out": {"auto enrollment opt out", "auto enrol opt out"},
        "employee choice acknowledgement waiver": {"employee choice acknowledgement waiver", "employee choice waiver", "waiver"},
        "birth and marriage certificates": {"birth marriage certs", "birth marriage certificates", "birth cert", "birth certificate", "marriage certs"},
    }
    aliases.update(manual.get(doc, set()))
    return {_slug(alias) for alias in aliases if alias}


def _employee_prefix(filename: str, matched_alias: str) -> str:
    """Extract the employee-name portion before the matched document label."""
    raw = Path(filename).stem.replace("_", " ")
    raw = re.sub(r"\s+", " ", raw).strip()
    if not raw:
        return ""

    # Export filenames normally use `Employee Name - Document.pdf`. Prefer the
    # original casing from that left-hand side rather than returning a slug.
    parts = re.split(r"\s+-\s+", raw)
    if len(parts) >= 2:
        for split_index in range(1, len(parts)):
            right = " - ".join(parts[split_index:])
            right_slug = _slug(right)
            right_compact = right_slug.replace(" ", "")
            alias_compact = matched_alias.replace(" ", "")
            if (
                matched_alias in right_slug
                or right_slug in matched_alias
                or alias_compact in right_compact
                or right_compact in alias_compact
            ):
                return " - ".join(parts[:split_index]).strip()

    raw_slug = _slug(raw)
    alias_index = raw_slug.rfind(matched_alias)
    if alias_index <= 0:
        return ""
    prefix_slug = raw_slug[:alias_index].strip()
    if not prefix_slug:
        return ""

    # Recover original capitalization by consuming the same number of leading
    # words from the original filename. This is tolerant of punctuation.
    prefix_word_count = len(prefix_slug.split())
    raw_words = raw.split()
    return " ".join(raw_words[:prefix_word_count]).strip(" -_")


def document_for_filename(filename: str, document_types: list[str]) -> tuple[str | None, str]:
    """Return the document type and employee prefix implied by a PDF filename.

    Matching is intentionally tolerant of legacy underscores, capitalization,
    and known typos, but never deletes real employee names from the filename.
    """
    stem_slug = _slug(filename)
    compact_stem = stem_slug.replace(" ", "")
    best_document: str | None = None
    best_alias = ""
    best_score = 0
    for document in document_types:
        for alias in _doc_aliases(document):
            if not alias:
                continue
            compact_alias = alias.replace(" ", "")
            matched = (
                stem_slug == alias
                or stem_slug.endswith(" " + alias)
                or alias in stem_slug
                or compact_alias in compact_stem
            )
            if matched:
                score = len(compact_alias)
                if score > best_score:
                    best_score = score
                    best_document = document
                    best_alias = alias
    return best_document, _employee_prefix(filename, best_alias) if best_document else ""


def pdf_page_count(path: Path) -> tuple[int | None, str | None]:
    try:
        reader = PdfReader(str(path), strict=False)
        if reader.is_encrypted:
            try:
                result = reader.decrypt("")
            except Exception:
                result = 0
            if not result:
                return None, "PDF is encrypted and cannot be opened"
        page_count = len(reader.pages)
        if page_count == 0:
            return 0, "PDF contains no pages"
        return page_count, None
    except Exception as exc:
        return None, f"PDF cannot be opened: {exc}"


def file_digest(path: Path) -> str | None:
    try:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()
    except OSError:
        return None


def _build_packet_analyzer(document_types: list[str], expected_documents: list[str], rules: dict[str, Any] | None):
    from app import PacketAnalyzer
    analyzer_rules = dict(rules or {})
    analyzer_rules.setdefault("document_types", list(document_types))
    analyzer_rules.setdefault("expected_document_types", list(expected_documents))
    analyzer_rules.setdefault("custom_rules", [])
    return PacketAnalyzer(analyzer_rules)


def _analyze_pdf_with_packetflow(analyzer, pdf: Path) -> tuple[list[Any], set[int]]:
    with tempfile.TemporaryDirectory(prefix="packetflow-directory-audit-") as temp_dir:
        _images, _texts, assignments, _rotations, blank_pages, _fingerprints = analyzer.analyze(
            pdf,
            Path(temp_dir),
            lambda *_args, **_kwargs: None,
        )
    return assignments, blank_pages


def _total_pages(files: dict[Path, set[int]]) -> int:
    return sum(len(pages) for pages in files.values())


def _folder_is_packet(folder: Path, prefixes: set[str]) -> bool:
    """Return False for shared folders containing multiple employees' PDFs."""
    if (folder / "Export Audit Log.txt").is_file():
        return True
    meaningful = {prefix.casefold() for prefix in prefixes if prefix.strip()}
    return len(meaningful) <= 1


def _load_packet_metadata(folder: Path) -> dict[str, Any]:
    sidecar = Path(folder) / ".packetflow.json"
    if not sidecar.is_file():
        return {}
    try:
        loaded = json.loads(sidecar.read_text(encoding="utf-8"))
        return loaded if isinstance(loaded, dict) else {}
    except Exception:
        return {"_metadata_error": "PacketFlow metadata file could not be read"}


def _workflow_document_statuses(
    folder: Path,
    expected_documents: list[str],
    workflow_templates: dict[str, Any] | None,
    default_workflow_template: str,
) -> tuple[str, dict[str, dict[str, str]], dict[str, str], str]:
    metadata = _load_packet_metadata(folder)
    selected = str(metadata.get("workflow_template", "")).strip() or str(default_workflow_template or "").strip()
    templates = workflow_templates if isinstance(workflow_templates, dict) else {}
    error = str(metadata.get("_metadata_error", "")).strip()
    raw_template = templates.get(selected) if selected else None
    if selected and raw_template is None and templates:
        error = f"Unknown workflow template in .packetflow.json: {selected}"
    documents: dict[str, dict[str, str]] = {}
    if isinstance(raw_template, dict) and isinstance(raw_template.get("documents"), dict):
        for document, raw_entry in raw_template["documents"].items():
            if isinstance(raw_entry, str):
                raw_entry = {"status": raw_entry}
            if not isinstance(raw_entry, dict):
                continue
            status = str(raw_entry.get("status", "optional")).strip().lower()
            if status not in {"required", "optional", "conditional", "expected_later"}:
                status = "optional"
            documents[str(document)] = {
                "status": status,
                "note": str(raw_entry.get("note", "")).strip(),
            }
    if not documents:
        documents = {document: {"status": "required", "note": ""} for document in expected_documents}
    raw_waivers = metadata.get("waived_documents", {})
    waivers = {str(key): str(value) for key, value in raw_waivers.items()} if isinstance(raw_waivers, dict) else {}
    return selected, documents, waivers, error


def audit_directory(
    root: Path,
    document_types: list[str],
    expected_documents: list[str],
    *,
    analyzer=None,
    rules: dict[str, Any] | None = None,
    workflow_templates: dict[str, Any] | None = None,
    default_workflow_template: str = "",
    progress_callback: Callable[[str], None] | None = None,
    folders_to_scan: list[Path] | None = None,
    modified_after: float | None = None,
    modified_before: float | None = None,
    scope_description: str = "All folders",
) -> DirectoryAuditResult:
    """Audit employee folders using filenames first and OCR only as fallback."""
    root = Path(root)
    result = DirectoryAuditResult(root=root)
    if not root.is_dir():
        result.findings.append(AuditFinding("ERROR", root, "Selected directory does not exist"))
        return result

    all_pdfs_by_folder: dict[Path, list[Path]] = {}
    try:
        for pdf in root.rglob("*.pdf"):
            if pdf.is_file():
                all_pdfs_by_folder.setdefault(pdf.parent, []).append(pdf)
    except OSError as exc:
        result.findings.append(AuditFinding("ERROR", root, f"Directory could not be scanned: {exc}"))
        return result

    result.scope_description = str(scope_description or "All folders")
    result.scope_is_complete = folders_to_scan is None and modified_after is None and modified_before is None

    selected_folders: set[Path] | None = None
    if folders_to_scan is not None:
        selected_folders = set()
        for folder in folders_to_scan:
            try:
                selected_folders.add(Path(folder).resolve())
            except OSError:
                selected_folders.add(Path(folder))

    def latest_activity(folder: Path, pdfs: list[Path]) -> float:
        timestamps: list[float] = []
        try:
            timestamps.append(folder.stat().st_mtime)
        except OSError:
            pass
        for pdf in pdfs:
            try:
                timestamps.append(pdf.stat().st_mtime)
            except OSError:
                pass
        return max(timestamps) if timestamps else 0.0

    pdfs_by_folder: dict[Path, list[Path]] = {}
    for folder, pdfs in all_pdfs_by_folder.items():
        try:
            resolved_folder = folder.resolve()
        except OSError:
            resolved_folder = folder
        if selected_folders is not None and resolved_folder not in selected_folders:
            continue
        activity = latest_activity(folder, pdfs)
        if modified_after is not None and activity < modified_after:
            continue
        if modified_before is not None and activity >= modified_before:
            continue
        pdfs_by_folder[folder] = pdfs

    result.folders_skipped = max(0, len(all_pdfs_by_folder) - len(pdfs_by_folder))
    result.folders_scanned = len(pdfs_by_folder)
    result.scanned_folders = sorted(pdfs_by_folder)
    if not pdfs_by_folder:
        message = "No PDF files matched the selected audit scope" if all_pdfs_by_folder else "No PDF files were found"
        result.findings.append(AuditFinding("WARNING", root, message))
        return result

    document_types = [str(item).strip() for item in document_types if str(item).strip()]
    expected_documents = [str(item).strip() for item in expected_documents if str(item).strip()]
    if not expected_documents:
        result.findings.append(AuditFinding("ERROR", root, "No expected-document checklist is configured for the active PacketFlow profile"))

    if analyzer is None:
        try:
            analyzer = _build_packet_analyzer(document_types, expected_documents, rules)
        except Exception:
            analyzer = None

    digests: dict[str, list[Path]] = {}
    optional_known_aliases = {"job description", "job duties", "personal support specialist", "mbc clearance", "aps clearance"}

    for folder, pdfs in sorted(pdfs_by_folder.items()):
        recognized: dict[str, dict[Path, set[int]]] = {}
        prefixes: set[str] = set()

        for pdf in sorted(pdfs):
            result.pdfs_scanned += 1
            if progress_callback:
                progress_callback(f"Reading {pdf.name}")

            try:
                size = pdf.stat().st_size
            except OSError as exc:
                result.findings.append(AuditFinding("ERROR", folder, f"PDF file could not be read: {exc}", pdf))
                continue
            if size == 0:
                result.findings.append(AuditFinding("ERROR", folder, "PDF file is empty", pdf))
                continue

            page_count, open_error = pdf_page_count(pdf)
            if open_error:
                result.findings.append(AuditFinding("ERROR", folder, open_error, pdf))
                # Still map a recognizable filename so duplicate output types
                # are reported even when one copy is corrupt.
                document, prefix = document_for_filename(pdf.name, document_types)
                if document:
                    recognized.setdefault(document, {}).setdefault(pdf, set())
                    if prefix:
                        prefixes.add(prefix)
                continue

            digest = file_digest(pdf)
            if digest:
                digests.setdefault(digest, []).append(pdf)

            document, prefix = document_for_filename(pdf.name, document_types)
            if document:
                recognized.setdefault(document, {}).setdefault(pdf, set()).update(range(1, (page_count or 0) + 1))
                if prefix:
                    prefixes.add(prefix)
                continue

            if analyzer is None:
                name_slug = _slug(pdf.name)
                if not any(alias in name_slug for alias in optional_known_aliases):
                    result.findings.append(AuditFinding("WARNING", folder, "PDF filename is not recognized and OCR fallback is unavailable", pdf))
                continue

            try:
                assignments, blank_pages = _analyze_pdf_with_packetflow(analyzer, pdf)
            except Exception as exc:
                result.findings.append(AuditFinding("ERROR", folder, f"PDF content could not be analyzed: {exc}", pdf))
                continue

            if not assignments:
                name_slug = _slug(pdf.name)
                if not any(alias in name_slug for alias in optional_known_aliases):
                    detail = "PDF content could not be classified; all detected pages appear blank" if blank_pages else "PDF content could not be classified by the active PacketFlow rules"
                    result.findings.append(AuditFinding("WARNING", folder, detail, pdf))
                continue

            for assignment in assignments:
                document = str(assignment.document)
                recognized.setdefault(document, {}).setdefault(pdf, set()).add(int(assignment.page_index) + 1)

        # Shared folders can contain PDFs for several employees. They are still
        # scanned for corrupt and duplicate files, but not judged as one packet.
        if not _folder_is_packet(folder, prefixes):
            result.findings.append(AuditFinding("WARNING", folder, "Shared folder detected from mixed employee filename prefixes; packet checklist validation was skipped"))
            continue

        workflow_name, checklist_documents, waived_documents, metadata_error = _workflow_document_statuses(
            folder, expected_documents, workflow_templates, default_workflow_template
        )
        if metadata_error:
            result.findings.append(AuditFinding("WARNING", folder, metadata_error))

        for document, entry in checklist_documents.items():
            if document in recognized:
                continue
            waiver_reason = str(waived_documents.get(document, "")).strip()
            if waiver_reason:
                continue
            status = str(entry.get("status", "optional")).strip().lower()
            note = str(entry.get("note", "")).strip()
            suffix = f" ({note})" if note else ""
            if status == "required":
                result.findings.append(AuditFinding("ERROR", folder, f"Missing expected output: {document}" + (f" ({note})" if note else "")))
            elif status == "conditional":
                result.findings.append(AuditFinding("WARNING", folder, f"Conditional requirement needs review: {document}{suffix}"))
            elif status == "expected_later":
                result.findings.append(AuditFinding("WARNING", folder, f"Waiting for expected email clearance: {document}{suffix}"))

        for document, files in recognized.items():
            if len(files) > 1:
                names = ", ".join(sorted(path.name for path in files))
                result.findings.append(AuditFinding("ERROR", folder, f"Duplicate output type: {document}: {names}"))

        # Structural checks for outputs that must contain supporting pages.
        i9_name = "Form I-9 Employment Eligibility Verification.pdf"
        if i9_name in recognized and _total_pages(recognized[i9_name]) < 3:
            result.findings.append(AuditFinding("ERROR", folder, "I-9 output must contain the form plus two identification pages"))

        mbc_auth_name = "MBC Authorization.pdf"
        if mbc_auth_name in recognized and _total_pages(recognized[mbc_auth_name]) < 2:
            result.findings.append(AuditFinding("ERROR", folder, "MBC Authorization output appears incomplete: expected the signed authorization pages"))

        direct_deposit_name = "Viventium Direct Deposit.pdf"
        if direct_deposit_name in recognized and _total_pages(recognized[direct_deposit_name]) < 2:
            result.findings.append(AuditFinding("ERROR", folder, "Direct Deposit output appears incomplete: expected the authorization form plus banking/check evidence"))

    for paths in digests.values():
        if len(paths) < 2:
            continue
        names = ", ".join(path.name for path in paths)
        result.findings.append(AuditFinding("WARNING", root, "Identical PDF content appears more than once: " + names))

    return result


def format_audit_report(result: DirectoryAuditResult) -> str:
    lines = [
        "PACKETFLOW DIRECTORY AUDIT",
        "Audit mode: Workflow-template checklist with filename matching and OCR fallback",
        f"Audit scope: {result.scope_description}",
        f"Folders containing PDFs: {result.folders_scanned}",
        f"Folders skipped by scope: {result.folders_skipped}",
        f"PDFs scanned: {result.pdfs_scanned}",
        f"Errors: {len(result.errors)}",
        f"Warnings: {len(result.warnings)}",
        "",
    ]
    if not result.findings:
        lines.append("No missing, incomplete, duplicate, unreadable, corrupt, or unclassified PDF issues were found.")
        return "\n".join(lines)

    for level in ("ERROR", "WARNING"):
        findings = [item for item in result.findings if item.level == level]
        if not findings:
            continue
        lines.append(level + "S")
        for item in findings:
            location = item.file.name if item.file else item.folder.name
            lines.append(f"- {location}: {item.message}" if location else f"- {item.message}")
        lines.append("")
    return "\n".join(lines).rstrip()
