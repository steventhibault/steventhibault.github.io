from __future__ import annotations

import hashlib
import re
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from pypdf import PdfReader


@dataclass
class AuditFinding:
    level: str
    folder: Path
    message: str
    file: Path | None = None


@dataclass
class DirectoryAuditResult:
    root: Path
    folders_scanned: int = 0
    pdfs_scanned: int = 0
    findings: list[AuditFinding] = field(default_factory=list)

    @property
    def errors(self) -> list[AuditFinding]:
        return [item for item in self.findings if item.level == "ERROR"]

    @property
    def warnings(self) -> list[AuditFinding]:
        return [item for item in self.findings if item.level == "WARNING"]


def _slug(value: str) -> str:
    value = Path(str(value)).stem
    value = re.sub(r"\.pdf$", "", value, flags=re.I)
    value = value.lower()
    value = value.replace("i-9", "i9").replace("w-4", "w4")
    value = re.sub(r"[^a-z0-9]+", " ", value)
    tokens = [
        token for token in value.split()
        if token not in {"pdf", "ford", "laurie"}
    ]
    return " ".join(tokens)


def _doc_aliases(document: str) -> set[str]:
    doc = _slug(document)
    aliases = {doc}
    compact = doc.replace(" ", "")
    aliases.add(compact)
    manual = {
        "orientation agenda": {"orientation", "orientation agenda"},
        "form i9 employment eligibility verification": {"form i9", "i9", "employment eligibility verification"},
        "job application": {"application", "job application", "careco job application"},
        "interview statement": {"interview", "interview statement"},
        "time recording": {"time recording", "recording of time worked"},
        "cherkr authorization": {"cherkr", "cherkr auth", "cherkr authorization", "consumer report"},
        "mbc authorization": {"mbc auth", "mbc authorization", "maine background check center authorization"},
        "mbc clearance": {"mbc clearance", "background check clearance"},
        "mbc payment": {"mbc payment", "background check payment"},
        "child protective services authorization": {"cps auth", "cps authorization", "child protective services authorization"},
        "confirmation child abuse registry background check request": {"confirmation child abuse registry background check request", "child abuse registry background check request", "child abuse background check confirmation"},
        "payroll": {"payroll"},
        "federal w4 withholding": {"federal w4", "federal withholding", "w4 withholding"},
        "viventium direct deposit": {"viventium direct deposit", "direct deposit"},
        "banking": {"banking", "baking", "bank", "voided check"},
        "auto enrollment opt out": {"auto enrollment opt out", "auto enrol opt out"},
        "employee choice acknowledgement waiver": {"employee choice acknowledgement waiver", "employee choice waiver", "waiver"},
        "birth and marriage certificates": {"birth marriage certs", "birth marriage certificates", "birth cert", "birth certificate", "marriage certs"},
    }
    aliases.update(manual.get(doc, set()))
    return {_slug(alias) for alias in aliases if alias}


def document_for_filename(filename: str, document_types: list[str]) -> tuple[str | None, str]:
    """Return the document type implied by a PDF filename, if any.

    This is intentionally tolerant of older employee folder names such as
    "LAURIE FORD_CHERKR AUTH.pdf", underscores, capitalization, and typos like
    "BAKING" for Banking. It is used as the primary directory-audit signal so
    OCR inside one combined packet does not falsely mark every matching phrase
    as a duplicate output document.
    """
    stem_slug = _slug(filename)
    compact_stem = stem_slug.replace(" ", "")
    best_document: str | None = None
    best_score = 0
    for document in document_types:
        for alias in _doc_aliases(document):
            if not alias:
                continue
            compact_alias = alias.replace(" ", "")
            matched = (
                stem_slug == alias
                or stem_slug.endswith(" " + alias)
                or alias in stem_slug
                or compact_alias in compact_stem
            )
            if matched:
                score = len(compact_alias)
                if score > best_score:
                    best_score = score
                    best_document = document
    return best_document, ""


def pdf_page_count(path: Path) -> tuple[int | None, str | None]:
    try:
        reader = PdfReader(str(path), strict=False)
        if reader.is_encrypted:
            try:
                result = reader.decrypt("")
            except Exception:
                result = 0
            if not result:
                return None, "PDF is encrypted and cannot be opened"
        page_count = len(reader.pages)
        if page_count == 0:
            return 0, "PDF contains no pages"
        return page_count, None
    except Exception as exc:
        return None, f"PDF cannot be opened: {exc}"


def file_digest(path: Path) -> str | None:
    try:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest()
    except OSError:
        return None


def _build_packet_analyzer(document_types: list[str], expected_documents: list[str], rules: dict[str, Any] | None):
    from app import PacketAnalyzer
    analyzer_rules = dict(rules or {})
    analyzer_rules.setdefault("document_types", list(document_types))
    analyzer_rules.setdefault("expected_document_types", list(expected_documents))
    analyzer_rules.setdefault("custom_rules", [])
    return PacketAnalyzer(analyzer_rules)


def _analyze_pdf_with_packetflow(analyzer, pdf: Path) -> tuple[list[Any], set[int]]:
    with tempfile.TemporaryDirectory(prefix="packetflow-directory-audit-") as temp_dir:
        _images, _texts, assignments, _rotations, blank_pages, _fingerprints = analyzer.analyze(
            pdf,
            Path(temp_dir),
            lambda *_args, **_kwargs: None,
        )
    return assignments, blank_pages


def audit_directory(
    root: Path,
    document_types: list[str],
    expected_documents: list[str],
    *,
    analyzer=None,
    rules: dict[str, Any] | None = None,
    progress_callback: Callable[[str], None] | None = None,
) -> DirectoryAuditResult:
    """Audit employee folders using filename-aware checklist plus OCR fallback.

    The old content-only audit treated a large application packet as many
    duplicate document outputs because the packet contained phrases for
    orientation, I-9, direct deposit, etc. This audit uses the output PDF name as
    the primary signal and only uses OCR for PDFs whose filename is unknown.
    """
    root = Path(root)
    result = DirectoryAuditResult(root=root)
    if not root.is_dir():
        result.findings.append(AuditFinding("ERROR", root, "Selected directory does not exist"))
        return result

    pdfs_by_folder: dict[Path, list[Path]] = {}
    try:
        for pdf in root.rglob("*.pdf"):
            if pdf.is_file():
                pdfs_by_folder.setdefault(pdf.parent, []).append(pdf)
    except OSError as exc:
        result.findings.append(AuditFinding("ERROR", root, f"Directory could not be scanned: {exc}"))
        return result

    result.folders_scanned = len(pdfs_by_folder)
    if not pdfs_by_folder:
        result.findings.append(AuditFinding("WARNING", root, "No PDF files were found"))
        return result

    document_types = [str(item).strip() for item in document_types if str(item).strip()]
    expected_documents = [str(item).strip() for item in expected_documents if str(item).strip()]
    if not expected_documents:
        result.findings.append(AuditFinding("ERROR", root, "No expected-document checklist is configured for the active PacketFlow profile"))

    if analyzer is None:
        try:
            analyzer = _build_packet_analyzer(document_types, expected_documents, rules)
        except Exception:
            analyzer = None

    digests: dict[str, list[Path]] = {}

    optional_known_aliases = {
        "job description",
        "job duties",
        "personal support specialist",
        "mbc clearance",
        "aps clearance",
    }

    for folder, pdfs in sorted(pdfs_by_folder.items()):
        recognized: dict[str, dict[Path, set[int]]] = {}
        unknown_pdfs: list[Path] = []

        for pdf in sorted(pdfs):
            result.pdfs_scanned += 1
            if progress_callback:
                progress_callback(f"Reading {pdf.name}")

            try:
                size = pdf.stat().st_size
            except OSError as exc:
                result.findings.append(AuditFinding("ERROR", folder, f"PDF file could not be read: {exc}", pdf))
                continue
            if size == 0:
                result.findings.append(AuditFinding("ERROR", folder, "PDF file is empty", pdf))
                continue

            page_count, open_error = pdf_page_count(pdf)
            if open_error:
                result.findings.append(AuditFinding("ERROR", folder, open_error, pdf))
                continue

            digest = file_digest(pdf)
            if digest:
                digests.setdefault(digest, []).append(pdf)

            document, _prefix = document_for_filename(pdf.name, document_types)
            if document:
                recognized.setdefault(document, {}).setdefault(pdf, set()).update(range(1, (page_count or 0) + 1))
                continue

            unknown_pdfs.append(pdf)
            if analyzer is None:
                name_slug = _slug(pdf.name)
                if not any(alias in name_slug for alias in optional_known_aliases):
                    result.findings.append(AuditFinding("WARNING", folder, "PDF filename is not recognized and OCR fallback is unavailable", pdf))
                continue

            try:
                assignments, blank_pages = _analyze_pdf_with_packetflow(analyzer, pdf)
            except Exception as exc:
                result.findings.append(AuditFinding("ERROR", folder, f"PDF content could not be analyzed: {exc}", pdf))
                continue

            if not assignments:
                name_slug = _slug(pdf.name)
                if not any(alias in name_slug for alias in optional_known_aliases):
                    detail = "PDF content could not be classified; all detected pages appear blank" if blank_pages else "PDF content could not be classified by the active PacketFlow rules"
                    result.findings.append(AuditFinding("WARNING", folder, detail, pdf))
                continue

            for assignment in assignments:
                document = str(assignment.document)
                recognized.setdefault(document, {}).setdefault(pdf, set()).add(int(assignment.page_index) + 1)

        for document in expected_documents:
            if document not in recognized:
                result.findings.append(AuditFinding("ERROR", folder, f"Missing expected document: {document}"))

        # Duplicate outputs are duplicate filenames/types, not every occurrence
        # of matching text inside a combined packet.
        for document, files in recognized.items():
            if len(files) > 1:
                names = ", ".join(sorted(path.name for path in files))
                result.findings.append(AuditFinding("ERROR", folder, f"Duplicate expected output: {document}: {names}"))

        # Only structural checks that make sense across separate output PDFs.
        if "Viventium Direct Deposit.pdf" in recognized and "Banking.pdf" not in recognized:
            result.findings.append(AuditFinding("ERROR", folder, "Direct Deposit appears incomplete: Banking/check evidence output is missing"))

    for paths in digests.values():
        if len(paths) < 2:
            continue
        names = ", ".join(path.name for path in paths)
        result.findings.append(AuditFinding("WARNING", root, "Identical PDF content appears more than once: " + names))

    return result


def format_audit_report(result: DirectoryAuditResult) -> str:
    lines = [
        "PACKETFLOW DIRECTORY AUDIT",
        "Audit mode: Filename-aware checklist with OCR fallback",
        f"Folders containing PDFs: {result.folders_scanned}",
        f"PDFs scanned: {result.pdfs_scanned}",
        f"Errors: {len(result.errors)}",
        f"Warnings: {len(result.warnings)}",
        "",
    ]
    if not result.findings:
        lines.append("No missing, incomplete, duplicate, unreadable, corrupt, or unclassified PDF issues were found.")
        return "\n".join(lines)

    for level in ("ERROR", "WARNING"):
        findings = [item for item in result.findings if item.level == level]
        if not findings:
            continue
        lines.append(level + "S")
        for item in findings:
            location = item.file.name if item.file else item.folder.name
            lines.append(f"- {location}: {item.message}" if location else f"- {item.message}")
        lines.append("")
    return "\n".join(lines).rstrip()
