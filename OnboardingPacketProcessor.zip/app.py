from __future__ import annotations

import copy
import difflib
import glob
import json
import os
import queue
import re
import shutil
import subprocess
import tempfile
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk

from PIL import Image, ImageStat, ImageTk
from pypdf import PdfReader, PdfWriter


APP_TITLE = "CareCo Onboarding Packet Processor"
APP_DIR = Path(__file__).resolve().parent
RULES_PATH = APP_DIR / "rules.json"
CORRECTION_MEMORY_PATH = APP_DIR / "correction_memory.json"

# Visual theme
COLOR_BG = "#f4f6f9"
COLOR_SURFACE = "#ffffff"
COLOR_ACCENT = "#1d4ed8"
COLOR_ACCENT_HOVER = "#1e40af"
COLOR_TEXT = "#111827"
COLOR_MUTED = "#6b7280"
COLOR_PREVIEW_BG = "#e5e7eb"
COLOR_SORTED = "#166534"
COLOR_UNSORTED = "#b45309"
COLOR_BLANK = "#9ca3af"
COLOR_READING = "#2563eb"

OCR_WORKERS = min(8, max(2, os.cpu_count() or 4))
TESSERACT_BASE_ARGS = ["--oem", "1", "-c", "preserve_interword_spaces=1"]


@dataclass
class Assignment:
    page_index: int
    document: str
    rotation: int = 0
    sequence: float | None = None

    @property
    def page_number(self) -> int:
        return self.page_index + 1


def find_program(name: str, common_paths: list[str]) -> str | None:
    located = shutil.which(name)
    if located:
        return located
    for raw_path in common_paths:
        expanded = os.path.expandvars(raw_path)
        matches = sorted(glob.glob(expanded), reverse=True)
        if matches:
            return matches[0]
    return None


def safe_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "_", name.strip())
    name = name.rstrip(". ")
    if not name.lower().endswith(".pdf"):
        name += ".pdf"
    return name or "Unsorted.pdf"


def safe_folder_name(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "_", name.strip())
    name = name.rstrip(". ")
    return name or "Sorted Packet"


class PacketAnalyzer:
    def __init__(self, rules: dict):
        self.rules = rules
        self.pdftoppm = find_program(
            "pdftoppm",
            [
                r"C:\Program Files\poppler-*\Library\bin\pdftoppm.exe",
                r"C:\Program Files\poppler\Library\bin\pdftoppm.exe",
                r"C:\Program Files (x86)\poppler-*\Library\bin\pdftoppm.exe",
            ],
        )
        self.tesseract = find_program(
            "tesseract",
            [
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            ],
        )

    def check_dependencies(self) -> None:
        missing = []
        if not self.pdftoppm:
            missing.append("Poppler (pdftoppm)")
        if not self.tesseract:
            missing.append("Tesseract OCR")
        if missing:
            raise RuntimeError(
                "Missing required software: "
                + ", ".join(missing)
                + ". Close the app and run 'Start Onboarding Packet Processor.cmd' "
                + "to receive installation help."
            )

    def analyze(
        self,
        pdf_path: Path,
        work_dir: Path,
        progress_callback,
    ) -> tuple[
        list[Path],
        list[str],
        list[Assignment],
        list[int],
        set[int],
        list[int],
    ]:
        self.check_dependencies()
        reader = PdfReader(str(pdf_path))
        page_count = len(reader.pages)
        image_prefix = work_dir / "page"

        progress_callback(2, "Rendering packet pages...")
        subprocess.run(
            [
                self.pdftoppm,
                "-jpeg",
                "-r",
                "110",
                "-jpegopt",
                "quality=78",
                str(pdf_path),
                str(image_prefix),
            ],
            check=True,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )

        images = sorted(work_dir.glob("page-*.jpg"))
        if len(images) != page_count:
            raise RuntimeError(
                f"Rendered {len(images)} page images, but the PDF has {page_count} pages."
            )

        ocr_texts: list[str] = [""] * page_count
        rotations: list[int] = [0] * page_count
        blank_pages: set[int] = set()
        fingerprints: list[int] = [0] * page_count
        worker_count = min(OCR_WORKERS, page_count)
        completed = 0
        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            future_pages = {
                executor.submit(
                    self.analyze_page,
                    index,
                    image_path,
                    work_dir,
                    pdf_path,
                ): index
                for index, image_path in enumerate(images)
            }
            for future in as_completed(future_pages):
                index, text, rotation, is_blank, fingerprint = future.result()
                ocr_texts[index] = text
                rotations[index] = rotation
                fingerprints[index] = fingerprint
                if is_blank:
                    blank_pages.add(index)
                completed += 1
                percent = 8 + int((completed / max(page_count, 1)) * 82)
                progress_callback(
                    percent,
                    f"Reading pages: {completed} of {page_count} complete...",
                    index,
                )

        progress_callback(94, "Building document groups...")
        assignments = self.classify_pages(ocr_texts, rotations, blank_pages)
        progress_callback(100, "Analysis complete")
        return (
            images,
            ocr_texts,
            assignments,
            rotations,
            blank_pages,
            fingerprints,
        )

    def analyze_page(
        self,
        index: int,
        image_path: Path,
        work_dir: Path,
        pdf_path: Path,
    ) -> tuple[int, str, int, bool, int]:
        with Image.open(image_path) as source_image:
            image = source_image.convert("RGB")
        grayscale = image.convert("L")
        statistics = ImageStat.Stat(grayscale)
        histogram = grayscale.histogram()
        ink_ratio = sum(histogram[:235]) / max(image.width * image.height, 1)
        fingerprint = self.page_fingerprint(grayscale)

        if statistics.stddev[0] < 3 and ink_ratio < 0.002:
            return index, "", 0, True, fingerprint

        with tempfile.NamedTemporaryFile(
            suffix=".jpg", dir=work_dir, delete=False
        ) as rotated_handle:
            rotated_path = Path(rotated_handle.name)
            image.rotate(180).save(rotated_path, quality=85)

        with ThreadPoolExecutor(max_workers=2) as orientation_pool:
            original_future = orientation_pool.submit(self.ocr_image, image_path)
            rotated_future = orientation_pool.submit(self.ocr_image, rotated_path)
            original_text = original_future.result()
            rotated_text = rotated_future.result()

        original_score = self.orientation_score(original_text)
        rotated_score = self.orientation_score(rotated_text)
        if rotated_score > original_score * 1.12 + 15:
            image.rotate(180).save(image_path, quality=85)
            selected_text = rotated_text
            rotation = 180
        else:
            selected_text = original_text
            rotation = 0
        rotated_path.unlink(missing_ok=True)

        if len(re.findall(r"[A-Za-z]{3,}", selected_text)) < 60:
            selected_text += "\n__SPARSE_SCAN__\n"
            detail_text = self.high_resolution_ocr(
                pdf_path, index, work_dir, rotation
            )
            if detail_text:
                selected_text += "\n" + detail_text

        return index, selected_text, rotation, False, fingerprint

    @staticmethod
    def page_fingerprint(grayscale: Image.Image) -> int:
        """Return a tiny difference hash using the image already in memory."""
        sample = grayscale.resize((17, 16), Image.Resampling.BILINEAR)
        pixels = list(sample.getdata())
        fingerprint = 0
        for row in range(16):
            offset = row * 17
            for column in range(16):
                fingerprint <<= 1
                if pixels[offset + column] > pixels[offset + column + 1]:
                    fingerprint |= 1
        return fingerprint

    def high_resolution_ocr(
        self,
        pdf_path: Path,
        page_index: int,
        work_dir: Path,
        rotation: int,
    ) -> str:
        prefix = work_dir / f"detail-{page_index + 1:03}"
        detail_path = prefix.with_suffix(".jpg")
        subprocess.run(
            [
                self.pdftoppm,
                "-f",
                str(page_index + 1),
                "-l",
                str(page_index + 1),
                "-singlefile",
                "-jpeg",
                "-r",
                "300",
                str(pdf_path),
                str(prefix),
            ],
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if not detail_path.exists():
            return ""
        try:
            if rotation:
                with Image.open(detail_path) as source_image:
                    source_image.rotate(rotation).save(detail_path, quality=88)
            result = subprocess.run(
                [
                    self.tesseract,
                    str(detail_path),
                    "stdout",
                    *TESSERACT_BASE_ARGS,
                    "--psm",
                    "6",
                    "-c",
                    "user_defined_dpi=300",
                ],
                check=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
            )
            return result.stdout.decode("utf-8", errors="ignore")
        finally:
            detail_path.unlink(missing_ok=True)

    def ocr_image(self, image_path: Path) -> str:
        result = subprocess.run(
            [
                self.tesseract,
                str(image_path),
                "stdout",
                *TESSERACT_BASE_ARGS,
                "--psm",
                "11",
                "-c",
                "user_defined_dpi=110",
            ],
            check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
        )
        return result.stdout.decode("utf-8", errors="ignore")

    @staticmethod
    def orientation_score(text: str) -> int:
        normalized = re.sub(r"\s+", " ", text.lower())
        words = re.findall(r"[a-z]{3,}", normalized)
        keywords = (
            "employee",
            "employer",
            "signature",
            "careco",
            "application",
            "authorization",
            "background",
            "withholding",
            "orientation",
            "employment",
            "instructions",
            "maine",
            "payroll",
            "coverage",
            "waiver",
            "deposit",
            "handbook",
        )
        return len(words) + (20 * sum(word in normalized for word in keywords))

    def classify_pages(
        self,
        texts: list[str],
        rotations: list[int] | None = None,
        blank_pages: set[int] | None = None,
    ) -> list[Assignment]:
        normalized = [re.sub(r"\s+", " ", text.lower()) for text in texts]
        rotations = rotations or [0] * len(texts)
        blank_pages = blank_pages or set()
        assignments: list[Assignment] = []
        last_i9_page: int | None = None

        def add(
            page_index: int,
            document: str,
            sequence: float | None = None,
        ):
            if sequence is None:
                sequence = self.document_sequence(document, normalized[page_index])
            candidate = Assignment(
                page_index,
                document,
                rotations[page_index],
                sequence,
            )
            if candidate not in assignments:
                assignments.append(candidate)

        for index, text in enumerate(normalized):
            if index in blank_pages:
                continue

            has_i9 = "form i-9" in text or (
                "employment eligibility verification" in text
                and (
                    "department of homeland security" in text
                    or "citizenship and immigration services" in text
                    or "anti-discrimination notice" in text
                )
            ) or (
                "lists of acceptable documents" in text
                and "documents that establish identity" in text
                and "employment authorization" in text
            )
            has_orientation = (
                "orientation agenda" in text
                or (
                    "congratulations" in text
                    and "welcome to our team" in text
                    and "careco" in text
                )
            )
            has_social_security_card = (
                (
                    ("security" in text or "ocial secur" in text)
                    and "established" in text
                    and "signature" in text
                )
                or "social security administration" in text
                or (
                    "security administration" in text
                    and ("social" in text or "soc security" in text)
                )
            )
            social_security_is_restricted = any(
                restriction in text
                for restriction in (
                    "not valid for employment",
                    "valid for work only with ins authorization",
                    "valid for work only with dhs authorization",
                )
            )
            has_social_security_card = (
                has_social_security_card and not social_security_is_restricted
            )
            license_detail_markers = sum(
                marker in text
                for marker in (
                    "dl. no",
                    "class",
                    "expires",
                    "issued",
                    "endorsements",
                    "restrictions",
                )
            )
            has_driver_license = (
                any(
                    marker in text
                    for marker in (
                        "driver's license",
                        "driver'slicense",
                        "driver'siicense",
                        "drivers license",
                    )
                )
                and license_detail_markers >= 1
            )
            passport_detail_markers = sum(
                marker in text
                for marker in (
                    "nationality",
                    "passport no",
                    "passport number",
                    "date of expiry",
                    "date of expiration",
                    "expiration date",
                    "issuing country",
                    "place of birth",
                )
            )
            has_passport = (
                (
                    "passport card" in text
                    and passport_detail_markers >= 1
                )
                or (
                    "passport" in text
                    and passport_detail_markers >= 2
                    and (
                        "united states of america" in text
                        or "issuing country" in text
                        or "nationality" in text
                    )
                )
            )
            has_permanent_resident_card = (
                "permanent resident card" in text
                or "alien registration receipt card" in text
                or (
                    re.search(r"\b(?:i|1)[ -]?551\b", text) is not None
                    and any(
                        marker in text
                        for marker in (
                            "resident since",
                            "card expires",
                            "alien registration",
                            "uscis#",
                            "uscis #",
                        )
                    )
                )
            )
            has_temporary_i551 = (
                "temporary i-551" in text
                or "temporary 1-551" in text
                or "upon endorsement serves as temporary i-551" in text
                or (
                    "machine readable immigrant visa" in text
                    and "passport" in text
                )
            )
            has_employment_authorization_card = (
                "employment authorization card" in text
                or (
                    "employment authorization document" in text
                    and re.search(r"\b(?:i|1)[ -]?766\b", text) is not None
                )
                or (
                    re.search(r"\b(?:i|1)[ -]?766\b", text) is not None
                    and "uscis" in text
                    and ("category" in text or "card expires" in text)
                )
            )
            has_i94 = (
                re.search(r"\b(?:i|1)[ -]?94a?\b", text) is not None
                or "arrival/departure record" in text
                or "arrival-departure record" in text
            ) and any(
                marker in text
                for marker in (
                    "class of admission",
                    "admit until",
                    "departure number",
                    "admission number",
                    "refugee",
                    "asylee",
                )
            )
            has_foreign_passport_work_authorization = (
                "passport" in text
                and (
                    has_temporary_i551
                    or (
                        has_i94
                        and any(
                            marker in text
                            for marker in (
                                "employment authorized",
                                "authorized to work",
                                "nonimmigrant status",
                                "h-1b",
                                "h1b",
                                "refugee",
                                "asylee",
                                "federated states of micronesia",
                                "marshall islands",
                                "compact of free association",
                            )
                        )
                    )
                )
            )
            identity_detail_markers = sum(
                marker in text
                for marker in (
                    "date of birth",
                    "dob",
                    "sex",
                    "height",
                    "eye color",
                    "eyes",
                    "address",
                    "photograph",
                    "photo",
                )
            )
            has_government_id = (
                any(
                    marker in text
                    for marker in (
                        "government identification card",
                        "government id card",
                        "personal identity verification",
                        "piv card",
                        "common access card",
                        "cac card",
                        "state identification card",
                        "state id card",
                    )
                )
                and identity_detail_markers >= 1
            )
            has_school_id = (
                any(
                    marker in text
                    for marker in (
                        "school identification card",
                        "school id card",
                        "student identification card",
                        "student id card",
                    )
                )
                and ("student" in text or "school" in text)
            )
            has_voter_registration = (
                "voter registration card" in text
                or "voter's registration card" in text
                or "voters registration card" in text
            )
            has_military_id = any(
                marker in text
                for marker in (
                    "uniformed services identification",
                    "united states uniformed services",
                    "military identification card",
                    "military id card",
                    "military dependent",
                    "dependent identification card",
                    "department of defense identification",
                    "dod identification card",
                    "common access card",
                    "draft record",
                )
            )
            has_merchant_mariner_card = (
                "merchant mariner card" in text
                or "merchant mariner credential" in text
                or (
                    "united states coast guard" in text
                    and "merchant mariner" in text
                )
            )
            has_tribal_document = any(
                marker in text
                for marker in (
                    "native american tribal document",
                    "tribal identification card",
                    "tribal enrollment card",
                    "certificate of degree of indian blood",
                )
            )
            has_canadian_driver_license = (
                ("canada" in text or "canadian" in text)
                and any(
                    marker in text
                    for marker in (
                        "driver's licence",
                        "driver licence",
                        "permis de conduire",
                    )
                )
                and license_detail_markers >= 1
            )
            has_us_citizen_id = (
                re.search(r"\b(?:i|1)[ -]?197\b", text) is not None
                and "citizen" in text
                and "identification" in text
            )
            has_resident_citizen_id = (
                re.search(r"\b(?:i|1)[ -]?179\b", text) is not None
                and "resident citizen" in text
                and "identification" in text
            )
            has_dhs_employment_document = any(
                marker in text
                for marker in (
                    "refugee travel document",
                    "reentry permit",
                    "re-entry permit",
                    "certificate of citizenship",
                    "certificate of naturalization",
                    "replacement certificate of citizenship",
                    "replacement certificate of naturalization",
                )
            ) or any(
                re.search(pattern, text) is not None
                for pattern in (
                    r"\b(?:i|1)[ -]?571\b",
                    r"\b(?:i|1)[ -]?327\b",
                    r"\bn[ -]?560\b",
                    r"\bn[ -]?561\b",
                    r"\bn[ -]?550\b",
                    r"\bn[ -]?570\b",
                )
            )
            has_birth_certificate = (
                "certificate of live birth" in text
                or "certified abstract of a certificate of live birth" in text
                or "consular report of birth abroad" in text
                or "certification of report of birth" in text
                or "certification of birth abroad" in text
                or any(
                    form_number in text
                    for form_number in ("ds-1350", "fs-545", "fs-240")
                )
                or (
                    "vital records" in text
                    and "birth place" in text
                    and "date of birth" in text
                )
            )
            has_marriage_certificate = (
                "certificate of marriage" in text
                or (
                    "vital records" in text
                    and "marriage" in text
                    and ("party a" in text or "party b" in text)
                )
            )
            has_interview_statement = (
                "interview statement" in text
                or (
                    "interviewed by" in text
                    and "what are your strengths" in text
                    and (
                        "what are your weaknesses" in text
                        or "why do you want this job" in text
                        or "why do youwantthisjob" in text
                    )
                )
            )
            is_i9_adjacent = (
                last_i9_page is not None
                and 0 < index - last_i9_page <= 3
            )
            has_minor_identity_record = (
                is_i9_adjacent
                and any(
                    marker in text
                    for marker in (
                        "school record",
                        "school report card",
                        "student report card",
                        "clinic record",
                        "doctor record",
                        "hospital record",
                        "day care record",
                        "day-care record",
                        "nursery school record",
                    )
                )
            )
            has_acceptable_replacement_receipt = (
                is_i9_adjacent
                and "receipt" in text
                and any(
                    marker in text
                    for marker in (
                        "replacement",
                        "lost",
                        "stolen",
                        "damaged",
                        "form i-797c",
                        "notice of action",
                        "adit stamp",
                        "refugee stamp",
                    )
                )
            )

            if has_i9 and has_orientation:
                # Mixed documents on one scan require rescanning. The app does
                # not divide a source page.
                continue
            if has_i9:
                add(index, "Form I-9 Employment Eligibility Verification.pdf")
                last_i9_page = index
                continue
            if has_orientation:
                add(index, "Orientation Agenda.pdf")
                continue
            if has_birth_certificate or has_marriage_certificate:
                add(index, "Birth and Marriage Certificates.pdf")
                continue
            if has_interview_statement:
                add(index, "Interview Statement.pdf")
                continue
            if any(
                (
                    has_social_security_card,
                    has_driver_license,
                    has_passport,
                    has_permanent_resident_card,
                    has_temporary_i551,
                    has_employment_authorization_card,
                    has_foreign_passport_work_authorization,
                    has_government_id,
                    has_school_id,
                    has_voter_registration,
                    has_military_id,
                    has_merchant_mariner_card,
                    has_tribal_document,
                    has_canadian_driver_license,
                    has_us_citizen_id,
                    has_resident_citizen_id,
                    has_dhs_employment_document,
                    has_minor_identity_record,
                    has_acceptable_replacement_receipt,
                )
            ):
                add(index, "Form I-9 Employment Eligibility Verification.pdf")
                continue
            if (
                is_i9_adjacent
                and "__sparse_scan__" in text
            ):
                # ID cards are often small, photographed, or faint enough that
                # OCR returns mostly noise. Immediately following I-9 pages are
                # treated as supporting identification unless a recognizable
                # certificate or other document matched above.
                add(index, "Form I-9 Employment Eligibility Verification.pdf")
                continue

            if "recording of time worked" in text:
                add(index, "Time Recording.pdf")
                continue

            job_application_markers = (
                "careco shoreline job application",
                "employee availability sheet",
                "non-exempt compensation agreement",
                "companion checklist",
                "comprehensive hiring form",
                "handbook acknowledgement form",
                "personal support specialist",
                "reasons for immediate termination",
                "requests that all employees follow the following rules",
                "nothing in this employee handbook shall form a contract",
                "employee handbook shall form a contract",
                "by signing this agreement",
                "acknowledges receipt of, and agreement to",
                "compensation agreement",
                "medical examination and drug test",
                "work reference",
                "personal references",
                "at-will employment",
                "must have a reliable enclosed vehicle",
                "the job description provides a framework for the job",
                "duties and responsibilities listed above for my position",
            )
            is_resume_page = (
                (
                    "experience" in text
                    and re.search(
                        r"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}",
                        text,
                    )
                    is not None
                )
                or ("page 2 of 2" in text and "education" in text)
            )
            if is_resume_page or any(
                marker in text for marker in job_application_markers
            ):
                add(index, "Job Application.pdf")
                continue

            if "cherkr" in text or (
                "consumer report" in text and "candidate disclosure" in text
            ):
                add(index, "CHERKR Authorization.pdf")
                continue

            if (
                "maine background check center" in text
                or "background check report correcting inaccurate information"
                in text
                or (
                    "authorization and release by the applicant" in text
                    and "background check center" in text
                )
            ):
                add(index, "MBC Authorization.pdf")
                continue

            if "application fee paid for maine criminal background check" in text:
                add(index, "MBC Payment.pdf")
                continue

            if "child abuse background check confirmation" in text:
                add(
                    index,
                    "Confirmation - Child Abuse Registry Background Check Request.pdf",
                )
                continue

            if (
                "child abuse and neglect records information" in text
                or "child protective services case" in text
                or (
                    "child and family services" in text
                    and "authorization release" in text
                )
            ):
                add(index, "Child Protective Services Authorization.pdf")
                continue

            if "w-4me" in text or (
                "maine" in text and "withholding allowance certificate" in text
            ):
                add(index, "Payroll.pdf")
                continue

            if "form 8850" in text or "work opportunity credit" in text:
                add(index, "Payroll.pdf")
                continue

            if (
                "form w-4" in text
                or "employee’s withholding certificate" in text
                or "employee's withholding certificate" in text
                or "multiple jobs worksheet" in text
            ) and (
                "internal revenue" in text
                or "treasury" in text
                or "multiple jobs worksheet" in text
                or "general instructions" in text
            ):
                add(index, "Federal W-4 Withholding.pdf")
                continue

            is_legacy_payroll = (
                "paypro payroll" in text
                or "skylight payoptions" in text
                or (
                    "card mailing address" in text
                    and "net pay" in text
                    and "employee signature" in text
                )
            )
            if is_legacy_payroll:
                continue

            if "viventium payroll" in text or "employee direct deposit authorization" in text:
                add(index, "Viventium Direct Deposit.pdf")
                continue

            if self.looks_like_banking_page(
                text, index, normalized, blank_pages
            ):
                add(index, "Banking.pdf")
                add(index, "Viventium Direct Deposit.pdf")
                continue

            if "auto enrol" in text and "opt out" in text:
                add(index, "Auto Enrollment Opt Out.pdf")
                continue

            if (
                "waiver form" in text
                or "decline all coverage" in text
                or ("employee" in text and "choice" in text and "waiver" in text)
            ):
                add(index, "Employee Choice Acknowledgement Waiver.pdf")
                continue

        return sorted(assignments, key=lambda item: (item.document.lower(), item.page_index))

    @staticmethod
    def document_sequence(document: str, text: str) -> float | None:
        if document == "Form I-9 Employment Eligibility Verification.pdf":
            if "form i-9" in text or "department of homeland security" in text:
                return 1
            return 2

        if document == "Job Application.pdf":
            markers = (
                ("careco shoreline job application", 1),
                ("work reference", 2),
                ("medical examination and drug test", 3),
                ("page 1 of 2", 13),
                ("page 2 of 2", 14),
                ("employee availability sheet", 4),
                ("nothing in this employee handbook shall form a contract", 5),
                ("employee handbook shall form a contract", 5),
                ("by signing this agreement", 5),
                ("acknowledges receipt of, and agreement to", 5),
                ("comprehensive hiring form", 6),
                ("companion checklist", 7),
                ("non-exempt compensation agreement", 8),
                ("compensation agreement", 8),
                ("requests that all employees follow the following rules", 9),
                ("reasons for immediate termination", 9.5),
                ("must have a reliable enclosed vehicle", 11),
                ("at least 18 years of age", 11),
                ("personal support specialist", 10),
                ("handbook acknowledgement form", 12),
                ("the job description provides a framework for the job", 12.5),
                ("duties and responsibilities listed above for my position", 12.5),
            )
            for marker, sequence in markers:
                if marker in text:
                    return sequence
            if (
                "experience" in text
                and re.search(
                    r"[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}",
                    text,
                )
                is not None
            ):
                return 13

        if document == "MBC Authorization.pdf":
            if "notification and authorization and release" in text:
                return 1
            if "authorization and release" in text and "applicant" in text:
                return 2
            if "signature of applicant" in text and "title 18" in text:
                return 2
            if "voluntary consent for disclosure" in text:
                return 3
            return 4

        if document == "Federal W-4 Withholding.pdf":
            heading = text[:500]
            if "multiple jobs worksheet" in heading:
                return 3
            if "general instructions" in heading or "page 2" in heading:
                return 2
            return 1

        if document == "Viventium Direct Deposit.pdf":
            if "direct deposit" in text or "viventium" in text:
                return 1
            return 2

        return None

    @staticmethod
    def looks_like_banking_page(
        text: str,
        index: int,
        all_texts: list[str],
        blank_pages: set[int] | None = None,
    ) -> bool:
        blank_pages = blank_pages or set()
        strong_banking_words = (
            "routing number",
            "voided check",
            "checking account",
            "savings account",
            "this check",
            "pay to the",
            "new balance",
        )
        if any(word in text for word in strong_banking_words):
            return True
        if (
            len(text.strip()) < 350 or "__sparse_scan__" in text
        ) and index > 0 and index not in blank_pages:
            previous = all_texts[index - 1]
            return (
                "direct deposit" in previous
                or "attach a voided check" in previous
                or "viventium" in previous
            )
        return False


try:
    import customtkinter as ctk
except ImportError as exc:
    raise SystemExit("Missing required package: customtkinter. Run Start Onboarding Packet Processor.cmd so it can install dependencies.") from exc

# Web-inspired CareCo palette, matched to annual training portal
NAVY = "#071B3A"
HEADER_BG = "#C2F1F9"
CARD_NAVY = "#112C6B"
CARECO_BLUE = "#1E88E5"
BRIGHT_BLUE = "#4DA3FF"
SUCCESS_GREEN = "#63C393"
APP_BG = "#F3F5F7"
CARD_BG = "#FFFFFF"
BORDER = "#DDE5EE"
TEXT = "#0F172A"
MUTED = "#64748B"
WARNING = "#8A2020"
DANGER = "#DC2626"
BLANK = "#94A3B8"


class PacketSorterApp:
    def __init__(self, root: ctk.CTk):
        ctk.set_appearance_mode("light")
        ctk.set_default_color_theme("blue")
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1440x900")
        self.root.minsize(1180, 760)
        self.root.configure(fg_color=APP_BG)
        # Open maximized/full-screen-window style on Windows so the PDF preview
        # has as much room as possible without hiding the taskbar.
        try:
            self.root.state("zoomed")
        except Exception:
            try:
                self.root.attributes("-zoomed", True)
            except Exception:
                pass

        self.rules = self.load_rules()
        self.analyzer = PacketAnalyzer(self.rules)
        self.pdf_path: Path | None = None
        self.reader: PdfReader | None = None
        self.work_dir: Path | None = None
        self.page_images: list[Path] = []
        self.ocr_texts: list[str] = []
        self.page_rotations: list[int] = []
        self.blank_pages: set[int] = set()
        self.page_fingerprints: list[int] = []
        self.assignments: list[Assignment] = []
        self.document_order: list[str] = []
        self.duplicate_pairs: list[tuple[int, int]] = []
        self.low_confidence_pages: set[int] = set()
        self.memory_applied_pages: set[int] = set()
        self.correction_memory = self.load_correction_memory()
        self.export_packet_name: str | None = None
        self.preview_photo = None
        self.preview_image_refs: list[ImageTk.PhotoImage] = []
        self.preview_page_offsets: list[int] = []
        self.preview_cache: dict[tuple[int, int, int], ImageTk.PhotoImage] = {}
        self.preview_cache_size = (0, 0)
        self.analyzing = False
        self.worker_queue: queue.Queue = queue.Queue()
        self.selected_pages: set[int] = set()
        self.selected_document: str | None = None
        self.preview_page_position = 0
        self.preview_nav_var = tk.StringVar(value="")
        self.page_status_widgets: dict[int, dict[str, object]] = {}
        self.output_row_widgets: dict[str, object] = {}
        self.dragging_document: str | None = None

        self.status_var = tk.StringVar(value="Open a PDF packet to begin.")
        self.summary_var = tk.StringVar(value="No packet loaded")
        self.progress_var = tk.DoubleVar(value=0)
        self.progress_label_var = tk.StringVar(value="0%")
        self.document_var = tk.StringVar()

        self.build_ui()
        self.bind_shortcuts()
        self.root.after(80, self.poll_worker_queue)

    def load_rules(self) -> dict:
        with RULES_PATH.open("r", encoding="utf-8") as handle:
            return json.load(handle)

    def load_correction_memory(self) -> list[dict]:
        if not CORRECTION_MEMORY_PATH.exists():
            return []
        try:
            data = json.loads(CORRECTION_MEMORY_PATH.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def save_correction_memory(self) -> bool:
        try:
            CORRECTION_MEMORY_PATH.write_text(
                json.dumps(self.correction_memory, indent=2),
                encoding="utf-8",
            )
            return True
        except Exception as exc:
            messagebox.showerror(
                APP_TITLE,
                "The correction could not be saved for future packets.\n\n"
                + str(exc),
            )
            return False

    @staticmethod
    def correction_signature(text: str) -> list[str]:
        cleaned = text.lower().replace("__sparse_scan__", " ")
        tokens = re.findall(r"[a-z]{4,}", cleaned)
        shingles = {
            f"{tokens[index]} {tokens[index + 1]}"
            for index in range(len(tokens) - 1)
        }
        return sorted(shingles)

    def apply_correction_memory(
        self,
        texts: list[str],
        assignments: list[Assignment],
        rotations: list[int],
        blank_pages: set[int],
    ) -> tuple[list[Assignment], set[int]]:
        if not self.correction_memory:
            return assignments, set()

        updated = list(assignments)
        applied: set[int] = set()
        for index, text in enumerate(texts):
            if index in blank_pages:
                continue
            current = set(self.correction_signature(text))
            if len(current) < 12:
                continue
            best_entry = None
            best_score = 0.0
            for entry in self.correction_memory:
                remembered = set(entry.get("signature", []))
                overlap = len(current & remembered)
                if overlap < 12:
                    continue
                score = overlap / max(len(current | remembered), 1)
                if score > best_score:
                    best_score = score
                    best_entry = entry
            if best_entry is None or best_score < 0.82:
                continue
            document = safe_filename(str(best_entry.get("document", "")))
            updated = [item for item in updated if item.page_index != index]
            updated.append(Assignment(index, document, rotations[index], None))
            if document == "Banking.pdf":
                updated.append(
                    Assignment(
                        index,
                        "Viventium Direct Deposit.pdf",
                        rotations[index],
                        None,
                    )
                )
            applied.add(index)
        return updated, applied

    @staticmethod
    def find_duplicate_pairs(
        texts: list[str],
        fingerprints: list[int],
        blank_pages: set[int],
    ) -> list[tuple[int, int]]:
        normalized = [
            re.sub(r"\s+", " ", text.replace("__SPARSE_SCAN__", "").strip().lower())
            for text in texts
        ]
        duplicates: list[tuple[int, int]] = []
        for left in range(len(texts)):
            if left in blank_pages or len(normalized[left]) < 40:
                continue
            for right in range(left + 1, len(texts)):
                if right in blank_pages:
                    continue
                distance = (fingerprints[left] ^ fingerprints[right]).bit_count()
                if distance > 40:
                    continue
                if normalized[left] == normalized[right]:
                    duplicates.append((left, right))
                    continue
                similarity = difflib.SequenceMatcher(
                    None,
                    normalized[left],
                    normalized[right],
                    autojunk=False,
                ).ratio()
                if similarity >= 0.92:
                    duplicates.append((left, right))
        return duplicates

    def calculate_low_confidence_pages(
        self,
        texts: list[str],
        assignments: list[Assignment],
    ) -> set[int]:
        assigned = {item.page_index for item in assignments}
        return {
            index
            for index, text in enumerate(texts)
            if index in assigned
            and (
                "__SPARSE_SCAN__" in text
                or self.analyzer.orientation_score(text) < 45
            )
        }

    def bind_shortcuts(self):
        self.root.bind("<Control-o>", lambda _event: self.open_packet())
        self.root.bind("<Control-r>", lambda _event: self.start_analysis())
        self.root.bind("<Control-e>", lambda _event: self.export_pdfs())
        self.root.bind("<Control-Return>", lambda _event: self.assign_to_document())

    def build_ui(self):
        """Windows-style utility layout.

        Left: compact page list. Center: large preview. Right: controls/output/status.
        This keeps the PDF preview as the main working area instead of pushing it
        down with assignment/output panels.
        """
        self.root.grid_columnconfigure(0, weight=1)
        self.root.grid_rowconfigure(1, weight=1)

        # Light CareCo header, closer to a professional Windows installer/wizard
        self.header = ctk.CTkFrame(self.root, fg_color=HEADER_BG, corner_radius=0, height=82)
        self.header.grid(row=0, column=0, sticky="ew")
        self.header.grid_propagate(False)
        self.header.grid_columnconfigure(1, weight=1)
        self.header.grid_columnconfigure(2, weight=0)
        self.header.grid_columnconfigure(3, weight=0)

        self.logo_frame = ctk.CTkFrame(self.header, fg_color="transparent", corner_radius=0, width=188, height=72)
        self.logo_frame.grid(row=0, column=0, padx=(22, 18), pady=5, sticky="w")
        self.logo_frame.grid_propagate(False)
        self.logo_label = ctk.CTkLabel(
            self.logo_frame,
            text="CareCo\nHomeCare",
            text_color=CARD_NAVY,
            font=("Segoe UI", 15, "bold"),
        )
        logo_path = APP_DIR / "careco-logo.png"
        if logo_path.exists():
            try:
                img = Image.open(logo_path)
                # Preserve the uploaded logo's aspect ratio. The logo is wide,
                # and must also fit inside the fixed-height header.
                target_w = min(172, max(1, int(60 * img.width / img.height)))
                target_h = max(1, int(target_w * img.height / img.width))
                self.logo_img = ctk.CTkImage(light_image=img, dark_image=img, size=(target_w, target_h))
                self.logo_label.configure(text="", image=self.logo_img)
            except Exception:
                pass
        self.logo_label.pack(expand=True)

        title_block = ctk.CTkFrame(self.header, fg_color="transparent")
        title_block.grid(row=0, column=1, sticky="w")
        ctk.CTkLabel(
            title_block,
            text="Onboarding Packet Processor",
            text_color=CARD_NAVY,
            font=("Segoe UI", 21, "bold"),
        ).pack(anchor="w")
        ctk.CTkLabel(
            title_block,
            text="OCR + document classification + review before export",
            text_color="#1D4E89",
            font=("Segoe UI", 13),
        ).pack(anchor="w")

        # Status/progress lives in the header to free the right pane for Output PDFs.
        header_status = ctk.CTkFrame(self.header, fg_color="transparent")
        header_status.grid(row=0, column=2, padx=(12, 14), pady=10, sticky="e")
        header_status.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            header_status,
            textvariable=self.status_var,
            text_color="#1D4E89",
            font=("Segoe UI", 11),
            wraplength=360,
            anchor="e",
            justify="right",
        ).grid(row=0, column=0, columnspan=2, sticky="e", pady=(0, 4))
        self.progress = ctk.CTkProgressBar(
            header_status,
            width=300,
            height=8,
            fg_color="#DDEBF5",
            progress_color=CARECO_BLUE,
            corner_radius=4,
        )
        self.progress.grid(row=1, column=0, sticky="ew")
        self.progress.set(0)
        ctk.CTkLabel(
            header_status,
            textvariable=self.progress_label_var,
            text_color=CARD_NAVY,
            font=("Segoe UI", 11, "bold"),
            width=42,
        ).grid(row=1, column=1, padx=(8, 0), sticky="e")

        toolbar = ctk.CTkFrame(self.header, fg_color="transparent")
        toolbar.grid(row=0, column=3, padx=(0, 22), pady=18, sticky="e")
        self.open_button = ctk.CTkButton(
            toolbar,
            text="Open Packet",
            command=self.open_packet,
            fg_color=CARECO_BLUE,
            hover_color=SUCCESS_GREEN,
            text_color="white",
            corner_radius=5,
            height=36,
            width=118,
            font=("Segoe UI", 12, "bold"),
        )
        self.open_button.pack(side="left", padx=(0, 8))
        self.analyze_button = ctk.CTkButton(
            toolbar,
            text="Analyze Again",
            command=self.start_analysis,
            state="disabled",
            fg_color="#F8FAFC",
            hover_color=SUCCESS_GREEN,
            text_color=MUTED,
            border_width=1,
            border_color="#B8C7D8",
            corner_radius=5,
            height=36,
            width=122,
            font=("Segoe UI", 12, "bold"),
        )
        self.analyze_button.pack(side="left", padx=(0, 8))
        self.export_button = ctk.CTkButton(
            toolbar,
            text="Export PDFs",
            command=self.export_pdfs,
            state="disabled",
            fg_color="#F8FAFC",
            hover_color=SUCCESS_GREEN,
            text_color=MUTED,
            border_width=1,
            border_color="#B8C7D8",
            corner_radius=5,
            height=36,
            width=112,
            font=("Segoe UI", 12, "bold"),
        )
        self.export_button.pack(side="left")
        self.review_button = ctk.CTkButton(
            toolbar,
            text="Review Packet",
            command=self.show_packet_review,
            state="disabled",
            fg_color="#F8FAFC",
            hover_color=SUCCESS_GREEN,
            text_color=MUTED,
            border_width=1,
            border_color="#B8C7D8",
            corner_radius=5,
            height=36,
            width=112,
            font=("Segoe UI", 12, "bold"),
        )
        self.review_button.pack(side="left", padx=(8, 0))

        # Main three-column layout. The center preview gets the extra space.
        main = ctk.CTkFrame(self.root, fg_color=APP_BG, corner_radius=0)
        main.grid(row=1, column=0, sticky="nsew", padx=14, pady=12)
        main.grid_columnconfigure(0, weight=0, minsize=252)
        main.grid_columnconfigure(1, weight=1)
        main.grid_columnconfigure(2, weight=0, minsize=340)
        main.grid_rowconfigure(0, weight=1)

        # Compact page list panel
        self.left_card = self.card(main)
        self.left_card.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        self.left_card.configure(width=252)
        self.left_card.grid_propagate(False)
        self.left_card.grid_rowconfigure(1, weight=1)
        self.left_card.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            self.left_card,
            text="Packet Pages",
            text_color=TEXT,
            font=("Segoe UI", 15, "bold"),
        ).grid(row=0, column=0, sticky="w", padx=10, pady=(9, 5))
        self.pages_scroll = ctk.CTkScrollableFrame(
            self.left_card,
            fg_color=CARD_BG,
            scrollbar_button_color="#CBD5E1",
            scrollbar_button_hover_color="#94A3B8",
        )
        self.pages_scroll.grid(row=1, column=0, sticky="nsew", padx=6, pady=(0, 6))

        # Large center preview. No assignment/output panels below it.
        self.preview_card = self.card(main)
        self.preview_card.grid(row=0, column=1, sticky="nsew", padx=(0, 10))
        self.preview_card.grid_columnconfigure(0, weight=1)
        self.preview_card.grid_columnconfigure(1, weight=0)
        self.preview_card.grid_rowconfigure(1, weight=1)
        top_preview = ctk.CTkFrame(self.preview_card, fg_color="transparent")
        top_preview.grid(row=0, column=0, sticky="ew", padx=12, pady=(9, 7))
        top_preview.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            top_preview,
            text="Page Preview",
            text_color=TEXT,
            font=("Segoe UI", 15, "bold"),
        ).grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(
            top_preview,
            textvariable=self.summary_var,
            text_color=MUTED,
            font=("Segoe UI", 11),
        ).grid(row=0, column=1, sticky="e", padx=(0, 10))
        preview_nav = ctk.CTkFrame(top_preview, fg_color="transparent")
        preview_nav.grid(row=0, column=2, sticky="e")
        self.preview_prev_button = ctk.CTkButton(
            preview_nav,
            text="‹",
            width=32,
            height=24,
            command=self.preview_previous_page,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color="#CBD5E1",
            text_color=CARD_NAVY,
            corner_radius=4,
            font=("Segoe UI", 14, "bold"),
        )
        self.preview_prev_button.pack(side="left", padx=(0, 4))
        ctk.CTkLabel(
            preview_nav,
            textvariable=self.preview_nav_var,
            text_color=MUTED,
            font=("Segoe UI", 10),
            width=92,
        ).pack(side="left")
        self.preview_next_button = ctk.CTkButton(
            preview_nav,
            text="›",
            width=32,
            height=24,
            command=self.preview_next_page,
            fg_color="#FFFFFF",
            hover_color="#EEF6FF",
            border_width=1,
            border_color="#CBD5E1",
            text_color=CARD_NAVY,
            corner_radius=4,
            font=("Segoe UI", 14, "bold"),
        )
        self.preview_next_button.pack(side="left", padx=(4, 0))
        self.preview_canvas = tk.Canvas(
            self.preview_card,
            background="#EAF2F8",
            highlightthickness=0,
            bd=0,
        )
        self.preview_canvas.grid(row=1, column=0, sticky="nsew", padx=(12, 0), pady=(0, 12))
        self.preview_scrollbar = ctk.CTkScrollbar(
            self.preview_card,
            orientation="vertical",
            command=self.preview_canvas.yview,
            button_color="#CBD5E1",
            button_hover_color="#94A3B8",
            width=12,
        )
        self.preview_scrollbar.grid(row=1, column=1, sticky="ns", padx=(6, 12), pady=(0, 12))
        self.preview_canvas.configure(yscrollcommand=self.preview_scrollbar.set)
        self.preview_canvas.bind("<Configure>", self.on_preview_resize)
        self.preview_canvas.bind("<MouseWheel>", self.on_preview_mousewheel)
        self.preview_canvas.bind("<Button-4>", self.on_preview_mousewheel)
        self.preview_canvas.bind("<Button-5>", self.on_preview_mousewheel)
        self.root.bind("<Prior>", lambda _event: self.preview_canvas.yview_scroll(-1, "pages"))
        self.root.bind("<Next>", lambda _event: self.preview_canvas.yview_scroll(1, "pages"))
        self.root.bind("<Left>", lambda _event: self.preview_previous_page())
        self.root.bind("<Right>", lambda _event: self.preview_next_page())

        # Right-side task pane, like a Windows setup/utility sidebar.
        right_panel = ctk.CTkFrame(main, fg_color=APP_BG, corner_radius=0)
        right_panel.grid(row=0, column=2, sticky="nsew")
        right_panel.grid_columnconfigure(0, weight=1)
        right_panel.grid_rowconfigure(1, weight=1)

        self.action_card = self.card(right_panel)
        self.action_card.grid(row=0, column=0, sticky="ew")
        self.action_card.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            self.action_card,
            text="Assign Selected Pages",
            text_color=TEXT,
            font=("Segoe UI", 15, "bold"),
        ).grid(row=0, column=0, sticky="w", padx=12, pady=(10, 6))
        ctk.CTkLabel(
            self.action_card,
            text="Document filename",
            text_color=MUTED,
            font=("Segoe UI", 11, "bold"),
        ).grid(row=1, column=0, sticky="w", padx=12, pady=(0, 4))
        self.document_combo = ctk.CTkComboBox(
            self.action_card,
            variable=self.document_var,
            values=self.rules["document_types"],
            height=34,
            fg_color="white",
            border_color="#CFE0EA",
            button_color=CARECO_BLUE,
            button_hover_color="#176FCC",
            dropdown_fg_color="white",
            corner_radius=5,
        )
        self.document_combo.grid(row=2, column=0, sticky="ew", padx=12, pady=(0, 8))

        button_grid = ctk.CTkFrame(self.action_card, fg_color="transparent")
        button_grid.grid(row=3, column=0, sticky="ew", padx=12, pady=(0, 12))
        button_grid.grid_columnconfigure((0, 1), weight=1)
        ctk.CTkButton(button_grid, text="Assign to Document", command=self.assign_to_document, fg_color=CARECO_BLUE, hover_color="#176FCC", corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        ctk.CTkButton(button_grid, text="Mark Unsorted", command=self.remove_assignments, fg_color="#FFFFFF", hover_color="#FBEAEA", border_color="#8A2020", border_width=1, text_color=WARNING, corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=1, column=0, sticky="ew", padx=(0, 5))
        ctk.CTkButton(button_grid, text="Rename Output", command=self.rename_document, fg_color="#FFFFFF", hover_color="#F8FAFC", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=1, column=1, sticky="ew", padx=(5, 0))
        ctk.CTkButton(button_grid, text="Remember Correction", command=self.remember_correction, fg_color="#FFFFFF", hover_color="#EEF6FF", border_color=CARECO_BLUE, border_width=1, text_color=CARECO_BLUE, corner_radius=5, height=32, font=("Segoe UI", 12, "bold")).grid(row=2, column=0, columnspan=2, sticky="ew", pady=(6, 0))

        self.output_card = self.card(right_panel)
        self.output_card.grid(row=1, column=0, sticky="nsew", pady=(10, 0))
        self.output_card.grid_columnconfigure(0, weight=1)
        self.output_card.grid_rowconfigure(1, weight=1)
        out_header = ctk.CTkFrame(self.output_card, fg_color="transparent")
        out_header.grid(row=0, column=0, sticky="ew", padx=12, pady=(10, 6))
        out_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(out_header, text="Output PDFs", text_color=TEXT, font=("Segoe UI", 15, "bold")).grid(row=0, column=0, sticky="w")
        order_buttons = ctk.CTkFrame(out_header, fg_color="transparent")
        order_buttons.grid(row=0, column=1, sticky="e")
        ctk.CTkButton(order_buttons, text="Up", command=lambda: self.move_document(-1), width=48, height=28, fg_color="#FFFFFF", hover_color="#F8FAFC", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5).pack(side="left", padx=(0, 5))
        ctk.CTkButton(order_buttons, text="Down", command=lambda: self.move_document(1), width=64, height=28, fg_color="#FFFFFF", hover_color="#F8FAFC", border_color="#CBD5E1", border_width=1, text_color=TEXT, corner_radius=5).pack(side="left")
        self.output_scroll = ctk.CTkScrollableFrame(
            self.output_card,
            fg_color=CARD_BG,
            scrollbar_button_color="#CBD5E1",
            scrollbar_button_hover_color="#94A3B8",
        )
        self.output_scroll.grid(row=1, column=0, sticky="nsew", padx=8, pady=(0, 8))


    def card(self, parent):
        return ctk.CTkFrame(parent, fg_color=CARD_BG, corner_radius=10, border_width=1, border_color=BORDER)

    def open_packet(self):
        selected = filedialog.askopenfilename(title="Choose an onboarding packet", filetypes=[("PDF files", "*.pdf"), ("All files", "*.*")])
        if not selected:
            return
        self.pdf_path = Path(selected)
        self.export_packet_name = None
        try:
            self.reader = PdfReader(str(self.pdf_path))
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Could not open that PDF:\n\n{exc}")
            return
        self.analyze_button.configure(state="normal", text_color=TEXT)
        self.status_var.set(f"Loaded {self.pdf_path.name} ({len(self.reader.pages)} pages).")
        self.start_analysis()

    def start_analysis(self):
        if not self.pdf_path or self.analyzing:
            return
        self.analyzing = True
        self.set_busy(True)
        self.progress_var.set(0)
        self.progress.set(0)
        self.progress_label_var.set("0%")
        self.assignments.clear(); self.page_images.clear(); self.ocr_texts.clear(); self.page_rotations.clear(); self.blank_pages.clear(); self.page_fingerprints.clear()
        self.duplicate_pairs.clear(); self.low_confidence_pages.clear(); self.memory_applied_pages.clear()
        self.selected_pages.clear(); self.selected_document = None; self.preview_page_position = 0
        self.clear_preview_cache()
        self.summary_var.set("Analyzing packet...")
        self.show_analyzing_placeholders()
        self.refresh_output_cards()
        self.refresh_preview()
        if self.work_dir and self.work_dir.exists():
            shutil.rmtree(self.work_dir, ignore_errors=True)
        self.work_dir = Path(tempfile.mkdtemp(prefix="onboarding_packet_"))

        def worker():
            try:
                def progress(value, text, page_index=None):
                    self.worker_queue.put(("progress", value, text, page_index))
                result = self.analyzer.analyze(self.pdf_path, self.work_dir, progress)
                (
                    page_images,
                    ocr_texts,
                    assignments,
                    rotations,
                    blank_pages,
                    fingerprints,
                ) = result
                assignments, memory_pages = self.apply_correction_memory(
                    ocr_texts,
                    assignments,
                    rotations,
                    blank_pages,
                )
                duplicates = self.find_duplicate_pairs(
                    ocr_texts,
                    fingerprints,
                    blank_pages,
                )
                low_confidence = self.calculate_low_confidence_pages(
                    ocr_texts,
                    assignments,
                )
                self.worker_queue.put(
                    (
                        "complete",
                        (
                            page_images,
                            ocr_texts,
                            assignments,
                            rotations,
                            blank_pages,
                            fingerprints,
                            duplicates,
                            low_confidence,
                            memory_pages,
                        ),
                    )
                )
            except Exception:
                self.worker_queue.put(("error", traceback.format_exc()))
        threading.Thread(target=worker, daemon=True).start()

    def show_analyzing_placeholders(self):
        self.clear_frame(self.pages_scroll)
        self.page_status_widgets.clear()
        if not self.reader:
            return
        for index in range(len(self.reader.pages)):
            self.add_page_card(index, "Analyzing...", "reading")

    def poll_worker_queue(self):
        poll_delay = 50 if self.analyzing else 120
        try:
            while True:
                message = self.worker_queue.get_nowait()
                kind = message[0]
                if kind == "progress":
                    value = message[1]
                    self.progress_var.set(value)
                    self.progress.set(max(0, min(1, value / 100)))
                    self.progress_label_var.set(f"{int(value)}%")
                    self.status_var.set(message[2])
                    # Match the original app behavior: each page changes from
                    # "Analyzing..." to "Read" as soon as that individual OCR
                    # worker finishes. Do not rebuild the full page list here;
                    # only update the one card that completed so the UI stays responsive.
                    if len(message) > 3 and message[3] is not None:
                        self.set_page_card_status(int(message[3]), "Read", "read")
                elif kind == "complete":
                    (
                        self.page_images,
                        self.ocr_texts,
                        self.assignments,
                        self.page_rotations,
                        self.blank_pages,
                        self.page_fingerprints,
                        self.duplicate_pairs,
                        self.low_confidence_pages,
                        self.memory_applied_pages,
                    ) = message[1]
                    self.document_order = []
                    self.sync_document_order()
                    self.analyzing = False
                    self.set_busy(False)
                    self.progress_var.set(100); self.progress.set(1); self.progress_label_var.set("100%")
                    grouped_count = len(self.grouped_assignments())
                    self.status_var.set(f"Found {grouped_count} output PDFs. Review before exporting.")
                    self.update_summary()
                    self.refresh_all_views()
                    if self.page_images:
                        self.selected_pages = {0}
                        self.refresh_page_cards()
                        self.on_page_selected()
                elif kind == "error":
                    self.analyzing = False
                    self.set_busy(False)
                    self.progress_var.set(0); self.progress.set(0); self.progress_label_var.set("0%")
                    self.status_var.set("Analysis failed.")
                    self.summary_var.set("Analysis failed")
                    messagebox.showerror(APP_TITLE, "The packet could not be analyzed.\n\n" + message[1])
        except queue.Empty:
            pass
        self.root.after(poll_delay, self.poll_worker_queue)

    def set_busy(self, busy: bool):
        self.open_button.configure(state="disabled" if busy else "normal")
        self.analyze_button.configure(state="disabled" if busy or not self.pdf_path else "normal")
        can_export = (not busy and bool(self.assignments))
        self.export_button.configure(
            state="normal" if can_export else "disabled",
            fg_color="#F8FAFC" if can_export else "#E9EEF5",
            text_color=TEXT if can_export else MUTED,
        )
        self.review_button.configure(
            state="normal" if can_export else "disabled",
            text_color=TEXT if can_export else MUTED,
        )

    def update_summary(self):
        if not self.page_images:
            self.summary_var.set("No packet loaded")
            return
        page_count = len(self.page_images)
        assigned_pages = {a.page_index for a in self.assignments if a.page_index not in self.blank_pages}
        unsorted_count = page_count - len(self.blank_pages) - len(assigned_pages)
        pdf_count = len(self.grouped_assignments())
        self.summary_var.set(f"{pdf_count} PDFs · {len(assigned_pages)} sorted · {unsorted_count} unsorted · {len(self.blank_pages)} blank")

    def clear_preview_cache(self):
        self.preview_cache.clear(); self.preview_cache_size = (0, 0); self.preview_photo = None; self.preview_image_refs = []; self.preview_page_offsets = []

    def refresh_all_views(self):
        self.refresh_page_cards(); self.refresh_output_cards(); self.refresh_preview(); self.update_summary(); self.set_busy(False)

    def clear_frame(self, frame):
        for child in frame.winfo_children():
            child.destroy()

    def page_label_for(self, index):
        docs = [a.document for a in self.assignments if a.page_index == index]
        if index in self.blank_pages:
            return "BLANK PAGE", "blank"
        if docs:
            return "; ".join(dict.fromkeys(docs)), "sorted"
        return "UNSORTED", "unsorted"

    def refresh_page_cards(self):
        self.clear_frame(self.pages_scroll)
        self.page_status_widgets.clear()
        for index in range(len(self.page_images)):
            label, state = self.page_label_for(index)
            self.add_page_card(index, label, state)

    def page_state_style(self, state):
        color_map = {
            "sorted": SUCCESS_GREEN,
            "unsorted": "#8A2020",
            "blank": "#CBD5E1",
            "reading": BRIGHT_BLUE,
            "read": CARECO_BLUE,
        }
        text_map = {"sorted": "✓", "unsorted": "!", "blank": "–", "reading": "…", "read": "✓"}
        text_color = NAVY if state == "sorted" else "white"
        label_color = WARNING if state == "unsorted" else MUTED
        return color_map.get(state, BRIGHT_BLUE), text_map.get(state, ""), text_color, label_color

    def compact_page_parts(self, index, label, state):
        # Windows setup/file-list style: dense, readable, no decorative graphics.
        status_map = {
            "sorted": "READ",
            "unsorted": "UNSORTED",
            "blank": "BLANK",
            "reading": "READING",
            "read": "READ",
        }
        status = status_map.get(state, "")
        short_label = label.replace(".pdf", "")
        if len(short_label) > 24:
            short_label = short_label[:21] + "..."
        return status, f"Page {index + 1:<3} {short_label}"

    def add_page_card(self, index, label, state):
        selected = index in self.selected_pages
        _badge_color, _badge_text, _badge_text_color, label_color = self.page_state_style(state)

        bg = "#EAF2FF" if selected else "#FFFFFF"
        row = ctk.CTkFrame(
            self.pages_scroll,
            fg_color=bg,
            corner_radius=0,
            border_width=0,
            height=21,
        )
        row.pack(fill="x", padx=0, pady=0)
        row.pack_propagate(False)

        status_text, detail_text = self.compact_page_parts(index, label, state)
        status_line = ctk.CTkLabel(
            row,
            text=status_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
            font=("Segoe UI", 10, "bold"),
            width=68,
            anchor="w",
        )
        status_line.pack(side="left", padx=(4, 0), pady=0)
        detail_line = ctk.CTkLabel(
            row,
            text=detail_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
            font=("Segoe UI", 10),
            anchor="w",
        )
        detail_line.pack(side="left", fill="x", expand=True, pady=0)

        self.page_status_widgets[index] = {
            "card": row,
            "status": status_line,
            "detail": detail_line,
        }
        status_line.bind("<Button-1>", lambda e, i=index: self.toggle_page_selection(i, e))
        detail_line.bind("<Button-1>", lambda e, i=index: self.toggle_page_selection(i, e))
        row.bind("<Button-1>", lambda e, i=index: self.toggle_page_selection(i, e))

    def set_page_card_status(self, index, label, state):
        widgets = self.page_status_widgets.get(index)
        if not widgets:
            return
        _badge_color, _badge_text, _badge_text_color, label_color = self.page_state_style(state)
        status_text, detail_text = self.compact_page_parts(index, label, state)
        widgets["status"].configure(
            text=status_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
        )
        widgets["detail"].configure(
            text=detail_text,
            text_color=label_color if state in ("unsorted", "blank") else TEXT,
        )
        try:
            self.pages_scroll.update_idletasks()
        except Exception:
            pass

    def toggle_page_selection(self, index, event=None):
        ctrl = bool(event and (event.state & 0x0004))
        shift = bool(event and (event.state & 0x0001))
        if shift and self.selected_pages:
            start = min(self.selected_pages)
            self.selected_pages = set(range(min(start,index), max(start,index)+1))
        elif ctrl:
            if index in self.selected_pages:
                self.selected_pages.remove(index)
            else:
                self.selected_pages.add(index)
        else:
            self.selected_pages = {index}
        self.preview_page_position = 0
        self.on_page_selected()
        self.refresh_page_cards()

    def grouped_assignments(self) -> dict[str, list[Assignment]]:
        grouped: dict[str, list[Assignment]] = {}
        for assignment in self.assignments:
            if assignment.page_index in self.blank_pages:
                continue
            grouped.setdefault(assignment.document, []).append(assignment)
        for values in grouped.values():
            values.sort(key=lambda item: (item.sequence is None, item.sequence if item.sequence is not None else item.page_index, item.page_index))
        self.sync_document_order(grouped)
        return {document: grouped[document] for document in self.document_order if document in grouped}

    def sync_document_order(self, grouped: dict[str, list[Assignment]] | None = None):
        if grouped is None:
            grouped = {}
            for assignment in self.assignments:
                grouped.setdefault(assignment.document, []).append(assignment)
        current_documents = set(grouped)
        self.document_order = [document for document in self.document_order if document in current_documents]
        preferred = [document for document in self.rules["document_types"] if document in current_documents]
        extras = sorted(current_documents.difference(preferred).difference(self.document_order), key=str.lower)
        for document in preferred + extras:
            if document not in self.document_order:
                self.document_order.append(document)

    def refresh_output_cards(self):
        self.clear_frame(self.output_scroll)
        self.output_row_widgets = {}
        grouped = self.grouped_assignments()
        if not grouped:
            ctk.CTkLabel(
                self.output_scroll,
                text="No output PDFs yet.",
                text_color=MUTED,
                font=("Segoe UI", 11),
            ).pack(anchor="w", padx=8, pady=6)
            return

        for number, (document, assignments) in enumerate(grouped.items(), start=1):
            selected = document == self.selected_document
            bg = "#EAF2FF" if selected else "#FFFFFF"
            border = CARECO_BLUE if selected else BORDER
            frame = ctk.CTkFrame(
                self.output_scroll,
                fg_color=bg,
                corner_radius=5,
                border_width=1,
                border_color=border,
            )
            # Keep the bordered/padded look, but make each row much tighter than
            # the earlier large card version.
            frame.pack(fill="x", padx=3, pady=1)
            frame.grid_columnconfigure(0, weight=1)

            # Compact bordered output row. Use explicit short label heights
            # because CTkLabel defaults to a taller control that creates a
            # large visual gap between the PDF name and page list.
            ctk.CTkLabel(
                frame,
                text=f"{number}.  {document}",
                text_color=CARECO_BLUE,
                font=("Segoe UI", 10, "bold" if selected else "normal"),
                anchor="w",
                height=16,
            ).grid(row=0, column=0, sticky="ew", padx=(8, 6), pady=(2, 0))

            pages = ", ".join(str(a.page_number) for a in assignments)
            page_word = "Page" if len(assignments) == 1 else "Pages"
            ctk.CTkLabel(
                frame,
                text=f"{len(assignments)} {page_word}: {pages}",
                text_color=MUTED,
                font=("Segoe UI", 9),
                anchor="w",
                height=15,
            ).grid(row=1, column=0, sticky="ew", padx=(8, 6), pady=(0, 2))

            self.output_row_widgets[document] = frame
            self.bind_output_row(frame, document)
            for child in frame.winfo_children():
                self.bind_output_row(child, document)

    def bind_output_row(self, widget, document: str):
        # Click to select. Reordering is handled by the Move Up / Move Down
        # buttons because drag reordering was unreliable in this scroll frame.
        widget.bind("<Button-1>", lambda e, d=document: self.on_output_selected(d))

    def on_output_drag_start(self, event, document: str):
        self.dragging_document = document
        self.on_output_selected(document)

    def on_output_drag_motion(self, event, document: str):
        # Keep the selected row visible while dragging. Reordering happens on release.
        self.dragging_document = document

    def on_output_drag_release(self, event, document: str):
        dragging = self.dragging_document or document
        self.dragging_document = None
        if dragging not in self.document_order:
            return

        target = self.output_document_at_pointer()
        if not target or target == dragging or target not in self.document_order:
            return

        old_index = self.document_order.index(dragging)
        new_index = self.document_order.index(target)
        self.document_order.pop(old_index)
        if old_index < new_index:
            new_index -= 1
        self.document_order.insert(new_index, dragging)
        self.selected_document = dragging
        self.refresh_output_cards()

    def output_document_at_pointer(self) -> str | None:
        pointer_y = self.root.winfo_pointery()
        closest_doc = None
        closest_distance = 10**9
        for document, frame in self.output_row_widgets.items():
            try:
                top = frame.winfo_rooty()
                bottom = top + frame.winfo_height()
                mid = (top + bottom) / 2
            except Exception:
                continue
            if top <= pointer_y <= bottom:
                return document
            distance = abs(pointer_y - mid)
            if distance < closest_distance:
                closest_distance = distance
                closest_doc = document
        return closest_doc

    def selected_page_indices(self) -> list[int]:
        return sorted(self.selected_pages)

    def selected_nonblank_page_indices(self) -> list[int]:
        selected = self.selected_page_indices()
        nonblank = [index for index in selected if index not in self.blank_pages]
        if selected and not nonblank:
            messagebox.showinfo(APP_TITLE, "Blank pages are always removed and cannot be assigned to a PDF.")
        return nonblank

    def on_page_selected(self, _event=None):
        selected = self.selected_page_indices()
        if not selected:
            return
        self.selected_document = None
        first = selected[0]
        matches = [a for a in self.assignments if a.page_index == first]
        if matches:
            self.document_var.set(matches[0].document)
        elif first in self.blank_pages:
            self.document_var.set("BLANK PAGE")
        else:
            self.document_var.set("UNSORTED")
        self.refresh_output_cards()
        self.refresh_preview(reset_scroll=True)

    def on_output_selected(self, document):
        self.selected_document = document
        self.document_var.set(document)
        self.selected_pages = {a.page_index for a in self.assignments if a.document == document}
        self.preview_page_position = 0
        self.refresh_output_cards(); self.refresh_page_cards(); self.refresh_preview(reset_scroll=True)

    def move_document(self, direction: int):
        document = self.selected_document
        if not document:
            messagebox.showwarning(APP_TITLE, "Select an output PDF to move.")
            return
        self.sync_document_order()
        if document not in self.document_order:
            return
        old_index = self.document_order.index(document)
        new_index = old_index + direction
        if new_index < 0 or new_index >= len(self.document_order):
            return
        self.document_order[old_index], self.document_order[new_index] = self.document_order[new_index], self.document_order[old_index]
        self.refresh_output_cards()

    def on_preview_resize(self, _event=None):
        canvas_width = max(self.preview_canvas.winfo_width() - 24, 200)
        canvas_height = max(self.preview_canvas.winfo_height() - 24, 200)
        if (canvas_width, canvas_height) != self.preview_cache_size:
            self.clear_preview_cache(); self.preview_cache_size = (canvas_width, canvas_height)
        self.refresh_preview()

    def on_preview_mousewheel(self, event):
        if not self.preview_pages():
            return
        if getattr(event, "num", None) == 4:
            self.preview_canvas.yview_scroll(-3, "units")
        elif getattr(event, "num", None) == 5:
            self.preview_canvas.yview_scroll(3, "units")
        else:
            delta = getattr(event, "delta", 0)
            self.preview_canvas.yview_scroll(int(-1 * (delta / 120)), "units")

    def preview_pages(self) -> list[int]:
        """Pages currently available in the preview.

        When an Output PDF is selected, this returns every source page that belongs
        to that output document in the same order it will export. That lets the
        preview step through all pages in a multi-page output PDF instead of only
        showing the first selected page.
        """
        if self.selected_document:
            grouped = self.grouped_assignments()
            if self.selected_document in grouped:
                return [assignment.page_index for assignment in grouped[self.selected_document]]
        return self.selected_page_indices()

    def update_preview_nav(self, pages: list[int]):
        if not pages:
            self.preview_nav_var.set("")
            try:
                self.preview_prev_button.configure(state="disabled")
                self.preview_next_button.configure(state="disabled")
            except Exception:
                pass
            return
        self.preview_page_position = max(0, min(self.preview_page_position, len(pages) - 1))
        if len(pages) == 1:
            self.preview_nav_var.set(f"Page {pages[0] + 1}")
        else:
            self.preview_nav_var.set(
                f"{self.preview_page_position + 1} of {len(pages)}  ·  Page {pages[self.preview_page_position] + 1}"
            )
        try:
            self.preview_prev_button.configure(state="normal" if self.preview_page_position > 0 else "disabled")
            self.preview_next_button.configure(state="normal" if self.preview_page_position < len(pages) - 1 else "disabled")
        except Exception:
            pass

    def preview_previous_page(self):
        pages = self.preview_pages()
        if not pages:
            return
        self.preview_page_position = max(0, self.preview_page_position - 1)
        self.refresh_preview(reset_scroll=True)

    def preview_next_page(self):
        pages = self.preview_pages()
        if not pages:
            return
        self.preview_page_position = min(len(pages) - 1, self.preview_page_position + 1)
        self.refresh_preview(reset_scroll=True)

    def refresh_preview(self, reset_scroll: bool = False):
        pages = self.preview_pages()
        self.preview_canvas.delete("all")
        self.preview_image_refs = []
        self.preview_page_offsets = []
        if not pages or not self.page_images:
            self.preview_nav_var.set("")
            try:
                self.preview_prev_button.configure(state="disabled")
                self.preview_next_button.configure(state="disabled")
            except Exception:
                pass
            self.preview_canvas.configure(scrollregion=(0, 0, self.preview_canvas.winfo_width(), self.preview_canvas.winfo_height()))
            self.preview_canvas.create_text(max(self.preview_canvas.winfo_width() // 2, 120), max(self.preview_canvas.winfo_height() // 2, 120), text="Select a page to preview it.", fill=MUTED, font=("Segoe UI", 14))
            return

        # Show every page in the selected Output PDF stacked vertically, like a
        # PDF viewer. The left/right buttons still jump between pages, but the
        # mouse wheel can now scroll naturally from page 1 through the last page.
        self.update_preview_nav(pages)
        canvas_width = max(self.preview_canvas.winfo_width() - 34, 200)
        canvas_height = max(self.preview_canvas.winfo_height() - 24, 200)
        y = 12
        gap = 18
        max_image_width = 0

        for position, page_index in enumerate(pages):
            cache_key = (page_index, canvas_width)
            if cache_key not in self.preview_cache:
                image = Image.open(self.page_images[page_index]).convert("RGB")
                scale = canvas_width / max(image.width, 1)
                new_width = max(1, int(image.width * scale))
                new_height = max(1, int(image.height * scale))
                image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
                self.preview_cache[cache_key] = ImageTk.PhotoImage(image)

            photo = self.preview_cache[cache_key]
            self.preview_image_refs.append(photo)
            self.preview_page_offsets.append(y)

            image_width = photo.width()
            image_height = photo.height()
            max_image_width = max(max_image_width, image_width)
            x = max(self.preview_canvas.winfo_width() // 2, image_width // 2 + 10)

            if len(pages) > 1:
                self.preview_canvas.create_text(
                    14,
                    y,
                    text=f"Page {position + 1} of {len(pages)}  ·  Source page {page_index + 1}",
                    anchor="nw",
                    fill=MUTED,
                    font=("Segoe UI", 10, "bold"),
                )
                y += 22

            self.preview_canvas.create_image(x, y, image=photo, anchor="n")
            y += image_height + gap

        scroll_height = max(y, self.preview_canvas.winfo_height())
        self.preview_canvas.configure(
            scrollregion=(0, 0, max(self.preview_canvas.winfo_width(), max_image_width + 20), scroll_height)
        )

        if reset_scroll and self.preview_page_offsets:
            target_y = self.preview_page_offsets[self.preview_page_position]
            max_scroll = max(scroll_height - canvas_height, 1)
            self.preview_canvas.yview_moveto(max(0, min(target_y / max_scroll, 1)))

    def normalized_document_name(self) -> str | None:
        name = self.document_var.get().strip()
        if not name:
            messagebox.showwarning(APP_TITLE, "Choose or enter a document name first.")
            return None
        return safe_filename(name)

    def assign_to_document(self):
        pages = self.selected_nonblank_page_indices()
        document = self.normalized_document_name()
        if not pages or not document:
            return
        self.assignments = [item for item in self.assignments if item.page_index not in pages]
        for page in pages:
            self.assignments.append(Assignment(page, document, self.page_rotations[page], None))
            if document == "Banking.pdf":
                self.assignments.append(
                    Assignment(
                        page,
                        "Viventium Direct Deposit.pdf",
                        self.page_rotations[page],
                        None,
                    )
                )
        self.refresh_all_views()
        if document == "Banking.pdf":
            self.status_var.set(
                "Assigned to Banking and automatically included with Direct Deposit."
            )
        else:
            self.status_var.set("Assigned to document.")

    def remove_assignments(self):
        pages = self.selected_page_indices()
        if not pages:
            return
        self.assignments = [item for item in self.assignments if item.page_index not in pages]
        self.selected_document = None
        self.document_var.set("UNSORTED")
        self.refresh_all_views(); self.status_var.set("Selected pages marked as unsorted.")

    def rename_document(self):
        old_name = self.selected_document
        if not old_name:
            messagebox.showwarning(APP_TITLE, "Select an output PDF to rename.")
            return
        new_name = simpledialog.askstring(APP_TITLE, "New PDF filename:", initialvalue=old_name)
        if not new_name:
            return
        new_name = safe_filename(new_name)
        for assignment in self.assignments:
            if assignment.document == old_name:
                assignment.document = new_name
        if old_name in self.document_order:
            self.document_order[self.document_order.index(old_name)] = new_name
        self.selected_document = new_name
        self.refresh_all_views(); self.document_var.set(new_name)

    def remember_correction(self):
        pages = self.selected_nonblank_page_indices()
        document = self.normalized_document_name()
        if not pages or not document:
            return

        remembered = 0
        for page in pages:
            signature = self.correction_signature(self.ocr_texts[page])
            if len(signature) < 12:
                continue
            self.correction_memory = [
                entry
                for entry in self.correction_memory
                if entry.get("signature") != signature
            ]
            self.correction_memory.append(
                {"document": document, "signature": signature}
            )
            remembered += 1

        if not remembered:
            messagebox.showwarning(
                APP_TITLE,
                "The selected page does not contain enough readable text to "
                "remember safely.",
            )
            return
        if self.save_correction_memory():
            self.status_var.set(
                f"Remembered {remembered} correction"
                + ("" if remembered == 1 else "s")
                + " for future similar pages."
            )

    @staticmethod
    def format_page_list(pages, limit: int = 18) -> str:
        values = [str(page) for page in pages]
        if len(values) <= limit:
            return ", ".join(values) if values else "None"
        return ", ".join(values[:limit]) + f", and {len(values) - limit} more"

    def review_details(self) -> dict:
        grouped = self.grouped_assignments()
        found = set(grouped)
        expected = self.rules.get("expected_document_types", [])
        found_expected = [document for document in expected if document in found]
        missing = [document for document in expected if document not in found]
        assigned_by_page: dict[int, list[str]] = {}
        for assignment in self.assignments:
            if assignment.page_index in self.blank_pages:
                continue
            assigned_by_page.setdefault(assignment.page_index, []).append(
                assignment.document
            )
        unsorted = [
            index + 1
            for index in range(len(self.reader.pages) if self.reader else 0)
            if index not in self.blank_pages and index not in assigned_by_page
        ]
        multiple = {
            index + 1: list(dict.fromkeys(documents))
            for index, documents in assigned_by_page.items()
            if len(set(documents)) > 1
        }
        return {
            "grouped": grouped,
            "found_expected": found_expected,
            "missing": missing,
            "unsorted": unsorted,
            "multiple": multiple,
            "duplicates": [
                (left + 1, right + 1) for left, right in self.duplicate_pairs
            ],
            "low_confidence": sorted(
                page + 1 for page in self.low_confidence_pages
            ),
            "blank": sorted(page + 1 for page in self.blank_pages),
            "rotated": [
                index + 1
                for index, rotation in enumerate(self.page_rotations)
                if rotation
            ],
            "memory": sorted(page + 1 for page in self.memory_applied_pages),
        }

    def build_review_summary(self) -> str:
        details = self.review_details()
        found_names = list(details["grouped"])
        lines = [
            "EXPECTED DOCUMENT CHECKLIST",
            f"Found: {len(found_names)} output PDFs",
        ]
        if details["found_expected"]:
            lines.append("Found expected:")
            lines.extend(
                f"  - {name}" for name in details["found_expected"]
            )
        else:
            lines.append("Found expected: None")
        if details["missing"]:
            lines.append("Missing expected:")
            lines.extend(f"  - {name}" for name in details["missing"])
        else:
            lines.append("Missing expected: None")

        lines.extend(
            [
                "",
                "PAGE REVIEW",
                "Unsorted pages: "
                + self.format_page_list(details["unsorted"]),
                "Low-confidence pages: "
                + self.format_page_list(details["low_confidence"]),
                "Blank pages removed: "
                + self.format_page_list(details["blank"]),
                "Pages rotated upright: "
                + self.format_page_list(details["rotated"]),
                "Remembered corrections applied: "
                + self.format_page_list(details["memory"]),
            ]
        )
        if details["duplicates"]:
            duplicate_text = ", ".join(
                f"{left}/{right}" for left, right in details["duplicates"]
            )
            lines.append("Suspected duplicate page pairs: " + duplicate_text)
        else:
            lines.append("Suspected duplicate page pairs: None")
        if details["multiple"]:
            multiple_text = "; ".join(
                f"{page}: {', '.join(documents)}"
                for page, documents in details["multiple"].items()
            )
            lines.append("Pages used in multiple PDFs: " + multiple_text)
        else:
            lines.append("Pages used in multiple PDFs: None")
        return "\n".join(lines)

    def show_packet_review(self):
        if not self.reader:
            return
        messagebox.showinfo(APP_TITLE, self.build_review_summary())

    @staticmethod
    def suggest_packet_name(stem: str) -> str:
        raw = re.sub(r"\s+", " ", stem.strip())
        raw = re.sub(
            r"(?i)[ _-]+(?:scan|packet)?[ _-]*\d+$",
            "",
            raw,
        ).strip(" _-")
        underscore_parts = [part for part in raw.split("_") if part]
        if (
            "_" in raw
            and len(underscore_parts) == 2
            and all(part.isalpha() and part.isupper() for part in underscore_parts)
        ):
            raw = f"{underscore_parts[1]} {underscore_parts[0]}"
        else:
            raw = re.sub(r"[_-]+", " ", raw)
        return " ".join(
            word if word.isupper() and len(word) <= 4 else word.title()
            for word in raw.split()
        )

    def confirm_packet_name(self) -> str | None:
        if not self.pdf_path:
            return None
        original = safe_folder_name(self.pdf_path.stem)
        suggested = safe_folder_name(self.suggest_packet_name(self.pdf_path.stem))
        if self.export_packet_name:
            return self.export_packet_name
        if suggested == original:
            self.export_packet_name = original
            return original
        answer = messagebox.askyesnocancel(
            APP_TITLE,
            "Use this cleaned packet name for the output folder and PDF prefix?\n\n"
            f"{suggested}\n\n"
            f"Yes: use {suggested}\n"
            f"No: keep {original}",
        )
        if answer is None:
            return None
        self.export_packet_name = suggested if answer else original
        return self.export_packet_name

    def cleanup_work_files(self):
        self.clear_preview_cache()
        if self.work_dir and self.work_dir.exists():
            shutil.rmtree(self.work_dir, ignore_errors=True)
        self.work_dir = None
        self.page_images = []

    def export_pdfs(self):
        if not self.reader or not self.pdf_path or not self.assignments:
            return
        packet_name = self.confirm_packet_name()
        if not packet_name:
            return
        destination = self.pdf_path.parent / packet_name
        ordered_groups = list(self.grouped_assignments().items())
        target_names = [
            safe_filename(f"{packet_name} - {document}")
            for document, _assignments in ordered_groups
        ]
        target_names.append("Export Audit Log.txt")
        proceed = messagebox.askyesno(
            APP_TITLE,
            self.build_review_summary()
            + "\n\nContinue with export?",
        )
        if not proceed:
            return
        if destination.exists():
            existing_files = [
                path.name for path in destination.iterdir() if path.is_file()
            ]
            replacements = [
                name for name in target_names if name in existing_files
            ]
            preserved = [
                name
                for name in existing_files
                if name not in replacements
            ]
            message = (
                "The output folder already exists:\n\n"
                + str(destination)
                + "\n\nFiles that will be replaced:\n"
                + ("\n".join(f"  - {name}" for name in replacements) or "  None")
                + "\n\nOther existing files that will remain untouched:\n"
                + (
                    "\n".join(f"  - {name}" for name in preserved[:12])
                    or "  None"
                )
            )
            if len(preserved) > 12:
                message += f"\n  - and {len(preserved) - 12} more"
            message += "\n\nContinue?"
            proceed = messagebox.askyesno(APP_TITLE, message)
            if not proceed:
                return
        try:
            destination.mkdir(parents=True, exist_ok=True)
            written = []
            newest_time = time.time()
            for order_index, (document, assignments) in enumerate(ordered_groups):
                writer = PdfWriter()
                for assignment in assignments:
                    page = copy.deepcopy(self.reader.pages[assignment.page_index])
                    if assignment.rotation:
                        page.rotate(assignment.rotation)
                    writer.add_page(page)
                output_path = destination / safe_filename(f"{packet_name} - {document}")
                with output_path.open("wb") as handle:
                    writer.write(handle)
                modified_time = newest_time - (order_index * 60)
                os.utime(output_path, (modified_time, modified_time))
                written.append(output_path.name)
            # lightweight audit trail
            audit_path = destination / "Export Audit Log.txt"
            with audit_path.open("w", encoding="utf-8") as audit:
                audit.write(f"Packet: {self.pdf_path.name}\nExported: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n")
                for document, assignments in ordered_groups:
                    audit.write(f"{document}: pages {', '.join(str(a.page_number) for a in assignments)}\n")
                audit.write("\n" + self.build_review_summary() + "\n")
            audit_time = newest_time - (len(ordered_groups) * 60)
            os.utime(audit_path, (audit_time, audit_time))
        except Exception as exc:
            messagebox.showerror(APP_TITLE, f"Export failed:\n\n{exc}")
            return
        self.cleanup_work_files()
        self.refresh_preview()
        self.status_var.set(f"Exported {len(written)} PDFs to {destination}.")
        report = (
            f"Finished. Exported {len(written)} PDFs to:\n\n{destination}\n\n"
            + "\n".join(f"  - {name}" for name in written)
            + "\n  - Export Audit Log.txt\n\n"
            + "Temporary OCR images have been deleted.\n\n"
            + "Open the output folder now?"
        )
        if messagebox.askyesno(APP_TITLE, report):
            try:
                os.startfile(destination)
            except Exception as exc:
                messagebox.showerror(
                    APP_TITLE,
                    "The folder could not be opened.\n\n" + str(exc),
                )

    def close(self):
        self.cleanup_work_files()
        self.root.destroy()


def main():
    root = ctk.CTk()
    root.after(100, lambda: root.state("zoomed"))
    app = PacketSorterApp(root)
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()


if __name__ == "__main__":
    main()
