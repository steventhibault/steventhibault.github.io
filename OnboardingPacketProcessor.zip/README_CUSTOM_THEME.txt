CARECO CUSTOMTKINTER BLUE THEME

This version uses CustomTkinter to get closer to the Annual Training portal look:
- dark navy header
- CareCo logo placement
- white rounded cards
- blue accent buttons
- bottom-right OCR progress card
- output audit log on export

Run Start Onboarding Packet Processor.cmd. The launcher will install customtkinter if it is missing.

You do not need the .pyc / __pycache__ file.

Update: Left page list is now compact with no per-page borders, smaller status pills, #8A2020 unsorted, and #63C393 success green.

Update: Output PDFs panel is more compact and supports drag-and-drop reordering in addition to Move Up/Move Down.

Update: Output PDF rows use compact bordered rows again; drag reorder removed because Move Up/Move Down is more reliable. App opens maximized by default.

Update: Output PDF selection now previews all pages in that output using the previous/next controls above the preview.

Update: Preview panel now has a right-side vertical scrollbar and mouse-wheel scrolling for the current page. Left/right preview controls still step through pages in the selected output PDF. App opens maximized automatically.


Update: Output PDF rows now have tighter vertical spacing; order number is inline with filename.

Update: Output PDF rows now use tight label heights and show page count with the actual pages, e.g. "1 Page: 5" or "3 Pages: 1, 2, 4".
