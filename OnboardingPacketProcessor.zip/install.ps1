$ErrorActionPreference = "Stop"

$SourceDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDirectory = Join-Path $env:LOCALAPPDATA "Programs\CareCo Onboarding Packet Processor"
$Desktop = [Environment]::GetFolderPath("Desktop")
$ShortcutPath = Join-Path $Desktop "CareCo Onboarding Packet Processor.lnk"
$OldShortcutPath = Join-Path $Desktop "CareCo Onboarding Packet Sorter.lnk"

try {
    $sourceResolved = [System.IO.Path]::GetFullPath($SourceDirectory)
    $installResolved = [System.IO.Path]::GetFullPath($InstallDirectory)

    if ($sourceResolved -ne $installResolved) {
        New-Item -ItemType Directory -Path $InstallDirectory -Force | Out-Null
        Get-ChildItem -LiteralPath $SourceDirectory -Force |
            Copy-Item -Destination $InstallDirectory -Recurse -Force
    }

    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($ShortcutPath)
    $shortcut.TargetPath = Join-Path $InstallDirectory "Start Onboarding Packet Processor.cmd"
    $shortcut.WorkingDirectory = $InstallDirectory
    $shortcut.Description = "CareCo Onboarding Packet Processor"
    $shortcut.Save()
    if (Test-Path -LiteralPath $OldShortcutPath) {
        Remove-Item -LiteralPath $OldShortcutPath -Force
    }

    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show(
        "CareCo Onboarding Packet Processor was installed.`n`nA shortcut was added to the desktop. The app will now check this computer for its required components.",
        "CareCo Onboarding Packet Processor",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Information
    ) | Out-Null

    Start-Process -FilePath (Join-Path $InstallDirectory "Start Onboarding Packet Processor.cmd") -WorkingDirectory $InstallDirectory
}
catch {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show(
        "The app could not be installed.`n`n$($_.Exception.Message)",
        "CareCo Onboarding Packet Processor",
        [System.Windows.MessageBoxButton]::OK,
        [System.Windows.MessageBoxImage]::Error
    ) | Out-Null
    exit 1
}
