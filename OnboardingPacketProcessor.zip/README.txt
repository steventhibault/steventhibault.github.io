ONBOARDING PACKET PROCESSOR

START
Double-click "Start Onboarding Packet Processor.cmd".

INSTALL ON A COMPUTER
For a normal installed copy with a desktop shortcut, double-click
"Install CareCo Onboarding Packet Processor.cmd". The installer places the app
in the current Windows user's local Programs folder, creates a desktop
shortcut with the filing-cabinet program icon, and starts the normal
dependency check.

FIRST RUN ON A COMPUTER
The launcher checks for every required component before opening the app:
- Python 3.10 or newer
- Pillow, pypdf, and customtkinter
- Tesseract OCR
- Poppler PDF tools

If anything is missing, a warning lists the missing items and asks whether
you want to install them. If Windows supports automatic installation, the
launcher will attempt it. Otherwise, it opens the appropriate download pages
and asks you to rerun the launcher after installation.

WORKFLOW
1. Click Open Packet and select a PDF.
2. Wait while the pages are read.
3. Review the suggested filenames and page groupings.
4. Select one or more pages to assign or mark unsorted.
5. Arrange the Output PDFs list with Move Up and Move Down.
6. Click Export PDFs.

The original PDF filename remains visible above the page preview and in the
Windows title bar while the packet is open.

REVIEW AND SAFETY
- Review Packet shows expected documents found or missing.
- It also reports unsorted pages, low-confidence scans, suspected duplicate
  pages, pages used in multiple PDFs, blank pages, rotations, and remembered
  corrections.
- Export always displays this review before writing files.
- If the output folder already exists, the app lists which files will be
  replaced and confirms that unrelated files will remain untouched.
- After export, the app lists every created file and can open the folder.

EXPORT FOLDER
The app automatically creates a folder beside the original scanned packet.
The folder uses the packet's filename without ".pdf".

Example:
PAULA LEMIUX.pdf
PAULA LEMIUX\PAULA LEMIUX - Job Application.pdf
PAULA LEMIUX\PAULA LEMIUX - Form I-9 Employment Eligibility Verification.pdf

If the folder already exists, the app asks before replacing PDFs with the
same filenames. Other files already in the folder are left alone.

OUTPUT ORDER
The PDFs are given modification times one minute apart. The first PDF shown
in the Output PDFs list is the newest, the second is one minute older, and so
on. In Windows File Explorer, sort by "Date modified" in descending order
(newest first) to display the same order.

IMPORTANT BEHAVIOR
- A normal I-9 page is grouped with supporting documents from the official
  Form I-9 Lists A, B, and C. This includes passports, green cards, EAD cards,
  driver's licenses and government IDs, school IDs, voter cards, military and
  dependent IDs, Merchant Mariner cards, tribal documents, unrestricted Social
  Security cards, and qualifying DHS or citizenship documents.
- Ambiguous school, medical, day-care, and replacement-receipt records are
  treated as I-9 support only when they immediately follow an I-9.
- Birth certificates remain in Birth and Marriage Certificates.pdf under CareCo's filing
  convention even though certified U.S. birth certificates can be List C
  documents.
- Birth and marriage certificates are saved in Birth and Marriage Certificates.pdf.
- Interview statements are saved in Interview Statement.pdf.
- The Orientation Agenda is a separate PDF.
- The app never divides a source page. A scan containing two documents is
  left unsorted so it can be rescanned correctly.
- A banking/check page is automatically included in both Banking.pdf and
  Viventium Direct Deposit.pdf. Staff do not need to assign it twice.
- The app always asks for human review before export.
- Upside-down scans are detected, shown upright, and exported upright.
- Blank scanner pages are always removed. They cannot be assigned to or
  included in an exported PDF.
- Known multi-page forms are placed in their logical form order even when
  the scanner feeds alternating or reversed pages.
- Sparse pages receive a selective high-resolution OCR pass so small Social
  Security cards, driver's licenses, and check images can be recognized.
- Resume pages are included at the end of Job Application.pdf.
- Maine background-check payment confirmations and child-abuse confirmation
  emails are saved under their matching filenames.
- Every export includes Export Audit Log.txt with the source pages used for
  each output PDF.
- Obsolete PayPro Payroll and Skylight PayOptions forms are left unsorted.
- "Remember Correction" can save an approved manual assignment for future
  pages with the same form layout. It also saves the current Output PDFs order
  and applies that preferred order to future packets.
- Temporary OCR page images are deleted after export and whenever the app
  closes.

EDITING THE DOCUMENT LIST
The filename choices are stored in rules.json. The app also allows a custom
filename to be typed directly into the Document box.

LOCAL REQUIREMENTS
The app checks and offers installation help for its local requirements.
Packet contents are processed locally and are not sent to the internet.

PERFORMANCE
OCR and upside-down-page detection are the most time-consuming steps. The
app reads up to eight pages concurrently to reduce processing time while
retaining both orientation checks for every nonblank page. Review checks reuse
the rendered images and OCR text and do not perform another OCR pass.
